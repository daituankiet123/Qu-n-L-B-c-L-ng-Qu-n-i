<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application for file storage.
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Below you may configure as many filesystem disks as necessary, and you
    | may even configure multiple disks for the same driver. Examples for
    | most supported storage drivers are configured here for reference.
    |
    | Supported drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => storage_path('app/private'),
            'serve' => true,
            'throw' => false,
            'report' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => storage_path('app/public'),
            'url' => env('APP_URL').'/storage',
            'visibility' => 'public',
            'throw' => false,
            'report' => false,
        ],

        // Cac file mau (.docx) di kem trong code, luon co san trong moi ban
        // deploy (khong nhu storage/app - se mat khi pod restart vi khong
        // co persistent volume). Dung cho ExportTemplateVersion cua cac mau
        // chinh thuc do he thong tu cai san (vd export-templates:seed-grades-defaults),
        // KHONG dung cho file admin tu upload qua giao dien (van phai luu
        // vao 'local'/'s3' nhu cu vi khong nam trong code).
        'export_template_seeds' => [
            'driver' => 'local',
            'root' => database_path('seed-assets'),
            'serve' => false,
            'throw' => false,
            'report' => false,
        ],

        /*
        |----------------------------------------------------------------------
        | Disk S3 (Viettel Cloud Storage)
        |----------------------------------------------------------------------
        |
        | ⚠️ PHAI dung driver `viettel-s3` cua kaibatech cho endpoint nay.
        |
        | Da THU thay bang driver S3 chinh thuc cua Laravel
        | (`league/flysystem-aws-s3-v3`) ngay 18/09/2026 va THAT BAI hoan toan:
        |     exists()  -> UnableToCheckDirectoryExistence
        |     put()     -> UnableToWriteFile
        |     list()    -> UnableToListContents: Error executing "ListObjects"
        |     get()     -> tra ve noi dung KHONG khop voi file goc (md5 KHAC)
        | => Endpoint Viettel KHONG nhan chu ky/header theo cach AWS SDK gui.
        |    Driver kaibatech tu ky SigV4 thu cong theo dung dinh dang Viettel doi.
        |    => KHONG doi driver nua.
        |
        | ⚠️ Khuyet diem DA BIET cua driver nay (da kiem chung tren cluster):
        |   - listContents() luon tra []  -> backup:list / backup:monitor luon bao s3
        |                                     rong (bao dong gia), va backup:clean
        |                                     KHONG BAO GIO xoa duoc backup cu tren S3
        |                                     -> thay bang lifecycle rule tren bucket
        |   - fileSize() luon 0, lastModified() luon = hien tai
        |   - exists() LUON TRA TRUE      -> KHONG dung exists() cho disk nay.
        |                                     Muon kiem tra ton tai phai doc noi dung
        |                                     va so md5 (get + strlen > 0).
        |
        |   GHI CHU: ghi/read/xoa/put deu CHAY DUNG (da chung minh bang so md5:
        |   file backup 1,792,280 bytes tren S3 khop tung byte voi ban local).
        |
        */
        's3' => [
            'driver' => 'viettel-s3',
            'key' => env('VIETTEL_S3_KEY'),
            'secret' => env('VIETTEL_S3_SECRET'),
            'region' => env('VIETTEL_S3_REGION', 'us-east-1'),
            'bucket' => env('VIETTEL_S3_BUCKET'),
            'endpoint' => env('VIETTEL_S3_ENDPOINT'),
            'url' => env('VIETTEL_S3_URL'),
            'visibility' => 'private',
            // Driver nay bo qua `throw` (luon nuot loi). KHONG dat throw=true vi no
            // khong giup gi, chi gay hieu nham. Loi ghi S3 phai duoc phat hien bang
            // cach so md5 sau khi backup (xem docs/INCIDENT_2026-09-17.md muc 4.3).
            'throw' => false,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
