<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Shared secret cho internal API
    |--------------------------------------------------------------------------
    |
    | Dùng khi `JWT_SECRET` chưa được cấu hình (InternalApiAuth chấp nhận
    | header `X-Internal-Token`).
    |
    | Nếu `INTERNAL_API_SECRET` không được đặt, suy ra một giá trị từ `APP_KEY`.
    | Lý do: `APP_KEY` BẮT BUỘC phải có để Laravel chạy, và mọi pod trong cùng
    | cluster dùng chung `APP_KEY`. Nhờ vậy internal API vẫn hoạt động giữa các
    | service mà KHÔNG cần thêm bước cấu hình Secret — tránh tình trạng deploy
    | xong nhưng LMS/TMS gọi Grades bị 403 vì thiếu biến.
    |
    | Giá trị suy ra này KHÔNG mạnh hơn `APP_KEY`. Muốn khoá riêng thì đặt
    | `INTERNAL_API_SECRET` (xem k8s/secret.example.yaml).
    |
    */

    'internal_api_secret' => env('INTERNAL_API_SECRET')
        ?: (env('APP_KEY') ? hash_hmac('sha256', 'cdhc2-internal-api', (string) env('APP_KEY')) : null),

    // Thời gian chờ 1 internal call (giây). connectTimeout cứng 5s trong InternalClient.
    'internal_timeout' => (int) env('INTERNAL_API_TIMEOUT', 10),

    // TypeSafe (System One / Jev) - doi chieu quan nhan khi import QL Bac Luong QNCN. Key chi o server.
    'typesafe' => [
        'key' => env('TYPESAFE_API_KEY', ''),
        'url' => env('TYPESAFE_API_URL', 'https://api.typesafe.ai/v1/systemone'),
        'model' => env('TYPESAFE_MODEL', 'jev-latest'),
    ],

    'internal_urls' => [
        'core' => env('INTERNAL_CORE_URL', 'http://core-svc:8080'),
        'lms' => env('INTERNAL_LMS_URL', 'http://lms-svc:8080'),
        'tms' => env('INTERNAL_TMS_URL', 'http://tms-svc:8080'),
        'grades' => env('INTERNAL_GRADES_URL', 'http://grades-svc:8080'),
        'salary' => env('INTERNAL_SALARY_URL', 'http://salary-svc:8080'),
    ],

];
