<?php

return [

    /*
    |--------------------------------------------------------------------------
    | JWT service-to-service authentication
    |--------------------------------------------------------------------------
    |
    | Dùng cho các internal API call giữa 4 service (core / lms / tms / grades).
    |
    | secret: khoá ký HS256. BẮT BUỘC >= 32 ký tự, KHÔNG commit vào repo.
    |         Sinh bằng: openssl rand -base64 48
    |         Nạp vào cluster qua Secret `tkb-env` (xem k8s/secret.example.yaml).
    |
    | ttl:     thời hạn token (giây) — 300s là đủ cho 1 internal call.
    |
    | enforce: khi true, InternalApiAuth CHỈ chấp nhận JWT, bỏ hẳn đường fallback
    |          shared secret X-Internal-Token. Chỉ bật sau khi đã xác nhận mọi
    |          service phát hành được JWT.
    |
    | min_secret_length: chặn secret quá ngắn (HS256 yêu cầu >= 32 byte).
    |
    */

    'secret' => env('JWT_SECRET'),

    'algo' => env('JWT_ALGO', 'HS256'),

    'ttl' => (int) env('JWT_TTL', 300),

    'leeway' => (int) env('JWT_LEEWAY', 5),

    'enforce' => (bool) env('JWT_ENFORCE', false),

    'min_secret_length' => (int) env('JWT_MIN_SECRET_LENGTH', 32),

];
