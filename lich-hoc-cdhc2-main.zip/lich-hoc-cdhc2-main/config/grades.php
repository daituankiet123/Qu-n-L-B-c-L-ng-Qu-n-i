<?php

/**
 * Cấu hình nghiệp vụ Quản lý điểm / Tổng kết TN.
 * Điều chỉnh danh sách chức danh để map đúng BGH / CN PDOT.
 */
return [

    /**
     * Ban giám hiệu — phê duyệt cuối (không gồm Chủ nhiệm khoa).
     * So khớp không phân biệt hoa thường, chứa một phần tên chức danh.
     */
    'board_position_needles' => [
        'hiệu trưởng',
        'hieu truong',
        'giám đốc',
        'giam doc',
        'chính ủy',
        'chinh uy',
        'ban giám hiệu',
        'ban giam hieu',
    ],

    /** Loại trừ khỏi BGH nếu tên chức danh chứa các chuỗi này */
    'board_position_exclude' => [
        'khoa',
        'bộ môn',
        'bo mon',
    ],

    /**
     * Chủ nhiệm / lãnh đạo Phòng Đào tạo — sửa điểm, tính KQ, ghi DL (không duyệt cuối).
     */
    'pdot_director_position_needles' => [
        'trưởng phòng',
        'truong phong',
        'chủ nhiệm phòng',
        'chu nhiem phong',
        'phó trưởng phòng đào tạo',
        'pho truong phong dao tao',
    ],

    /**
     * Quyền Spatie bổ sung (nếu gán tay trên user/role):
     * - grades.approve → BGH
     * - grades.manage → CN PDOT (đã dùng sẵn)
     */
    'permission_board' => 'grades.approve',

    /**
     * Ngưỡng xếp loại khi «Tính kết quả» (điểm hệ 10, theo ĐTB Điều 14).
     */
    'result_thresholds' => [
        'gioi' => 8.0,       // >= → Giỏi
        'tot_nghiep' => 5.0, // >= → Tốt nghiệp
        // < tot_nghiep → Không TN
    ],

    /**
     * Header Excel được nhận khi import điểm (không dấu / có dấu, lower).
     * Map → grade_columns.code (kttx_1..3 / ktdk_1..3 / thi_l1 / thi_l2) hoặc student field.
     */
    'import_headers' => [
        'ma' => 'student_code',
        'mã' => 'student_code',
        'mã sv' => 'student_code',
        'mã hv' => 'student_code',
        'mssv' => 'student_code',
        'ma hv' => 'student_code',
        'ma sv' => 'student_code',
        'code' => 'student_code',
        'họ tên' => 'student_name',
        'ho ten' => 'student_name',
        'họ và tên' => 'student_name',
        'ho va ten' => 'student_name',
        'tên' => 'student_name',
        'name' => 'student_name',
        'kttx1' => 'kttx_1',
        'kttx 1' => 'kttx_1',
        'ktx1' => 'kttx_1',
        'kt thường xuyên 1' => 'kttx_1',
        'kttx2' => 'kttx_2',
        'kttx 2' => 'kttx_2',
        'kt thường xuyên 2' => 'kttx_2',
        'kttx3' => 'kttx_3',
        'kttx 3' => 'kttx_3',
        'kt thường xuyên 3' => 'kttx_3',
        'ktdk1' => 'ktdk_1',
        'ktđk1' => 'ktdk_1',
        'ktđk 1' => 'ktdk_1',
        'kt định kỳ 1' => 'ktdk_1',
        'ktdk2' => 'ktdk_2',
        'ktđk2' => 'ktdk_2',
        'ktđk 2' => 'ktdk_2',
        'kt định kỳ 2' => 'ktdk_2',
        'ktdk3' => 'ktdk_3',
        'ktđk3' => 'ktdk_3',
        'ktđk 3' => 'ktdk_3',
        'kt định kỳ 3' => 'ktdk_3',
        'thi lần 1' => 'thi_l1',
        'thi lan 1' => 'thi_l1',
        'điểm thi' => 'thi_l1',
        'diem thi' => 'thi_l1',
        'thi' => 'thi_l1',
        'thi lần 2' => 'thi_l2',
        'thi lan 2' => 'thi_l2',
        'thi lại' => 'thi_l2',
        'thi lai' => 'thi_l2',
    ],
];
