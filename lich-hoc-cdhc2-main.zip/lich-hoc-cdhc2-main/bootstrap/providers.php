<?php

use App\Providers\AppServiceProvider;
use App\Providers\CrossServiceRoutesServiceProvider;
use App\Support\ServiceTopology;
use Kaibatech\ViettelCloudS3\ViettelCloudS3ServiceProvider;
use Spatie\Permission\PermissionServiceProvider;

$shared = [
    AppServiceProvider::class,
    ViettelCloudS3ServiceProvider::class,
    PermissionServiceProvider::class,
];

$core = ServiceTopology::core();

// Module nao thuoc service nao: nguon duy nhat o App\Support\ServiceTopology
// (CrossServiceRoutesServiceProvider cung dung danh sach nay).
$services = ServiceTopology::services();

$serviceName = env('CDHC2_SERVICE', 'monolith');

if ($serviceName === 'monolith' || $serviceName === 'core') {
    return array_merge($shared, $core, ...array_values($services));
}

// Service tach le chi nap module cua minh, nen them route cua module khac (chi de
// sinh URL) - neu khong sidebar/App Grid mat link sang service khac. Dat CUOI de thu
// tu dang ky route giong monolith. Monolith/core da nap du nen khong can.
return array_merge(
    $shared,
    $core,
    $services[$serviceName] ?? [],
    [CrossServiceRoutesServiceProvider::class],
);
