<?php

use App\Http\Middleware\Authenticate;
use App\Http\Middleware\CheckMultiplePermissions;
use App\Http\Middleware\CheckPermission;
use App\Http\Middleware\CheckRole;
use App\Http\Middleware\EnforceSingleSession;
use App\Http\Middleware\InternalApiAuth;
use App\Http\Middleware\JwtServiceAuth;
use App\Http\Middleware\RecordManagerActivity;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Foundation\Http\Middleware\ValidateCsrfToken;
use Illuminate\Http\Request;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Illuminate\View\Middleware\ShareErrorsFromSession;
use Modules\Authentication\Middleware\RedirectIfAuthenticated;
use Modules\ExportTemplates\Exceptions\ActiveTemplateNotFoundException;
use Modules\Subject\Support\ImportRuntime;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        /*
         * TrustProxies — P0 điểm danh Wi‑Fi (IP client đúng sau reverse proxy / LB).
         * .env: TRUSTED_PROXIES=*  hoặc  10.0.0.1,10.0.0.2
         * Headers: X-Forwarded-For, X-Forwarded-Proto, X-Forwarded-Port, X-Forwarded-Host
         */
        $trusted = env('TRUSTED_PROXIES');
        if ($trusted !== null && trim((string) $trusted) !== '') {
            $at = trim((string) $trusted) === '*'
                ? '*'
                : array_values(array_filter(array_map('trim', explode(',', (string) $trusted))));
            $middleware->trustProxies(
                at: $at,
                headers: Request::HEADER_X_FORWARDED_FOR
                    | Request::HEADER_X_FORWARDED_HOST
                    | Request::HEADER_X_FORWARDED_PORT
                    | Request::HEADER_X_FORWARDED_PROTO
                    | Request::HEADER_X_FORWARDED_AWS_ELB
            );
        }

        $middleware->web(append: [
            SecurityHeaders::class,
            AddQueuedCookiesToResponse::class,
            StartSession::class,
            ShareErrorsFromSession::class,
            ValidateCsrfToken::class,
            SubstituteBindings::class,
            // 1 tai khoan - 1 thiet bi: phien cu bi dang xuat khi co noi khac dang nhap (truoc khi ghi hoat dong).
            EnforceSingleSession::class,
            RecordManagerActivity::class,
        ]);

        $middleware->alias([
            'auth' => Authenticate::class,
            'guest' => RedirectIfAuthenticated::class,
            'permission' => CheckPermission::class,
            'role' => CheckRole::class,
            'permission.multiple' => CheckMultiplePermissions::class,
            'internal.auth' => InternalApiAuth::class,
            'jwt.service' => JwtServiceAuth::class,
        ]);
    })
    ->withSchedule(function (Schedule $schedule): void {
        // Weekly database backup to every configured destination (local + S3).
        $schedule->command('backup:run --only-db')
            ->weekly()
            ->sundays()
            ->at('00:00')
            ->withoutOverlapping()
            ->emailOutputOnFailure(explode(',', env('BACKUP_NOTIFICATIONS_MAIL', 'hc2@cdhc2.edu.vn')));

        // Verify the newly-created S3 object by reading its exact path. Avoid
        // exists/list operations because the Viettel S3 driver cannot report them reliably.
        $schedule->command('cdhc2:verify-backup')
            ->weekly()
            ->sundays()
            ->at('00:30')
            ->withoutOverlapping()
            ->emailOutputOnFailure(explode(',', env('BACKUP_NOTIFICATIONS_MAIL', 'hc2@cdhc2.edu.vn')));

        // Clean old backups after backup creation and verification have finished.
        $schedule->command('backup:clean')
            ->weekly()
            ->sundays()
            ->at('2:00');

        // Khởi tạo/cập nhật khóa LMS theo lịch trước khi đồng bộ roster.
        $schedule->command('lms:provision-courses')
            ->dailyAt('01:10')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/lms-provision-courses.log'));

        // TMS: quét chứng chỉ sắp/đã hết hạn có chu kỳ tái đào tạo, tự giao lại khóa học.
        $schedule->command('tms:check-recertifications')
            ->dailyAt('01:30')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/tms-check-recertifications.log'));

        // TMS: quet nhiem vu qua han (assignment target + task-unit).
        $schedule->command('tms:mark-overdue')
            ->hourly()
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/tms-mark-overdue.log'));

        // Salary: moi nguoi 1 ngay den han rieng -> ai con <= 60 ngay thi dua vao dot thuong xuyen dang xet + bao nguoi duyet.
        $schedule->command('salary:auto-due')
            ->dailyAt('06:30')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/salary-auto-due.log'));

        // Salary: moi nguoi 1 ngay den han rieng -> ai con <= 60 ngay thi dua vao dot thuong xuyen dang xet + bao nguoi duyet.
        $schedule->command('salary:auto-due')
            ->dailyAt('06:30')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/salary-auto-due.log'));

        // TMS: nhac deadline 14/7/3/1 ngay truoc han + qua han (khong gui trung).
        $schedule->command('tms:notify-deadlines')
            ->dailyAt('07:00')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/tms-notify-deadlines.log'));

        // TMS: nhac deadline van ban den/di 7/3/1 ngay truoc han + qua han.
        $schedule->command('tms:notify-document-deadlines')
            ->dailyAt('07:15')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/tms-notify-document-deadlines.log'));

        // Đồng bộ roster LMS hằng ngày.
        $schedule->command('lms:sync-members --published')
            ->dailyAt('01:30')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/lms-sync-members.log'));

        // Sprint 9 T8: retention file bài nộp (hàng tháng, dry log + prune)
        $schedule->command('lms:prune-submissions --months=24')
            ->monthlyOn(1, '03:30')
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/lms-prune-submissions.log'));

        $schedule->command('app:prune-old-records --days=90')
            ->weekly()
            ->withoutOverlapping()
            ->appendOutputTo(storage_path('logs/prune-old-records.log'));
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // Sprint 8 G11: trang 403 riêng cho portal LMS
        $exceptions->render(function (HttpException $e, $request) {
            if ($e->getStatusCode() !== 403) {
                return null;
            }
            $path = ltrim($request->path(), '/');
            if (str_starts_with($path, 'lms/') || $path === 'lms') {
                return response()->view('errors.lms-403', [
                    'exception' => $e,
                ], 403);
            }

            return null;
        });

        // Trang 403/422 thân thiện dùng chung cho toàn hệ thống (trừ các
        // trang đã có xử lý riêng ở trên như LMS, và trừ request JSON/API —
        // để nguyên hành vi JSON mặc định cho những nơi đó). Luôn ghi log
        // kèm mã tra cứu ngắn để đối chiếu nhanh với storage/logs khi người
        // dùng báo lỗi.
        $exceptions->render(function (HttpException $e, $request) {
            if (! in_array($e->getStatusCode(), [403, 404, 422], true) || $request->expectsJson()) {
                return null;
            }

            $ref = strtoupper(Str::random(8));
            Log::warning("HTTP {$e->getStatusCode()} [{$ref}] {$request->method()} {$request->path()}", [
                'ref' => $ref,
                'status' => $e->getStatusCode(),
                'message' => $e->getMessage(),
                'user_id' => $request->user()?->id,
            ]);

            $titles = [
                403 => 'Không có quyền truy cập',
                404 => 'Không tìm thấy',
                422 => 'Yêu cầu không hợp lệ',
            ];
            $defaultMessages = [
                403 => 'Bạn không có quyền thực hiện thao tác này.',
                404 => 'Không tìm thấy trang hoặc dữ liệu bạn yêu cầu.',
                422 => 'Dữ liệu gửi lên không hợp lệ hoặc không khớp với quy trình hiện tại.',
            ];

            return response()->view('errors.friendly', [
                'code' => $e->getStatusCode(),
                'title' => $titles[$e->getStatusCode()],
                'message' => $e->getMessage() ?: $defaultMessages[$e->getStatusCode()],
                'ref' => $ref,
            ], $e->getStatusCode());
        });

        // Upload vượt dung lượng cho phép (413 - PostTooLargeException) trước đây
        // rơi qua hết các handler trên (không khớp 403/422) rồi bị chặn bởi điều
        // kiện "instanceof HttpExceptionInterface" ở trang 500 thân thiện cuối
        // file, nên hiển thị thẳng trang lỗi mặc định xấu, không ghi log. Thêm
        // handler riêng ở đây theo đúng khuôn trang 500 thân thiện.
        $exceptions->render(function (HttpException $e, $request) {
            if ($e->getStatusCode() !== 413 || $request->expectsJson()) {
                return null;
            }

            $ref = strtoupper(Str::random(8));
            Log::warning("HTTP 413 [{$ref}] {$request->method()} {$request->path()}", [
                'ref' => $ref,
                'content_length' => $request->header('Content-Length'),
                'user_id' => $request->user()?->id,
            ]);

            return response()->view('errors.friendly', [
                'code' => 413,
                'title' => 'File tải lên quá lớn',
                'message' => 'Dung lượng file vượt quá giới hạn cho phép của hệ thống. Vui lòng giảm dung lượng file rồi thử lại.',
                'ref' => $ref,
            ], 413);
        });

        // Import Excel luôn trả JSON có mã tra cứu. Nhờ vậy exception xảy ra ở
        // middleware/validation trước controller không còn biến thành trang 500
        // HTML mà giao diện không thể giải thích cho người dùng.
        $exceptions->render(function (Throwable $e, $request) {
            $isLessonImport = $request->is('subjects/lessons-manage/import')
                || $request->is('subjects/lessons/import');

            if (! $isLessonImport || ! $request->isMethod('POST') || ! $request->expectsJson()) {
                return null;
            }

            $importId = ImportRuntime::resolveId(
                $request->header('X-Import-ID')
            );
            $status = $e instanceof HttpExceptionInterface
                ? $e->getStatusCode()
                : ($e instanceof ValidationException ? 422 : 500);

            try {
                Log::error('Unhandled lesson import request failure.', [
                    'import_id' => $importId,
                    'path' => $request->path(),
                    'status' => $status,
                    'user_id' => $request->user()?->id,
                    'exception' => $e,
                ]);
            } catch (Throwable) {
                // Logging must never replace the JSON fallback.
            }

            $payload = [
                'success' => false,
                'message' => $status >= 500
                    ? 'Máy chủ không hoàn tất được import. Vui lòng cung cấp mã lỗi '.$importId.' cho quản trị viên.'
                    : ImportRuntime::safeExceptionMessage($e),
            ];

            if ($e instanceof ValidationException) {
                $payload['errors'] = $e->errors();
            }

            return ImportRuntime::jsonResponse(
                $payload,
                $status,
                $importId
            );
        });

        // Xuat Word/Excel theo mau (Grades/TrainingSchedule): thieu template
        // Active cho feature_key/dinh dang truoc day roi thang thanh 500 trang
        // trang khong giai thich duoc gi - chan lai o day, tra ve mot man
        // hinh/flash ro rang cho nguoi dung thay vi loi he thong.
        $exceptions->render(function (ActiveTemplateNotFoundException $e, $request) {
            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
            }

            return back()->with('error', 'Không xuất được báo cáo này (chưa có mẫu xuất hoặc mẫu xuất bị lỗi). Đã ghi lại lỗi cho quản trị viên kiểm tra.');
        });

        // Trang 500 thân thiện dùng chung — CHỈ khi APP_DEBUG=false (ở local/dev
        // vẫn muốn thấy trang lỗi chi tiết mặc định của Laravel để debug) và
        // request không phải JSON/API. Đặt cuối cùng để không nuốt mất các
        // exception cụ thể hơn đã có handler riêng ở trên.
        $exceptions->render(function (Throwable $e, $request) {
            if ($e instanceof HttpExceptionInterface || $e instanceof ValidationException) {
                return null;
            }
            if (config('app.debug') || $request->expectsJson()) {
                return null;
            }

            $ref = strtoupper(Str::random(8));
            Log::error("HTTP 500 [{$ref}] {$request->method()} {$request->path()}", [
                'ref' => $ref,
                'user_id' => $request->user()?->id,
                'exception' => $e,
            ]);

            return response()->view('errors.friendly', [
                'code' => 500,
                'title' => 'Đã xảy ra lỗi hệ thống',
                'message' => 'Máy chủ gặp sự cố khi xử lý yêu cầu này. Đã ghi lại lỗi cho quản trị viên kiểm tra.',
                'ref' => $ref,
            ], 500);
        });
    })->create();
