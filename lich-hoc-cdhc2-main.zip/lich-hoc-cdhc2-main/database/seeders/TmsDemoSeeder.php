<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Modules\Tms\Models\TmsAssignment;
use Modules\Tms\Models\TmsAssignmentTarget;
use Modules\Tms\Models\TmsCourse;
use Modules\Tms\Models\TmsExam;
use Modules\Tms\Models\TmsExamQuestion;
use Modules\Tms\Models\TmsLesson;
use Modules\Tms\Models\TmsQuestion;
use Modules\Tms\Models\TmsQuestionBank;

/**
 * Demo dữ liệu TMS (Cổng Đào tạo & Khảo thí).
 *
 * Tạo: khóa học + bài học, ngân hàng câu trắc nghiệm (mcq/true_false/short),
 * đề thi gắn khóa (có câu hỏi), ghi danh cán bộ vào khóa (tms_course_user),
 * và 1 assignment/target để học viên thấy "Thi chính thức"/"Thi thử".
 *
 * Tài khoản demo (mật khẩu: it@Cdhc2):
 *   - tms.canbo1@example.com / tms.canbo2@example.com / tms.canbo3@example.com (loại cán bộ)
 * Quản trị (có sẵn): admin@example.com / password  → để ghi danh/soạn đề.
 */
class TmsDemoSeeder extends Seeder
{
    public function run(): void
    {
        DB::transaction(function () {
            if (TmsCourse::where('title', 'like', '[Demo]%')->exists()) {
                $this->command?->warn('Đã có dữ liệu demo TMS (title bắt đầu "[Demo]"). Bỏ qua để tránh trùng — muốn chạy lại hãy xóa các bản ghi "[Demo]" trước.');

                return;
            }

            $admin = User::where('email', 'admin@example.com')->first()
                ?: User::first()
                ?: User::create(['name' => 'Admin', 'email' => 'admin@example.com', 'password' => Hash::make('password'), 'user_type' => 'internal_user']);

            // ── Cán bộ demo ──────────────────────────────────────────────
            $demoUsers = collect();
            foreach ([
                ['email' => 'tms.canbo1@example.com', 'name' => 'Cán bộ demo 1 (Hậu cần)'],
                ['email' => 'tms.canbo2@example.com', 'name' => 'Cán bộ demo 2 (Tài chính)'],
                ['email' => 'tms.canbo3@example.com', 'name' => 'Cán bộ demo 3 (Đào tạo)'],
            ] as $u) {
                $user = User::firstOrCreate(
                    ['email' => $u['email']],
                    ['name' => $u['name'], 'password' => Hash::make('it@Cdhc2'), 'user_type' => 'internal_user']
                );
                $demoUsers->push($user);
            }

            // ── Khóa học + bài học ───────────────────────────────────────
            $course = TmsCourse::create([
                'title' => '[Demo] An toàn thông tin cơ bản',
                'description' => "Khóa học demo cho cán bộ (TMS).\nNội dung: nhận diện nguy cơ mạng, mật khẩu mạnh, phòng chống phishing.\nĐề thi trắc nghiệm cuối khóa đi kèm — có chế độ 'Thi thử' để luyện tập trước khi thi chính thức.",
                'category' => 'An toàn thông tin',
                'is_active' => true,
                'created_by' => $admin->id,
            ]);
            foreach ([
                'Bài 1 — Giới thiệu an toàn thông tin',
                'Bài 2 — Mật khẩu & xác thực hai lớp',
                'Bài 3 — Nhận diện email lừa đảo (phishing)',
            ] as $i => $lesson) {
                TmsLesson::create([
                    'course_id' => $course->id,
                    'title' => $lesson,
                    'content' => 'Nội dung tóm tắt bài demo số '.($i + 1).' — dùng để kiểm thử giao diện khóa học TMS.',
                    'sort_order' => $i,
                    'is_published' => true,
                ]);
            }

            // ── Ngân hàng câu hỏi + câu trắc nghiệm ──────────────────────
            $bank = TmsQuestionBank::create(['title' => '[Demo] Ngân hàng trắc nghiệm An toàn thông tin', 'created_by' => $admin->id]);
            $qs = [];
            $qs[] = TmsQuestion::create(['bank_id' => $bank->id, 'type' => 'mcq', 'stem' => 'Loại mã độc nào thường mã hóa dữ liệu rồi đòi tiền chuộc?', 'options' => ['Virus', 'Trojan', 'Ransomware', 'Spyware'], 'correct_answer' => 'Ransomware', 'points' => 1, 'difficulty' => 'medium']);
            $qs[] = TmsQuestion::create(['bank_id' => $bank->id, 'type' => 'mcq', 'stem' => 'Giao thức nào bảo mật dữ liệu khi truy cập website?', 'options' => ['FTP', 'HTTP', 'HTTPS', 'SMTP'], 'correct_answer' => 'HTTPS', 'points' => 1, 'difficulty' => 'easy']);
            $qs[] = TmsQuestion::create(['bank_id' => $bank->id, 'type' => 'mcq', 'stem' => 'Yếu tố quan trọng nhất tạo nên mật khẩu mạnh là gì?', 'options' => ['Độ dài & phức tạp', 'Ngày sinh', 'Số điện thoại', 'Tên đăng nhập'], 'correct_answer' => 'Độ dài & phức tạp', 'points' => 1, 'difficulty' => 'easy']);
            $qs[] = TmsQuestion::create(['bank_id' => $bank->id, 'type' => 'true_false', 'stem' => 'Bật tường lửa giúp giảm rủi ro tấn công mạng.', 'options' => ['Đúng', 'Sai'], 'correct_answer' => 'Đúng', 'points' => 1, 'difficulty' => 'easy']);
            $qs[] = TmsQuestion::create(['bank_id' => $bank->id, 'type' => 'mcq', 'stem' => 'Khi nhận email lạ có đường dẫn, hành động nào KHÔNG nên làm?', 'options' => ['Mở đường dẫn', 'Quét virus file đính kèm', 'Báo bộ phận IT', 'Xóa email'], 'correct_answer' => 'Mở đường dẫn', 'points' => 1, 'difficulty' => 'hard']);
            $qs[] = TmsQuestion::create(['bank_id' => $bank->id, 'type' => 'short', 'stem' => 'Nhập tên viết tắt thường dùng của xác thực hai lớp.', 'options' => null, 'correct_answer' => '2FA', 'points' => 1, 'difficulty' => 'medium']);

            // ── Đề thi gắn khóa (câu hỏi tĩnh từ ngân hàng) ───────────────
            $exam = TmsExam::create([
                'course_id' => $course->id,
                'title' => '[Demo] Thi trắc nghiệm An toàn thông tin',
                'duration_minutes' => 20,
                'pass_score' => 5,
                'max_attempts' => 3,
                'shuffle_questions' => false,
                'shuffle_options' => false,
                'allow_review_answers' => true,
                'proctor_basic' => true,
                'require_fullscreen' => true,
                'max_blur_events' => 3,
                'opens_at' => now()->subHour(),
                'closes_at' => now()->addDays(14),
                'created_by' => $admin->id,
            ]);
            foreach ($qs as $idx => $q) {
                TmsExamQuestion::create(['exam_id' => $exam->id, 'question_id' => $q->id, 'sort_order' => $idx]);
            }

            // ── Ghi danh cán bộ vào khóa (tms_course_user) ────────────────
            $course->enrolledUsers()->sync($demoUsers->pluck('id')->all());

            // ── Assignment + target cho cán bộ 1 (hiện "Thi chính thức") ──
            $assignment = TmsAssignment::create([
                'assignable_type' => TmsExam::class,
                'assignable_id' => $exam->id,
                'title' => 'Thi trắc nghiệm An toàn thông tin (cuối khóa)',
                'audience_type' => 'user',
                'audience_ref_id' => $demoUsers[0]->id,
                'due_at' => now()->addDays(7),
                'min_score' => 5,
                'require_retake_on_fail' => true,
                'created_by' => $admin->id,
            ]);
            TmsAssignmentTarget::create([
                'assignment_id' => $assignment->id,
                'user_id' => $demoUsers[0]->id,
                'status' => 'pending',
            ]);

            $this->command?->info('Đã tạo demo TMS:');
            $this->command?->info('  Khóa học: '.$course->title.' (id '.$course->id.') — đã ghi danh '.$demoUsers->count().' cán bộ');
            $this->command?->info('  Đề thi: '.$exam->title.' (id '.$exam->id.') — '.count($qs).' câu hỏi');
            $this->command?->info('  Cán bộ demo (pass: it@Cdhc2): tms.canbo1@example.com, tms.canbo2@example.com, tms.canbo3@example.com');
            $this->command?->info('  Quản trị (có sẵn): admin@example.com / password');
        });
    }
}
