<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Modules\LeaveManagement\Models\LeaveLocality;

/**
 * Nạp danh mục hành chính 2 cấp (Tỉnh/Thành phố -> Xã/Phường) áp dụng từ 01/07/2025.
 * Nguồn: https://github.com/zuydd/vn-geo (34 tỉnh/thành, 3320 xã/phường).
 */
class LeaveLocalitySeeder extends Seeder
{
    public function run(): void
    {
        $dataPath = database_path('data/vn-localities');
        $provinces = json_decode(file_get_contents($dataPath.'/provinces.json'), true);
        $wards = json_decode(file_get_contents($dataPath.'/wards.json'), true);

        DB::transaction(function () use ($provinces, $wards) {
            LeaveLocality::query()->delete();

            $now = now();
            $provinceIdByCode = [];
            foreach ($provinces as $p) {
                $provinceIdByCode[$p['code']] = DB::table('leave_localities')->insertGetId([
                    'name' => $p['name'],
                    'level' => 'PROVINCE',
                    'parent_id' => null,
                    'code' => $p['code'],
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }

            $chunk = [];
            foreach ($wards as $w) {
                $parentId = $provinceIdByCode[$w['provinceCode']] ?? null;
                if (! $parentId) {
                    continue;
                }
                $chunk[] = [
                    'name' => $w['name'],
                    'level' => 'WARD',
                    'parent_id' => $parentId,
                    'code' => $w['code'],
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
                if (count($chunk) >= 500) {
                    DB::table('leave_localities')->insert($chunk);
                    $chunk = [];
                }
            }
            if ($chunk) {
                DB::table('leave_localities')->insert($chunk);
            }
        });

        $this->command?->info('Đã nạp '.LeaveLocality::whereNull('parent_id')->count().' tỉnh/thành và '.LeaveLocality::whereNotNull('parent_id')->count().' xã/phường.');
    }
}
