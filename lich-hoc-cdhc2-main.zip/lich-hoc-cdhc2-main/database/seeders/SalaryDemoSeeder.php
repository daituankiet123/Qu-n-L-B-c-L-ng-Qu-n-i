<?php

namespace Database\Seeders;

use App\Models\MilitaryRank;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Modules\Salary\Domain\RaiseType;
use Modules\Salary\Domain\RankMap;
use Modules\Salary\Import\AccessImporter;
use Modules\Salary\Models\SalaryDecisionSetting;
use Modules\Salary\Models\SalaryHistory;
use Modules\Salary\Models\SalaryProfile;
use Modules\Salary\Models\SalaryRound;
use Modules\Salary\Models\SalaryRuleSetting;
use Modules\Salary\Models\SalaryScale;
use Modules\Salary\Services\RoundApplier;
use Modules\Salary\Services\RoundService;
use Modules\Unit\Models\Unit;

/**
 * Du lieu THU cho QL Bac Luong QNCN (chi dung o may dev / staging, KHONG chay tren prod):
 *   php artisan db:seed --class=SalaryDemoSeeder
 * Bang luong that cua Access (docs/salary/access-spec/bang-luong.tsv, TC7/10 = 5,3) + 10 quan nhan QNCN gia
 * (email salary.demoN@example.test) + 3 dot: 1 da ap dung, 1 dang xet (nhap), 1 da de nghi.
 */
class SalaryDemoSeeder extends Seeder
{
    private const PEOPLE = [
        // ten, (cap bac lay theo bac luong), ma bac, nhan tu, TNVK
        ['Phạm Minh Tuấn', '2/CN', 'SC4/10', '2024-07-01', 0],
        ['Lê Thị Hồng', '2/CN', 'SC5/10', '2024-03-01', 0],
        ['Trần Quốc Bảo', '1/CN', 'SC2/10', '2024-05-01', 0],
        ['Vũ Đức Anh', '3/CN', 'TC5/10', '2023-01-01', 0],
        ['Hoàng Văn Long', '3/CN', 'TC6/10', '2022-06-01', 0],
        ['Đặng Thu Trang', '2/CN', 'SC3/10', '2025-07-01', 0],
        ['Ngô Thanh Sơn', '3//CN', 'TC10/10', '2025-02-01', 6],
        ['Bùi Thị Mai', '1/CN', 'SC1/10', '2024-09-01', 0],
        ['Đỗ Mạnh Hùng', '2/CN', 'SC6/10', '2023-11-01', 0],
        ['Nguyễn Thị Lan', '3/CN', 'TC4/10', '2024-01-01', 0],
    ];

    public function run(): void
    {
        $this->scales();
        // Can cu, ten QD, don vi, dia danh... = DUNG gia tri bang `Lam viec` cua Access (docs/salary/access-spec/lam-viec-defaults.json);
        // ten nguoi ky la ten gia.
        $lamViec = json_decode((string) file_get_contents(base_path('docs/salary/access-spec/lam-viec-defaults.json')), true)
            + ['NguoikyQD_NBL' => 'Nguyễn Văn Ký', 'Nguoi_Ky' => 'Đại tá Lê Văn Mẫu', 'Nguoi_BC' => 'Thiếu tá CN Phạm Văn Thử'];
        foreach (AccessImporter::decisionSettingRows($lamViec) as $type => $row) {
            SalaryDecisionSetting::query()->updateOrCreate(['raise_type' => $type], $row);
        }
        SalaryRuleSetting::query()->firstOrNew()->fill(AccessImporter::orgSettingRow($lamViec))->save();

        $units = Unit::query()->limit(3)->pluck('id')->all();
        $users = [];
        foreach (self::PEOPLE as $i => [$name, , $scale, $received, $tnvk]) {
            $s = SalaryScale::query()->where('code', $scale)->firstOrFail();
            $user = User::query()->updateOrCreate(['email' => 'salary.demo'.($i + 1).'@example.test'], [
                'name' => $name, 'password' => Hash::make('it@Cdhc2'), 'status' => 1, 'user_type' => 'internal_user',
                'military_rank_id' => MilitaryRank::query()->where('code', RankMap::toCore((string) $s->military_rank_code))->value('id'),
                'unit_id' => $units ? $units[$i % count($units)] : null,
            ]);
            SalaryProfile::query()->updateOrCreate(['user_id' => $user->id], [
                'scale_code' => $scale, 'received_at' => $received, 'seniority_percent' => $tnvk,
                'birth_date' => (1985 + $i).'-0'.(1 + $i % 9).'-15', 'enlistment_date' => (2005 + $i).'-09-01',
                'education_level' => $i % 2 ? 'Cao đẳng' : 'Đại học', 'last_raise_type' => 'regular',
                'position_title' => ['Giảng viên', 'NV Tài chính', 'NV Quân lực', 'Trợ lý', 'NV Kỹ thuật'][$i % 5],
            ]);
            SalaryHistory::query()->updateOrCreate(['user_id' => $user->id, 'received_at' => $received, 'raise_type' => 'regular'], [
                'scale_code' => $scale, 'grade' => $s->grade, 'group' => $s->group, 'step' => $s->step, 'coefficient' => $s->coefficient,
                'military_rank_code' => $s->military_rank_code, 'seniority_percent' => $tnvk,
                'decision_no' => (40 + $i).'/QĐ-CĐHC2', 'signed_at' => $received, 'signer' => 'Người ký (thử)',
            ]);
            $users[] = $user;
        }

        if (SalaryRound::query()->exists()) {
            return;
        }
        $rounds = app(RoundService::class);

        // Dot 1: thuong xuyen 2025 - da ap dung
        $applied = $rounds->open(RaiseType::Regular, 2025, today: now()->setDate(2025, 9, 1)->toImmutable());
        if ($applied->items()->exists()) {
            $applied->items()->update(['approved' => true, 'selected' => true]);
            $rounds->propose($applied->fresh());
            $rounds->decide($applied->fresh(), ['decision_no' => '88/QĐ-CĐHC2', 'signed_at' => '2025-09-20', 'signer' => 'Người ký (thử)', 'signer_title' => 'Hiệu trưởng']);
            app(RoundApplier::class)->apply($applied->fresh());
        }

        // Dot 2: thuong xuyen 2026 - dang xet, duyet 1 phan
        $draft = $rounds->open(RaiseType::Regular, 2026);
        $draft->items()->orderBy('id')->limit(2)->update(['approved' => true, 'selected' => true]);

        // Dot 3: nang truoc han 2026 - da de nghi
        $early = $rounds->open(RaiseType::Early, 2026);
        $rounds->addPerson($early, $users[5]->id, ['reason' => 'Chiến sĩ thi đua cơ sở 2 năm liền', 'new_received_at' => '2026-10-01']);
        $early->items()->update(['approved' => true, 'selected' => true]);
        $rounds->propose($early->fresh());
    }

    private function scales(): void
    {
        $lines = file(base_path('docs/salary/access-spec/bang-luong.tsv'), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $header = str_getcsv(ltrim(array_shift($lines), "\u{FEFF}"), "\t", '"', '');
        foreach ($lines as $line) {
            $r = array_combine($header, str_getcsv($line, "\t", '"', ''));
            $fix = $r['Maso_Luong'] === 'TC7/10';
            SalaryScale::query()->updateOrCreate(['code' => $r['Maso_Luong'], 'effective_from' => '2020-01-01'], [
                'grade' => $r['KyhieuLoai'], 'group' => $r['Nhom'] === '' ? null : $r['Nhom'],
                'step' => $fix ? '7/10' : $r['Bac'], 'coefficient' => $fix ? 5.3 : (float) $r['Heso'],
                'military_rank_code' => $r['KyhieuQH'],
            ]);
        }
    }
}
