<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * NOTE: This seeder is ONLY for development/testing.
     * In PRODUCTION, use: php artisan permissions:sync
     */
    public function run(): void
    {
        $this->command->info('🔐 Setting up permissions and roles...');
        $this->command->warn('⚠️  This seeder calls the permissions:sync command.');
        $this->command->warn('⚠️  For production, run: php artisan permissions:sync directly');

        // QUAN TRONG: KHONG duoc truyen --reset o day. Seeder nay chay tu dong
        // qua db:seed --force moi khi RUN_SEEDERS=true trong pipeline deploy
        // (docker/entrypoint.sh) - --reset se XOA SACH toan bo bang permissions
        // va roles (ke ca cac role tu tao khong nam trong RoleCatalog, vd
        // "PDOT", "super") roi build lai TU DAU chi theo danh sach cung trong
        // code, lam mat vinh vien nhung role/quyen do admin tu tao qua giao
        // dien. Goi khong co --reset se dung dung hanh vi "cong them, khong
        // xoa" cua permissions:sync (xem SyncPermissionsAndRoles::assignPermissionsToRoles).
        \Illuminate\Support\Facades\Artisan::call('permissions:sync');

        $this->command->info('✓ Permissions and roles setup completed!');
    }
}
