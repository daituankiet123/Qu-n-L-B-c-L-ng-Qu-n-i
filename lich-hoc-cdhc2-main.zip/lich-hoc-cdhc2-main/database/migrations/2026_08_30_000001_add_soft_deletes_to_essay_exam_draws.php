<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'lms';

    public function up(): void
    {
        if (! Schema::hasColumn('essay_exam_draws', 'deleted_at')) {
            Schema::table('essay_exam_draws', fn (Blueprint $table) => $table->softDeletes());
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('essay_exam_draws', 'deleted_at')) {
            Schema::table('essay_exam_draws', fn (Blueprint $table) => $table->dropSoftDeletes());
        }
    }
};
