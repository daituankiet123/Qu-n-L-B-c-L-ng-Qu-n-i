<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'lms';

    public function up(): void
    {
        Schema::table('lms_exam_attempts', function (Blueprint $table) {
            $table->boolean('is_trial')->default(false)->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('lms_exam_attempts', function (Blueprint $table) {
            $table->dropColumn('is_trial');
        });
    }
};
