<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Truong con thieu de in DUNG mau report Access (bang `Lam viec` id=2 + o tren form de nghi):
 * - don vi bao cao / trich sao: DV_Tren, DV_BC, Dia_Danh, KyhieuVB, CD_NguoiBC, Nguoi_BC, CD_NguoiKy, Nguoi_Ky, Noi_nhan
 * - chuc vu quan nhan (Chucvu) va ngay trich sao (Cmbngaysao/thang/nam).
 */
return new class extends Migration
{
    protected $connection = 'salary';

    public function up(): void
    {
        Schema::connection('salary')->table('salary_rule_settings', function (Blueprint $table) {
            $table->string('org_parent', 255)->nullable()->after('seniority_yearly_from');      // DV_Tren
            $table->string('org_name', 255)->nullable()->after('org_parent');                   // DV_BC
            $table->string('org_place', 100)->nullable()->after('org_name');                    // Dia_Danh
            $table->string('doc_code', 50)->nullable()->after('org_place');                     // KyhieuVB
            $table->string('report_signer_title', 255)->nullable()->after('doc_code');          // CD_NguoiBC
            $table->string('report_signer', 255)->nullable()->after('report_signer_title');     // Nguoi_BC
            $table->string('approver_title', 255)->nullable()->after('report_signer');          // CD_NguoiKy
            $table->string('approver', 255)->nullable()->after('approver_title');               // Nguoi_Ky
            $table->text('list_recipients')->nullable()->after('approver');                     // Noi_nhan
        });

        Schema::connection('salary')->table('salary_profiles', function (Blueprint $table) {
            $table->string('position_title', 255)->nullable()->after('enlistment_date');        // Chucvu
        });

        Schema::connection('salary')->table('salary_decisions', function (Blueprint $table) {
            $table->date('copy_signed_at')->nullable()->after('copy_no');                        // ngay trich sao
        });
    }

    public function down(): void
    {
        Schema::connection('salary')->table('salary_decisions', fn (Blueprint $t) => $t->dropColumn('copy_signed_at'));
        Schema::connection('salary')->table('salary_profiles', fn (Blueprint $t) => $t->dropColumn('position_title'));
        Schema::connection('salary')->table('salary_rule_settings', fn (Blueprint $t) => $t->dropColumn([
            'org_parent', 'org_name', 'org_place', 'doc_code', 'report_signer_title', 'report_signer', 'approver_title', 'approver', 'list_recipients',
        ]));
    }
};
