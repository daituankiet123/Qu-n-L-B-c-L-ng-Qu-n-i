<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Clone co che duyet NHCH tu modules/Lms (lms_question_banks) sang TMS -
 * cung workflow DRAFT -> PENDING_DEPT -> PENDING_EXAM_OFFICE -> PENDING_BGH
 * -> APPROVED/RETURNED, dong bo voi essay-exams va LMS de nguoi dung dung
 * mot quy trinh duyet duy nhat trong toan he thong.
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('tms_question_banks', function (Blueprint $table) {
            $table->string('status', 30)->default('DRAFT')->index()->after('created_by');
            $table->timestamp('submitted_at')->nullable()->after('status');
            $table->timestamp('approved_at')->nullable()->after('submitted_at');
            $table->foreignId('approved_by')->nullable()->after('approved_at')->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->text('return_note')->nullable()->after('approved_by');
        });
    }

    public function down(): void
    {
        Schema::table('tms_question_banks', function (Blueprint $table) {
            $table->dropConstrainedForeignId('approved_by');
            $table->dropColumn(['status', 'submitted_at', 'approved_at', 'return_note']);
        });
    }
};
