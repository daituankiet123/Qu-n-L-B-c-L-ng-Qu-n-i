<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        if (! Schema::hasColumn('tms_questions', 'lesson_id')) {
            Schema::table('tms_questions', function (Blueprint $table) {
                $table->foreignId('lesson_id')->nullable()->after('bank_id')->constrained('tms_lessons')->nullOnDelete();
                $table->index(['lesson_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::table('tms_questions', function (Blueprint $table) {
            $table->dropForeign(['lesson_id']);
            $table->dropColumn('lesson_id');
        });
    }
};
