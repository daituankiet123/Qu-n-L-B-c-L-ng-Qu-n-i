<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Điểm TMS chuyển hẳn sang thang 10.
 *
 * Trước đây GradingService chấm theo thang 100 (điểm % đúng), còn giao diện
 * chia 10 để hiển thị "/10" — vừa lệch giữa nơi lưu và nơi hiển thị, vừa dễ
 * so sánh sai với pass_score/min_score nhập theo thang 10. Migration này quy
 * toàn bộ dữ liệu cũ về thang 10 và hạ mặc định của tms_exams.pass_score.
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        // Điểm đỗ mặc định 50 (thang 100) -> 5 (thang 10).
        if (Schema::hasTable('tms_exams')) {
            Schema::table('tms_exams', function (Blueprint $table) {
                $table->unsignedTinyInteger('pass_score')->default(5)->change();
            });
        }

        // Dữ liệu cũ: chỉ quy đổi những dòng còn mang thang 100 (> 10) để
        // migration chạy lại trên DB đã chuyển vẫn không làm sai điểm.
        $this->rescale('tms_exams', 'pass_score');
        $this->rescale('tms_assignments', 'min_score');
        $this->rescale('tms_tasks', 'min_score');
        $this->rescale('tms_exam_attempts', 'score');
        $this->rescale('tms_assignment_targets', 'score');
    }

    public function down(): void
    {
        if (Schema::hasTable('tms_exams')) {
            Schema::table('tms_exams', function (Blueprint $table) {
                $table->unsignedTinyInteger('pass_score')->default(50)->change();
            });
        }

        $tables = [
            ['tms_exams', 'pass_score'],
            ['tms_assignments', 'min_score'],
            ['tms_tasks', 'min_score'],
            ['tms_exam_attempts', 'score'],
            ['tms_assignment_targets', 'score'],
        ];

        foreach ($tables as [$table, $column]) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, $column)) {
                continue;
            }

            DB::table($table)
                ->whereNotNull($column)
                ->update([$column => DB::raw("ROUND(`{$column}` * 10, 2)")]);
        }
    }

    private function rescale(string $table, string $column): void
    {
        if (! Schema::hasTable($table) || ! Schema::hasColumn($table, $column)) {
            return;
        }

        DB::table($table)
            ->whereNotNull($column)
            ->where($column, '>', 10)
            ->update([$column => DB::raw("ROUND(`{$column}` / 10, 2)")]);
    }
};
