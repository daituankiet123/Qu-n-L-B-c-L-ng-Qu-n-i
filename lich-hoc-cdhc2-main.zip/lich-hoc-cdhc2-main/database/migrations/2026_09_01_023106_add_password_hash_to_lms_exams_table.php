<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'lms';

    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('lms_exams', function (Blueprint $table) {
            $table->string('password_hash')->nullable()->after('publish_score_after_submit');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('lms_exams', function (Blueprint $table) {
            $table->dropColumn('password_hash');
        });
    }
};
