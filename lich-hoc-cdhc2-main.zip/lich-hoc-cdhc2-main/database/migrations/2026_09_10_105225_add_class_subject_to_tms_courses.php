<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Khóa TMS vốn là đào tạo nội bộ cho cán bộ nên không gắn lớp/môn nào.
 * Nhưng có khóa TMS thực sự dạy cho học viên theo lớp — những khóa đó cần
 * gắn lớp + môn để điểm thi đổ được sang Quản lý điểm như bên LMS.
 *
 * Để nullable: khóa đào tạo nội bộ thuần vẫn dùng bình thường, không gắn gì.
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('tms_courses', function (Blueprint $table) {
            $table->foreignId('class_id')->nullable()->after('category')->constrained(DbRef::forMigration('classes'))->nullOnDelete();
            $table->foreignId('subject_id')->nullable()->after('class_id')->constrained(DbRef::forMigration('subjects'))->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('tms_courses', function (Blueprint $table) {
            $table->dropConstrainedForeignId('subject_id');
            $table->dropConstrainedForeignId('class_id');
        });
    }
};
