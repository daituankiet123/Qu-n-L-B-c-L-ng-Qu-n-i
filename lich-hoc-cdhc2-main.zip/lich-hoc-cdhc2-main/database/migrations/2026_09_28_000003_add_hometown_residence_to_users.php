<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Que quan va tru quan cua nguoi dung theo dia gioi 2 cap (Tinh/Thanh pho -> Xa/Phuong, ap dung tu 01/07/2025).
 * Luu MA (nguon database/data/vn-localities) - ten tra qua App\Support\VnLocalities. Dung chung moi phan he
 * (vd salary in cot "Noi thuong tru" nhu Access QLNL).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('hometown_province_code', 4)->nullable();
            $table->string('hometown_ward_code', 8)->nullable();
            $table->string('residence_province_code', 4)->nullable();
            $table->string('residence_ward_code', 8)->nullable();
            $table->string('residence_address', 255)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['hometown_province_code', 'hometown_ward_code', 'residence_province_code', 'residence_ward_code', 'residence_address']);
        });
    }
};
