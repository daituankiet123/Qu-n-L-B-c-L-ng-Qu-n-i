<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        $coreDatabase = DbRef::databaseFor('mysql');
        $tmsDatabase = DB::connection('tms')->getDatabaseName();
        $corePrefix = $coreDatabase === $tmsDatabase ? '' : $coreDatabase.'.';

        $rows = DB::connection('tms')->table('leave_personnel as lp')
            ->leftJoin($corePrefix.'users as u', 'u.id', '=', 'lp.user_id')
            ->leftJoin($corePrefix.'standard_positions as p', 'p.id', '=', 'u.position_id')
            ->where('lp.active', true)
            ->whereNotNull('lp.user_id')
            ->select('lp.id', 'u.position_id', 'p.name')
            ->get();

        foreach ($rows as $row) {
            DB::connection('tms')->table('leave_personnel')->where('id', $row->id)->update([
                'position_id' => $row->position_id,
                'position' => $row->name,
            ]);
        }
    }

    public function down(): void
    {
        // The previous free-text values cannot be restored reliably.
    }
};
