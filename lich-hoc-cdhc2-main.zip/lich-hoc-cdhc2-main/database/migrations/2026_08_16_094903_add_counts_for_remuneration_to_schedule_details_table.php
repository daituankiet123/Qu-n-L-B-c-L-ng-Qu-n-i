<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('schedule_details', function (Blueprint $table) {
            $table->boolean('counts_for_remuneration')->default(true)
                ->after('standard_hours_conversion_category_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('schedule_details', function (Blueprint $table) {
            $table->dropColumn('counts_for_remuneration');
        });
    }
};
