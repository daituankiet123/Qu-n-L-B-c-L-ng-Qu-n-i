<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        // 1. Expand tms_documents with missing fields
        Schema::table('tms_documents', function (Blueprint $table) {
            // Expand status enum
            DB::statement("ALTER TABLE tms_documents MODIFY COLUMN status ENUM('open','processing','done','rejected','returned') DEFAULT 'open'");
        });

        Schema::table('tms_documents', function (Blueprint $table) {
            $table->string('document_code')->nullable()->after('doc_number');
            $table->text('summary')->nullable()->after('subject');
            $table->date('doc_issued_date')->nullable()->after('doc_date');
            $table->string('urgency')->nullable()->after('file_path');
            $table->string('classification')->nullable()->after('urgency');
            $table->string('sender_agency')->nullable()->after('classification');
            $table->foreignId('receiving_unit_id')->nullable()->after('sender_agency')->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $table->foreignId('handler_id')->nullable()->after('receiving_unit_id')->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->date('deadline')->nullable()->after('handler_id');
            $table->text('director_comment')->nullable()->after('deadline');
            // Outgoing-specific fields
            $table->string('draft_number')->nullable()->after('director_comment');
            $table->foreignId('author_id')->nullable()->after('draft_number')->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->foreignId('drafting_unit_id')->nullable()->after('author_id')->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $table->foreignId('reviewer_id')->nullable()->after('drafting_unit_id')->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->foreignId('signer_id')->nullable()->after('reviewer_id')->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->date('signing_date')->nullable()->after('signer_id');
            $table->date('release_date')->nullable()->after('signing_date');
            $table->foreignId('recipient_unit_id')->nullable()->after('release_date')->constrained(DbRef::forMigration('units'))->nullOnDelete();
        });

        // 2. Expand tms_document_steps
        Schema::table('tms_document_steps', function (Blueprint $table) {
            DB::statement("ALTER TABLE tms_document_steps MODIFY COLUMN status ENUM('pending','done','rejected','returned') DEFAULT 'pending'");
        });

        Schema::table('tms_document_steps', function (Blueprint $table) {
            $table->string('action_type')->nullable()->after('action');
            $table->date('deadline')->nullable()->after('note');
        });

        // 3. Create audit log table
        Schema::create('tms_document_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('document_id')->constrained('tms_documents')->cascadeOnDelete();
            $table->string('action');
            $table->foreignId('actor_id')->constrained(DbRef::forMigration('users'));
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->text('reason')->nullable();
            $table->string('ip_address')->nullable();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_document_logs');

        Schema::table('tms_document_steps', function (Blueprint $table) {
            $table->dropColumn(['action_type', 'deadline']);
            DB::statement("ALTER TABLE tms_document_steps MODIFY COLUMN status ENUM('pending','done') DEFAULT 'pending'");
        });

        Schema::table('tms_documents', function (Blueprint $table) {
            $table->dropConstrainedForeignId('receiving_unit_id');
            $table->dropConstrainedForeignId('handler_id');
            $table->dropConstrainedForeignId('author_id');
            $table->dropConstrainedForeignId('drafting_unit_id');
            $table->dropConstrainedForeignId('reviewer_id');
            $table->dropConstrainedForeignId('signer_id');
            $table->dropConstrainedForeignId('recipient_unit_id');
            $table->dropColumn([
                'document_code', 'summary', 'doc_issued_date', 'urgency', 'classification',
                'sender_agency', 'deadline', 'director_comment',
                'draft_number', 'signing_date', 'release_date',
            ]);
            DB::statement("ALTER TABLE tms_documents MODIFY COLUMN status ENUM('open','processing','done') DEFAULT 'open'");
        });
    }
};
