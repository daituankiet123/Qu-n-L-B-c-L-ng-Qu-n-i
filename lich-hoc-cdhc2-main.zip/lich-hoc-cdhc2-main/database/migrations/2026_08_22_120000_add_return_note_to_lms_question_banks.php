<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Bo sung cot con thieu de hoan thien workflow duyet NHCH (status/submitted_at/
 * approved_at/approved_by da co tu migration 2026_08_20_000002) - can them
 * return_note de Khoa/Khao thi/BGH tra lai kem ly do, dong bo voi EssayExam.
 */
return new class extends Migration
{
    protected $connection = 'lms';

    public function up(): void
    {
        Schema::table('lms_question_banks', function (Blueprint $table) {
            if (! Schema::hasColumn('lms_question_banks', 'return_note')) {
                $table->text('return_note')->nullable()->after('approved_by');
            }
        });
    }

    public function down(): void
    {
        Schema::table('lms_question_banks', function (Blueprint $table) {
            if (Schema::hasColumn('lms_question_banks', 'return_note')) {
                $table->dropColumn('return_note');
            }
        });
    }
};
