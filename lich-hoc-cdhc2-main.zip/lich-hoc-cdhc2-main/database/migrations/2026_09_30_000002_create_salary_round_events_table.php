<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Nhat ky thao tac tren dot nang luong: ai lap / duyet / de nghi / ra QD / tra ve / ap dung / xoa, luc nao. */
return new class extends Migration
{
    protected $connection = 'salary';

    public function up(): void
    {
        Schema::connection('salary')->create('salary_round_events', function (Blueprint $table) {
            $table->id();
            // Khong FK: dot xoa mem, nhat ky phai con de tra cuu.
            $table->unsignedBigInteger('round_id')->index();
            $table->string('action', 40);
            $table->unsignedBigInteger('actor_id')->nullable(); // users.id (core) - khac DB, khong FK
            $table->text('note')->nullable();
            $table->json('meta')->nullable();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::connection('salary')->dropIfExists('salary_round_events');
    }
};
