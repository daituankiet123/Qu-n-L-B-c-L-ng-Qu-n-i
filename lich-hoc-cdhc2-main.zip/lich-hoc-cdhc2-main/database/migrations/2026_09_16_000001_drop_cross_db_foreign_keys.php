<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Bỏ khoá ngoại liên database trên `grade_books`.
 *
 * `grade_books` thuộc service Grades, nhưng `tms_course_id` trỏ `tms_courses`
 * (TMS) và `lms_course_id` trỏ `lms_courses` (LMS). MySQL không cho FK vượt
 * database, nên sau khi tách DB (Gate D) hai FK này buộc phải bỏ.
 *
 * ⚠️ Migration PHẢI idempotent: `k8s/core/deployment.yaml` có initContainer
 * `migrate` với RUN_MIGRATIONS=true, tức `php artisan migrate --force` chạy lại
 * mỗi lần rollout. Nếu FK đã bị bỏ từ trước mà vẫn gọi dropForeign thì MySQL ném
 * lỗi -> initContainer fail -> toàn bộ rollout của core treo.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    private const TABLE = 'grade_books';

    /** @var array<int, string> */
    private const COLUMNS = ['tms_course_id', 'lms_course_id'];

    public function up(): void
    {
        if (! Schema::hasTable(self::TABLE)) {
            return;
        }

        foreach (self::COLUMNS as $column) {
            $this->dropForeignKeyIfExists($column);
        }
    }

    public function down(): void
    {
        // Không khôi phục FK: sau khi tách DB thì FK vượt database không tạo được.
        // Muốn quay lại phải chạy trên môi trường còn dùng chung 1 database.
    }

    /**
     * Bỏ FK đang gắn với $column nếu có — tra thẳng information_schema để không
     * phụ thuộc quy ước đặt tên index của Laravel, và để chạy lại được nhiều lần.
     */
    private function dropForeignKeyIfExists(string $column): void
    {
        $constraint = $this->foreignKeyName($column);

        if ($constraint === null) {
            return;
        }

        Schema::table(self::TABLE, function (Blueprint $table) use ($constraint) {
            $table->dropForeign($constraint);
        });
    }

    private function foreignKeyName(string $column): ?string
    {
        $row = DB::selectOne(
            'SELECT CONSTRAINT_NAME AS name
               FROM information_schema.KEY_COLUMN_USAGE
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = ?
                AND COLUMN_NAME = ?
                AND REFERENCED_TABLE_NAME IS NOT NULL
              LIMIT 1',
            [self::TABLE, $column]
        );

        return $row->name ?? null;
    }
};
