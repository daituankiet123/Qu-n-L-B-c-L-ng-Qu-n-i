<?php

use App\Models\User;
use App\Support\RoleCatalog;
use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\Models\Role;

return new class extends Migration
{
    // Gán ROLE "Quân lực" (RoleCatalog::LEAVE_QUAN_LUC) thay vì cấp quyền
    // rời rạc trực tiếp cho tài khoản khớp tên hiển thị - tên hiển thị
    // không phải định danh ổn định (có thể trùng, đổi tên...), nên moi
    // permission gan theo ten se khong the quan ly duoc qua man hinh Vai
    // tro va khong dong bo duoc khi RoleCatalog thay doi sau nay.
    public function up(): void
    {
        $role = Role::firstOrCreate(['name' => RoleCatalog::LEAVE_QUAN_LUC, 'guard_name' => 'web']);

        User::query()->where('name', 'Nguyễn Văn D')->get()
            ->each(fn (User $user) => $user->assignRole($role));
    }

    public function down(): void
    {
        User::query()->where('name', 'Nguyễn Văn D')->get()
            ->each(fn (User $user) => $user->removeRole(RoleCatalog::LEAVE_QUAN_LUC));
    }
};
