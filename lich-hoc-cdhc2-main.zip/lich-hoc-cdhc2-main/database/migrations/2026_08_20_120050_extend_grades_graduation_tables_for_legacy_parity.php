<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Bổ sung các trường/khái niệm còn thiếu so với ứng dụng Access cũ (Tổng kết - Xét TN):
 * - Điểm thi TN đa thành phần + nhiều vòng thi lại (bảng grade_graduation_exam_attempts)
 * - Điểm học bổng, nợ môn/tín chỉ, số hiệu văn bằng riêng từng học viên, cờ in/nhận bằng
 * - Khen thưởng (bên cạnh kỷ luật đã có)
 * - Các trường hành chính của đợt xét (chỉ tiêu, trúng tuyển, khoảng ngày, dải số văn bằng...)
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        Schema::table('grade_graduation_results', function (Blueprint $table) {
            if (! Schema::hasColumn('grade_graduation_results', 'scholarship_score')) {
                $table->decimal('scholarship_score', 6, 2)->nullable()->after('exam_score');
            }
            if (! Schema::hasColumn('grade_graduation_results', 'credits_owed')) {
                $table->unsignedInteger('credits_owed')->nullable()->after('scholarship_score');
            }
            if (! Schema::hasColumn('grade_graduation_results', 'owed_subjects')) {
                $table->json('owed_subjects')->nullable()->after('credits_owed'); // [{subject_id,name,credits}]
            }
            if (! Schema::hasColumn('grade_graduation_results', 'registry_number')) {
                $table->string('registry_number')->nullable()->after('owed_subjects'); // số vào sổ (riêng học viên)
            }
            if (! Schema::hasColumn('grade_graduation_results', 'series_number')) {
                $table->string('series_number')->nullable()->after('registry_number'); // số hiệu văn bằng (riêng học viên)
            }
            if (! Schema::hasColumn('grade_graduation_results', 'diploma_printed_at')) {
                $table->timestamp('diploma_printed_at')->nullable()->after('series_number');
            }
            if (! Schema::hasColumn('grade_graduation_results', 'diploma_received_at')) {
                $table->timestamp('diploma_received_at')->nullable()->after('diploma_printed_at');
            }
        });

        Schema::table('grade_conduct_records', function (Blueprint $table) {
            if (! Schema::hasColumn('grade_conduct_records', 'commendation')) {
                $table->text('commendation')->nullable()->after('discipline'); // khen thưởng
            }
        });

        Schema::table('grade_graduation_profiles', function (Blueprint $table) {
            if (! Schema::hasColumn('grade_graduation_profiles', 'quota')) {
                $table->unsignedInteger('quota')->nullable()->after('duration_text'); // chỉ tiêu
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'admitted_count')) {
                $table->unsignedInteger('admitted_count')->nullable()->after('quota'); // trúng tuyển
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'registration_from')) {
                $table->date('registration_from')->nullable()->after('admitted_count');
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'registration_to')) {
                $table->date('registration_to')->nullable()->after('registration_from');
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'registry_number_from')) {
                $table->string('registry_number_from')->nullable()->after('registry_number');
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'registry_number_to')) {
                $table->string('registry_number_to')->nullable()->after('registry_number_from');
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'series_number_from')) {
                $table->string('series_number_from')->nullable()->after('series_group');
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'series_number_to')) {
                $table->string('series_number_to')->nullable()->after('series_number_from');
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'diploma_symbol')) {
                $table->string('diploma_symbol')->nullable()->after('series_number_to'); // ký hiệu văn bằng
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'training_location')) {
                $table->string('training_location')->nullable()->after('diploma_symbol'); // nơi đào tạo
            }
            if (! Schema::hasColumn('grade_graduation_profiles', 'major_code')) {
                $table->string('major_code')->nullable()->after('major_name'); // mã ngành
            }
        });

        if (! Schema::hasTable('grade_graduation_exam_attempts')) {
            Schema::create('grade_graduation_exam_attempts', function (Blueprint $table) {
                $table->id();
                $table->foreignId('result_id')->constrained('grade_graduation_results')->cascadeOnDelete();
                $table->unsignedTinyInteger('attempt_no')->default(1); // 1=chính thức, 2-4=thi lại (b/c/d)
                $table->decimal('political_score', 5, 2)->nullable(); // chính trị (tn1)
                $table->decimal('specialty_written_score', 5, 2)->nullable(); // chuyên môn - viết (tn32)
                $table->decimal('specialty_practical_score', 5, 2)->nullable(); // chuyên môn - thực hành (tn33)
                $table->decimal('average_score', 5, 2)->nullable(); // tbttn - trung bình các thành phần đã nhập
                $table->string('classification', 40)->nullable(); // xếp loại của vòng thi này
                $table->boolean('is_absent')->default(false); // vắng thi
                $table->date('exam_date')->nullable();
                $table->text('note')->nullable();
                $table->foreignId('updated_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
                $table->timestamps();
                $table->unique(['result_id', 'attempt_no']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('grade_graduation_exam_attempts');

        Schema::table('grade_graduation_profiles', function (Blueprint $table) {
            $table->dropColumn([
                'quota', 'admitted_count', 'registration_from', 'registration_to',
                'registry_number_from', 'registry_number_to', 'series_number_from', 'series_number_to',
                'diploma_symbol', 'training_location', 'major_code',
            ]);
        });

        Schema::table('grade_conduct_records', function (Blueprint $table) {
            $table->dropColumn('commendation');
        });

        Schema::table('grade_graduation_results', function (Blueprint $table) {
            $table->dropColumn([
                'scholarship_score', 'credits_owed', 'owed_subjects',
                'registry_number', 'series_number', 'diploma_printed_at', 'diploma_received_at',
            ]);
        });
    }
};
