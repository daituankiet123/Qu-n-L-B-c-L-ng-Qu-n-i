<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Fix users.role_id type mismatch (unsignedInteger → unsignedBigInteger)
        Schema::table('users', function (Blueprint $table) {
            $table->unsignedBigInteger('role_id')->default(2)->change();
        });

        // Add index on users.unit_id (FK column without index)
        Schema::table('users', function (Blueprint $table) {
            $table->index('unit_id');
        });

        // Add index on users.role_id
        Schema::table('users', function (Blueprint $table) {
            $table->index('role_id');
        });

        // Add onDelete to classes FKs (drop + re-add)
        Schema::table('classes', function (Blueprint $table) {
            $table->dropForeign(['specialization_id']);
            $table->dropForeign(['instructor_id']);
            $table->dropForeign(['created_by']);
            $table->dropForeign(['updated_by']);

            $table->foreign('specialization_id')->references('id')->on('specializations')->onDelete('restrict');
            $table->foreign('instructor_id')->references('id')->on('instructors')->onDelete('restrict');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('restrict');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('restrict');
        });

        // Add onDelete to instructors FKs
        Schema::table('instructors', function (Blueprint $table) {
            $table->dropForeign(['specialization_id']);
            $table->dropForeign(['unit_id']);

            $table->foreign('specialization_id')->references('id')->on('specializations')->onDelete('set null');
            $table->foreign('unit_id')->references('id')->on('units')->onDelete('set null');
        });

        // Add index on schedule_details.training_schedule_id (FK without dedicated index)
        if (! $this->hasIndex('schedule_details', 'schedule_details_training_schedule_id_index')) {
            Schema::table('schedule_details', function (Blueprint $table) {
                $table->index('training_schedule_id');
            });
        }

        // Add index on schedule_details.subject_id
        if (! $this->hasIndex('schedule_details', 'schedule_details_subject_id_index')) {
            Schema::table('schedule_details', function (Blueprint $table) {
                $table->index('subject_id');
            });
        }
    }

    public function down(): void
    {
        Schema::table('schedule_details', function (Blueprint $table) {
            $table->dropIndex(['subject_id']);
            $table->dropIndex(['training_schedule_id']);
        });

        Schema::table('instructors', function (Blueprint $table) {
            $table->dropForeign(['specialization_id']);
            $table->dropForeign(['unit_id']);
            $table->foreign('specialization_id')->references('id')->on('specializations');
            $table->foreign('unit_id')->references('id')->on('units');
        });

        Schema::table('classes', function (Blueprint $table) {
            $table->dropForeign(['specialization_id']);
            $table->dropForeign(['instructor_id']);
            $table->dropForeign(['created_by']);
            $table->dropForeign(['updated_by']);
            $table->foreign('specialization_id')->references('id')->on('specializations');
            $table->foreign('instructor_id')->references('id')->on('instructors');
            $table->foreign('created_by')->references('id')->on('users');
            $table->foreign('updated_by')->references('id')->on('users');
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex(['role_id']);
            $table->dropIndex(['unit_id']);
            $table->unsignedInteger('role_id')->default(2)->change();
        });
    }

    private function hasIndex(string $table, string $indexName): bool
    {
        $indexes = Schema::getIndexes($table);
        foreach ($indexes as $index) {
            if ($index['name'] === $indexName) {
                return true;
            }
        }

        return false;
    }
};
