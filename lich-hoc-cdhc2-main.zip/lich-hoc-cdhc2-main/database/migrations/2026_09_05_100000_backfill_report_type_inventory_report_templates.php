<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        $mapping = [
            'POSITION' => 'position',
            'TOTAL_POSITION' => 'total-position',
            'UNIT' => 'unit',
            'INCREASE_DECREASE' => 'increase-decrease',
            'PERIOD' => 'period',
            'WAREHOUSE' => 'warehouse',
            'USING_POSITION' => 'using-position',
            'USING_TOTAL' => 'using-total',
            'SYSTEM_WAREHOUSE' => 'system-warehouse',
            'TRANSFER' => 'transfer',
            'RECALL' => 'recall',
            'REPAIR' => 'repair',
            'UPDATE_LOG' => 'update-log',
        ];

        foreach ($mapping as $codeSuffix => $reportType) {
            DB::table('inventory_report_templates')
                ->whereNull('report_type')
                ->where('code', 'like', '%'.$codeSuffix)
                ->update(['report_type' => $reportType]);
        }
    }

    public function down(): void {}
};
