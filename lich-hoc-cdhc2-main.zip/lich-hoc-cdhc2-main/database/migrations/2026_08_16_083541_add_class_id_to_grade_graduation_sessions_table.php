<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'grades';

    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('grade_graduation_sessions', function (Blueprint $table) {
            $table->foreignId('class_id')->nullable()->after('term')
                ->constrained(DbRef::forMigration('classes'))->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('grade_graduation_sessions', function (Blueprint $table) {
            $table->dropConstrainedForeignId('class_id');
        });
    }
};
