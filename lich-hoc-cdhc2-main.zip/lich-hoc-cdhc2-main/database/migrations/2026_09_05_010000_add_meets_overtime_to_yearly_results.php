<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('yearly_standard_results', function (Blueprint $table) {
            $table->boolean('meets_overtime')->nullable()->after('meets_overall');
        });
    }

    public function down(): void
    {
        Schema::table('yearly_standard_results', function (Blueprint $table) {
            $table->dropColumn('meets_overtime');
        });
    }
};
