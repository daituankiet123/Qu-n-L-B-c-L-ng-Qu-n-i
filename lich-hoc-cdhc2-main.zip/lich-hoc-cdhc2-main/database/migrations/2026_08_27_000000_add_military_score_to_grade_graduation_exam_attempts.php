<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Bo sung thanh phan diem thi tot nghiep con thieu so voi Access cu: "Dieu
 * lenh" (tn2 - dung dung cot rieng ben canh Chinh tri/tn1, giu nguyen
 * Chuyen mon viet/tn32 va Chuyen mon thuc hanh/tn33 da co).
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        Schema::table('grade_graduation_exam_attempts', function (Blueprint $table) {
            if (! Schema::hasColumn('grade_graduation_exam_attempts', 'military_score')) {
                $table->decimal('military_score', 5, 2)->nullable()->after('political_score');
            }
        });
    }

    public function down(): void
    {
        Schema::table('grade_graduation_exam_attempts', function (Blueprint $table) {
            $table->dropColumn('military_score');
        });
    }
};
