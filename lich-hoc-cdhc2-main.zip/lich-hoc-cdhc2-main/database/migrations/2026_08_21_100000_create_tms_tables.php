<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TMS — Cổng Đào tạo và Khảo thí Nội bộ (cán bộ/giảng viên).
 *
 * Module hoàn toàn tách biệt với modules/Lms: bảng prefix `tms_`, KHÔNG có FK
 * sang subjects/classes/lms_*. Giai đoạn 1 — xem kế hoạch tại
 * .claude (plan majestic-purring-wilkes) mục "Giai đoạn 1".
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::create('tms_courses', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('category', 100)->nullable();
            $table->string('cover_image')->nullable();
            $table->boolean('is_active')->default(true);
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('tms_lessons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained('tms_courses')->cascadeOnDelete();
            $table->string('title');
            $table->longText('content')->nullable();
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_published')->default(false);
            $table->timestamps();
            $table->softDeletes();

            $table->index(['course_id', 'sort_order']);
        });

        Schema::create('tms_materials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained('tms_courses')->cascadeOnDelete();
            $table->foreignId('lesson_id')->nullable()->constrained('tms_lessons')->nullOnDelete();
            $table->string('kind', 30); // pdf|video|slide|document|scorm-placeholder
            $table->string('disk', 30)->default('public');
            $table->string('path');
            $table->string('title')->nullable();
            $table->foreignId('uploaded_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('tms_question_banks', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('topic', 150)->nullable();
            $table->foreignId('unit_id')->nullable()->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('tms_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('bank_id')->constrained('tms_question_banks')->cascadeOnDelete();
            $table->string('type', 30); // mcq|true_false|multi_select|short|essay|file_upload
            $table->text('stem');
            $table->json('options')->nullable();
            $table->json('correct_answer')->nullable();
            $table->unsignedSmallInteger('points')->default(1);
            $table->string('difficulty', 10)->default('medium'); // easy|medium|hard
            $table->timestamps();
            $table->softDeletes();

            $table->index(['bank_id', 'difficulty']);
        });

        Schema::create('tms_exams', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->nullable()->constrained('tms_courses')->nullOnDelete();
            $table->string('title');
            $table->unsignedSmallInteger('duration_minutes')->default(45);
            $table->unsignedTinyInteger('pass_score')->default(50);
            $table->unsignedTinyInteger('max_attempts')->default(1);
            $table->boolean('shuffle_questions')->default(false);
            $table->boolean('shuffle_options')->default(false);
            $table->boolean('allow_review_answers')->default(true);
            $table->timestamp('opens_at')->nullable();
            $table->timestamp('closes_at')->nullable();
            $table->json('generation_rule')->nullable(); // {bank_id, easy_count, medium_count, hard_count}
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('tms_exam_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('exam_id')->constrained('tms_exams')->cascadeOnDelete();
            $table->foreignId('question_id')->constrained('tms_questions')->cascadeOnDelete();
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();

            $table->unique(['exam_id', 'question_id']);
        });

        Schema::create('tms_exam_attempts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('exam_id')->constrained('tms_exams')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained(DbRef::forMigration('users'))->cascadeOnDelete();
            $table->json('question_snapshot')->nullable();
            $table->json('answers')->nullable();
            $table->decimal('score', 5, 2)->nullable();
            $table->string('status', 20)->default('in_progress'); // in_progress|submitted|graded|needs_review
            $table->timestamp('started_at')->nullable();
            $table->timestamp('submitted_at')->nullable();
            $table->timestamps();

            $table->index(['exam_id', 'user_id']);
        });

        Schema::create('tms_groups', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('tms_group_members', function (Blueprint $table) {
            $table->id();
            $table->foreignId('group_id')->constrained('tms_groups')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained(DbRef::forMigration('users'))->cascadeOnDelete();
            $table->timestamps();

            $table->unique(['group_id', 'user_id']);
        });

        Schema::create('tms_assignments', function (Blueprint $table) {
            $table->id();
            $table->string('assignable_type');
            $table->unsignedBigInteger('assignable_id');
            $table->string('audience_type', 20); // all|unit|position|user|group
            $table->unsignedBigInteger('audience_ref_id')->nullable();
            $table->timestamp('due_at')->nullable();
            $table->unsignedTinyInteger('min_score')->nullable();
            $table->boolean('require_retake_on_fail')->default(false);
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['assignable_type', 'assignable_id']);
            $table->index(['audience_type', 'audience_ref_id']);
        });

        Schema::create('tms_assignment_targets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('assignment_id')->constrained('tms_assignments')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained(DbRef::forMigration('users'))->cascadeOnDelete();
            $table->string('status', 20)->default('pending'); // pending|in_progress|completed|failed|overdue
            $table->timestamp('completed_at')->nullable();
            $table->decimal('score', 5, 2)->nullable();
            $table->timestamps();

            $table->unique(['assignment_id', 'user_id']);
            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_assignment_targets');
        Schema::dropIfExists('tms_assignments');
        Schema::dropIfExists('tms_group_members');
        Schema::dropIfExists('tms_groups');
        Schema::dropIfExists('tms_exam_attempts');
        Schema::dropIfExists('tms_exam_questions');
        Schema::dropIfExists('tms_exams');
        Schema::dropIfExists('tms_questions');
        Schema::dropIfExists('tms_question_banks');
        Schema::dropIfExists('tms_materials');
        Schema::dropIfExists('tms_lessons');
        Schema::dropIfExists('tms_courses');
    }
};
