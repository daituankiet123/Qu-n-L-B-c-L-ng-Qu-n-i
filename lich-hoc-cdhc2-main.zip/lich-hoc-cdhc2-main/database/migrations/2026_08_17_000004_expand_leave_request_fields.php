<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('leave_requests', function (Blueprint $t): void {
            $t->string('request_scope', 30)->default('OTHER');
            $t->string('object_type', 50)->nullable();
            $t->unsignedInteger('service_years')->default(0);
            $t->unsignedInteger('base_days')->default(0);
            $t->unsignedInteger('travel_days')->default(0);
            $t->unsignedInteger('extra_days')->default(0);
            $t->json('extra_reasons')->nullable();
            $t->unsignedInteger('total_days')->default(0);
            $t->string('leave_year', 10)->nullable();
            $t->foreignId('locality_id')->nullable()->constrained('leave_localities')->nullOnDelete();
            $t->text('locality_path')->nullable();
            $t->foreignId('proposed_by_user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $t->string('proposed_by_username')->nullable();
            $t->string('proposed_by_display_name')->nullable();
            $t->string('proposer_email')->nullable();
            $t->foreignId('decided_by_user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $t->string('decided_by_username')->nullable();
            $t->timestamp('decided_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('leave_requests', function (Blueprint $t): void {
            $t->dropForeign(['locality_id']);
            $t->dropForeign(['proposed_by_user_id']);
            $t->dropForeign(['decided_by_user_id']);
            $t->dropColumn(['request_scope', 'object_type', 'service_years', 'base_days', 'travel_days', 'extra_days', 'extra_reasons', 'total_days', 'leave_year', 'locality_id', 'locality_path', 'proposed_by_user_id', 'proposed_by_username', 'proposed_by_display_name', 'proposer_email', 'decided_by_user_id', 'decided_by_username', 'decided_at']);
        });
    }
};
