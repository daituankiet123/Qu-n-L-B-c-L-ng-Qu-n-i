<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Nut "Dong bo chuc vu sang danh sach nhan su" (LeaveWorkflowController::
 * positionsSyncToPersonnel) truoc day chen thang ten chuc vu ben Quan ly
 * phep (leave_positions) vao bang chuc danh dung cho Gio chuan GV
 * (standard_positions), lam 2 danh sach vai tro khac nhau bi lan vao nhau.
 *
 * Chi xoa (mem) cac dong THOA CA 4 dieu kien sau de chan xoa nham chuc
 * danh hop le co san tu truoc:
 * - Trung ten voi 1 chuc vu dang co trong leave_positions.
 * - ratio_percent = 0 VA min_classroom_percent = 0 (gia tri mac dinh script
 *   dong bo tu dat cho dong MOI TAO, chuc danh Gio chuan that thuong khac 0).
 * - created_by IS NULL (script dong bo khong dat nguoi tao).
 * - Khong co giang vien nao dang gan chuc danh nay (instructors.position_id).
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::connection('tms')->hasTable('leave_positions') || ! Schema::hasTable('standard_positions')) {
            return;
        }

        $leaveNames = DB::connection('tms')->table('leave_positions')->pluck('name')->filter()->map(fn ($n) => trim($n))->unique();
        if ($leaveNames->isEmpty()) {
            return;
        }

        $candidates = DB::table('standard_positions')
            ->whereNull('deleted_at')
            ->whereNull('created_by')
            ->where('ratio_percent', 0)
            ->where('min_classroom_percent', 0)
            ->get(['id', 'name']);

        $toDelete = $candidates->filter(function ($row) use ($leaveNames) {
            return $leaveNames->contains(fn ($name) => mb_strtolower(trim($name), 'UTF-8') === mb_strtolower(trim($row->name), 'UTF-8'));
        })->pluck('id')->values();

        if ($toDelete->isEmpty()) {
            return;
        }

        $stillUsed = DB::table('instructors')->whereIn('position_id', $toDelete)->pluck('position_id')->unique()->values();
        $safeToDelete = $toDelete->diff($stillUsed)->values();

        if ($safeToDelete->isNotEmpty()) {
            DB::table('standard_positions')->whereIn('id', $safeToDelete)->update(['deleted_at' => now(), 'is_active' => false]);
        }
    }

    public function down(): void
    {
        // Khong hoan tac - day la don xoa du lieu bi lan, khong phai thay doi schema.
    }
};
