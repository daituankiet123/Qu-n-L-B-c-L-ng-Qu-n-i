<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TMS "quest": nguoi dung phan anh "Giao nhiem vu" hien bat buoc gan voi
 * 1 khoa hoc/de thi (giong bai thi) - thuc te can giao nhiem vu KIEU QUEST
 * tu do (doc/nam ro 1 van ban, thong tu ban hanh...) kem nhieu file dinh
 * kem, khong nhat thiet phai co noi dung khoa hoc/de thi di kem.
 *
 * 1. tms_assignments.assignable_type/assignable_id: NOT NULL -> nullable
 *    (assignment khong con BAT BUOC gan course/exam nua). Khong doi du
 *    lieu cu (moi row hien co van co gia tri, chi la khong con bat buoc
 *    o hang moi tro di).
 * 2. tms_attachments (moi): bang file dinh kem dung chung (polymorphic)
 *    cho ca tms_tasks va tms_assignments - 1 nhiem vu/quest co the kem
 *    nhieu file (nhieu thong tu cung luc).
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('tms_assignments', function (Blueprint $table) {
            $table->string('assignable_type')->nullable()->change();
            $table->unsignedBigInteger('assignable_id')->nullable()->change();
        });

        Schema::create('tms_attachments', function (Blueprint $table) {
            $table->id();
            $table->string('attachable_type');
            $table->unsignedBigInteger('attachable_id');
            $table->string('disk', 30)->default('public');
            $table->string('path');
            $table->string('title')->nullable();
            $table->unsignedBigInteger('size')->nullable();
            $table->foreignId('uploaded_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();

            $table->index(['attachable_type', 'attachable_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_attachments');

        Schema::table('tms_assignments', function (Blueprint $table) {
            $table->string('assignable_type')->nullable(false)->change();
            $table->unsignedBigInteger('assignable_id')->nullable(false)->change();
        });
    }
};
