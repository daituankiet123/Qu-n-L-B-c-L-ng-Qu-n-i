<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Bảng điểm đang nhận điểm từ khóa LMS qua lms_course_id. Khóa TMS có gắn
 * lớp/môn cũng cần đường tương ứng, tách riêng để một lớp-môn có thể vừa
 * có bảng từ LMS vừa có bảng từ TMS mà không đè lên nhau.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        Schema::table('grade_books', function (Blueprint $table) {
            $table->foreignId('tms_course_id')->nullable()->after('lms_course_id')->constrained(DbRef::forMigration('tms_courses'))->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('grade_books', function (Blueprint $table) {
            $table->dropConstrainedForeignId('tms_course_id');
        });
    }
};
