<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Toạ độ x/y do người dùng kéo-thả tự do cho từng chức vụ trên sơ đồ luồng. */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('tms_workflows', function (Blueprint $table) {
            $table->json('layout')->nullable()->after('object_type');
        });
    }

    public function down(): void
    {
        Schema::table('tms_workflows', function (Blueprint $table) {
            $table->dropColumn('layout');
        });
    }
};
