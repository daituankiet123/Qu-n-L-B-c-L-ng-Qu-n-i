<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        if (! Schema::hasColumn('tms_exam_attempts', 'is_practice')) {
            Schema::table('tms_exam_attempts', function (Blueprint $table) {
                $table->boolean('is_practice')->default(false)->after('user_id');
            });
        }
    }

    public function down(): void
    {
        Schema::table('tms_exam_attempts', function (Blueprint $table) {
            $table->dropColumn('is_practice');
        });
    }
};
