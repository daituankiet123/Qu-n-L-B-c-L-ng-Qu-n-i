<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Bổ sung inventory_report_templates.original_name.
 *
 * Controller (InventoryWorkflowController::repairProposalReplace...) ghi tên
 * file gốc vào cột này và model InventoryReportTemplate đã khai báo trong
 * $fillable, nhưng chưa từng có migration tạo cột — nên thao tác thay mẫu báo
 * cáo sửa chữa chết với "Unknown column 'original_name' in INSERT INTO".
 *
 * Đặt sau file_path cho khớp bảng lms_/leave_report_templates đã có cùng cột.
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        if (! Schema::hasTable('inventory_report_templates')) {
            return;
        }

        if (! Schema::hasColumn('inventory_report_templates', 'original_name')) {
            Schema::table('inventory_report_templates', function (Blueprint $table) {
                $table->string('original_name')->nullable()->after('file_path');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('inventory_report_templates')
            && Schema::hasColumn('inventory_report_templates', 'original_name')) {
            Schema::table('inventory_report_templates', function (Blueprint $table) {
                $table->dropColumn('original_name');
            });
        }
    }
};
