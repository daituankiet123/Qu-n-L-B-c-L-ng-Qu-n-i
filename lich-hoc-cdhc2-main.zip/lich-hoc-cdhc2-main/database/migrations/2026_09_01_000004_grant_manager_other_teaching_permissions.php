<?php
use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

return new class extends Migration
{
    public function up(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();

        // Role "manager" là role Khoa hiện đang được gán thật cho các tài khoản
        // demo/production (vd quanlykhoa@example.com) - vốn đã có đủ quyền
        // view/create/edit/delete cho các ứng dụng standard-hours.* khác
        // (external-activities, conversion-records...) nên cấp tương tự cho
        // other-teaching để họ dùng được bước "Khoa thẩm định". KHÔNG cấp
        // .approve để giữ đúng ranh giới 2 cấp — bước duyệt cuối chỉ dành cho
        // role training-office-manager (Phòng Đào Tạo) như đã cấp ở migration
        // 2026_09_01_000003.
        $role = Role::where('name', 'manager')->first();
        if ($role) {
            $role->givePermissionTo([
                'standard-hours.other-teaching.view',
                'standard-hours.other-teaching.create',
                'standard-hours.other-teaching.edit',
                'standard-hours.other-teaching.delete',
            ]);
        }

        app(PermissionRegistrar::class)->forgetCachedPermissions();
    }

    public function down(): void
    {
        $role = Role::where('name', 'manager')->first();
        if ($role) {
            $role->revokePermissionTo([
                'standard-hours.other-teaching.view',
                'standard-hours.other-teaching.create',
                'standard-hours.other-teaching.edit',
                'standard-hours.other-teaching.delete',
            ]);
        }
    }
};
