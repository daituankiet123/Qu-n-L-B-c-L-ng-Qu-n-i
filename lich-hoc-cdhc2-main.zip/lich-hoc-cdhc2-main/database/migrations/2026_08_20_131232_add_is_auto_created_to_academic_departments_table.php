<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Đánh dấu "Bộ môn" tự sinh đại diện cho cả Khoa (Khoa có 0 Bộ môn thật) —
 * để dùng chung code tính pool vượt định mức thay vì phải rẽ nhánh Khoa/Bộ môn
 * ở tầng route/controller. Xem Modules\StandardHours\Services\DepartmentService.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('academic_departments', function (Blueprint $table) {
            if (! Schema::hasColumn('academic_departments', 'is_auto_created')) {
                $table->boolean('is_auto_created')->default(false)->after('is_active');
            }
        });
    }

    public function down(): void
    {
        Schema::table('academic_departments', function (Blueprint $table) {
            $table->dropColumn('is_auto_created');
        });
    }
};
