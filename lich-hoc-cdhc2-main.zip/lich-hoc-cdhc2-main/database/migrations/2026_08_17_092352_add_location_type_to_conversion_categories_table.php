<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('conversion_categories', function (Blueprint $table) {
            $table->string('location_type', 30)->nullable()->after('entry_source');
        });

        // HD-01 = "...ban ngày tại giảng đường" — danh mục duy nhất hiện có gắn
        // rõ 1 loại địa điểm cụ thể. HD-02/03/04 gộp chung nhiều loại địa điểm
        // trong 1 dòng (thao trường/bệnh viện/xưởng...) nên để null (không phân
        // biệt) — PĐT tự tách/gắn thêm qua trang Danh mục quy đổi khi cần.
        DB::table('conversion_categories')->where('code', 'HD-01')->update(['location_type' => 'lecture_hall']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('conversion_categories', function (Blueprint $table) {
            $table->dropColumn('location_type');
        });
    }
};
