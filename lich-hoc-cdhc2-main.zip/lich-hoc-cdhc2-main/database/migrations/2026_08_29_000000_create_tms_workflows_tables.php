<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Cho phép nhiều "luồng xử lý công việc" đặt tên riêng (vd: Văn bản đến,
 * Văn bản đi, Phiếu trình đi, Giấy mời đến), mỗi luồng gắn 1 đơn vị + đối
 * tượng áp dụng, và là 1 CÂY chức vụ có thể phân nhánh (1 chức vụ có thể
 * có nhiều bước kế tiếp) thay vì 1 chuỗi thẳng duy nhất như trước.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::connection('tms')->create('tms_workflows', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->foreignId('unit_id')->nullable()->constrained(DbRef::forMigration('units', 'tms'))->nullOnDelete();
            $table->string('object_type')->nullable();
            $table->boolean('is_active')->default(true);
            $table->foreignId('created_by')->constrained(DbRef::forMigration('users', 'tms'));
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::connection('tms')->create('tms_workflow_edges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('workflow_id')->constrained('tms_workflows')->cascadeOnDelete();
            // from_position_id null = điểm bắt đầu của luồng (bước 1 có thể có nhiều lựa chọn).
            $table->foreignId('from_position_id')->nullable()->constrained(DbRef::forMigration('standard_positions', 'tms'))->cascadeOnDelete();
            $table->foreignId('to_position_id')->constrained(DbRef::forMigration('standard_positions', 'tms'))->cascadeOnDelete();
            $table->string('label')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->foreignId('created_by')->constrained(DbRef::forMigration('users', 'tms'));
            $table->timestamps();
        });

        Schema::connection('tms')->table('tms_documents', function (Blueprint $table) {
            $table->foreignId('workflow_id')->nullable()->after('created_by')->constrained('tms_workflows')->nullOnDelete();
        });

        // Chuyển luồng thẳng cũ (nếu có) thành 1 luồng mặc định để không mất cấu hình đã lưu.
        $oldSteps = DB::connection('tms')->table('tms_workflow_steps')->orderBy('step_order')->get();
        if ($oldSteps->isNotEmpty()) {
            $adminId = DB::table('users')->orderBy('id')->value('id');
            $workflowId = DB::connection('tms')->table('tms_workflows')->insertGetId([
                'name' => 'Luồng xử lý công việc (mặc định)',
                'unit_id' => null,
                'object_type' => null,
                'is_active' => true,
                'created_by' => $adminId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $steps = $oldSteps->values();
            foreach ($steps as $index => $step) {
                DB::connection('tms')->table('tms_workflow_edges')->insert([
                    'workflow_id' => $workflowId,
                    'from_position_id' => $index === 0 ? null : $steps[$index - 1]->position_id,
                    'to_position_id' => $step->position_id,
                    'label' => null,
                    'sort_order' => $index,
                    'created_by' => $step->created_by,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }

    public function down(): void
    {
        Schema::connection('tms')->table('tms_documents', function (Blueprint $table) {
            $table->dropConstrainedForeignId('workflow_id');
        });
        Schema::connection('tms')->dropIfExists('tms_workflow_edges');
        Schema::connection('tms')->dropIfExists('tms_workflows');
    }
};
