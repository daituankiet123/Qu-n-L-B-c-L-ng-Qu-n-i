<?php
use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

return new class extends Migration
{
    public function up(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();

        $names = array_map(
            fn ($action) => "standard-hours.other-teaching.$action",
            ['view', 'create', 'edit', 'delete', 'approve']
        );
        foreach ($names as $name) {
            Permission::firstOrCreate(['name' => $name, 'guard_name' => 'web']);
        }

        // Giảng viên tự kê khai; Chủ nhiệm khoa xem để thẩm định (bước 1, gác bởi
        // App\Support\TrainingDept::isFacultyManager, không phải permission riêng);
        // Phòng Đào Tạo duyệt cuối (bước 2, permission .approve).
        $grants = [
            'instructor' => ['view', 'create', 'edit', 'delete'],
            'faculty-manager' => ['view'],
            'training-office-manager' => ['view', 'approve'],
        ];

        foreach ($grants as $roleName => $actions) {
            $role = Role::where('name', $roleName)->first();
            if (! $role) {
                continue;
            }
            $role->givePermissionTo(array_map(fn ($a) => "standard-hours.other-teaching.$a", $actions));
        }

        app(PermissionRegistrar::class)->forgetCachedPermissions();
    }

    public function down(): void
    {
        Permission::whereIn('name', array_map(
            fn ($action) => "standard-hours.other-teaching.$action",
            ['view', 'create', 'edit', 'delete', 'approve']
        ))->delete();
    }
};
