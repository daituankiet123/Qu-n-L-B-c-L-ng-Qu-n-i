<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Học lại (Điều 15) + trường trích ngang khớp mẫu giấy thật của trường.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        if (Schema::hasTable('grade_books') && ! Schema::hasColumn('grade_books', 'attempt_no')) {
            Schema::table('grade_books', function (Blueprint $table) {
                // 1 = học lần đầu, 2 = học lại (khác grade_columns.attempt là lần thi trong 1 lượt học)
                $table->unsignedTinyInteger('attempt_no')->default(1)->after('term');
            });
        }

        if (Schema::hasTable('grade_student_profiles') && ! Schema::hasColumn('grade_student_profiles', 'gender')) {
            Schema::table('grade_student_profiles', function (Blueprint $table) {
                $table->string('gender', 10)->nullable()->after('student_code');
                $table->date('dob')->nullable()->after('gender');
                $table->string('birth_ward')->nullable()->after('birth_place');
                $table->string('birth_district')->nullable()->after('birth_ward');
                $table->string('birth_province')->nullable()->after('birth_district');
                $table->string('hometown')->nullable()->after('birth_province');
                $table->string('nationality')->nullable()->default('Việt Nam')->after('hometown');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('grade_student_profiles') && Schema::hasColumn('grade_student_profiles', 'gender')) {
            Schema::table('grade_student_profiles', function (Blueprint $table) {
                $table->dropColumn(['gender', 'dob', 'birth_ward', 'birth_district', 'birth_province', 'hometown', 'nationality']);
            });
        }

        if (Schema::hasTable('grade_books') && Schema::hasColumn('grade_books', 'attempt_no')) {
            Schema::table('grade_books', function (Blueprint $table) {
                $table->dropColumn('attempt_no');
            });
        }
    }
};
