<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Service QL Bac Luong QNCH (Task 3). Tat ca bang tren DB cua service `salary`. Tham chieu sang core
 * (users, military_ranks) chi luu id/ma - KHONG FK cheo DB. Nguon cot: docs/salary/access-spec/schema.md.
 */
return new class extends Migration
{
    protected $connection = 'salary';

    public function up(): void
    {
        // Tham so quy tac mac dinh (Access: TxtDK1 = TxtDK2 = 5.4) - mot dong; moi dot chup snapshot rieng.
        if (! Schema::hasTable('salary_rule_settings')) {
            Schema::create('salary_rule_settings', function (Blueprint $table) {
                $table->id();
                $table->decimal('threshold', 4, 2)->default(5.40);
                $table->unsignedTinyInteger('years_below')->default(2);
                $table->unsignedTinyInteger('years_above')->default(3);
                $table->unsignedTinyInteger('seniority_first')->default(5);
                $table->unsignedTinyInteger('seniority_step')->default(1);
                $table->unsignedTinyInteger('seniority_yearly_from')->default(5);
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->timestamps();
            });
        }

        // Bang luong (Access BANG LUONG) - co phien ban theo ngay hieu luc de sua ma van in lai dung.
        if (! Schema::hasTable('salary_scales')) {
            Schema::create('salary_scales', function (Blueprint $table) {
                $table->id();
                $table->string('code', 20);
                $table->string('grade', 5);
                $table->string('group', 5)->nullable();
                $table->string('step', 10);
                $table->decimal('coefficient', 5, 2);
                $table->string('military_rank_code', 50)->nullable();
                $table->date('effective_from');
                $table->boolean('is_active')->default(true);
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->timestamps();
                $table->unique(['code', 'effective_from']);
                $table->index(['grade', 'group', 'is_active']);
            });
        }

        // Ho so luong cua 1 quan nhan (cot luong cua Access CAN BO NHAN VIEN); user_id = users.id (core).
        if (! Schema::hasTable('salary_profiles')) {
            Schema::create('salary_profiles', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->unique();
                $table->string('scale_code', 20)->nullable();
                $table->date('received_at')->nullable();
                $table->date('check_received_at')->nullable();
                $table->unsignedTinyInteger('seniority_percent')->default(0);
                $table->decimal('reserved_coefficient', 5, 2)->default(0);
                $table->string('last_raise_type', 20)->nullable();
                $table->date('birth_date')->nullable();
                $table->date('enlistment_date')->nullable();
                $table->string('education_level', 50)->nullable();
                $table->string('education_major', 255)->nullable();
                $table->string('graduation_year', 10)->nullable();
                $table->text('note')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        // Qua trinh luong (Access QUA TRINH LUONG; ma Maso_CBNV&mm&yyyy -> unique user + ngay nhan + loai).
        if (! Schema::hasTable('salary_histories')) {
            Schema::create('salary_histories', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('user_id')->index();
                $table->string('scale_code', 20);
                $table->string('grade', 5);
                $table->string('group', 5)->nullable();
                $table->string('step', 10);
                $table->decimal('coefficient', 5, 2);
                $table->string('military_rank_code', 50)->nullable();
                $table->unsignedTinyInteger('seniority_percent')->default(0);
                $table->decimal('reserved_coefficient', 5, 2)->default(0);
                $table->string('raise_type', 20);
                $table->unsignedBigInteger('decision_id')->nullable()->index();
                $table->string('decision_no', 50)->nullable();
                $table->date('signed_at')->nullable();
                $table->date('received_at');
                $table->string('signer', 255)->nullable();
                $table->string('note', 255)->nullable();
                $table->timestamps();
                $table->unique(['user_id', 'received_at', 'raise_type']);
            });
        }

        // Dot xet nang luong (5 form F DE NGHI … cua Access gop thanh 1 luong); rules = snapshot RuleSettings.
        if (! Schema::hasTable('salary_rounds')) {
            Schema::create('salary_rounds', function (Blueprint $table) {
                $table->id();
                $table->string('raise_type', 20);
                $table->unsignedSmallInteger('work_year');
                $table->json('rules');
                $table->string('status', 20)->default('draft');
                $table->unsignedBigInteger('created_by')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->index(['raise_type', 'work_year']);
            });
        }

        // Tung nguoi trong dot: snapshot cu/moi (Access L NANG LUONG + co Denghi_*/Duyet*).
        if (! Schema::hasTable('salary_round_items')) {
            Schema::create('salary_round_items', function (Blueprint $table) {
                $table->id();
                $table->foreignId('round_id')->constrained('salary_rounds')->cascadeOnDelete();
                $table->unsignedBigInteger('user_id');
                $table->string('old_scale_code', 20)->nullable();
                $table->decimal('old_coefficient', 5, 2)->nullable();
                $table->unsignedTinyInteger('old_seniority_percent')->default(0);
                $table->string('old_rank_code', 50)->nullable();
                $table->date('old_received_at')->nullable();
                $table->string('new_scale_code', 20)->nullable();
                $table->decimal('new_coefficient', 5, 2)->nullable();
                $table->unsignedTinyInteger('new_seniority_percent')->nullable();
                $table->string('new_rank_code', 50)->nullable();
                $table->date('new_received_at')->nullable();
                $table->decimal('reserved_coefficient', 5, 2)->default(0);
                $table->string('reason', 255)->nullable();
                $table->unsignedSmallInteger('extend_months')->nullable();
                $table->boolean('selected')->default(false);
                $table->boolean('approved')->default(false);
                $table->string('note', 255)->nullable();
                $table->timestamps();
                $table->unique(['round_id', 'user_id']);
            });
        }

        if (! Schema::hasTable('salary_decisions')) {
            Schema::create('salary_decisions', function (Blueprint $table) {
                $table->id();
                $table->foreignId('round_id')->constrained('salary_rounds')->cascadeOnDelete();
                $table->string('decision_no', 50);
                $table->date('signed_at');
                $table->string('signer', 255);
                $table->string('signer_title', 255);
                $table->string('copy_no', 50)->nullable();
                $table->string('copy_signer', 255)->nullable();
                $table->string('copy_signer_title', 255)->nullable();
                $table->timestamp('applied_at')->nullable();
                $table->unsignedBigInteger('applied_by')->nullable();
                $table->timestamps();
            });
        }

        // Can cu + tham so van ban theo loai (Access Lam viec id=2) - docs/salary/access-spec/can-cu.md.
        if (! Schema::hasTable('salary_decision_settings')) {
            Schema::create('salary_decision_settings', function (Blueprint $table) {
                $table->id();
                $table->string('raise_type', 20)->unique();
                $table->text('title')->nullable();
                $table->text('legal_basis')->nullable();
                $table->string('issuer_parent', 255)->nullable();
                $table->string('issuer', 255)->nullable();
                $table->string('decider_title', 255)->nullable();
                $table->string('signer_title', 255)->nullable();
                $table->string('signer', 255)->nullable();
                $table->text('recipients')->nullable();
                $table->string('doc_suffix', 50)->nullable();
                $table->string('place', 100)->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('salary_decision_settings');
        Schema::dropIfExists('salary_decisions');
        Schema::dropIfExists('salary_round_items');
        Schema::dropIfExists('salary_rounds');
        Schema::dropIfExists('salary_histories');
        Schema::dropIfExists('salary_profiles');
        Schema::dropIfExists('salary_scales');
        Schema::dropIfExists('salary_rule_settings');
    }
};
