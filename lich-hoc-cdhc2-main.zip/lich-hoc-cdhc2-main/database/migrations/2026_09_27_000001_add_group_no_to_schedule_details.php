<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Chia tổ/nhóm tiết thực hành (TKB_DONG 27/09): 1 tiết thực hành của lớp có thể tách N tổ, mỗi tổ 1 dòng
 * schedule_details (phòng + GV riêng). `group_no` null = tiết không chia tổ (toàn bộ dữ liệu cũ giữ nguyên).
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('schedule_details', 'group_no')) {
            Schema::table('schedule_details', function (Blueprint $table) {
                $table->unsignedTinyInteger('group_no')->nullable()->after('period')->comment('Tổ/nhóm thực hành (null = không chia tổ)');
                $table->index(['training_schedule_id', 'date', 'period'], 'schedule_details_ts_date_period_idx');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('schedule_details', 'group_no')) {
            Schema::table('schedule_details', function (Blueprint $table) {
                $table->dropIndex('schedule_details_ts_date_period_idx');
                $table->dropColumn('group_no');
            });
        }
    }
};
