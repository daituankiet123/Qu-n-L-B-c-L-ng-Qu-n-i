<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * TKB_DONG 28/09: lịch có class_id nhưng thiếu class_code -> các màn hình đọc lớp qua class_code hiện "—".
 * Điền class_code = mã lớp theo class_id. Chỉ đụng dòng đang trống; không rollback (không biết giá trị cũ là rỗng hay không).
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('training_schedules') || ! Schema::hasColumn('training_schedules', 'class_id')) {
            return;
        }

        DB::table('training_schedules')
            ->whereNotNull('class_id')
            ->where(fn ($q) => $q->whereNull('class_code')->orWhere('class_code', ''))
            ->orderBy('id')
            ->select(['id', 'class_id'])
            ->chunkById(200, function ($rows) {
                $codes = DB::table('classes')->whereIn('id', $rows->pluck('class_id'))->pluck('code', 'id');
                foreach ($rows as $row) {
                    $code = $codes[$row->class_id] ?? null;
                    if ($code) {
                        DB::table('training_schedules')->where('id', $row->id)->update(['class_code' => $code]);
                    }
                }
            });
    }

    public function down(): void
    {
        // Một chiều: không xoá class_code đã điền.
    }
};
