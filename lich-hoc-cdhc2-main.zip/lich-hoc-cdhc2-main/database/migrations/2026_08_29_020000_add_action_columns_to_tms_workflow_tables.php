<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Gắn "Loại hành động" cho mỗi dây nối (label ở tms_workflow_edges đã dùng
 * làm tên "Hành động"), và ghi lại đúng hành động đã thực hiện trên mỗi
 * bước xử lý văn bản — để luồng xử lý không chỉ là gợi ý mà thực sự ràng
 * buộc: chọn hành động nào thì chỉ được đi đúng (các) nhánh khớp hành động đó.
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('tms_workflow_edges', function (Blueprint $table) {
            $table->string('action_type')->nullable()->after('label');
        });
        Schema::table('tms_document_steps', function (Blueprint $table) {
            $table->string('action')->nullable()->after('instruction');
        });
    }

    public function down(): void
    {
        Schema::table('tms_workflow_edges', function (Blueprint $table) {
            $table->dropColumn('action_type');
        });
        Schema::table('tms_document_steps', function (Blueprint $table) {
            $table->dropColumn('action');
        });
    }
};
