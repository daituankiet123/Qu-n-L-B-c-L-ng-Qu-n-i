<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    // Commit "cap nhat day du module quan ly phep" them sap xep "Phep them"
    // theo sort_order (request-create.blade.php: ->orderBy('sort_order')...)
    // nhung khong kem migration them cot nay vao leave_regulations - thieu
    // cot gay loi 500 "Unknown column 'sort_order'" ngay khi mo trang De xuat.
    public function up(): void
    {
        if (! Schema::hasColumn('leave_regulations', 'sort_order')) {
            Schema::table('leave_regulations', function (Blueprint $table): void {
                $table->unsignedInteger('sort_order')->default(0)->after('label');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('leave_regulations', 'sort_order')) {
            Schema::table('leave_regulations', function (Blueprint $table): void {
                $table->dropColumn('sort_order');
            });
        }
    }
};
