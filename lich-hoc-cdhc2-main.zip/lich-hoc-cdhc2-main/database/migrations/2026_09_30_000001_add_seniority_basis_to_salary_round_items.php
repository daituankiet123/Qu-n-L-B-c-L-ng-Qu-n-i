<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TNVK theo moc ngay (chu du an chot 30/09/2026): luu cach tinh + co "can doi chieu" tren tung dong de nghi,
 * va snapshot ngay chuyen luong cu de tinh lai / chong ap dung khi luong nguon da doi.
 */
return new class extends Migration
{
    protected $connection = 'salary';

    public function up(): void
    {
        Schema::connection('salary')->table('salary_round_items', function (Blueprint $table) {
            $table->date('old_check_received_at')->nullable()->after('old_received_at');
            $table->string('seniority_basis', 255)->nullable()->after('new_seniority_percent');
            $table->boolean('seniority_issue')->default(false)->after('seniority_basis');
        });
    }

    public function down(): void
    {
        Schema::connection('salary')->table('salary_round_items', function (Blueprint $table) {
            $table->dropColumn(['old_check_received_at', 'seniority_basis', 'seniority_issue']);
        });
    }
};
