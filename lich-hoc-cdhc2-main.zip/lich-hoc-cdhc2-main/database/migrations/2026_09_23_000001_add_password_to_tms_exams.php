<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        if (! Schema::hasColumn('tms_exams', 'password')) {
            Schema::table('tms_exams', function (Blueprint $table) {
                $table->string('password')->nullable()->after('pass_score');
            });
        }
    }

    public function down(): void
    {
        Schema::table('tms_exams', function (Blueprint $table) {
            $table->dropColumn('password');
        });
    }
};
