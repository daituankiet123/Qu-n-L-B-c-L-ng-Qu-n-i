<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        if (! Schema::hasTable('tms_course_user')) {
            Schema::create('tms_course_user', function (Blueprint $table) {
                $table->id();
                $table->foreignId('course_id')->constrained('tms_courses')->cascadeOnDelete();
                $table->foreignId('user_id')->constrained(DbRef::forMigration('users'))->cascadeOnDelete();
                $table->string('role')->nullable()->comment('Vai trò trong khóa: học viên/cán bộ giảng dạy/...');
                $table->timestamps();
                $table->unique(['course_id', 'user_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_course_user');
    }
};
