<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::create('tms_documents', function (Blueprint $table) {
            $table->id();
            $table->enum('direction', ['in', 'out']);
            $table->string('doc_number')->nullable();
            $table->string('subject');
            $table->date('doc_date')->nullable();
            $table->string('counterpart')->nullable();
            $table->string('file_path')->nullable();
            $table->enum('status', ['open', 'processing', 'done'])->default('open');
            $table->foreignId('created_by')->constrained(DbRef::forMigration('users'));
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('tms_document_steps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('document_id')->constrained('tms_documents')->cascadeOnDelete();
            $table->unsignedInteger('step_order');
            $table->foreignId('unit_id')->nullable()->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $table->foreignId('position_id')->nullable()->constrained(DbRef::forMigration('standard_positions'))->nullOnDelete();
            $table->foreignId('assigned_to')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->text('instruction')->nullable();
            $table->enum('status', ['pending', 'done'])->default('pending');
            $table->foreignId('acted_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamp('acted_at')->nullable();
            $table->text('note')->nullable();
            $table->foreignId('created_by')->constrained(DbRef::forMigration('users'));
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_document_steps');
        Schema::dropIfExists('tms_documents');
    }
};
