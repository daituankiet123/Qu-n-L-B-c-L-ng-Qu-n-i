<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TMS Phase "Task/Distribution" — tach nhiem vu cap tren giao ra khoi
 * assignment ca nhan, phan anh dung luong nghiep vu:
 *
 *   Task (cap tren tao, giao cho 1..N don vi)
 *     -> TaskUnit (1 don vi nhan, trang thai tiep nhan/phan cong)
 *          -> Assignment (nguoi phu trach don vi phan cong xuong ca nhan,
 *             tai su dung nguyen ven tms_assignments/tms_assignment_targets
 *             da co - chi them cot lien ket nullable, KHONG doi/xoa cot cu).
 *
 * An toan: chi CREATE bang moi + 1 cot nullable tren bang cu. Luong tao
 * assignment truc tiep (khong qua Task) van hoat dong y het truoc gio vi
 * task_unit_id cho phep NULL.
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::create('tms_tasks', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('assignable_type')->nullable(); // TmsCourse|TmsExam - noi dung nguon (neu co)
            $table->unsignedBigInteger('assignable_id')->nullable();
            $table->timestamp('due_at')->nullable();
            $table->unsignedTinyInteger('min_score')->nullable();
            // draft: chua issue: issued: da giao cho cac don vi; cancelled: huy; closed: da dong (het han/hoan tat)
            $table->string('status', 20)->default('issued');
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['assignable_type', 'assignable_id']);
            $table->index('status');
        });

        Schema::create('tms_task_units', function (Blueprint $table) {
            $table->id();
            $table->foreignId('task_id')->constrained('tms_tasks')->cascadeOnDelete();
            $table->foreignId('unit_id')->constrained(DbRef::forMigration('units'))->cascadeOnDelete();
            // pending: cho tiep nhan; accepted: da tiep nhan chua phan cong het;
            // fully_assigned: da phan cong het so nguoi; completed: toan bo ca nhan hoan thanh; overdue.
            $table->string('status', 20)->default('pending');
            $table->foreignId('accepted_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamp('accepted_at')->nullable();
            $table->timestamps();

            $table->unique(['task_id', 'unit_id']);
            $table->index(['unit_id', 'status']);
        });

        Schema::table('tms_assignments', function (Blueprint $table) {
            $table->foreignId('task_unit_id')->nullable()->after('assignable_id')
                ->constrained('tms_task_units')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('tms_assignments', function (Blueprint $table) {
            $table->dropConstrainedForeignId('task_unit_id');
        });
        Schema::dropIfExists('tms_task_units');
        Schema::dropIfExists('tms_tasks');
    }
};
