<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::create('tms_document_numbering_configs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('unit_id')->nullable()->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $table->enum('direction', ['in', 'out']);
            $table->string('prefix', 20)->default('CV');
            $table->string('pattern')->default('{prefix}/{sequence}/{year}');
            $table->unsignedInteger('current_sequence')->default(0);
            $table->unsignedSmallInteger('current_year')->default(0);
            $table->boolean('reset_yearly')->default(true);
            $table->foreignId('created_by')->constrained(DbRef::forMigration('users'));
            $table->timestamps();

            $table->unique(['unit_id', 'direction']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_document_numbering_configs');
    }
};
