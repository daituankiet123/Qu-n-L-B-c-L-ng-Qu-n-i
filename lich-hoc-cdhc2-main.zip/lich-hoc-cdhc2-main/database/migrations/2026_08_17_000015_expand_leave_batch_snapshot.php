<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('leave_requests', function (Blueprint $t): void {
            $t->dropForeign(['personnel_id']);
            $t->unsignedBigInteger('personnel_id')->nullable()->change();
            $t->foreign('personnel_id')->references('id')->on('leave_personnel')->nullOnDelete();
        });
        Schema::table('leave_batches', function (Blueprint $t): void {
            $t->foreignId('personnel_id')->nullable()->constrained('leave_personnel')->nullOnDelete();
            $t->string('personnel_code')->nullable();
            $t->string('personnel_name')->nullable();
            $t->string('object_type')->nullable();
            $t->string('leave_type')->nullable();
            $t->unsignedInteger('batch_index')->default(1);
            $t->string('batch_label')->nullable();
            $t->foreignId('created_by_user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('leave_batches', function (Blueprint $t): void {
            $t->dropForeign(['personnel_id']);
            $t->dropForeign(['created_by_user_id']);
            $t->dropColumn(['personnel_id', 'personnel_code', 'personnel_name', 'object_type', 'leave_type', 'batch_index', 'batch_label', 'created_by_user_id']);
        });
        Schema::table('leave_requests', function (Blueprint $t): void {
            $t->dropForeign(['personnel_id']);
            $t->unsignedBigInteger('personnel_id')->nullable(false)->change();
            $t->foreign('personnel_id')->references('id')->on('leave_personnel')->cascadeOnDelete();
        });
    }
};
