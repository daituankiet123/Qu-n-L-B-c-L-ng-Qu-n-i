<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * TMS — Giai đoạn 2: Chứng chỉ/tái đào tạo + Đào tạo trực tiếp (offline).
 *
 * Tách biệt hoàn toàn với modules/Lms, tiếp nối schema `tms_*` của giai đoạn 1
 * (xem 2026_08_21_100000_create_tms_tables.php).
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::create('tms_certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained(DbRef::forMigration('users'))->cascadeOnDelete();
            $table->foreignId('course_id')->constrained('tms_courses')->cascadeOnDelete();
            $table->string('code')->unique();
            $table->timestamp('issued_at');
            $table->timestamp('expires_at')->nullable();
            $table->string('status', 20)->default('active'); // active|expired|revoked
            $table->unsignedBigInteger('template_id')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'course_id']);
            $table->index(['status', 'expires_at']);
        });

        Schema::create('tms_recertification_cycles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained('tms_courses')->cascadeOnDelete();
            $table->unsignedSmallInteger('cycle_months');
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();

            $table->unique('course_id');
        });

        Schema::create('tms_offline_sessions', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->timestamp('starts_at');
            $table->timestamp('ends_at');
            $table->string('location')->nullable();
            $table->foreignId('instructor_user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->string('mode', 10)->default('admin'); // qr|otp|admin
            $table->string('checkin_token')->nullable()->unique();
            $table->string('otp_code', 10)->nullable();
            $table->foreignId('course_id')->nullable()->constrained('tms_courses')->nullOnDelete();
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['starts_at', 'ends_at']);
        });

        Schema::create('tms_offline_attendance', function (Blueprint $table) {
            $table->id();
            $table->foreignId('session_id')->constrained('tms_offline_sessions')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained(DbRef::forMigration('users'))->cascadeOnDelete();
            $table->string('status', 20)->default('present'); // present|absent
            $table->timestamp('checked_in_at')->nullable();
            $table->timestamps();

            $table->unique(['session_id', 'user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_offline_attendance');
        Schema::dropIfExists('tms_offline_sessions');
        Schema::dropIfExists('tms_recertification_cycles');
        Schema::dropIfExists('tms_certificates');
    }
};
