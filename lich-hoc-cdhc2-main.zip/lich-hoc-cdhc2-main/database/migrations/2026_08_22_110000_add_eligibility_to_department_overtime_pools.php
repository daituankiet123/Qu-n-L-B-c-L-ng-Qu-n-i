<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Quy tac moi (theo yeu cau nguoi dung): neu bo mon co DU 1 giang vien
 * khong dat dieu kien (meets_overall=false, bao gom ca truong hop khong
 * dat toi thieu 50% dung lop truc tiep - meets_classroom), thi CA BO MON
 * khong duoc xet vuot dinh muc ky do - khong duoc lay gio vuot cua GV khac
 * de "bu" trong pool chung. Chi them cot, khong doi/xoa gi cu.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('department_overtime_pools', function (Blueprint $table) {
            $table->boolean('is_eligible')->default(true)->after('member_snapshot');
            $table->string('ineligibility_reason')->nullable()->after('is_eligible');
        });
    }

    public function down(): void
    {
        Schema::table('department_overtime_pools', function (Blueprint $table) {
            $table->dropColumn(['is_eligible', 'ineligibility_reason']);
        });
    }
};
