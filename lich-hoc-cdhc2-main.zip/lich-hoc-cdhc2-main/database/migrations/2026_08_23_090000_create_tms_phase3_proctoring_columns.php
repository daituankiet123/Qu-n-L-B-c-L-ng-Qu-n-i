<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    /**
     * Giai đoạn 3 — giám sát thi cơ bản (proctoring) trên tms_exams/tms_exam_attempts.
     * Không đụng migration Phase 1/2 — chỉ thêm cột mới, mọi cột đều có default an toàn
     * (bool default false / int default 0 / nullable) nên không phá dữ liệu hiện có.
     */
    public function up(): void
    {
        Schema::table('tms_exams', function (Blueprint $table) {
            $table->boolean('proctor_basic')->default(false)->after('generation_rule');
            $table->boolean('require_fullscreen')->default(false)->after('proctor_basic');
            $table->unsignedInteger('max_blur_events')->nullable()->after('require_fullscreen');
            $table->boolean('single_device_lock')->default(false)->after('max_blur_events');
            $table->boolean('ip_lock')->default(false)->after('single_device_lock');
        });

        Schema::table('tms_exam_attempts', function (Blueprint $table) {
            $table->string('client_ip', 45)->nullable()->after('submitted_at');
            $table->string('device_fingerprint', 128)->nullable()->after('client_ip');
            $table->unsignedInteger('blur_event_count')->default(0)->after('device_fingerprint');
            $table->json('action_log')->nullable()->after('blur_event_count');
            $table->boolean('flagged')->default(false)->after('action_log');
            $table->string('flagged_reason')->nullable()->after('flagged');
        });
    }

    public function down(): void
    {
        Schema::table('tms_exam_attempts', function (Blueprint $table) {
            $table->dropColumn(['client_ip', 'device_fingerprint', 'blur_event_count', 'action_log', 'flagged', 'flagged_reason']);
        });

        Schema::table('tms_exams', function (Blueprint $table) {
            $table->dropColumn(['proctor_basic', 'require_fullscreen', 'max_blur_events', 'single_device_lock', 'ip_lock']);
        });
    }
};
