<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Form F CAN BO NHAN VIEN (Access QLNL) - chu du an muon clone nguyen Access (28/09):
 * ngay tang + ly do tang, ngay giam + ly do giam (in DS khong con quan ly), don vi den.
 * Que quan / tru quan / dia chi la thong tin cua NGUOI -> luu o `users` (core, dia gioi 2 cap), salary chi doc sang.
 */
return new class extends Migration
{
    protected $connection = 'salary';

    public function up(): void
    {
        Schema::connection('salary')->table('salary_profiles', function (Blueprint $table) {
            $table->date('increased_at')->nullable()->after('position_title');           // Ngaytang
            $table->string('increase_reason', 255)->nullable()->after('increased_at');   // Lydo_tang
            $table->date('decreased_at')->nullable()->after('increase_reason');          // Ngaygiam
            $table->string('decrease_reason', 255)->nullable()->after('decreased_at');   // Lydo_giam
            $table->string('transfer_unit', 255)->nullable()->after('decrease_reason');  // Don vi den
        });
    }

    public function down(): void
    {
        Schema::connection('salary')->table('salary_profiles', function (Blueprint $table) {
            $table->dropColumn(['increased_at', 'increase_reason', 'decreased_at', 'decrease_reason', 'transfer_unit']);
        });
    }
};
