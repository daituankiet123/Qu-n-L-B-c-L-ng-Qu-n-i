<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Dang nhap 1 thiet bi + "Lan dang nhap truoc":
 * - current_login_*: phien dang nhap hien tai; last_login_*: lan dang nhap TRUOC do (hien cho nguoi dung).
 * - session_token: token cua phien hop le duy nhat; phien nao mang token khac -> bi dang xuat ("da dang nhap o may khac").
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_ip', 45)->nullable();
            $table->string('last_login_user_agent', 255)->nullable();
            $table->timestamp('current_login_at')->nullable();
            $table->string('current_login_ip', 45)->nullable();
            $table->string('current_login_user_agent', 255)->nullable();
            $table->string('session_token', 64)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'last_login_at', 'last_login_ip', 'last_login_user_agent',
                'current_login_at', 'current_login_ip', 'current_login_user_agent', 'session_token',
            ]);
        });
    }
};
