<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('inventory_materials', function (Blueprint $t): void {
            $t->decimal('min_quantity', 14, 2)->default(0);
            $t->decimal('price', 14, 2)->default(0);
            $t->string('status', 30)->default('ACTIVE');
            $t->unsignedInteger('manufacture_year')->nullable();
            $t->unsignedInteger('usage_year')->nullable();
            $t->string('classification')->nullable();
            $t->string('asset_status', 30)->default('NORMAL');
            $t->date('purchase_date')->nullable();
            $t->date('expiry_date')->nullable();
            $t->text('description')->nullable();
        });
        Schema::table('inventory_assets', function (Blueprint $t): void {
            $t->decimal('broken_quantity', 14, 2)->default(0);
            $t->foreignId('holding_unit_id')->nullable()->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $t->unsignedTinyInteger('grade')->default(1);
            $t->unsignedInteger('manufacture_year')->nullable();
            $t->unsignedInteger('usage_year')->nullable();
            $t->string('install_address')->nullable();
            $t->date('broken_at')->nullable();
            $t->date('repair_started_at')->nullable();
            $t->date('repair_completed_at')->nullable();
            $t->string('repair_performer')->nullable();
            $t->text('description')->nullable();
        });
        Schema::table('inventory_proposals', function (Blueprint $t): void {
            $t->string('proposal_code')->nullable();
            $t->string('nganh_code')->nullable();
            $t->string('decision_issuing_level')->nullable();
            $t->string('decision_signer')->nullable();
            $t->timestamp('completed_at')->nullable();
            $t->foreignId('proposed_by_user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $t->string('proposed_by_username')->nullable();
            $t->string('proposed_by_display_name')->nullable();
        });
        Schema::table('inventory_proposal_items', function (Blueprint $t): void {
            $t->string('material_code')->nullable();
            $t->string('material_name')->nullable();
            $t->string('category')->nullable();
            $t->string('nganh_code')->nullable();
            $t->string('chuyen_nganh_code')->nullable();
            $t->foreignId('source_asset_id')->nullable()->constrained('inventory_assets')->nullOnDelete();
            $t->unsignedTinyInteger('original_grade')->nullable();
            $t->string('original_code')->nullable();
            $t->foreignId('from_classroom_id')->nullable()->constrained(DbRef::forMigration('classrooms'))->nullOnDelete();
            $t->string('from_room_code')->nullable();
            $t->string('from_room_name')->nullable();
            $t->text('location_note')->nullable();
            $t->foreignId('target_room_id')->nullable()->constrained(DbRef::forMigration('classrooms'))->nullOnDelete();
            $t->string('target_room_code')->nullable();
            $t->string('target_room_name')->nullable();
        });
        Schema::table('inventory_repairs', function (Blueprint $t): void {
            $t->string('source_type')->default('REPAIR_REQUEST');
            $t->foreignId('requested_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $t->string('performer')->nullable();
            $t->date('started_at')->nullable();
            $t->text('result_note')->nullable();
        });
        Schema::table('inventory_transfers', function (Blueprint $t): void {
            $t->timestamp('decided_at')->nullable();
            $t->string('decision_number')->nullable();
        });
        Schema::create('inventory_broken_logs', function (Blueprint $t): void {
            $t->id();
            $t->string('event_type');
            $t->string('source_type')->default('OTHER');
            $t->unsignedBigInteger('source_id')->nullable();
            $t->foreignId('asset_id')->nullable()->constrained('inventory_assets')->nullOnDelete();
            $t->string('asset_code')->nullable();
            $t->string('asset_name');
            $t->decimal('quantity', 14, 2)->default(1);
            $t->unsignedTinyInteger('original_grade')->nullable();
            $t->unsignedTinyInteger('grade_after')->nullable();
            $t->string('status_after')->nullable();
            $t->text('reason')->nullable();
            $t->text('result_note')->nullable();
            $t->string('performer')->nullable();
            $t->timestamp('event_at');
            $t->foreignId('actor_user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('inventory_broken_logs');
        Schema::table('inventory_transfers', function (Blueprint $t): void {
            $t->dropColumn(['decided_at', 'decision_number']);
        });
        Schema::table('inventory_repairs', function (Blueprint $t): void {
            $t->dropForeign(['requested_by']);
            $t->dropColumn(['source_type', 'requested_by', 'performer', 'started_at', 'result_note']);
        });
        Schema::table('inventory_proposal_items', function (Blueprint $t): void {
            $t->dropForeign(['source_asset_id']);
            $t->dropForeign(['from_classroom_id']);
            $t->dropForeign(['target_room_id']);
            $t->dropColumn(['material_code', 'material_name', 'category', 'nganh_code', 'chuyen_nganh_code', 'source_asset_id', 'original_grade', 'original_code', 'from_classroom_id', 'from_room_code', 'from_room_name', 'location_note', 'target_room_id', 'target_room_code', 'target_room_name']);
        });
        Schema::table('inventory_proposals', function (Blueprint $t): void {
            $t->dropForeign(['proposed_by_user_id']);
            $t->dropColumn(['proposal_code', 'nganh_code', 'decision_issuing_level', 'decision_signer', 'completed_at', 'proposed_by_user_id', 'proposed_by_username', 'proposed_by_display_name']);
        });
        Schema::table('inventory_assets', function (Blueprint $t): void {
            $t->dropForeign(['holding_unit_id']);
            $t->dropColumn(['broken_quantity', 'holding_unit_id', 'grade', 'manufacture_year', 'usage_year', 'install_address', 'broken_at', 'repair_started_at', 'repair_completed_at', 'repair_performer', 'description']);
        });
        Schema::table('inventory_materials', function (Blueprint $t): void {
            $t->dropColumn(['min_quantity', 'price', 'status', 'manufacture_year', 'usage_year', 'classification', 'asset_status', 'purchase_date', 'expiry_date', 'description']);
        });
    }
};
