<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'lms';

    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('lms_exams', function (Blueprint $table) {
            $table->string('exam_type', 10)->default('kttx')->after('title');
            $table->unsignedTinyInteger('attempt')->default(1)->after('exam_type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('lms_exams', function (Blueprint $table) {
            $table->dropColumn(['exam_type', 'attempt']);
        });
    }
};
