<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Mẫu xuất LHL kiểu canvas kéo-thả tự do: mỗi field được đặt ở toạ độ
 * x/y/width/height tuỳ ý trên khổ giấy, thay vì bám theo lưới ô có sẵn của
 * file mẫu gốc (như export_template_bindings) hay khối tuyến tính (như
 * export_template_builder_documents). "schema" lưu toàn bộ danh sách block
 * + vị trí + style, dùng chung để render preview và (ở giai đoạn sau) xuất
 * PDF/Excel/Word.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lhl_canvas_templates', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->unsignedInteger('page_width_mm')->default(297); // A4 ngang mặc định
            $table->unsignedInteger('page_height_mm')->default(210);
            $table->json('schema')->nullable(); // { blocks: [{id,type,field_key,label,x,y,width,height,style{}}] }
            $table->boolean('is_active')->default(false);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lhl_canvas_templates');
    }
};
