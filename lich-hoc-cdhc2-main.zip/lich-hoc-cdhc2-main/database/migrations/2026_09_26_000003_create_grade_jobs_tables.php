<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Buoc 4A: queue cua service grades nam trong DB cua chinh no. Bang job cung DB voi du lieu nghiep vu
 * -> dispatch trong transaction la atomic (bang job dong vai outbox). Schema giong jobs/failed_jobs.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        if (! Schema::hasTable('grade_jobs')) {
            Schema::create('grade_jobs', function (Blueprint $table) {
                $table->id();
                $table->string('queue')->index();
                $table->longText('payload');
                $table->unsignedTinyInteger('attempts');
                $table->unsignedInteger('reserved_at')->nullable();
                $table->unsignedInteger('available_at');
                $table->unsignedInteger('created_at');
            });
        }

        if (! Schema::hasTable('grade_failed_jobs')) {
            Schema::create('grade_failed_jobs', function (Blueprint $table) {
                $table->id();
                $table->string('uuid')->unique();
                $table->text('connection');
                $table->text('queue');
                $table->longText('payload');
                $table->longText('exception');
                $table->timestamp('failed_at')->useCurrent();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('grade_failed_jobs');
        Schema::dropIfExists('grade_jobs');
    }
};
