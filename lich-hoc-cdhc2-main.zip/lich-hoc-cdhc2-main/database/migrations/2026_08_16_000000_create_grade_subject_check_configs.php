<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Cho phép Khoa ghi đè số lần KTTX/KTĐK theo môn (mặc định hệ thống tính theo
 * tín chỉ — GradeSettings::columnCountsForCredits()). null = dùng mặc định.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        if (! Schema::hasTable('grade_subject_check_configs')) {
            Schema::create('grade_subject_check_configs', function (Blueprint $table) {
                $table->id();
                $table->foreignId('subject_id')->unique()->constrained(DbRef::forMigration('subjects'))->cascadeOnDelete();
                $table->unsignedTinyInteger('kttx_count')->nullable();
                $table->unsignedTinyInteger('ktdk_count')->nullable();
                $table->foreignId('updated_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('grade_subject_check_configs');
    }
};
