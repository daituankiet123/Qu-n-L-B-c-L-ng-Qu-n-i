<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * "Đơn vị quản lý" của lớp lâu nay là ô chữ gõ tay (classes.management_unit)
 * nên mỗi người ghi một kiểu, không lọc hay thống kê theo đơn vị được.
 *
 * Giờ đã có cây đơn vị nên cho chọn từ cây. Giữ luôn cột chữ cũ và ghi tên
 * đơn vị vào đó mỗi lần lưu, để mọi chỗ đang hiển thị management_unit không
 * phải sửa và dữ liệu lớp cũ vẫn đọc được.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('classes', function (Blueprint $table) {
            $table->foreignId('management_unit_id')->nullable()->after('management_unit')->constrained('units')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('classes', function (Blueprint $table) {
            $table->dropConstrainedForeignId('management_unit_id');
        });
    }
};
