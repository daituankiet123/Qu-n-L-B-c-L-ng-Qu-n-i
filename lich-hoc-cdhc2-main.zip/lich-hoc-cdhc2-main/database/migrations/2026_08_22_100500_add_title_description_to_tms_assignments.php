<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * tms_assignments gio co the la "quest" tu do (khong gan course/exam) - can
 * co title/description rieng lam ten hien thi, vi truoc day ten hien thi
 * hoan toan dua vao assignable->title (se null neu la quest tu do khong
 * gan noi dung dao tao nao).
 */
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('tms_assignments', function (Blueprint $table) {
            $table->string('title')->nullable()->after('assignable_id');
            $table->text('description')->nullable()->after('title');
        });
    }

    public function down(): void
    {
        Schema::table('tms_assignments', function (Blueprint $table) {
            $table->dropColumn(['title', 'description']);
        });
    }
};
