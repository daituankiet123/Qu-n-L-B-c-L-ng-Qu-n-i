<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * ineligibility_reason liệt kê tên TẤT CẢ giảng viên chưa đạt điều kiện
 * trong bộ môn, không giới hạn số lượng — với bộ môn đông người dễ vượt
 * quá 255 ký tự của VARCHAR mặc định (lỗi "Data too long for column").
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('department_overtime_pools', function (Blueprint $table) {
            $table->text('ineligibility_reason')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('department_overtime_pools', function (Blueprint $table) {
            $table->string('ineligibility_reason')->nullable()->change();
        });
    }
};
