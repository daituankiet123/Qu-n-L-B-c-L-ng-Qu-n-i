<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Sprint 1 — Nền tảng LMS học tập.
 * Tận dụng subjects, classes, instructors, users — không nhân bản CTĐT/lịch.
 */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::connection('lms')->hasTable('lms_courses')) {
            Schema::connection('lms')->create('lms_courses', function (Blueprint $table) {
                $table->id();
                $table->string('code', 80)->nullable()->index();
                $table->string('title');
                $table->text('description')->nullable();
                $table->foreignId('subject_id')->constrained(DbRef::forMigration('subjects', 'lms'))->cascadeOnDelete();
                $table->foreignId('class_id')->constrained(DbRef::forMigration('classes', 'lms'))->cascadeOnDelete();
                $table->foreignId('instructor_id')->nullable()->constrained(DbRef::forMigration('instructors', 'lms'))->nullOnDelete();
                $table->string('status', 20)->default('draft')->index(); // draft|published|archived
                $table->date('starts_at')->nullable();
                $table->date('ends_at')->nullable();
                $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users', 'lms'))->nullOnDelete();
                $table->foreignId('updated_by')->nullable()->constrained(DbRef::forMigration('users', 'lms'))->nullOnDelete();
                $table->timestamps();
                $table->softDeletes();

                // Một course LMS active cho mỗi cặp môn + lớp (soft-delete xử lý ở app)
                $table->unique(['subject_id', 'class_id'], 'lms_courses_subject_class_unique');
            });
        }

        if (! Schema::connection('lms')->hasTable('lms_course_members')) {
            Schema::connection('lms')->create('lms_course_members', function (Blueprint $table) {
                $table->id();
                $table->foreignId('lms_course_id')->constrained('lms_courses')->cascadeOnDelete();
                $table->foreignId('user_id')->constrained(DbRef::forMigration('users', 'lms'))->cascadeOnDelete();
                $table->string('role', 20)->default('student'); // student|lecturer|assistant
                $table->timestamp('joined_at')->nullable();
                $table->timestamps();

                $table->unique(['lms_course_id', 'user_id']);
                $table->index(['user_id', 'role']);
            });
        }

        if (! Schema::connection('lms')->hasTable('lms_lessons')) {
            Schema::connection('lms')->create('lms_lessons', function (Blueprint $table) {
                $table->id();
                $table->foreignId('lms_course_id')->constrained('lms_courses')->cascadeOnDelete();
                // Tuỳ chọn: map bài khung CTĐT (subject_lessons) — không bắt buộc
                $table->unsignedBigInteger('subject_lesson_id')->nullable()->index();
                $table->string('title');
                $table->text('summary')->nullable();
                $table->longText('content')->nullable();
                $table->unsignedSmallInteger('sort_order')->default(0);
                $table->unsignedSmallInteger('week_number')->nullable();
                $table->boolean('is_published')->default(false);
                $table->timestamp('published_at')->nullable();
                $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users', 'lms'))->nullOnDelete();
                $table->foreignId('updated_by')->nullable()->constrained(DbRef::forMigration('users', 'lms'))->nullOnDelete();
                $table->timestamps();
                $table->softDeletes();

                $table->index(['lms_course_id', 'sort_order']);
            });

            if (Schema::hasTable('subject_lessons')) {
                try {
                    Schema::connection('lms')->table('lms_lessons', function (Blueprint $table) {
                        $table->foreign('subject_lesson_id')
                            ->references('id')
                            ->on(DbRef::forMigration('subject_lessons', 'lms'))
                            ->nullOnDelete();
                    });
                } catch (Throwable $e) {
                    // FK optional
                }
            }
        }
    }

    public function down(): void
    {
        Schema::connection('lms')->dropIfExists('lms_lessons');
        Schema::connection('lms')->dropIfExists('lms_course_members');
        Schema::connection('lms')->dropIfExists('lms_courses');
    }
};
