<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::create('inventory_warehouses', function (Blueprint $table): void {
            $table->id();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->string('location')->nullable();
            $table->foreignId('manager_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
        Schema::create('inventory_assets', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('material_id')->nullable()->constrained('inventory_materials')->nullOnDelete();
            $table->foreignId('classroom_id')->nullable()->constrained(DbRef::forMigration('classrooms'))->nullOnDelete();
            $table->string('asset_code', 100)->unique();
            $table->string('name');
            $table->string('category')->nullable();
            $table->decimal('quantity', 14, 2)->default(1);
            $table->string('unit', 30)->nullable();
            $table->enum('status', ['NORMAL', 'BROKEN', 'REPAIRING', 'LIQUIDATED'])->default('NORMAL');
            $table->date('purchase_date')->nullable();
            $table->date('expiry_date')->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });
        Schema::create('inventory_repairs', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('asset_id')->constrained('inventory_assets')->cascadeOnDelete();
            $table->enum('status', ['OPEN', 'ASSIGNED', 'COMPLETED', 'CANCELLED'])->default('OPEN');
            $table->text('content');
            $table->foreignId('assigned_to')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->decimal('cost', 14, 2)->default(0);
            $table->text('result')->nullable();
            $table->date('opened_at')->nullable();
            $table->date('completed_at')->nullable();
            $table->timestamps();
        });
        Schema::create('inventory_transfers', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('asset_id')->nullable()->constrained('inventory_assets')->nullOnDelete();
            $table->foreignId('material_id')->nullable()->constrained('inventory_materials')->nullOnDelete();
            $table->foreignId('from_classroom_id')->nullable()->constrained(DbRef::forMigration('classrooms'))->nullOnDelete();
            $table->foreignId('to_classroom_id')->nullable()->constrained(DbRef::forMigration('classrooms'))->nullOnDelete();
            $table->enum('type', ['TRANSFER', 'RECALL']);
            $table->enum('status', ['PENDING', 'APPROVED', 'REJECTED', 'COMPLETED'])->default('PENDING');
            $table->foreignId('requested_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->foreignId('decided_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->text('reason')->nullable();
            $table->text('decision_note')->nullable();
            $table->timestamps();
        });
        Schema::create('inventory_proposals', function (Blueprint $table): void {
            $table->id();
            $table->enum('type', ['REPAIR', 'RECALL', 'LIQUIDATION', 'PURCHASE']);
            $table->enum('status', ['PENDING', 'APPROVED', 'REJECTED', 'COMPLETED'])->default('PENDING');
            $table->string('title');
            $table->text('description')->nullable();
            $table->foreignId('unit_id')->nullable()->constrained(DbRef::forMigration('units'))->nullOnDelete();
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->foreignId('decided_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->string('decision_number')->nullable();
            $table->text('decision_note')->nullable();
            $table->timestamp('decided_at')->nullable();
            $table->timestamps();
        });
        Schema::create('inventory_proposal_items', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('proposal_id')->constrained('inventory_proposals')->cascadeOnDelete();
            $table->foreignId('material_id')->nullable()->constrained('inventory_materials')->nullOnDelete();
            $table->foreignId('asset_id')->nullable()->constrained('inventory_assets')->nullOnDelete();
            $table->string('name');
            $table->decimal('quantity', 14, 2)->default(1);
            $table->string('unit', 30)->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });
        Schema::create('inventory_report_templates', function (Blueprint $table): void {
            $table->id();
            $table->string('code', 80)->unique();
            $table->string('name');
            $table->string('file_path')->nullable();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });

        Schema::create('leave_object_types', function (Blueprint $table): void {
            $table->id();
            $table->string('code', 30)->unique();
            $table->string('name');
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
        Schema::create('leave_localities', function (Blueprint $table): void {
            $table->id();
            $table->string('name');
            $table->string('level', 30);
            $table->foreignId('parent_id')->nullable()->constrained('leave_localities')->nullOnDelete();
            $table->string('code', 50)->nullable();
            $table->timestamps();
        });
        Schema::create('leave_regulations', function (Blueprint $table): void {
            $table->id();
            $table->string('leave_type', 50);
            $table->string('object_type', 30)->nullable();
            $table->unsignedInteger('min_years')->nullable();
            $table->unsignedInteger('max_years')->nullable();
            $table->unsignedInteger('base_days');
            $table->string('label')->nullable();
            $table->text('description')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
        Schema::create('leave_positions', function (Blueprint $table): void {
            $table->id();
            $table->string('name')->unique();
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();
        });
        Schema::create('leave_batches', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('request_id')->constrained('leave_requests')->cascadeOnDelete();
            $table->string('label');
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->unsignedInteger('total_days')->default(0);
            $table->text('note')->nullable();
            $table->foreignId('created_by')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->timestamps();
        });
        Schema::create('leave_records', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('request_id')->unique()->constrained('leave_requests')->cascadeOnDelete();
            $table->foreignId('personnel_id')->nullable()->constrained('leave_personnel')->nullOnDelete();
            $table->string('status', 30);
            $table->string('leave_type', 50);
            $table->unsignedInteger('total_days')->default(0);
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->text('note')->nullable();
            $table->timestamp('archived_at')->nullable();
            $table->timestamps();
        });
        Schema::create('leave_audit_logs', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained(DbRef::forMigration('users'))->nullOnDelete();
            $table->string('action', 80);
            $table->string('entity_type', 80);
            $table->unsignedBigInteger('entity_id')->nullable();
            $table->json('details')->nullable();
            $table->timestamps();
        });
        DB::table('leave_object_types')->insertOrIgnore([['code' => 'SQ', 'name' => 'Sĩ quan', 'sort_order' => 1, 'active' => 1, 'created_at' => now(), 'updated_at' => now()], ['code' => 'QNCN', 'name' => 'Quân nhân chuyên nghiệp', 'sort_order' => 2, 'active' => 1, 'created_at' => now(), 'updated_at' => now()], ['code' => 'CNQP', 'name' => 'Công nhân quốc phòng', 'sort_order' => 3, 'active' => 1, 'created_at' => now(), 'updated_at' => now()], ['code' => 'VCQP', 'name' => 'Viên chức quốc phòng', 'sort_order' => 4, 'active' => 1, 'created_at' => now(), 'updated_at' => now()], ['code' => 'HSQBS', 'name' => 'Hạ sĩ quan, binh sĩ', 'sort_order' => 5, 'active' => 1, 'created_at' => now(), 'updated_at' => now()], ['code' => 'HV', 'name' => 'Học viên', 'sort_order' => 6, 'active' => 1, 'created_at' => now(), 'updated_at' => now()]]);
    }

    public function down(): void
    {
        foreach (['leave_audit_logs', 'leave_records', 'leave_batches', 'leave_positions', 'leave_regulations', 'leave_localities', 'leave_object_types', 'inventory_report_templates', 'inventory_proposal_items', 'inventory_proposals', 'inventory_transfers', 'inventory_repairs', 'inventory_assets', 'inventory_warehouses'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
