<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

/**
 * Mở rộng enum "semester" của training_schedules từ semester_1..semester_6
 * lên semester_1..semester_7 (+ summer) - trang Tạo/Sửa lịch đào tạo cần
 * liệt kê đủ 7 học kỳ theo yêu cầu nghiệp vụ.
 */
return new class extends Migration
{
    public function up(): void
    {
        DB::statement("ALTER TABLE training_schedules MODIFY semester ENUM('semester_1','semester_2','semester_3','semester_4','semester_5','semester_6','semester_7','summer') NOT NULL");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE training_schedules MODIFY semester ENUM('semester_1','semester_2','semester_3','semester_4','semester_5','semester_6','summer') NOT NULL");
    }
};
