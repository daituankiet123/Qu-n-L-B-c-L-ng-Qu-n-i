<?php

use Cdhc2\Core\Support\DbRef;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    /**
     * Mot "cay thang" duy nhat — thu tu chuc vu xu ly van ban di/den mac
     * dinh cua toan truong (vd: Van thu -> Truong phong -> Pho hieu truong
     * -> Hieu truong). Don gian: khong can nhieu template, chi 1 danh sach
     * step_order tang dan.
     */
    public function up(): void
    {
        Schema::create('tms_workflow_steps', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('step_order');
            $table->foreignId('position_id')->constrained(DbRef::forMigration('standard_positions'))->cascadeOnDelete();
            $table->foreignId('created_by')->constrained(DbRef::forMigration('users'));
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tms_workflow_steps');
    }
};
