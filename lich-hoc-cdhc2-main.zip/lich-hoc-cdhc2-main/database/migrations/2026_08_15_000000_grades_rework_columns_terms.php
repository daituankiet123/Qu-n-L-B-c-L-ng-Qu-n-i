<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Đưa bảng điểm đúng Quy chế đào tạo (Điều 10-14):
 * - grade_columns: phân loại kttx|ktdk|exam để tính ĐTBKT/ĐKTM/ĐMH, exam có 2 lượt (attempt).
 * - grade_books / grade_graduation_sessions: thêm học kỳ để tách Tổng kết học kỳ khỏi năm/khóa.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        if (Schema::hasTable('grade_columns') && ! Schema::hasColumn('grade_columns', 'kind')) {
            Schema::table('grade_columns', function (Blueprint $table) {
                $table->string('kind', 16)->default('other')->after('code'); // kttx|ktdk|exam|other
                $table->unsignedTinyInteger('attempt')->nullable()->after('kind'); // 1|2, chỉ dùng khi kind=exam
            });
        }

        if (Schema::hasTable('grade_books') && ! Schema::hasColumn('grade_books', 'term')) {
            Schema::table('grade_books', function (Blueprint $table) {
                $table->string('term', 20)->nullable()->after('academic_year'); // semester_1..semester_6|summer
            });
        }

        if (Schema::hasTable('grade_graduation_sessions') && ! Schema::hasColumn('grade_graduation_sessions', 'term')) {
            Schema::table('grade_graduation_sessions', function (Blueprint $table) {
                $table->string('term', 20)->nullable()->after('academic_year'); // dùng khi session_type = semester_end
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('grade_graduation_sessions') && Schema::hasColumn('grade_graduation_sessions', 'term')) {
            Schema::table('grade_graduation_sessions', function (Blueprint $table) {
                $table->dropColumn('term');
            });
        }

        if (Schema::hasTable('grade_books') && Schema::hasColumn('grade_books', 'term')) {
            Schema::table('grade_books', function (Blueprint $table) {
                $table->dropColumn('term');
            });
        }

        if (Schema::hasTable('grade_columns') && Schema::hasColumn('grade_columns', 'kind')) {
            Schema::table('grade_columns', function (Blueprint $table) {
                $table->dropColumn(['kind', 'attempt']);
            });
        }
    }
};
