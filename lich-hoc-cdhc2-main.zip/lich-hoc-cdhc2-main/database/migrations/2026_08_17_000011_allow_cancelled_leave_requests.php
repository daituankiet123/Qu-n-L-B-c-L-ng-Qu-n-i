<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('leave_requests', function (Blueprint $table): void {
            $table->string('status', 30)->default('PENDING')->change();
        });
    }

    public function down(): void
    {
        Schema::table('leave_requests', function (Blueprint $table): void {
            $table->string('status', 30)->default('PENDING')->change();
        });
    }
};
