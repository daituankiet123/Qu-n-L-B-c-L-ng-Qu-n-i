<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        Schema::table('inventory_report_templates', function (Blueprint $table) {
            $table->string('report_type', 80)->nullable()->after('code');
        });
    }

    public function down(): void
    {
        Schema::table('inventory_report_templates', function (Blueprint $table) {
            $table->dropColumn('report_type');
        });
    }
};
