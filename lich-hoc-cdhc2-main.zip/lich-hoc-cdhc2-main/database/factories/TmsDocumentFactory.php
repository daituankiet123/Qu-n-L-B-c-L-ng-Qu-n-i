<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Modules\Tms\Models\TmsDocument;

class TmsDocumentFactory extends Factory
{
    protected $model = TmsDocument::class;

    public function definition(): array
    {
        return [
            'direction' => $this->faker->randomElement(['in', 'out']),
            'subject' => $this->faker->sentence(),
            'status' => 'open',
            'created_by' => User::factory(),
        ];
    }
}
