# Sửa HTTP 500 tại /vat-tu/cap-nhat

- Log production: ref `ILBIXLHN`, 26/09/2026 17:03:34, biến `$materialGradeLabel` chưa khai báo trong partial `assets`.
- Nguyên nhân: khi tích hợp #461, đoạn khai báo nhãn phân cấp bị bỏ nhưng `materialFallback` còn gọi hàm này. View cache chỉ biên dịch, không bắt lỗi runtime khi danh sách vật tư có dữ liệu.
- Khôi phục nhãn cũ: tập hợp các cấp thực tế từ `allAssets`, bỏ trùng, sắp xếp; nếu chưa có cấp thì dùng `classification`, cuối cùng `Chưa phân cấp`. Không thêm truy vấn DB, không sửa dữ liệu hay quyền.
- Test render toàn bộ partial với ba vật tư, các cấp 3/1/3 và fallback đã tái hiện đúng lỗi trước sửa; dùng để kiểm tra sau sửa và trong CI chung/tách DB.
