# CSS/JS của dịch vụ triển khai độc lập

## Lỗi production

Ngày 27/09, trang mới `/vat-tu`, `/quan-ly-phep`, `/essay-exams`, `/exam-organization` gọi `build/assets/app-ANsrfpjW.css` nhưng stylesheet không tải được. Tab rút đề cũ dùng `app-B8kQbbNM.css` vẫn có bố cục. Các font/vendor cố định vẫn tải.

Tailwind quét view toàn bộ module khi build; thay đổi module có thể đổi hash CSS. Deploy độc lập giữ nguyên core và sidecar core, trong khi `/build/` đi qua route catch-all về core. Vì vậy manifest của LMS/TMS có thể trỏ file không tồn tại ở core.

## Sửa

- Vite sinh URL `/lms/build/...`, `/tms/build/...`, `/grades/build/...`, `/salary/build/...` theo `config('app.cdhc2_service')`.
- Ingress hiện tại đã định tuyến các tiền tố đó tới đúng dịch vụ. Nginx sidecar rewrite nội bộ về `/build/...` rồi phục vụ file cùng phiên bản với manifest PHP.
- Core/monolith giữ đường dẫn cũ; tài nguyên thiếu trả 404, cache immutable được giữ.
- Vite base tương đối để chunk tải động và URL trong CSS tiếp tục đi theo tiền tố dịch vụ.
- Không sửa workflow. Thay đổi `app/**` và `docker/**` thuộc nhóm shared hiện tại, nên lần deploy bản sửa sẽ build các dịch vụ cùng cấu hình mới. Các lần deploy riêng về sau vẫn dùng sidecar đúng dịch vụ.

## Kiểm tra

- PHPUnit kiểm tra URL CSS/JS của bốn dịch vụ, core và monolith.
- Build sạch với cùng đầu vào Docker đạt, tái tạo đúng file `app-ANsrfpjW.css` mà web đang thiếu. Build ngay trong worktree chứa cache kiểm thử bị Tailwind quét nhầm dữ liệu cache; thư mục sạch không gặp lỗi này.
- Kiểm tra cấu hình và phục vụ file thật bằng Nginx: mọi tiền tố, Content-Type/cache và file không tồn tại.
- Chỉ kiểm tra GET trên web, chưa merge/deploy hoặc sửa dữ liệu production.

Sau khi chủ dự án merge/deploy: mở lại cả bốn phân hệ, kiểm tra Network CSS/JS 200 và tab cũ cần tải lại. Việc asset thuộc phiên bản cũ đã bị thay thế trong cùng dịch vụ vẫn cần refresh trang; PR này xử lý sai dịch vụ phục vụ asset khi các dịch vụ ở các phiên bản khác nhau.
