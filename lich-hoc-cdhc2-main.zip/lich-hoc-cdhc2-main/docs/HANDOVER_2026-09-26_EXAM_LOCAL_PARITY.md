# Đồng bộ Tổ chức thi từ working tree local

- Sửa/xóa kế hoạch, phân công, nhật ký và thí sinh; kiểm tra quyền ở controller như thao tác tạo hiện có.
- Bổ sung nút thao tác trong bảng kế hoạch, phân công, danh sách học viên và nhật ký túi; không ghi đè phần import danh sách của main.
- Chọn kế hoạch hiển thị dạng đề, ngày thi; nhập điểm giới hạn lớp của kế hoạch.
- Dồn túi tự luận yêu cầu phiếu đúng lớp, môn, ngày và chẵn/lẻ; nhận ngân hàng Tự luận/Tích hợp, kể cả bộ đề dùng chung không có class_id. Trắc nghiệm/thực hành vẫn dồn túi được khi không có ngân hàng tương ứng.
- Xóa kế hoạch xóa dữ liệu con của đúng kế hoạch trong transaction LMS, ghi audit ở core. Tránh orphan khi đã tách DB.
- Giữ model/migration kết nối LMS; sửa các transaction kế hoạch/danh sách cũ còn chạy ở connection mặc định.

Review 27/09: khôi phục chặn vượt số bàn; cấm đổi lớp/môn/ngày/loại khi có thí sinh; cấm xóa kế hoạch có điểm hoặc phách; giới hạn loại nhật ký. Test: 7 bài, 22 assertions, core/LMS SQLite riêng. Chưa kiểm thử mọi nút UI trên production.

PR bổ sung riêng cho các thay đổi local chưa nằm trong 13 commit nguồn. Không merge/deploy. CI chạy trên commit mới; xem Checks của PR.
