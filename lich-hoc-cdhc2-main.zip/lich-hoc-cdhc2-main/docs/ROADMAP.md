# Roadmap CDHC2 → microservices — bảng theo dõi

Cập nhật: **26/09/2026**. Ký hiệu: ✅ xong trên prod · 🟡 đang làm / PR chờ merge · ⏳ chưa bắt đầu · ⛔ bị chặn.

> ⚠️ **Phút GitHub Actions gần hết (~2000/tháng, repo private).** Mỗi lần merge vào `main` ≈ 13–15 phút (test + build + deploy); PR Tests ≈ 6 phút (chỉ chạy khi gắn nhãn `run-ci`). Từ 25/09: **chạy test ở máy, gom merge**, chỉ merge khi cần deploy thật. Đề xuất lâu dài: cài **self-hosted runner** trên node (không tốn phút) — cần chủ dự án tạo token đăng ký runner.

## 1. Tổng quan 5 bước

| Bước | Nội dung | Trạng thái | Plan |
|---|---|---|---|
| 1 + 1b | Ranh giới code (contract, bỏ phụ thuộc chéo) | ✅ 22–23/09 | `plans/2026-09-22-step1-code-boundaries.md` |
| 2 | Tách DB: 4 schema (`eduka_v2`, `cdhc2_lms`, `cdhc2_tms`, `cdhc2_grades`) | ✅ 24/09 (+ sửa lỗi sau tách #432) | `plans/2026-09-23-step2-database-split.md` |
| 3 | Deploy độc lập: tag `sha-*`, chỉ rollout service đổi, lùi từng service, JWT_ENFORCE | ✅ 25/09 (còn: kiểm "migration kéo core" ở #446) | `plans/2026-09-24-step3-independent-deploy.md` |
| 4A | Queue riêng từng service + ghi chéo service qua job | ✅ 25/09 (gộp #453, nghiệm thu trên prod; docs #455 chờ merge) | `plans/2026-09-25-step4a-queue-per-service.md` |
| 4B | File người dùng lên S3, bỏ PVC NFS | ⏳ (bắt đầu bằng spike driver S3) | `plans/2026-09-25-step4b-object-storage.md` |
| 5 | Cụm nhiều node | ⏳ cần phần cứng — chủ dự án quyết | roadmap |
| + | **Service thứ 5 "QL Bậc Lương QNCN"** (từ Access QLNL) — bài test microservices | 🟡 Task 0–8 + mẫu in chuẩn Access + đủ chức năng Access xong ở máy; PR xếp chồng #456→#457→#458→#460→#463→#464 **chưa merge**; còn Task 9 (nghiệm thu prod) | `plans/2026-09-25-salary-qncn-service.md` |

## 2. Bước 4A — chi tiết

| Task | Việc | Trạng thái |
|---|---|---|
| 1 | Đo backlog queue (`cdhc2:queue-status`, workflow `queue-status`) | ✅ #444; xoá 41 email cũ (chủ dự án đồng ý) |
| 2 | Bảng `lms_jobs`/`tms_jobs`/`grade_jobs` + config failed/batching | 🟡 #446 (test máy: 533 / split 530 xanh) |
| 3 | Job `DeliverInternalCall` + provisioning LMS qua queue | 🟡 #449 (538 / 535 xanh) |
| 4 | Chuyển điểm bài thi qua job `TransferExamToGrades` | 🟡 #450 (541 / 538 xanh; chuyển 2 lần không nhân đôi) |
| 5 | Test canh giữ: ghi chéo service phải qua queue | 🟡 #451 (546 / 543 xanh) — bắt được lỗi thật ở nộp bài TMS, đã sửa |
| 6 | Worker trong pod mỗi service + env queue (sửa email chưa từng gửi) | 🟡 #452 |
| 7 | Nghiệm thu (tắt lms → tạo lớp → bật lại → khoá LMS vẫn được tạo) | ⏳ |

## 3. Service "QL Bậc Lương QNCN" — chi tiết

Quyết định chủ dự án 25/09: tên `salary` / `/salary`, nút **"QL Bậc Lương QNCN"**; bảng lương + ngưỡng tuỳ chỉnh được (có phiên bản, kiểm tra tự động); TypeSafe được dùng để đối chiếu; nguồn quân nhân = **Người dùng** (`users`); ngưỡng 5,4 và 2/3 năm sửa theo đợt.

| Task | Việc | Trạng thái |
|---|---|---|
| 0 | Đóng băng đặc tả Access vào repo | ✅ ở máy (#457) |
| 1 | Khung service thứ 5 (pod, DB `cdhc2_salary`, pipeline, Traefik `/salary`) | ✅ ở máy (#456 workflow tạo DB, #457) |
| 2 | Lớp tính toán thuần `SalaryRules` (TDD bám 87 query Access) | ✅ ở máy (#457); 26/09 đến hạn OR 2 mốc như Access |
| 3 | Schema `salary_*` + cấu hình quy tắc | ✅ ở máy (#458) |
| 4 | Endpoint nội bộ core (cấp bậc; không tạo user theo chủ dự án) | ✅ ở máy (#458) |
| 5 | Nghiệp vụ đợt nâng lương (5 loại) | ✅ ở máy (#458; 26/09 khớp Access: "Khác", chặn trùng đợt, duyệt tất cả) |
| 6 | Import Access + đối chiếu quân nhân (TypeSafe) | ✅ ở máy (#460) |
| 7 | Màn hình (cổng riêng, natural green) + nút ở trang chủ | ✅ ở máy (#463, #464) |
| 8 | Mẫu in: chuẩn Access (QĐ 5 loại, danh sách, phụ lục, quá trình lương, báo cáo, thống kê, in lại QĐ) + mẫu tự tạo | ✅ ở máy (#464) |
| 9 | Nghiệm thu microservices trên prod | ⏳ chờ chủ dự án duyệt merge chuỗi PR + tạo DB `cdhc2_salary` |

## 4. PR đang mở — thứ tự merge đề xuất

| PR | Nội dung | Đề xuất |
|---|---|---|
| #448 | CI cho pull request (nhãn `run-ci`) | Merge (đã chạy thử xanh) — gom cùng lần deploy #446 |
| #446 → #449 → #450 → #451 → #452 | 4A Task 2–6 (chuỗi xếp chồng) | Merge **1 đợt theo thứ tự** (hoặc gộp thành 1 PR vào main = 1 lần deploy). Thiếu #452 thì prod ngừng tạo khoá LMS |
| #447 | Plan Bậc lương + hướng dẫn cho Nam + roadmap này | Chỉ tài liệu — merge khi tiện (vẫn tốn 1 lần chạy test) |
| #445 | Nam: EssayExam / Inventory / NCKH (WIP) | **Không merge** — 4 lỗi fatal; Nam làm lại theo `docs/guides/2026-09-25-huong-dan-nam-pipeline-microservices.md` |
| #426 | Handover cũ | Đóng (đã lỗi thời) |

## 5. Việc của chủ dự án

- [ ] Harbor: retention giữ 10 tag `sha-*` mỗi repo `cdhc2-*`.
- [ ] Gửi hướng dẫn cho Nam; đóng #426.
- [ ] (Tuỳ chọn) Self-hosted runner để hết lo phút Actions.
