# In đáp án — đối chiếu web và local ngày 26/09/2026

- Đã mở trực tiếp bản in đáp án phiếu 16 trên `tkb.cdhc2.edu.vn` bằng phiên Chrome người dùng đăng nhập và đối chiếu với `127.0.0.1:8000`.
- Nội dung bốn câu, đáp án và tổng điểm 10,00 khớp nhau. Web có lỗi bố cục: header một cột, thông tin thi căn giữa, lặp mã đề với `-D`, đáp án thụt lề. Local đã có bố cục mong muốn.
- Tạo `print-answers.blade.php` riêng, chọn qua `answers=1` trong `printDraw`. Dùng `paperCode()` một lần, giữ nội dung/barem và chữ ký chủ nhiệm khoa bên trái, giáo viên bên phải. Mẫu in đề hiện có không thay đổi.
- PR này độc lập từ main, không bổ sung vào #465 và không mang theo thay đổi nút xóa. Không sửa DB, migration hoặc phân quyền. Sau này thay đổi barem phải kiểm tra cả hai mẫu in.
- Local: 20 tests / 148 assertions đạt (EssayExamAnswerPrintTest và EssayExamWorkflowTest); PHP lint, Pint, view:cache; xem bản dựng Chrome ở chế độ print, cùng dữ liệu phiếu 16.
- Full suite với MySQL test không thể chạy local vì cổng 3307 không có dịch vụ. CI cần đạt cả blade-lint và phpunit-split trước merge/deploy.
