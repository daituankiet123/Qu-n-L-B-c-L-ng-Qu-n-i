# Khôi phục luồng Duyệt đề từ local

## Phạm vi

Bổ sung phần bị thiếu khi chuyển các commit nguồn `c3a100f2` và `cc31fdba` sang PR #459: giao diện duyệt, in PDF gốc, chữ ký đang bật của người duyệt BGH, ký trực tiếp, lưu và mở PDF đã ký. PR độc lập với sửa in đề (#465), in đáp án (#469), vật tư (#470) và import (#471).

## Hành vi

- Khoa, Khảo thí, BGH đều có In PDF đã import; thao tác xem trước không duyệt và không tạo văn bản.
- BGH có In ký số BGH và In ký trực tiếp. Xác nhận ký/in sẽ duyệt toàn bộ đề đang chờ BGH trong bộ đề. Chặn nếu còn đề ở cấp duyệt trước.
- Chữ ký đã lưu được chọn phía máy chủ, chỉ từ tài khoản hiện tại, đang bật, ưu tiên mặc định. Tên gọi “ký số” trong giao diện dùng ảnh chữ ký đã lưu; không phải ký PDF bằng chứng thư số.
- Ký trực tiếp dùng PNG từ canvas. Thiếu chữ ký hợp lệ không được hoàn tất duyệt.
- PDF đầu ra nhập lại mọi trang PDF gốc, giữ kích thước trang và đặt chữ ký BGH cuối trang cuối, theo local. PDF gốc cần có vùng trống dưới bên phải cho khối ký; bản import cũ có nội dung tại vùng này cần xem trước trước khi duyệt.
- Duyệt từng đề vẫn hoạt động. Chỉ khi tất cả đề đã duyệt mới tạo PDF hoàn chỉnh và khóa bộ đề.
- PDF và ảnh ký kết quả lưu trên disk local riêng tư, tải qua route có phân quyền. Văn bản HTML cũ tiếp tục xem/tải được.
- Giữ nút trả ngân hàng LMS, danh sách câu hỏi, duyệt từng đề, phân quyền và phạm vi khoa. Bộ lọc ngành hiển thị mã ngành, trình độ, hệ, hình thức đào tạo.

## Microservices / pipeline

- Dữ liệu EssayExam ở kết nối lms; giao dịch duyệt dùng kết nối của model và khóa dòng bộ đề.
- DigitalSignature/User dùng UsesCoreConnection sẵn có. Không thêm join/whereHas qua database.
- Đọc file bằng StorageHelper::getContents, hỗ trợ file cũ public/S3 mà không tin exists trên S3.
- Tạo PDF trước khi cập nhật trạng thái. Lỗi PDF hoặc giao dịch DB sẽ giữ nguyên trạng thái và dọn file mới. Thông báo gửi sau commit; lỗi thông báo không xóa PDF đã lưu.
- Không thêm migration, không đổi pipeline và không duyệt dữ liệu thật khi kiểm tra.

## Kiểm tra

- EssayExamWorkflowTest: 27 tests / 193 assertions trên SQLite cô lập: chữ ký mặc định đúng chủ sở hữu, ký trực tiếp, PDF hai trang, phân quyền, xem trước không duyệt, thiếu/sai chữ ký, PDF hỏng, rollback DB, duyệt từng đề và render giao diện cả ba cấp.
- Pint, PHP lint, Blade view cache, git diff --check.
- PR gắn run-ci; kiểm tra blade-lint và phpunit-split trên GitHub trước khi bàn giao.

## Sau merge/deploy

Bổ sung sau audit 13 commit/#445: khôi phục kiểm tra cấp duyệt/đơn vị khi trả đề, thông báo kết quả cho người duyệt cấp dưới, giới hạn thông báo khoa theo đơn vị người soạn. Test local chạy lại đạt 27 tests / 194 assertions. CI xanh trước đó thuộc commit 08a6aec5; kết quả đó không thay cho kiểm tra commit bổ sung này.

Triển khai service lms từ commit đã merge. Mở Duyệt đề, chọn từng cấp, xem PDF gốc; thử ký bằng bộ đề thử nghiệm và tài khoản có quyền BGH. PR được tạo chưa đồng nghĩa bản production đã đổi; kiểm tra SHA/image đã triển khai và tải lại trang sau deploy.
