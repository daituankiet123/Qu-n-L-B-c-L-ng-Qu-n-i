# Bổ sung phần NCKH chỉ có ở working tree local

- Phân quyền xem danh sách/portal theo người tham gia và đơn vị; người duyệt đơn vị không xem/duyệt hồ sơ đơn vị khác.
- Chặn tự nghiệm thu, sửa đăng ký của người khác qua sản phẩm và thay đổi gia hạn đã duyệt.
- Tệp đính kèm và kho tài liệu tải qua route kiểm tra quyền, lưu riêng tư; bỏ URL public trực tiếp trong các view.
- Migration chuyển tệp cũ: đọc trực tiếp object, xác minh nội dung bản riêng tư trước khi xóa bản công khai, chạy lại được. Nếu bản riêng tư khác thì dừng, giữ cả hai. Không dùng HEAD/exists trên S3 public.
- Giữ UsesCoreConnection và truy vấn user ID riêng rồi whereIn; không đưa whereHas qua connection trở lại.
- Khôi phục nhãn tiếng Việt trong nhật ký và nút về Dashboard.

Test SQLite riêng: phân quyền HTTP, tải tệp, migration; kiểm tra kiến trúc kết nối. Chưa chạy migration trên production, chưa merge/deploy. CI mới phụ thuộc GitHub khắc phục Billing & plans.
