# Hướng dẫn cho Nam: pipeline, microservices và cách tích hợp PR #445

> Người đọc: Nam (`NamMaiNamMai0505`). Viết ngày 25/09/2026, sau khi prod đã **tách DB** (24/09) và **deploy độc lập** (Bước 3, 25/09).
> Phần D là plan thực hiện (định dạng `superpowers:writing-plans`) — làm theo từng task, đánh dấu `- [x]` khi xong.

---

## A. Hệ thống bây giờ chạy thế nào

### A.1 Một codebase, 4 service, 4 database

```
                    Internet → SafeLine WAF → Traefik (k8s, NodePort 30800)
                                   │ định tuyến theo đường dẫn (k8s/traefik/ingressroute.yaml)
        ┌──────────────┬───────────┴──────────┬───────────────┐
   tkb-core        tkb-lms              tkb-tms          tkb-grades         (+ tkb-scheduler chạy image core)
   /, /dashboard,  /lms, /essay-exams,  /tms, /vat-tu,  /grades
   /users, ...     /exam-organization   /quan-ly-phep
        │               │                    │                │
   eduka_v2        cdhc2_lms            cdhc2_tms        cdhc2_grades       (cùng MariaDB server, 4 schema)
```

- **Cùng một image gốc**, mỗi service build với `CDHC2_SERVICE=<core|lms|tms|grades>` (`docker/Dockerfile.service`).
- **Service nào nạp module nào**: `app/Support/ServiceTopology.php` — nguồn DUY NHẤT.
  - `ServiceTopology::core()` = module nền tảng (User, Unit, Class, Subject, Instructor, TrainingSchedule, StandardHours, Trash, ExportTemplates…) — **mọi** service đều nạp.
  - `ServiceTopology::services()` = module riêng: `lms` (Lms, EssayExam, ExamOrganization), `tms` (Tms, Inventory, LeaveManagement), `grades` (Grades), `dashboard` (Dashboard, Home — chỉ core nạp).
  - `bootstrap/providers.php` **không liệt kê module** — nó đọc `ServiceTopology`. Đừng thêm provider trực tiếp vào đó (đây là lỗi cú pháp dòng 10 trong #445).
- **Bảng thuộc DB nào**: `packages/cdhc2-core/src/Support/TableOwnership.php` theo **tiền tố**:
  `lms_`, `essay_exam`, `exam_organization`, `integrated_answer` → `lms`; `tms_`, `inventory_`, `leave_` → `tms`; `grade_` → `grades`; còn lại → core.

### A.2 Các service nói chuyện với nhau

| Cách | Khi nào | Ví dụ |
|---|---|---|
| **Đọc bảng core trực tiếp** | Mọi service đọc được core (users, units, subjects, classes…) | `User::find()` trong lms |
| **Contract** (`packages/cdhc2-core/src/Contracts`) | Đọc/ghi dữ liệu của service KHÁC | `GradeTransferContract`, `LmsProvisioningContract`, `DashboardLmsContract` |
| → `Direct*` | Khi đang chạy trong service sở hữu (hoặc monolith) | gọi thẳng code |
| → `Http*` | Khi service khác gọi | `InternalClient` gọi `/api/internal/<svc>/…` kèm **JWT** |
| **Queue job** (Bước 4A, đang làm) | Ghi chéo service không cần chờ kết quả | `DeliverInternalCall` — có retry, không mất khi service đích tạm chết |

`CoreServiceProvider::OWNERSHIP` quyết định dùng Direct hay Http. **JWT_ENFORCE=true** trên 4 service: API nội bộ chỉ nhận token JWT.

### A.3 Luật dữ liệu sau khi tách DB (test kiến trúc sẽ đỏ nếu vi phạm)

1. `DB::table('<bảng service>')` luôn chạy trên **core** → phải `DB::connection('lms')->table('lms_courses')`. (`RuntimeTableConnectionTest`)
2. `Schema::hasTable($bien)` chạy trên core → dùng `TableOwnership::hasTable($bien)`.
3. **Không** `whereHas/has/withCount/whereRelation` sang model ở connection khác → lấy id trước rồi `whereIn`. (`CrossConnectionRelationQueryTest`)
4. `DbRef::core()/lms()/…` **cấm** (tính theo service đang chạy, sai DB) → `DbRef::relativeTo($table, $connection)`.
5. Model của service: `protected $connection = 'lms'` (hoặc trait sẵn có). (`ModelConnectionTest`)
6. Migration của bảng service: `protected $connection = '<svc>'`, tên bảng viết chữ (không ghép biến); **không FK sang DB khác** (vd bảng `inventory_*` không được `constrained('users')`). Migration phải chạy lại được (`hasTable` trước `create`). (`MigrationConnectionTest`)
7. Luật validate: `exists:lms.lms_questions,id` (có tên connection) cho bảng service.
8. Disk `s3` (Viettel): `exists()` luôn `true`, `size()` = 0 → không dùng; kiểm bằng `get()`.

Chi tiết + lịch sử lỗi thật: `docs/HANDOVER_2026-09-22.md` mục 5, mục 0.

---

## B. Pipeline CI/CD (từ push đến prod)

```
PR (nhãn run-ci) ──► PR Tests: blade-lint + phpunit-split          (không build, không deploy)
merge vào main ──► Build and Deploy:
   tests (blade-lint + phpunit-split)  ─┐
   detect-changes (path filter)        ─┴─► build-and-push-ghcr (chỉ service đổi, tag sha-<7>) ─► mirror-and-deploy
```

- **`tests.yml`** (dùng chung): `blade-lint` = test script deploy + `view:cache` (lỗi Blade) + `php artisan test`; `phpunit-split` = chạy lại toàn bộ test với 4 DB riêng (`CDHC2_TEST_SPLIT_DB=1`). Đỏ → **không deploy**.
- **`pr-tests.yml`**: chỉ chạy khi PR có nhãn **`run-ci`** (repo private, phút Actions có hạn ~2000/tháng — **gần hết**). Gắn nhãn khi PR sẵn sàng; **chạy test ở máy trước** (mục D.0).
- **`detect-changes`**: nhóm file → service (`build-and-deploy.yml`, test `DeployPathFilterTest` canh giữ):
  `shared` (app/, config/, resources/, packages/, module nền tảng) → build cả 4; `lms`/`tms`/`grades` → chỉ service đó; `**/Migrations/**`, `database/**` → kéo **core** (chỉ initContainer `migrate` của core chạy migration).
- **Deploy độc lập** (`scripts/deploy/render-manifests.sh`): service vừa build nhận tag `sha-*`; service không build **giữ nguyên image đang chạy** → không khởi động lại. Deploy lỗi → chỉ lùi service vừa đổi (`rollout undo`).
- **Workflow vận hành** (chạy tay, `gh workflow run <file> --ref main …`): `service-logs.yaml` (log 1 service, `grep=…`, `curl_path=/…` gọi qua Traefik không vướng WAF), `cluster-diagnostics.yaml`, `service-rollback.yaml` (`confirm=LUI-SERVICE`), `queue-status.yaml`, `db-split.yaml`, `migrate.yaml`.
- **Không bao giờ push thẳng `main`** (mỗi push = deploy prod). #417 đã phải revert 16 commit Payroll vì điều này.

---

## C. PR #445 hiện tại — vì sao chưa merge được

Kiểm trên worktree riêng 25/09 (`php -l` + đọc diff):

| # | Vấn đề | Chỗ | Hậu quả |
|---|---|---|---|
| 1 | Lỗi cú pháp | `bootstrap/providers.php:10` (dán danh sách provider kiểu cũ vào giữa mảng `$shared`) | **App không khởi động** ở mọi pod |
| 2 | Lỗi cú pháp | `modules/EssayExam/Controllers/EssayExamController.php:938` | fatal |
| 3 | `use` trùng tên | `modules/ExamOrganization/Controllers/ExamOrganizationController.php:18` | fatal |
| 4 | Lỗi cú pháp | `modules/Inventory/Controllers/InventoryWorkflowController.php:993` | fatal |
| 5 | Ghi đè bản sửa sau tách DB | EssayExamController: `DB::connection('lms')->table('lms_courses')` bị thay lại bằng `DB::table('lms_courses')` | 500 trên prod (bảng nằm ở `cdhc2_lms`) |
| 6 | Migration sai DB | `2026_09_14_000001_create_inventory_asset_depreciation_years.php`: không `$connection='tms'`, FK `constrained('users')` | tạo nhầm DB core / FK chéo DB lỗi |
| 7 | Module mới chưa có chỗ | `modules/ScientificResearch` (33 file) không có trong `ServiceTopology`, không có trong path filter | không service nào nạp đúng; `DeployPathFilterTest` đỏ |

Nguyên nhân gốc: cherry-pick bằng `-X theirs` từ repo `dethiall` (không chung lịch sử) — xung đột bị giải quyết bằng cách **lấy nguyên bản cũ**, xoá mất code mới của `main`.

**Kết luận:** không phụ thuộc việc Bước 4A/4B xong hay chưa; có thể tích hợp **ngay** nếu làm theo phần D.

---

## D. Plan tích hợp lại (thay cho PR #445)

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans để làm task-by-task. Steps dùng checkbox (`- [ ]`).

**Goal:** Đưa 13 commit từ `dethiall` (20–25/09) vào `main` thành **3 PR nhỏ** chạy đúng trên kiến trúc đã tách DB.

**Architecture:** Mỗi PR tạo từ `origin/main` mới nhất, áp **thay đổi theo tính năng** (không phải theo commit), giải xung đột bằng tay, giữ mọi bản sửa của `main`. Test ở máy cả 2 chế độ trước khi gắn nhãn `run-ci`.

**Tech Stack:** Laravel 12, PHPUnit, MariaDB/MySQL test (`127.0.0.1:3307`, DB `cdhc_testing`), `vendor/bin/pint`.

**Spec:** mục A–C của tài liệu này + `CLAUDE.md` + `docs/HANDOVER_2026-09-22.md`.

### Global Constraints

- Không `git push origin main`; không `-X theirs`/`-X ours`; không `--force` lên nhánh người khác.
- Mọi file PHP đổi phải qua `php -l`; `vendor/bin/pint --dirty` trước commit.
- Test xanh cả `php artisan test` **và** chế độ tách DB (D.0).
- Quyền mới chỉ khai báo trong `app/Console/Commands/SyncPermissionsAndRoles.php` (định dạng `module.action`).
- Select dùng Apple Dropdown (không Tom Select). Không đụng Moodle.

### D.0 Cách chạy test ở máy (bắt buộc mỗi task)

```bash
php artisan test
```

```bash
CDHC2_TEST_SPLIT_DB=1 DB_LMS_DATABASE=cdhc_testing_lms DB_TMS_DATABASE=cdhc_testing_tms DB_GRADES_DATABASE=cdhc_testing_grades DB_SALARY_DATABASE=cdhc_testing_salary php artisan test
```

(Tạo sẵn 4 DB `cdhc_testing_lms/tms/grades/salary` trên MySQL test. `composer test:split` bị giới hạn 300s của composer — dùng lệnh trên.)

### Task 1: PR "EssayExam + ExamOrganization — sửa lỗi phía giáo viên"

**Files:**
- Modify: `modules/EssayExam/Controllers/EssayExamController.php`, `modules/EssayExam/Views/**` (các view trong 13 commit), `modules/ExamOrganization/Controllers/ExamOrganizationController.php`
- Create/Modify: `tests/Feature/EssayExamWorkflowTest.php` (431 dòng từ #445)
- Migration: `database/migrations/2026_09_24_000001_separate_essay_exam_list_permissions.php`

- [ ] **Step 1:** `git fetch origin && git checkout -b fix/essay-exam-teacher-flow origin/main`
- [ ] **Step 2:** Lấy test trước: `git checkout transfer/dethiall-since-20260920 -- tests/Feature/EssayExamWorkflowTest.php` → chạy `php artisan test --filter=EssayExamWorkflowTest` → ghi lại test nào đỏ (đó là hành vi cần mang sang).
- [ ] **Step 3:** Áp từng thay đổi của controller **bằng tay** (xem `git diff origin/main...transfer/dethiall-since-20260920 -- modules/EssayExam/Controllers/EssayExamController.php`). Giữ nguyên các dòng của `main`:

```php
// GIỮ (bản sửa sau tách DB, #432) — bảng lms_courses nằm ở DB lms:
foreach (DB::connection('lms')->table('lms_courses')->whereNotNull('class_id')
    ->when($isInstructor, fn ($q) => $q->where('instructor_id', $instructorId ?: 0))
    ->get(['class_id', 'subject_id']) as $course) {
    $classSubjectMap[$course->class_id] = collect($classSubjectMap[$course->class_id] ?? [])
        ->push($course->subject_id)->unique()->values()->all();
}
// KHÔNG viết DB::table('lms_courses') — RuntimeTableConnectionTest sẽ đỏ.
```

- [ ] **Step 4:** `ExamOrganizationController.php`: xoá dòng `use Modules\ExamOrganization\Models\ExamOrganizationPlan;` bị lặp (giữ 1 dòng).
- [ ] **Step 5:** Migration quyền: đảm bảo idempotent (`Permission::firstOrCreate`) **và** khai báo quyền mới trong `SyncPermissionsAndRoles` (migration không phải nơi định nghĩa quyền).
- [ ] **Step 6:** `php -l` các file đổi → D.0 cả 2 chế độ → xanh.
- [ ] **Step 7:** `vendor/bin/pint --dirty` → commit `fix(essay-exam): …` → push → mở PR, gắn nhãn `run-ci`.

### Task 2: PR "Inventory — khấu hao tài sản theo năm"

**Files:**
- Modify: `database/migrations/2026_09_14_000001_create_inventory_asset_depreciation_years.php`
- Modify: `modules/Inventory/**` (23 file trong #445), `resources/views/portals/inventory.blade.php`

- [ ] **Step 1:** `git checkout -b feat/inventory-depreciation origin/main`
- [ ] **Step 2:** Migration đúng kiến trúc — bảng `inventory_*` thuộc **tms**; `inventory_assets` cùng DB nên giữ FK; `users` ở core nên **bỏ FK**:

```php
return new class extends Migration
{
    protected $connection = 'tms';

    public function up(): void
    {
        if (Schema::hasTable('inventory_asset_depreciation_years')) {
            return;
        }
        Schema::create('inventory_asset_depreciation_years', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('asset_id')->constrained('inventory_assets')->cascadeOnDelete(); // cùng DB tms: OK
            // ... các cột như bản gốc ...
            $table->unsignedBigInteger('created_by')->nullable()->index(); // users ở core: KHÔNG FK chéo DB
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('inventory_asset_depreciation_years');
    }
};
```

- [ ] **Step 3:** Model mới dưới `modules/Inventory/Models` phải `protected $connection = 'tms'` (xem model Inventory có sẵn làm mẫu). Quan hệ tới `User`: `belongsTo(User::class, 'created_by')` được (Eloquent chạy query riêng trên core), **nhưng không** `whereHas('creator', …)`.
- [ ] **Step 4:** `InventoryWorkflowController.php:993` — sửa phần code bị trùng (hai phiên bản của cùng một phương thức); giữ bản sửa của `main`: `->orWhereIn('assigned_to', User::query()->where('name', 'like', …)->pluck('id'))` (không `orWhereHas`).
- [ ] **Step 5:** `php -l` → D.0 cả 2 chế độ → pint → commit → PR + `run-ci`.

### Task 3: PR "Module NCKH (ScientificResearch)"

**Files:**
- Modify: `app/Support/ServiceTopology.php`, `.github/workflows/build-and-deploy.yml` (path filter), `app/Console/Commands/SyncPermissionsAndRoles.php`, `app/Support/ApplicationRegistry.php`
- Add: `modules/ScientificResearch/**` (33 file), migrations `modules/ScientificResearch/Database/Migrations/*`

- [ ] **Step 1:** Quyết định chỗ đặt — **đề xuất: module core** (bảng `scientific_research_*` không có tiền tố service → `TableOwnership` xếp vào core; migration FK sang `users` hợp lệ vì cùng DB core). Nếu sau này muốn tách thành service riêng, làm theo mẫu plan `docs/superpowers/plans/2026-09-25-salary-qncn-service.md` Task 1 (tiền tố riêng, DB riêng, pod riêng).
- [ ] **Step 2:** Đăng ký trong `ServiceTopology::core()`:

```php
            ExportTemplatesServiceProvider::class,
            ScientificResearchServiceProvider::class,
```

  và thêm `- 'modules/ScientificResearch/**'` vào nhóm **`shared`** của `detect-changes` (module nền tảng được mọi service nạp). Chạy `php artisan test --filter=DeployPathFilterTest` → phải xanh.
- [ ] **Step 3:** **Không** sửa `bootstrap/providers.php`.
- [ ] **Step 4:** Quyền `scientific-research.index/show/create/edit/delete` khai báo trong `SyncPermissionsAndRoles`; menu/app grid qua `ApplicationRegistry`.
- [ ] **Step 5:** Migrations chạy lại được (`hasTable`); upload file dùng `StorageHelper`/cột `disk` (Bước 4B sẽ chuyển file lên S3 — không ghi cứng `storage_path('app/public/...')`).
- [ ] **Step 6:** `php -l` → D.0 cả 2 chế độ → pint → commit → PR + `run-ci`.

### Task 4: Đóng PR #445

- [ ] Khi 3 PR trên đã merge: đóng #445 với comment liệt kê 3 PR thay thế. Xoá nhánh `transfer/dethiall-since-20260920`.

### Self-review (đã chạy)

- Bao phủ: 7 vấn đề ở mục C ↔ Task 1 (2, 3, 5), Task 2 (4, 6), Task 3 (1, 7). ✔
- Không placeholder ngoài "các cột như bản gốc" ở Task 2 Step 2 — cột lấy nguyên từ file migration của #445, chỉ đổi 3 điểm đã chỉ rõ. ✔

---

## E. Công cụ gợi ý

- **Skill có sẵn trong repo** (`.claude/skills/`): `module-generator.md` (tạo module), `permission-manager.md`, `testing-guide.md`, `laravel-12-expert.md`, `apple-design` (giao diện).
- **Skill cộng đồng** (tra bằng `npx skills find`, 25/09): `anthropics/skills@docx` (192K lượt cài) hữu ích khi làm mẫu Word; không có skill tốt cho "Laravel module"/"MS Access migration" (kết quả < 100 lượt cài — không nên dùng).
- **TypeSafe** (`typesafe-ai`): chỉ dùng cho **tính năng AI** thật (phán đoán ngữ nghĩa có xác suất — vd đối chiếu hồ sơ trùng người). Không dùng cho quy tắc tính toán, hạ tầng, hay kiến trúc. Module NCKH hiện chưa có chỗ cần AI; nếu muốn (vd phân loại lĩnh vực đề tài, phát hiện đề tài trùng lặp), đọc `https://docs.typesafe.ai/llms.txt` trước, API key chỉ để ở server.

Có câu hỏi: xem `docs/HANDOVER_2026-09-22.md` hoặc hỏi chủ dự án (Thọ).
