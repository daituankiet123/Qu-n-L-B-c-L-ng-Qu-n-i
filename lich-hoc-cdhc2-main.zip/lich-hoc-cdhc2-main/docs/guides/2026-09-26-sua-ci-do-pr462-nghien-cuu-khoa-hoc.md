# Sửa CI đỏ — PR #462 (module Nghiên cứu khoa học)

Gửi Nam. PR: https://github.com/tho076/lich-hoc-cdhc2/pull/462 · run lỗi: `36145678916`.

## Tóm tắt

Hai job `tests / blade-lint` và `tests / phpunit-split` đỏ vì **cùng 2 test kiến trúc** (543 test khác đều qua):

| Test | Lỗi | Nguyên nhân |
|---|---|---|
| `Tests\Feature\CoreModelConnectionTest::test_every_core_model_has_a_non_null_connection` | "Model core chưa có connection" | Module được đăng ký là **module core** (`ServiceTopology::core()`), nhưng 14 model `ScientificResearch*` **chưa khai báo connection** |
| `Tests\Unit\Architecture\CrossConnectionRelationQueryTest::test_cross_connection_relations_are_not_used_in_has_queries` | `ScientificResearchController.php:116, :139, :225` dùng `orWhereHas('user', …)` | Sau tách DB, `whereHas` trên quan hệ có thể trỏ **sang DB khác** sẽ sinh JOIN chéo DB và lỗi trên prod; dự án cấm dùng `has/whereHas` với quan hệ tới `User` |

> Dòng `Class Modules\Unit\... does not comply with psr-4` trong log là cảnh báo cũ của main, **không phải** lỗi của PR.

## Sửa 1 — gắn connection core cho mọi model (bắt buộc)

Model của module core phải dùng trait `App\Models\Concerns\UsesCoreConnection` (giống `Modules\ExportTemplates\Models\ExportTemplate`). Thiếu trait, khi model được gọi qua quan hệ từ model của service khác (lms/tms/grades) nó sẽ **mượn nhầm connection của model cha** và truy vấn sai DB.

Làm cho **cả 14 file** trong `modules/ScientificResearch/Models/`:

```php
use App\Models\Concerns\UsesCoreConnection;

class ScientificResearchRegistration extends Model
{
    use SoftDeletes;
    use UsesCoreConnection;
    // ...
}
```

Danh sách: `ScientificResearchAnnouncement`, `AuditLog`, `Council`, `CouncilMember`, `File`, `Funding`, `Plan`, `Product`, `Registration`, `RegistrationExtension`, `RegistrationMember`, `RepositoryDocument`, `Result`, `StaffProfile` (đều có tiền tố `ScientificResearch`).

## Sửa 2 — bỏ `orWhereHas('user', …)` (3 chỗ trong `ScientificResearchController`)

Thay bằng lọc theo **danh sách id người dùng** (subquery chạy trên connection của `User`, không JOIN quan hệ):

```php
// Trước (dòng 116, 139, 225)
->orWhereHas('user', fn ($userQuery) => $userQuery->where('name', 'like', '%'.$keyword.'%'));

// Sau
->orWhereIn('user_id', User::query()
    ->where('name', 'like', '%'.addcslashes($keyword, '\\%_').'%')
    ->pluck('id'));
```

- Dùng `pluck('id')` (lấy mảng id) thay vì subquery `select('id')`: an toàn cả khi `users` và bảng nghiên cứu khoa học nằm ở hai DB khác nhau.
- `addcslashes(..., '\\%_')` để từ khoá có `%` hoặc `_` không thành ký tự đại diện (cùng cách các module khác đang làm).
- Nếu chỗ 225 lọc trên model có cột người dùng khác (`created_by`, `requested_by`…), đổi `'user_id'` cho đúng cột của quan hệ `user()` trong model đó.

## Kiểm tra trước khi đẩy lại

1. Rebase theo `main` mới (#459 và #461 đã merge):
   ```bash
   git fetch origin && git rebase origin/main
   ```
2. Chạy 2 test đang đỏ:
   ```bash
   php artisan test tests/Feature/CoreModelConnectionTest.php tests/Unit/Architecture/CrossConnectionRelationQueryTest.php
   ```
3. Chạy toàn bộ ở chế độ tách DB (giống job `phpunit-split`):
   ```bash
   CDHC2_TEST_SPLIT_DB=1 DB_LMS_DATABASE=cdhc_testing_lms DB_TMS_DATABASE=cdhc_testing_tms DB_GRADES_DATABASE=cdhc_testing_grades php artisan test
   ```
   Không chạy 2 bộ test song song — chúng dùng chung DB test.
4. `vendor/bin/pint --dirty`, rồi push; gắn nhãn `run-ci` để CI chạy.

## Ghi chú thêm khi review (không làm CI đỏ, nên xem)

- Migration để trong `modules/ScientificResearch/Database/Migrations/` với ngày 16–19/09: chúng sẽ chạy **sau** các migration đã có trên prod (không ảnh hưởng dữ liệu cũ), nhưng nhớ bảng mới thuộc DB **core** (`eduka_v2`) — đừng thêm FK sang bảng của lms/tms/grades.
- Bước `build-and-deploy.yml` có thêm `modules/ScientificResearch/**` vào nhóm path: đúng, vì module core thay đổi thì phải build lại image core.
