# Review mức độ sẵn sàng Production — Microservices CDHC2

> Ngày 17/09/2026 · Nhánh `dev` tại `70dc2904` · Người thực hiện: agent (theo uỷ quyền "auto approve" của chủ dự án)
> Phạm vi: toàn bộ Phase 0-6 của kế hoạch chuyển monolith → 4 microservices + API Gateway.

---

## 1. Kết luận nhanh

| Câu hỏi | Trả lời |
|---|---|
| Code đã hoàn thiện hết issue chưa? | **Có.** 9/9 rủi ro R1–R9 đã xử lý; Phase 4/5/6 đã hoàn tất phần code; phát sinh thêm 5 vấn đề mới (N1–N5) đều đã sửa. |
| Đã đủ điều kiện đẩy lên prod chưa? | **Về code: gần đủ. Về vận hành: CHƯA** — còn 3 việc bắt buộc phải làm trên cluster (mục 5) mà tôi không thể tự thực hiện/kiểm chứng. |
| Có nên merge `dev` → `main` ngay? | **Không nên merge tự động.** Đây là cutover kiến trúc một chiều, cần người trực cluster. Xem mục 6. |

**Lý do chính:** `main` hiện chạy monolith 1 pod. Merge `dev` sẽ thay **toàn bộ** mô hình triển khai (6 deployment + Traefik thay nginx gateway + NFS PVC + secret mới) trong một lần push. Tôi không có quyền truy cập cluster nên **không thể xác minh** kết quả.

---

## 2. Đã hoàn thiện những gì

### 2.1 Chín rủi ro trong kế hoạch (R1–R9) — 9/9 xong

| # | Rủi ro | Cách xử lý | Bằng chứng |
|---|---|---|---|
| R1 | `.env.example` (file commit) chứa `JWT_SECRET` thật | Xoá giá trị, thay placeholder trống + hướng dẫn `openssl rand -base64 48` | `git show ee7b32a6` |
| R2 | `JWT_SECRET` không có trên cluster → nhánh JWT inert | Thêm `k8s/secret.example.yaml` (mẫu + lệnh tạo/xoay secret); `config/app.php` có `cdhc2_service`; JWT đọc qua config | `k8s/secret.example.yaml`, `config/jwt.php` |
| R3 | `gateway-svc` và `traefik-svc` tranh NodePort 30800 → `kubectl apply` fail | CI xoá `tkb-gateway` + `gateway-svc` trước khi apply; `git rm -r k8s/gateway` | `.github/workflows/build-and-deploy.yml` |
| R4 | Migration bỏ FK không idempotent, mà `k8s/core` chạy migrate trong initContainer mỗi rollout → treo rollout | Tra `information_schema.KEY_COLUMN_USAGE`, bỏ qua khi FK không còn | `database/migrations/2026_09_16_000001_*` |
| R5 | 1 PR khổng lồ không rollback được từng phần | Tách 3 nhánh `feat/phase4-s3-storage` (4 commit), `feat/phase5-jwt-traefik` (2), `feat/phase6-db-split` (4) | `git log --oneline --graph` |
| R6 | Pint format lẫn vào logic, không review được | Tách commit `style:` riêng; `InventoryController` 198/74 → **4/3** dòng logic | `git show 957ed7c0` |
| R7 | Tách DB nửa vời → JOIN đọc nhầm database | `php artisan cdhc2:db-topology` — exit 1 khi phát hiện tách không đồng bộ | `app/Console/Commands/DbTopologyCheck.php` + 5 test |
| R8 | `PathPrefix('/lms/')` không khớp `/lms` → **mọi tile App Grid rơi vào core** | Đổi sang `Path(x) \|\| PathPrefix(x/)` + `priority` tường minh (internal 100 / service 50 / core 1) | `k8s/traefik/ingressroute.yaml` |
| R9 | `InternalClient` retry cả POST không idempotent → ghi trùng | Chỉ retry khi `idempotent: true` (GET); thêm `connectTimeout` 5s | `packages/cdhc2-core/src/Http/InternalClient.php` |

### 2.2 Năm vấn đề phát hiện thêm trong quá trình làm — 5/5 đã sửa

| # | Vấn đề | Mức | Cách xử lý |
|---|---|---|---|
| N1 | `CoreServiceProvider` đọc `env('CDHC2_SERVICE')` lúc `register()`. Nếu bật `php artisan config:cache` thì `env()` trả `null` → **mọi service bind nhầm sang implementation Direct**, tức pod TMS/LMS/Grades tự truy vấn bảng không thuộc quyền | 🔴 | Bind lazy qua closure đọc `config('app.cdhc2_service')`; thêm `ServiceContractBindingTest` (5 test) chống hồi quy |
| N2 | `DbRef::core()` so database đích với connection **mặc định** (vốn luôn là core) nên **luôn trả tên bảng trần** — hoàn toàn vô tác dụng sau khi tách DB | 🔴 | Suy ra database của service từ `app.cdhc2_service`; đọc từ config thay vì mở connection; thêm `DbRef::ownership()` |
| N3 | Gán `$connection` cho model sinh **deadlock chéo connection**: nhiều PDO cùng trỏ một database, `RefreshDatabase` chỉ bọc connection mặc định → `Lock wait timeout exceeded` (50s) rồi `DeadlockException` | 🔴 | Khi chưa tách DB, alias `tms/lms/grades` về **cùng một PDO** với connection mặc định (`DB::extend`). Test `LmsCourseEnrollsEntireClassTest`: fail sau 114s → **pass 63s** |
| N4 | `InternalApiAuth`: có Bearer nhưng sai vẫn rơi xuống shared secret → hạ cấp bảo mật âm thầm | 🟡 | Bearer sai thì chặn ngay (403), không fallback; thêm `JWT_ENFORCE` để bỏ hẳn shared secret |
| N5 | `JwtTokenService` chấp nhận cả thuật toán ngoài HMAC (kể cả `none`) và không kiểm tra độ dài khoá | 🟡 | Chỉ cho HS256/384/512; khoá ≥ 32 ký tự; thêm `aud`/`jti`/`nbf` và đối chiếu audience |

### 2.3 Khối lượng code

| Phase | Nội dung | Trạng thái |
|---|---|---|
| 0-3 | 6 contracts + 12 Direct + 12 Http impl, 12 internal API, 6 K8s deployment, nginx sidecar | ✅ (commit `756f7480`) |
| 4 | `StorageHelper` (9 method) + `storage:migrate-s3` + **toàn bộ call-site** chuyển sang disk-agnostic | ✅ code xong, **chưa bật S3** |
| 5 | JWT service auth (+hardening) + App Grid 22 tile + Traefik + CI path filter | ✅ code xong, **JWT chưa bật** |
| 6 | 82 model có `$connection` + `DbRef` + 3 connection + migration idempotent + guard topology | ✅ code xong, **chưa tách DB** |

---

## 3. Kiểm chứng đã chạy

| Hạng mục | Kết quả |
|---|---|
| `php -l` trên **mọi file .php** khác `origin/dev` (~150 file) | ✅ sạch |
| `php artisan view:cache` (blade lint) | ✅ pass |
| `php artisan route:list` + 22 route của App Grid | ✅ 22/22 tồn tại |
| `php artisan cdhc2:db-topology` | ✅ "Cấu hình database nhất quán" |
| Bộ test mới (StorageHelper, JWT, DbRef, topology, model connection, service binding, ExportTemplate lifecycle, SCORM, LmsSprint9) | ✅ **59 passed (161 assertions)** |
| Test từng treo trước đó (`LmsCourseEnrollsEntireClassTest`) | ✅ pass 63s (trước fail 114s) |
| `migrate:status` / migration mới | ✅ cú pháp sạch, có guard idempotent |
| Đối chiếu test hỏng với baseline `origin/main` | ✅ 7 test hỏng **giống hệt** trên main → không do microservices |

---

## 4. Rủi ro còn lại (đã biết, chấp nhận được hoặc cần theo dõi)

| # | Rủi ro | Mức | Ghi chú |
|---|---|---|---|
| C1 | **Chưa test với S3 thật.** Toàn bộ Phase 4 mới chỉ được kiểm chứng với disk local và `Storage::fake()`. `StorageHelper::pathForProcessing()` nhánh tải file từ xa **chưa từng chạy thật** | 🔴 | Bắt buộc test trên môi trường có S3 trước khi bật `FILESYSTEM_DISK=s3` |
| C2 | **Chưa test Traefik.** IngressRoute/priority mới chỉ đối chiếu bằng `route:list`, chưa chạy Traefik thật | 🔴 | Cutover cần người trực; xem runbook mục 6 |
| C3 | **Chưa test JWT end-to-end giữa 4 service.** Test hiện dùng HTTP test client nội bộ, chưa gọi chéo pod thật | 🟡 | Bật `JWT_ENFORCE=true` chỉ sau khi xác nhận log không còn 401/403 |
| C4 | File tạm rò rỉ: các caller `absolutePath()` (WordTemplateEngine, ExcelTemplateEngine, …) tải file từ S3 về tmp nhưng không phải chỗ nào cũng gọi `cleanup()` | 🟡 | Không ảnh hưởng đúng/sai, chỉ tốn đĩa. Nên có cron dọn `storage/app/tmp` |
| C5 | Bảo mật Traefik: IngressRoute đặt `X-Forwarded-Proto: https` cứng trong khi `entryPoints: web` là HTTP, và **chưa có TLS** | 🟡 | Bật TLS trước khi dùng thật; nếu không, cookie `secure` có thể bị set sai |
| C6 | `getRealPath()`/`$file->store()` của upload vẫn ghi vào disk `local` ở một số chỗ (upload template ExportTemplates) — giả định local disk ngoài phạm vi Phase 4 | 🟡 | Cần task riêng nếu muốn upload thẳng lên S3 |
| C7 | **CI không chạy test**, chỉ chạy `view:cache`. 7 test đỏ có sẵn trên `main` vẫn được deploy | 🔴 | Xem mục 7 |
| C8 | `TlsCertificate`/`cert-manager` chưa có; NodePort `30443` mở nhưng chưa phục vụ | 🟢 | |

---

## 5. Ba việc BẮT BUỘC làm trên cluster trước khi deploy

> **Cập nhật 17/09 (sau khi rà lại):** hai trong ba rủi ro dưới đây đã được xử lý
> bằng code — xem mục 10. Danh sách còn lại thực chất chỉ là **(1) backup** và
> **(2) tuỳ chọn nạp `JWT_SECRET`**.

```bash
# 1) Nạp khoá JWT vào Secret tkb-env (BẮT BUỘC — nếu thiếu, JWT inert và hệ thống
#    chạy bằng shared secret; nếu nạp khoá cũ đã lộ trong .env.example thì vô nghĩa)
kubectl -n tkb patch secret tkb-env --type merge \
  -p "{\"stringData\":{\"JWT_SECRET\":\"$(openssl rand -base64 48)\",\"JWT_TTL\":\"300\",\"JWT_ENFORCE\":\"false\"}}"

# 2) Xác nhận các biến tối thiểu cho kiến trúc nhiều pod
kubectl -n tkb get secret tkb-env -o jsonpath='{.data}' | tr ',' '\n' | grep -oE '"[A-Z_]+"' | sort
#    Phải có: APP_KEY, APP_ENV, APP_URL, DB_*, SESSION_DRIVER=database,
#             CACHE_STORE=database, QUEUE_CONNECTION=database,
#             INTERNAL_API_SECRET, JWT_SECRET, TRUSTED_PROXIES

# 3) Sao lưu trạng thái hiện tại để có đường lùi
kubectl -n tkb get deploy,svc,pvc,ingressroute -o yaml > backup-truoc-microservices.yaml
```

Kiểm tra tương thích trước khi merge (an toàn, chỉ đọc):

```bash
kubectl -n tkb get pvc tkb-storage          # phải Bound, ReadWriteMany 20Gi
kubectl -n tkb get node -o wide             # đủ tài nguyên cho 6 deployment
kubectl get storageclass                    # có nfs-client
```

---

## 6. Runbook cutover (khi có người trực)

Đây là cutover **một chiều**: từ nginx gateway sang Traefik, cùng NodePort 30800.

1. **Chuẩn bị:** hoàn thành mục 5. Ghi lại `backup-truoc-microservices.yaml`.
2. **Deploy:** merge PR `dev → main`. CI sẽ: lint blade → build 6 image → mirror Harbor → xoá `tkb-gateway` + `gateway-svc` → `kubectl apply -R` (gồm Traefik) → chờ 6 rollout.
3. **Theo dõi:** `gh run watch` — job fail ở bước `Waiting for rollouts` thì dừng ngay.
4. **Kiểm tra sau deploy:**
   ```bash
   kubectl -n tkb get deploy,pods,svc
   curl -s -o /dev/null -w '%{http_code}\n' http://<node-ip>:30800/
   curl -s -o /dev/null -w '%{http_code}\n' http://<node-ip>:30800/api/internal/lms/stats   # phải 403
   ```
5. **Kiểm tra nghiệp vụ:** đăng nhập admin → mở `/lms`, `/tms`, `/grades`, `/vat-tu`, `/quan-ly-phep`; tải 1 file lên và mở lại; mở 1 đề thi tự luận; xuất 1 báo cáo Word có ảnh chữ ký.
6. **Nếu lỗi:**
   ```bash
   kubectl -n tkb rollout undo deploy/tkb-core
   # hoặc quay lại gateway cũ:
   git revert -m 1 <merge-commit>   # rồi push main
   ```

**Chỉ sau khi 5. bước 4–5 đạt** mới nên: bật `JWT_ENFORCE=true`, rồi chuyển `FILESYSTEM_DISK=s3` và chạy `php artisan storage:migrate-s3`.

---

## 7. Việc NÊN cải thiện thêm (khuyến nghị, chưa làm)

| # | Việc | Vì sao |
|---|---|---|
| 1 | **Thêm bước chạy test vào CI** (`php artisan test`) trước `build-and-push` | Hiện chỉ lint blade; 7 test đỏ trên `main` vẫn deploy được. Đây là lỗ hổng chất lượng lớn nhất |
| 2 | Sửa 7 test đỏ có sẵn (mục 8) | Trong đó `FacultyTrainingPlanGroupingTest` và `LessonsImportTest` nghi là **lỗi thật**, không phải test cũ |
| 3 | Cron dọn `storage/app/tmp` | Tránh rò rỉ file tạm khi S3 bật (C4) |
| 4 | Bật TLS (cert-manager hoặc Secret thủ công) | Hiện `X-Forwarded-Proto: https` cứng nhưng entryPoint là HTTP (C5) |
| 5 | Chuyển `JWT` sang RS256 hoặc thêm allowlist `iss` | HS256 dùng chung khoá: 1 service lộ khoá = ký được token cho mọi service |
| 6 | Đo lại hiệu năng trang `/training-schedules/{id}/schedule-details/{date}/edit` | Sự cố prod "đơ" trước đó chưa có kết luận; đã có fix vòng lặp vô hạn ở `Unit.php` (PR #357) và fix N+1 (PR #356) |

---

## 8. Bảy test đỏ có sẵn trên `origin/main` (không do microservices)

Xác minh: các file test này **giống hệt nhau** giữa `origin/main` và `dev`
(`git diff --stat origin/main...dev -- <các file test>` → rỗng).

| Test | Assertion | Nhận định |
|---|---|---|
| `Unit\FacultyTrainingPlanGroupingTest:39` | `subject_short` trả tên môn đầy đủ (`Thể thao`) thay vì mã (`TTT`) | Nghi **lệch hành vi thật** trong `FacultyTrainingPlanExport::rowsFromDetails()` |
| `Feature\LessonsImportTest:137` | Thiếu dòng `subject_lessons` `code=B02, parent_id=null` — file Excel có 3 mục nhưng chỉ import được 2 | Nghi **lỗi import thật**: bài học đứng sau một mục con không được tạo |
| `Feature\ApplicationRegistryPermissionTest:94` | `assertTrue(false)` — quyền `exam manager` / `legacy manage` | Cần soát lại bảng quyền |
| `Feature\ExternalActivityAndAuthStabilityTest:28` | `assertTrue(false)` | Cần điều tra |
| `Unit\ScheduleDetailFormScriptTest:47` | Blade thiếu chuỗi `{{-- Legacy Tom Select API … --}}` | Test khẳng định theo **nội dung chuỗi** → dễ cũ sau refactor |
| `Unit\TrainingScheduleSprint20UiTest:37` | Cùng lý do trên | Cùng nhóm |
| `Unit\TrainingScheduleSprint23ExportUiTest:20` | Blade thiếu `@extends('layouts.admin')` | Cùng nhóm |

Ngoài ra subagent còn phát hiện `LmsStandardHoursCloneTest::test_declaration_with_other_teaching_hours_still_requires_approval`
(expected `submitted`, got `approved`) fail khi chạy một mình → **thêm một test đỏ có sẵn**, cùng nhóm cần soát.

---

## 9. Trả lời câu hỏi "cần cải thiện gì thêm"

**Trước khi lên prod (bắt buộc):**
1. Nạp `JWT_SECRET` mới vào Secret `tkb-env` và xác nhận các biến ở mục 5.
2. Cutover có người trực theo runbook mục 6 (không merge tự động).
3. Sau cutover: bật `JWT_ENFORCE=true` khi log sạch, rồi mới bật S3.

**Ngay sau khi lên prod (nên làm sớm):**
4. Thêm `php artisan test` vào CI — nếu không, 7 test đỏ sẽ tiếp tục đi cùng mọi lần deploy.
5. Soát 2 nghi vấn lỗi thật: `FacultyTrainingPlanExport::subject_short` và luồng import bài học.
6. Cron dọn `storage/app/tmp` + bật TLS.

**Trung hạn:**
7. Chuyển JWT sang khoá bất đối xứng hoặc allowlist `iss`.
8. Đo lại hiệu năng trang sửa chi tiết lịch (sự cố prod chưa có kết luận cuối).

---

## 10. Ba hardening bổ sung trước khi merge (17/09)

Rà lại lần cuối phát hiện thêm 3 lỗ hổng có thể gây **sập web khi deploy**. Đã sửa:

| # | Lỗ hổng | Hậu quả nếu bỏ qua | Cách sửa |
|---|---|---|---|
| A | **Không có Traefik CRD trong repo**, mà CI xoá `tkb-gateway` **trước** khi apply | Cluster chưa cài CRD → apply `IngressRoute` fail → **gateway đã bị xoá, web mất cổng vào** | CI **kiểm tra CRD trước**; thiếu thì thử cài từ bản phát hành chính thức v3.3, vẫn thiếu thì **DỪNG DEPLOY** và giữ nguyên gateway cũ. Thêm precheck **PVC `tkb-storage` phải Bound**, thiếu cũng dừng trước khi gỡ gateway |
| B | 5 Deployment **không khai báo** `SESSION_DRIVER`/`CACHE_STORE`/`QUEUE_CONNECTION`, phụ thuộc hoàn toàn vào Secret `tkb-env` | Đi từ **1 pod → 6 pod**. Nếu Secret đang là `file` thì mỗi pod giữ session riêng → **người dùng bị văng đăng nhập liên tục** | Khai báo tường minh `= database` trong cả 5 deployment (env khai báo tại chỗ sẽ đè `envFrom`), không còn phụ thuộc nội dung Secret |
| C | `INTERNAL_API_SECRET` thiếu → `InternalApiAuth` luôn `abort(403)` | Deploy xong nhưng **LMS/TMS gọi Grades bị 403**, ví dụ chuyển điểm không chạy | Nếu `INTERNAL_API_SECRET` trống, suy ra khoá từ `APP_KEY` (mọi pod dùng chung `APP_KEY`) → internal API chạy được mà không cần thêm bước cấu hình |

Kiểm chứng: 22 file YAML trong `k8s/` parse hợp lệ (PyYAML); bash script trong CI
qua `sh -n` (exit 0); `php -l` sạch; `php artisan view:cache` pass;
**43 test pass (94 assertions)** cho nhóm JWT/DbRef/StorageHelper/topology/model connection.

**Rủi ro còn lại sau 3 sửa trên:** nếu pod không lên được vì lý do khác (image pull,
thiếu tài nguyên), CI fail sau khi gateway đã bị gỡ. Đường lùi: `git revert -m 1 <merge-commit>`
rồi push `main` — thao tác này khôi phục nguyên trạng cây `main` (CI monolith + manifest cũ)
và deploy lại bản cũ trong ~5 phút.

### Phát hiện quan trọng về nhánh

`main` và `dev` **đã rẽ nhánh từ lâu**: `main` đi trước **132 commit**, `dev` đi trước **19 commit**
(merge-base `50c4a279`). Toàn bộ công việc microservices được xây trên snapshot **cũ 132 commit**
— tức trước các PR #351–#358 vừa làm.

Đã xử lý: **merge `origin/main` vào `dev`** — kết quả **không xung đột file nào**
(phần microservices chủ yếu là file/thư mục mới). Từ đây PR `dev → main` là **thuần bổ sung**,
không còn rủi ro ghi đè công việc trên `main`.

Lưu ý: merge sạch về văn bản không bảo đảm đúng về ngữ nghĩa ở các file cả hai bên cùng sửa
(`app/Models/User.php`, `bootstrap/providers.php`, các `Providers/*.php`, CI) — vẫn cần
kiểm tra nghiệp vụ sau khi deploy.



---

## 11. KET QUA DEPLOY THUC TE — 17/09/2026

`dev -> main` **da merge va deploy thanh cong** (run `35213984391`, sau do `35215873155`).
Trang thai cluster xac minh bang workflow chan doan chi-doc:

```
deployment    READY  CONTAINERS   IMAGES
tkb-core      1/1    fpm,nginx    cdhc2-core + cdhc2-sidecar
tkb-lms       1/1    fpm,nginx    cdhc2-lms  + cdhc2-sidecar
tkb-tms       1/1    fpm,nginx    cdhc2-tms  + cdhc2-sidecar
tkb-grades    1/1    fpm,nginx    cdhc2-grades + cdhc2-sidecar
tkb-scheduler 1/1    scheduler    cdhc2-core
traefik       1/1    traefik      traefik:v3.3
tkb (cu)      1/1    qlhv         tkb:latest      <- monolith, van chay
```

Test HTTP qua Traefik (NodePort 30800):

| Duong dan | Ma | Nhan xet |
|---|---|---|
| `/` | 302 | chuyen huong dang nhap |
| `/login` | **200** | **trang dang nhap render duoc — Laravel boot, DB ket noi, session OK** |
| `/lms`, `/tms`, `/grades`, `/vat-tu`, `/quan-ly-phep`, `/essay-exams` | 302 | dinh tuyen toi dung service |
| `/api/internal/lms/stats` | 404 | route khong ton tai, nhung chung to Traefik da route toi lms-svc |

### 6 loi that da gap va sua trong qua trinh deploy

| # | Loi | Sua |
|---|---|---|
| 1 | PVC khai ReadWriteMany nhung cluster la ReadWriteOnce; accessModes BAT BIEN -> kubectl apply fail | Bo PVC khoi danh sach scp; sua manifest cho khop + precheck Bound |
| 2 | Traefik RBAC thieu `endpointslices` (discovery.k8s.io) | Them rule |
| 3 | Probe `/ping` 404: mac dinh phuc vu o entrypoint `traefik` (khong bat) | Them `--ping.entryPoint=web` |
| 4 | Traefik thieu quyen doc `nodes` | Them rule |
| 5 | **entrypoint.sh tim APP_KEY trong file /var/www/.env** — container khong co file nay (dung envFrom) -> `set -e` giet initContainer migrate -> pod BackOff | Uu tien bien moi truong; chi key:generate khi thuc su co .env |
| 6 | Pod cu khong duoc thay vi tag `:latest` + imagePullPolicy IfNotPresent -> "exceeded its progress deadline" | imagePullPolicy: Always (10 container) + kubectl rollout restart |

Ngoai ra sua: middleware dat cung `X-Forwarded-Proto: https` (se lam hong dang nhap qua HTTP),
don 2 Job rac InvalidImageName, va loi zsh (`for path in ...` ghi de PATH).

### ⚠️ VIEC CON LAI: chuyen traffic prod (CHUA thuc hien)

**Prod hien VAN do monolith phuc vu.** Ingress `tkb` (class nginx, host tkb.cdhc2.edu.vn, cong 80)
dang tro `/ -> tkb:8000` (monolith). Stack moi chay song song, da san sang o NodePort 30800.

Chuyen traffic (1 lenh, quay lai duoc tuc thi):

```bash
gh workflow run cutover-ingress.yaml --ref main -f action=status
gh workflow run cutover-ingress.yaml --ref main -f action=to-traefik
gh workflow run cutover-ingress.yaml --ref main -f action=to-monolith   # neu co van de
```

**Vi sao chua tu chuyen:** khong xac minh duoc. Goi Ingress tu runner tra **468** — day la
**ma rate-limit cua chinh app** (frontend coi `429 || 468` la "bi chan, cho 30s"), nen curl tu
runner bi throttle va khong phan anh dung trai nghiem nguoi dung that. Chuyen traffic ma khong
nhin thay duoc ket qua la rui ro khong can thiet khi prod dang chay tot.
