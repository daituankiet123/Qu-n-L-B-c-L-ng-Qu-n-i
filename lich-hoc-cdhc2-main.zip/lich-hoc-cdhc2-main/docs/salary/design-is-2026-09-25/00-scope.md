# Phạm vi audit (design-is, 25/09/2026)

- Đối tượng: giao diện web **dự kiến** cho service "Bậc lương QNCN" — chưa có thiết kế web.
- Nguồn đối chiếu: ứng dụng MS Access `QLNL.accdb` (41 form, 43 report) — dùng để hiểu nghiệp vụ, không phải thiết kế cần giữ.
- Người dùng chính: cán bộ Quân lực lập hồ sơ nâng lương; lãnh đạo duyệt/ký.
- Việc chính: mỗi đợt chọn loại nâng lương → danh sách đúng người đến hạn → duyệt → in quyết định → áp dụng lương mới.
- Ràng buộc: Laravel 12 + Blade + Alpine + Tailwind v4; Apple Design System của dự án; select dùng Apple Dropdown (không Tom Select); tiếng Việt Unicode; WCAG AA.
