# Kết luận: NEW DESIGN

Chưa tồn tại thiết kế web nào để giữ lại, nên bỏ qua chấm điểm (Phase 1–2) và thiết kế mới từ mục đích.

Nước đi có đòn bẩy lớn nhất:
1. **#2 Hữu ích** — gộp 5 bộ form gần giống nhau của Access (`F DE NGHI NANG LUONG`, `… TRUOC HAN`, `… KEO DAI`, `… CHUYEN NGACH`, `… KHAC`) thành **một luồng đợt nâng lương** có bộ chọn loại.
2. **#4 Dễ hiểu** — mỗi bước một hành động chính, nhãn nghiệp vụ ("Xét danh sách", "Duyệt", "In quyết định", "Áp dụng lương mới") thay tên kỹ thuật (`Chuyen DL`, `Cap nhat`).
3. **#10 Ít thiết kế nhất** — 43 report (mỗi loại × danh sách/phụ lục/quyết định/tìm kiếm/tìm kiếm all) → ~8 mẫu `ExportTemplates` có biến theo loại.
4. **#8 Chu đáo** — đủ 6 trạng thái (trống/tải/lỗi/thành công/focus/vô hiệu) + banner khi TMS mất kết nối.
5. **#6 Trung thực** — "Áp dụng lương mới" không hoàn tác → xác nhận nêu rõ số người + số QĐ.
