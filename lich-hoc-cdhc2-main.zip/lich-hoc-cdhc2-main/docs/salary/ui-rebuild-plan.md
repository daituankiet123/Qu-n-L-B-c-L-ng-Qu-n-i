# Plan: dựng lại giao diện QL Bậc Lương QNCN (Apple Design)

Yêu cầu chủ dự án (26/09): "build lại giao diện của QL Bậc lương QNCN", **bắt buộc dùng skill `/apple-design`**. Giữ cổng riêng
(`layouts.salary`) + tông natural green kính mờ (memory: salary là cổng riêng). Không đổi route/controller/logic — chỉ view + CSS.
Không dùng Tom Select; select dùng Apple Dropdown (`partials.apple-dropdown`, theme `salary`).

## Vấn đề hiện tại (chủ dự án: "UI kì")
- Form lồng trong từng dòng bảng (Bảng lương: mỗi dòng 1 form 5 ô + xoá) → rối, cột không thẳng.
- Nhiều `<details>` thô (Sửa đợt, Xoá đợt, In theo mẫu Access, Thêm dòng quá trình lương) — mũi tên mặc định, không giống Apple.
- Form thêm người vào đợt dồn 6–9 ô trên 1 hàng; nhãn dài xuống dòng lệch.
- Card nào cũng cùng kiểu → không có thứ bậc; KPI, bảng, form trông như nhau.

## Hướng thiết kế (theo /apple-design)
- Nền sáng, lưới 8px, khoảng trắng rộng; tiêu đề lớn (clamp), chữ hệ thống; radius 16–20; bóng nhẹ; kính mờ chỉ cho header + sheet.
- **Bảng chỉ để xem** (tabular-nums, hàng cao 48px, hover nhẹ). Sửa/thêm/xoá mở **sheet trượt từ phải** (Alpine `x-data`), 1 form dọc.
- Nút: pill 44px (primary xanh `--s-accent`, secondary kính, destructive đỏ `--s-bad` chỉ trong sheet xoá). Xoá vẫn gõ `XOA`.
- Segmented control cho tab/trạng thái; thanh tiến trình đợt dạng stepper tròn có số.
- Menu "In theo mẫu Access" → popover kính có nhóm Word/PDF, đóng khi bấm ngoài.
- Empty state có câu hướng dẫn + nút hành động. Focus ring 2px, `prefers-reduced-motion`, chạm ≥ 44px, mobile 1 cột.

## Việc theo file (thứ tự làm)
1. `resources/views/layouts/salary.blade.php` + `modules/Salary/Views/layout.blade.php`: token (8px spacing, radius, shadow scale),
   component CSS mới: `.s-table`, `.s-sheet` (+ backdrop), `.s-segment`, `.s-stepper`, `.s-popover`, `.s-field` (label trên, help dưới),
   `.s-btn` / `.s-btn-secondary` / `.s-btn-danger`; include Alpine nếu layout chưa có.
2. `dashboard.blade.php`: hàng KPI 3 ô lớn; "Sắp đến hạn" bảng gọn + chip trạng thái; "Đợt đang mở" dạng list có chip.
3. `rounds/index.blade.php`: danh sách đợt (bảng) + nút "Mở đợt" → sheet form.
4. `rounds/show.blade.php`: stepper; hàng hành động (In ▾, Sửa đợt, Xoá đợt → sheet); "Thêm quân nhân" → sheet, ô theo loại đợt;
   bảng người: nút Duyệt/Bỏ gọn; khối bước tiếp (Chuyển đề nghị / Lưu quyết định / Áp dụng) thành card nổi bật cuối trang.
5. `catalog/scales.blade.php`: mỗi loại/nhóm 1 card, bảng xem; bấm dòng → sheet sửa (bậc, hệ số, quân hàm, hiệu lực) + vùng xoá gõ XOA;
   nút "Thêm bậc" trên mỗi card (điền sẵn loại/nhóm) + nút "Thêm loại/nhóm mới" ở đầu trang.
6. `people/index.blade.php`, `people/show.blade.php`, `people/history-form.blade.php`: hồ sơ dạng 2 cột (thông tin | quá trình lương
   timeline); sửa hồ sơ + thêm/sửa dòng quá trình → sheet.
7. `catalog/settings.blade.php`, `reports.blade.php`, `decisions.blade.php`, `guide.blade.php`: form dọc theo nhóm, segmented cho 5 loại QĐ.

## Kiểm tra (bắt buộc trước khi xin duyệt — memory "xem UI trước khi xin duyệt")
- Dữ liệu demo ở máy (`SalaryDemoSeeder`), chủ dự án tự đăng nhập ở Browser pane `localhost:8123` (agent không gõ mật khẩu).
- Chụp từng trang desktop + mobile (375px); bấm thử: mở/đóng sheet, thêm/sửa/xoá bậc, thêm người vào đợt, duyệt, xoá đợt gõ XOA.
- `php artisan test tests/Feature/Salary tests/Unit/Salary` (test dùng `assertSee` chữ tiếng Việt — giữ nguyên các nhãn đang được test
  hoặc sửa test cùng lúc); `vendor/bin/pint --dirty`.
- 1 PR, merge 1 lần (tiết kiệm phút Actions).
