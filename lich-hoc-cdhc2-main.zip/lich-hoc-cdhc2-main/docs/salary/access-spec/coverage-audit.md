# Đối chiếu chức năng Access QLNL ↔ web `salary` (26/09/2026)

Nguồn: menu thật `Navigation Form` / `FrmMenu`, code VBA sự kiện của 19 form nghiệp vụ, 87 query, 43 report
(trích bằng `export-scripts/`). Các macro `MDSXN*`, `MLuu*`, BHXH, thẻ học nghề… trỏ tới form **không tồn tại** trong
file (sót lại từ ứng dụng "QL XN" gốc) → không tính.

Ký hiệu: ✅ có, đúng logic · 🟡 có nhưng khác/thiếu một phần · ❌ chưa có · ♻️ dùng hệ thống chung (core)

## Nghiệp vụ nâng lương (5 form `F DE NGHI …`)

| Chức năng Access | Web | Ghi chú |
|---|---|---|
| Danh sách đến hạn TX (`Q_Danh sach den han nang luong`: ngưỡng 5.4, 2/3 năm, TNVK ≥5 xét hằng năm, `Ngaynhan_Ktra`) | ✅ | `SalaryRules::isDueRegular`, test theo bảng lương thật |
| 1 Duyệt DS đến hạn (duyệt toàn bộ) | ✅ | nút "Duyệt tất cả" (26/09) |
| 2 Duyệt đề nghị từ kết quả xét | ✅ | duyệt từng người + "Chuyển đề nghị" |
| Loại người đang đề nghị kéo dài khỏi DS TX (`Denghi_keodai=False`) | ✅ | chặn 1 người ở 2 đợt chưa áp dụng (26/09) |
| Trước niên hạn: xác nhận/bỏ xác nhận, chặn 2 lần liên tiếp, bắt nhập ngày nhận mới + lý do | ✅ | 29/09: ô lý do/ngày nhận mới đánh dấu bắt buộc ngay trên form |
| Kéo dài: bắt nhập lý do + số tháng; lương mới lùi theo số tháng | ✅ | 29/09: ô lý do/số tháng đánh dấu bắt buộc ngay trên form |
| Khác: bắt nhập **ngày nhận mới + lý do** (`Q_Duyet xet nang luong khac`) | ✅ | sửa 26/09 (trước đó web tự tính ngày) |
| Chuyển loại/ngạch/nhóm: chọn loại/nhóm mới, hệ số bằng hoặc cao hơn gần nhất | ✅ | |
| 3 In quyết định (bắt nhập số QĐ, ngày ký, người ký) | ✅ | mẫu chuẩn Access, mỗi người 1 QĐ |
| 5–8 In DS đến niên hạn / DS xét / DS đề nghị / Phụ lục | ✅ | mẫu chuẩn Access (Word/PDF) |
| 4 Cập nhật lương mới (`Q_Chuyen DL …`, `Q_Cap nhat …`) → quá trình lương + hồ sơ + thăng quân hàm | ✅ | `RoundApplier`, 1 transaction, không nhân đôi |
| Sửa căn cứ (5 form `F CAN CU …`) | ✅ | trang Căn cứ & người ký |
| Nhận/xuất Excel danh mục trong form đề nghị | ❌ | thấp — nút ẩn/không có caption trong Access |
| In công văn đề nghị (`CmdTimfile`) | — | handler rỗng trong Access (không hoạt động) |

## Hồ sơ – tra cứu – báo cáo

| Chức năng Access | Web | Ghi chú |
|---|---|---|
| Hồ sơ quân nhân (`F CAN BO NHAN VIEN`): danh sách = mọi người mang cấp bậc QNCN | ✅ | roster tự động từ Người dùng (quyết định chủ dự án) |
| Sửa hồ sơ lương: bậc hiện hưởng, ngày nhận, TNVK, hệ số bảo lưu, nhập ngũ, chức vụ, trình độ | ✅ | form trên trang hồ sơ (26/09) |
| In DS QNCN đang quản lý / không còn quản lý (`R_Danh sach CB NV …`) | ✅ | mẫu Access; ngày giảm hồ sơ đưa người sang DS không còn quản lý, lọc theo khoảng ngày giảm. Trú quán lấy xã/phường và tỉnh từ Người dùng (core, địa giới 2 cấp; không tự chuyển địa chỉ Access cũ) |
| Quá trình lương (`F QUA TRINH LUONG`): xem | ✅ | trang hồ sơ |
| Quá trình lương: thêm / sửa / xoá dòng thủ công | ✅ | mã bậc → loại/nhóm/bậc/hệ số theo bảng lương hiệu lực; ghi đè hệ số được |
| In quá trình lương của quân nhân (`R_Qua trinh luong cua quan nhan`) | ✅ | mẫu Access (mặc định); mẫu tự tạo vẫn dùng được |
| Báo cáo bậc lương hiện hưởng (`F BAO CAO`: tất cả / theo loại) | ✅ | mẫu Access; lương tiếp theo = ngày nhận (hoặc chuyển lương) + 1/2/3 năm đúng công thức query |
| Thống kê DS nâng bậc lương theo khoảng năm (`F THONG KE`, `R Danh sach thong ke …`) | ✅ | cũ/mới ghép từ quá trình lương (tương đương bảng `L NANG LUONG`); sửa lỗi cột tháng nhận mới của Access |
| Tìm kiếm thông tin bậc lương (`F TIM KIEM`) | ✅ | tìm theo tên/mã ở Quân nhân QNCN |
| Tìm kiếm quyết định (`F TIM KIEM QUYET DINH`) + in lại QĐ cũ (`R_Quyet dinh …_Timkiem`) | ✅ | mọi số QĐ trong quá trình lương (cả QĐ nhập từ Access) có nút In lại |
| Bảng lương (`F BANG LUONG QNCN`): sửa, kiểm tra | ✅ | phiên bản theo ngày hiệu lực + `ScaleValidator` |
| Bảng lương: nhận/xuất Excel | ✅ | #506: Nhập Excel theo cột BANG LUONG (ghi phiên bản theo ngày hiệu lực, không xoá bậc thiếu), Xuất Excel. Quá trình lương: xuất Excel 1 người / tất cả (nút nhập của Access ghi nhầm bảng chuyên ngành → không làm) |

## Danh mục – hệ thống

| Chức năng Access | Web | Ghi chú |
|---|---|---|
| Đơn vị, Cấp bậc/quân hàm, Chức vụ, CNQS, Dân tộc, Tôn giáo, Tỉnh/Huyện/Xã | ♻️ | danh mục chung của core (không nhân đôi) |
| Đăng nhập, đổi mật khẩu, người dùng, phân quyền (`MAT KHAU`, `user`) | ♻️ | tài khoản + RBAC core, quyền `salary.*` |
| Thiết lập cấu hình (`F THAY DOI` = bảng `Lam viec`) | ✅ | Căn cứ & người ký + Đơn vị báo cáo & trích sao |
| Hướng dẫn, giới thiệu | — | không cần |

## Khác biệt logic

- 26/09: điều kiện đến hạn thường xuyên đổi cho giống Access — OR mốc ngày nhận lương và mốc ngày chuyển lương.
- 26/09 (rà lần 2, đọc SQL từng query cập nhật + VBA form), đã sửa cho giống Access:
  - **Chuyển ngạch** (`Q_Cap nhat nang luong chuyen loai ngach`, `Q_Kiem tra`): không đổi `Ngaynhan_Luong`, không đổi TNVK;
    `Ngaynhan_Ktra` = ngày nhận cũ nếu hệ số tăng < 1 bậc ngạch cũ, ngược lại rỗng. Trước đó web đặt ngày nhận = ngày chuyển.
  - Chuyển ngạch bắt buộc lý do + trình độ + ngành đào tạo; được chọn bậc mới (≥ hệ số đang hưởng, mặc định DMin) và tháng nhận mới.
  - **Kéo dài**: chỉ người đã đến hạn (form lấy từ `Q_Danh sach den han nang luong KEO DAI`); ngày nhận mới sửa tay được.
  - **Trước niên hạn**: không đổi TNVK trong hồ sơ (`Q_Cap nhat nang luong truoc nien han`).
  - **Import**: `last_raise_type` = loại của dòng quá trình lương mới nhất (Access dùng `CBNV.Ghichu` để chặn trước hạn 2 lần).
- Khác có chủ đích (web đúng hơn, không làm theo lỗi Access):
  - Nâng lương thường xuyên/khác/kéo dài/trước hạn xoá `Ngaynhan_Ktra` cũ (Access để sót → người từng chuyển ngạch đến hạn lại mỗi năm).
  - Loại "Khác": Access ghi lý do vào `Lydo_truochan` nhưng đọc `Lydo_Khac` → mất lý do; web giữ lý do.

## Việc còn lại

- (Thấp, không làm) Nhận/xuất Excel danh mục trong form đề nghị — nút ẩn, không có caption trong Access.
- Nhập dữ liệu Access thật lên prod: màn Salary → Thiết lập → Nhập từ Access (#507), chủ dự án tự thao tác.
