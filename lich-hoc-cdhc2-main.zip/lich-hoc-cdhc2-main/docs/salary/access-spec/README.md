# Đặc tả nghiệp vụ trích từ Access `QLNL.accdb`

Nguồn sự thật cho test của service `salary` (plan `docs/superpowers/plans/2026-09-25-salary-qncn-service.md`, mục "Đặc tả nghiệp vụ").

| File | Nội dung |
|---|---|
| `schema.md` | 26 bảng (cột, kiểu, index, quan hệ) |
| `queries.sql` | 87 query (xét/duyệt/cập nhật/chuyển dữ liệu từng loại nâng lương) — các quy tắc trong `SalaryRules` bám các query `Q_Danh sach den han nang luong`, `Q_Danh sach kiem tra he so luong`, `Q_Cap nhat nang luong *`, `Q_Chuyen DL *` |
| `bang-luong.tsv` | Bảng lương 42 dòng (dòng `TC7/10` nghi nhập sai: bậc 6/10, hệ số 5) |
| `quan-ham.tsv`, `loai.tsv`, `loai-loc.tsv`, `trinh-do.tsv` | Danh mục |
| `can-cu.md` | Căn cứ, tên quyết định, nơi nhận… theo từng loại (bỏ tên người thật) |
| `export-scripts/` | Script tái xuất |

**Không** có dữ liệu cá nhân quân nhân trong thư mục này.

## Tái xuất (máy Windows có MS Access)

Luôn làm trên **bản sao** file `.accdb`, macro/VBA tắt (`AutomationSecurity = 3`):

1. `powershell -File export-scripts/export_access.ps1` — form/report/macro/module (`SaveAsText`).
2. `C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -File export-scripts/export_dao32.ps1` — bảng + query (DAO chỉ chạy được với PowerShell 32-bit vì Office 32-bit).
3. Cùng PowerShell 32-bit: `export-scripts/export_lookups32.ps1` — danh mục ra TSV (bỏ ảnh, cột mật khẩu, người dùng).

Sửa đường dẫn `$src`/`$work` ở đầu script trước khi chạy. Ngưỡng hệ số `5.4` nằm trong VBA của form `F DE NGHI … NANG LUONG` (`TxtDK1/TxtDK2`), không có trong bảng.
