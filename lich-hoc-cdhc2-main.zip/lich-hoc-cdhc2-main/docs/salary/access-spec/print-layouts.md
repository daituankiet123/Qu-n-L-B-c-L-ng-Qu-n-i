# Mẫu in chuẩn Access (QL Bậc Lương QNCN)

Nguồn sự thật: chính các report của `QLNL.accdb`. Mẫu in của service `salary` tái tạo **bố cục, câu chữ, font và định dạng số** của từng report; đã so sánh với ảnh PDF do Access in ra.

## Cách lấy từ Access

| Bước | Script (`export-scripts/`) | Kết quả |
|---|---|---|
| Định nghĩa report (`SaveAsText`) | `export_access.ps1` | `reports/*.txt`: vị trí control (twip), font, biểu thức `ControlSource`, `Format`, nhóm/sắp xếp |
| Bảng `Lam viec` id=2 (giữ nguyên `\r\n`, khoảng trắng đầu dòng; bỏ tên người thật) | `export_lamviec32.ps1` (PowerShell 32-bit) | `lam-viec-defaults.json` |
| Spec bảng danh sách (16 report) | `build_print_spec.py <reports> modules/Salary/Printing/access-lists.json <tên report...>` | `access-lists.json`: khổ giấy, lề, control và đường kẻ theo section, nhóm |
| Ảnh đối chiếu | `export_report_pdfs.ps1` (mở form tham số ẩn, `OutputTo` PDF), `pdf2png.ps1` | PDF/PNG (dữ liệu thật, **không** commit) |

Luôn làm trên **bản sao** `.accdb`, macro/VBA tắt (`AutomationSecurity = 3`).

## Trong code (`modules/Salary/Printing`)

- `DecisionDocx`: 5 loại quyết định (`R_Quyet dinh ...`), **mỗi quân nhân một quyết định, mỗi quyết định một trang**. A4 dọc, lề 1.78/0.89 cm, vùng in 18.10 cm (đúng `Width` của report nên xuống dòng giống Access). Căn cứ in từng dòng căn đều; đuôi "   ." (khoảng trắng + dấu chấm) thành tab phải, giống kiểu *distribute* của Access.
- `ListDocx`: danh sách Đề nghị / Xét / Phụ lục / Đến niên hạn, đọc `access-lists.json`. Tiêu đề 2 tầng (vạch dọc chạy hết chiều cao = cột chính, vạch từ giữa = cột con), lặp mỗi trang; nhóm theo `Loc` → `SXL` (chuyển ngạch: `LSX2` → `LSX`), TT đánh lại theo nhóm, đường chấm giữa các dòng, dòng trống cuối, khối ký 3 cột, "Trang n".
- `AccessExpr`: thông dịch biểu thức Access (`IIf`, `UCase`, `Left/Len/Val`, `Format`, `DLookUp`, `Count`, `[Page]`, `[Forms]!…`) để ô in **đúng nguyên văn** biểu thức gốc.
- `AccessFormat`: hệ số trong quyết định dạng *General Number* (`6.2`, `3.95`), trong bảng dạng *Standard* (`6.20`); tháng/năm `mm/yy` (bảng), `mm/yyyy` (quyết định); ngày hưởng lương mới `d/m/yyyy`; tên cấp bậc theo bảng `QUAN HAM` của Access ("Trung uý QNCN").
- `PrintRecords`: dựng bản ghi theo **tên trường của query Access** (`Hoten`, `Heso`, `HS_Moi`, `VKM`, `QHM`, `KyhieuDV`…).

## Khác biệt có chủ đích

- `R_Quyet dinh nang luong truoc khac`: bản in của chính Access bị **chồng chữ** (control cao 6 cm đè nhau). Mẫu "Khác" dùng bố cục của "Trước thời hạn", dòng "Lý do" đặt sau thông tin bậc.
- Nhãn "Tuyểndụng" (Access viết liền, tự ngắt dòng thành "Tuyển / dụng" trong ô hẹp) được in là "Tuyển dụng" để Word ngắt dòng giống hệt.
- Phụ lục thường xuyên có dòng nghiêng chữ "t" dưới tiêu đề: giữ nguyên như Access.
- Thống kê nâng bậc lương: cột "Tháng năm nhận" mới của Access trỏ nhầm vào `HSBL_Moi` (hệ số bảo lưu) → web in `Ngaynhan_Moi`.
- DS QNCN đang quản lý: cột trú quán dùng xã/phường và tỉnh từ Người dùng (core, địa giới 2 cấp); huyện để trống, bỏ dấu phẩy của phần trống. Địa chỉ chi tiết đọc từ `residence_address` khi mẫu có trường `Diachi`; không tự chuyển địa chỉ Access 3 cấp.
- `NguoikyQD_CN` trong Access là **chức danh người quyết định** ("Bộ trưởng Bộ Quốc phòng"), không phải tên người ký.
