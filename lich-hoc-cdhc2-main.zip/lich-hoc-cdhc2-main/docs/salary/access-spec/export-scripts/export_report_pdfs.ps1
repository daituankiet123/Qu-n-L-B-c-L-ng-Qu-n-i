﻿param([string[]]$Reports, [string]$ListFile)
if ($ListFile) { $Reports = Get-Content -Encoding UTF8 $ListFile }
$ErrorActionPreference = 'Continue'
$src = 'C:\Users\Admin\Downloads\QLNBL\QLNBL\QLNL.accdb'
$work = 'C:\Users\Admin\AppData\Local\Temp\claude\D--CDHC2-lich-hoc-cdhc2\5ebd99ab-41a8-4467-a18f-d4f5628b2274\scratchpad\qlnl-pdf'
New-Item -ItemType Directory -Force -Path $work | Out-Null
$copy = Join-Path $work 'QLNL-pdf.accdb'
Copy-Item $src $copy -Force

$app = New-Object -ComObject Access.Application
$app.AutomationSecurity = 3   # tat macro/VBA
$app.Visible = $false
$app.OpenCurrentDatabase($copy, $false)

# Gia tri mau cho cac o tham so ma report doc tu form (khong phai du lieu that)
$values = @{
    'TxtSQD' = '123/QĐ-TCHC'; 'CmbNgay' = '20'; 'CmbThang' = '09'; 'CmbNam' = '2026';
    'TxtchucNK' = 'KT. CHỦ NHIỆM'; 'TxtNguoiky' = 'Nguyễn Văn Ký';
    'Txtsosao' = '45/TS-TCHC'; 'Cmbngaysao' = '25'; 'Cmbthangsao' = '09'; 'Cmbnamsao' = '2026';
    'TxtCDsao' = 'TL. CHỦ NHIỆM'; 'TxtNguoisao' = 'Trần Văn Sao';
    'TxtNgay' = '20/09/2026'; 'TxtNamLV' = '2026'; 'TxtTu' = '2000'; 'TxtDen' = '2030'; 'TxtNam' = '2023'
}
foreach ($f in @('F DE NGHI NANG LUONG', 'F DE NGHI NANG LUONG TRUOC HAN', 'F DE NGHI KEO DAI NANG LUONG', 'F DE NGHI NANG LUONG KHAC', 'F DE NGHI CHUYEN NGACH LUONG', 'USER', 'F BAO CAO', 'F THONG KE', 'F TIM KIEM', 'F TIM KIEM QUYET DINH', 'F QUA TRINH LUONG', 'F CAN BO NHAN VIEN')) {
    try {
        $app.DoCmd.OpenForm($f, 0, '', '', -1, 1)   # acNormal, hidden
        $frm = $app.Forms.Item($f)
        foreach ($k in $values.Keys) { try { $frm.Controls.Item($k).Value = $values[$k] } catch {} }
        "FORM ok $f"
    } catch { "FORM skip $f : " + $_.Exception.Message }
}

foreach ($r in $Reports) {
    $out = Join-Path $work (($r -replace '[\\/:*?"<>|]', '_') + '.pdf')
    try { $app.DoCmd.OutputTo(3, $r, 'PDF Format (*.pdf)', $out, $false); "PDF ok $r" }
    catch { "PDF ERR $r : " + $_.Exception.Message }
}
$app.CloseCurrentDatabase()
$app.Quit()
"DONE"
