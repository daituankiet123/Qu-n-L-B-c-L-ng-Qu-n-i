$ErrorActionPreference = 'Continue'
$src = 'C:\Users\Admin\Downloads\QLNBL\QLNBL\QLNL.accdb'
$work = 'C:\Users\Admin\AppData\Local\Temp\claude\D--CDHC2-lich-hoc-cdhc2\5ebd99ab-41a8-4467-a18f-d4f5628b2274\scratchpad\qlnl'
New-Item -ItemType Directory -Force -Path $work | Out-Null
$copy = Join-Path $work 'QLNL-copy.accdb'
Copy-Item $src $copy -Force
foreach ($d in 'tables','queries','forms','reports','macros','modules') { New-Item -ItemType Directory -Force -Path (Join-Path $work $d) | Out-Null }

# 1) DAO: bang + truong + quan he + query SQL (khong chay macro)
$dbe = New-Object -ComObject DAO.DBEngine.120
$db = $dbe.OpenDatabase($copy, $false, $true)
$schema = New-Object System.Text.StringBuilder
foreach ($t in $db.TableDefs) {
    if ($t.Name -like 'MSys*' -or $t.Name -like '~*') { continue }
    $count = -1
    try { $rs = $db.OpenRecordset("SELECT COUNT(*) FROM [" + $t.Name + "]"); $count = $rs.Fields.Item(0).Value; $rs.Close() } catch {}
    [void]$schema.AppendLine("## TABLE " + $t.Name + "  (rows=" + $count + ", connect=" + $t.Connect + ")")
    foreach ($f in $t.Fields) { [void]$schema.AppendLine("  - " + $f.Name + " : type=" + $f.Type + " size=" + $f.Size + " required=" + $f.Required) }
    foreach ($ix in $t.Indexes) { $fl = ($ix.Fields | ForEach-Object { $_.Name }) -join ','; [void]$schema.AppendLine("  * index " + $ix.Name + " primary=" + $ix.Primary + " unique=" + $ix.Unique + " (" + $fl + ")") }
}
[void]$schema.AppendLine("## RELATIONS")
foreach ($r in $db.Relations) { $fl = ($r.Fields | ForEach-Object { $_.Name + '->' + $_.ForeignName }) -join ','; [void]$schema.AppendLine("  " + $r.Table + " -> " + $r.ForeignTable + " (" + $fl + ") attr=" + $r.Attributes) }
[IO.File]::WriteAllText((Join-Path $work 'schema.md'), $schema.ToString(), [Text.Encoding]::UTF8)

$q = New-Object System.Text.StringBuilder
foreach ($qd in $db.QueryDefs) {
    if ($qd.Name -like '~*') { continue }
    [void]$q.AppendLine("## QUERY " + $qd.Name + " (type=" + $qd.Type + ")")
    [void]$q.AppendLine($qd.SQL)
}
[IO.File]::WriteAllText((Join-Path $work 'queries.sql'), $q.ToString(), [Text.Encoding]::UTF8)
$db.Close()

# 2) Access.Application: form/report/macro/module qua SaveAsText, TAT macro/VBA
$app = New-Object -ComObject Access.Application
$app.AutomationSecurity = 3   # msoAutomationSecurityForceDisable
$app.Visible = $false
$app.OpenCurrentDatabase($copy, $false)
$proj = $app.CurrentProject
$map = @(
    @{ coll = $proj.AllForms;   type = 2; dir = 'forms' },
    @{ coll = $proj.AllReports; type = 3; dir = 'reports' },
    @{ coll = $proj.AllMacros;  type = 4; dir = 'macros' },
    @{ coll = $proj.AllModules; type = 5; dir = 'modules' }
)
foreach ($m in $map) {
    foreach ($obj in $m.coll) {
        $safe = ($obj.Name -replace '[\\/:*?"<>|]', '_')
        $out = Join-Path (Join-Path $work $m.dir) ($safe + '.txt')
        try { $app.SaveAsText($m.type, $obj.Name, $out) } catch { "ERR " + $m.dir + " " + $obj.Name + ": " + $_.Exception.Message }
    }
}
$app.CloseCurrentDatabase()
$app.Quit()
"DONE"
Get-ChildItem $work -Recurse -File | Group-Object { $_.Directory.Name } | ForEach-Object { $_.Name + ': ' + $_.Count }
