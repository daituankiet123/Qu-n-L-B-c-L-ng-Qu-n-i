$ErrorActionPreference = 'Stop'
$src = 'C:\Users\Admin\Downloads\QLNBL\QLNBL\QLNL.accdb'
$work = 'C:\Users\Admin\AppData\Local\Temp\claude\D--CDHC2-lich-hoc-cdhc2\5ebd99ab-41a8-4467-a18f-d4f5628b2274\scratchpad\qlnl'
$copy = Join-Path $work 'QLNL-lamviec.accdb'
Copy-Item $src $copy -Force
$dbe = New-Object -ComObject DAO.DBEngine.120
$db = $dbe.OpenDatabase($copy, $false, $true)
# Bo truong ten nguoi that / ghi chu noi bo
$skip = @('ID', 'Nguoi_Ky', 'Nguoi_BC', 'NguoikyQD_NBL', 'Ghi chu', 'Hienthi', 'MkND', 'MkSD', 'Nguoidung', 'Nguoilv', 'Nguoisd', 'logo')
$rs = $db.OpenRecordset('SELECT * FROM [Lam viec] WHERE ID = 2')
$out = [ordered]@{}
foreach ($f in $rs.Fields) {
    if ($skip -contains $f.Name) { continue }
    $v = $f.Value; if ($v -eq $null) { $v = '' }
    $out[$f.Name] = [string]$v
}
$rs.Close(); $db.Close()
$json = $out | ConvertTo-Json
[IO.File]::WriteAllText((Join-Path $work 'lam-viec.json'), $json, (New-Object System.Text.UTF8Encoding($false)))
'OK ' + $out.Count
