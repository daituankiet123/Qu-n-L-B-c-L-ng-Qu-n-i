"""SaveAsText report Access -> spec JSON cho ListDocx (chi bo cuc; khong du lieu ca nhan)."""
import json
import os
import re
import struct
import sys

T = 567.0


def load(path):
    lines = open(path, encoding='utf-16').read().splitlines()
    root = {'t': 'ROOT', 'p': {}, 'c': [], 'bin': {}}
    st = [root]
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        m = re.match(r'^Begin\s*(\w*)$', s)
        if m:
            n = {'t': m.group(1) or 'G', 'p': {}, 'c': [], 'bin': {}}
            st[-1]['c'].append(n)
            st.append(n)
        elif s == 'End':
            if len(st) > 1:
                st.pop()
        else:
            m = re.match(r'^(\w+)\s*=\s*(.*)$', s)
            if m and m.group(2).strip() == 'Begin':
                key, hexs = m.group(1), ''
                i += 1
                while lines[i].strip() != 'End':
                    hexs += ''.join(re.findall(r'0x([0-9a-fA-F]+)', lines[i]))
                    i += 1
                st[-1]['bin'][key] = hexs
                i += 1
                continue
            if m:
                k, v = m.group(1), m.group(2)
                while i + 1 < len(lines) and lines[i + 1].strip().startswith('"'):
                    i += 1
                    v += lines[i].strip()
                st[-1]['p'][k] = v
        i += 1
    return root


def val(v):
    if v is None:
        return ''
    v = v.strip()
    if v.startswith('"'):
        segs = re.findall(r'"((?:[^"\\]|\\.)*)"', v)
        return ''.join(segs).replace('\\"', '"')
    return v


def num(p, k, d=0):
    try:
        return int(p.get(k, d))
    except ValueError:
        return d


def cm(x):
    return round(x / T, 3)


def controls(sec):
    out = []
    for g in sec['c']:
        for c in (g['c'] if g['t'] == 'G' else [g]):
            p = c['p']
            if c['t'] not in ('Label', 'TextBox', 'Line'):
                continue
            item = {'type': c['t'], 't': cm(num(p, 'Top')), 'l': cm(num(p, 'Left')), 'w': cm(num(p, 'Width')), 'h': cm(num(p, 'Height'))}
            if c['t'] == 'Line':
                item.update({'bw': num(p, 'BorderWidth'), 'ls': num(p, 'BorderLineStyle')})
            else:
                item.update({
                    'text': val(p.get('Caption')) if c['t'] == 'Label' else val(p.get('ControlSource')),
                    'size': num(p, 'FontSize', 11), 'bold': num(p, 'FontWeight', 400) >= 600,
                    'italic': 'FontItalic' in p, 'underline': 'FontUnderline' in p,
                    'align': {'1': 'left', '2': 'center', '3': 'right', '4': 'both'}.get(p.get('TextAlign', ''), 'left'),
                    'format': val(p.get('Format')) if 'Format' in p else None,
                    'decimals': num(p, 'DecimalPlaces', -1) if 'DecimalPlaces' in p else None,
                    'running': num(p, 'RunningSum', 0), 'visible': p.get('Visible') not in ('0', 'NotDefault'),
                })
            out.append(item)
    return sorted(out, key=lambda c: (c['t'], c['l']))


def spec(path):
    root = load(path)
    rep = next(c for c in root['c'] if c['t'] == 'Report')
    p = rep['p']
    mip = bytes.fromhex(rep['bin'].get('PrtMip', ''))
    dev = bytes.fromhex(rep['bin'].get('PrtDevMode', ''))
    ml, mt, mr, mb = struct.unpack_from('<4i', mip, 0) if len(mip) >= 16 else (0, 0, 0, 0)
    orient = struct.unpack_from('<h', dev, 44)[0] if len(dev) >= 46 else 1
    out = {'record_source': val(p.get('RecordSource')), 'width': cm(num(p, 'Width')),
           'page': {'orientation': 'landscape' if orient == 2 else 'portrait', 'margins': [cm(ml), cm(mt), cm(mr), cm(mb)]},
           'groups': [], 'sections': {}}

    def walk(node):
        for c in node['c']:
            if c['t'] == 'BreakLevel':
                out['groups'].append({'field': val(c['p'].get('ControlSource')), 'header': 'GroupHeader' in c['p'],
                                      'descending': 'SortOrder' in c['p']})
            elif c['t'] in ('Section', 'PageHeader', 'PageFooter', 'FormHeader', 'FormFooter', 'BreakHeader', 'BreakFooter'):
                out['sections'][val(c['p'].get('Name', c['t']))] = {'kind': c['t'], 'height': cm(num(c['p'], 'Height')),
                                                                     'controls': controls(c)}
            elif c['t'] == 'G':
                walk(c)
    walk(rep)
    return out


if __name__ == '__main__':
    src = sys.argv[1]
    names = sys.argv[3:]
    res = {n: spec(os.path.join(src, n + '.txt')) for n in names}
    json.dump(res, open(sys.argv[2], 'w', encoding='utf-8', newline='\n'), ensure_ascii=False, indent=1)
    print('ok', len(res))
