$ErrorActionPreference = 'Continue'
$work = 'C:\Users\Admin\AppData\Local\Temp\claude\D--CDHC2-lich-hoc-cdhc2\5ebd99ab-41a8-4467-a18f-d4f5628b2274\scratchpad\qlnl'
$copy = Join-Path $work 'QLNL-copy.accdb'
New-Item -ItemType Directory -Force -Path (Join-Path $work 'data') | Out-Null
$dbe = New-Object -ComObject DAO.DBEngine.120
$db = $dbe.OpenDatabase($copy, $false, $true)
# Chi bang danh muc / cau hinh; KHONG xuat du lieu ca nhan (CAN BO NHAN VIEN, QUA TRINH LUONG, L NANG LUONG, user, User_Account)
$tables = @('BANG LUONG','BANG LUONG VIEN CHUC','QUAN HAM','LOAI','LOAI2','Loai loc','TRINH DO','CHUC VU','CNQS','DANH MUC DON VI','CAN CU','Lam viec')
$skip = @('logo','MkND','MkSD','Nguoidung','Nguoisd','Nguoilv')
foreach ($t in $tables) {
    $rs = $db.OpenRecordset("SELECT * FROM [" + $t + "]")
    $sb = New-Object System.Text.StringBuilder
    $names = @(); foreach ($f in $rs.Fields) { if ($skip -notcontains $f.Name) { $names += $f.Name } }
    [void]$sb.AppendLine(($names -join "`t"))
    while (-not $rs.EOF) {
        $vals = @(); foreach ($n in $names) { $v = $rs.Fields.Item($n).Value; if ($v -eq $null) { $v = '' }; $vals += (([string]$v) -replace "`r?`n", ' \n ' -replace "`t", ' ') }
        [void]$sb.AppendLine(($vals -join "`t"))
        $rs.MoveNext()
    }
    $rs.Close()
    [IO.File]::WriteAllText((Join-Path (Join-Path $work 'data') ($t + '.tsv')), $sb.ToString(), [Text.Encoding]::UTF8)
}
# Chi so luong + phan bo (khong ten) cua du lieu nghiep vu
$stats = New-Object System.Text.StringBuilder
foreach ($sql in @(
    "SELECT Giam, COUNT(*) FROM [CAN BO NHAN VIEN] GROUP BY Giam",
    "SELECT Left(Maso_Luong,2), COUNT(*) FROM [CAN BO NHAN VIEN] GROUP BY Left(Maso_Luong,2)",
    "SELECT Ghi_chu, COUNT(*) FROM [QUA TRINH LUONG] GROUP BY Ghi_chu",
    "SELECT Ghi_chu, COUNT(*) FROM [L NANG LUONG] GROUP BY Ghi_chu",
    "SELECT MIN(Ngaynhan), MAX(Ngaynhan) FROM [QUA TRINH LUONG]",
    "SELECT COUNT(*) FROM [CAN BO NHAN VIEN] WHERE TNVK > 0")) {
    [void]$stats.AppendLine("## " + $sql)
    $rs = $db.OpenRecordset($sql)
    while (-not $rs.EOF) { $vals = @(); foreach ($f in $rs.Fields) { $vals += [string]$f.Value }; [void]$stats.AppendLine("  " + ($vals -join ' | ')); $rs.MoveNext() }
    $rs.Close()
}
[IO.File]::WriteAllText((Join-Path $work 'stats.md'), $stats.ToString(), [Text.Encoding]::UTF8)
$db.Close()
"DONE-LOOKUPS"
