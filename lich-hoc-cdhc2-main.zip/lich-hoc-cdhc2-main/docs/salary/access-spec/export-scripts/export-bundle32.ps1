# Xuat goi JSON cho `php artisan salary:import` tu Access QLNL.
# CHAY bang PowerShell 32-bit (Office 32-bit):
#   C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -ExecutionPolicy Bypass -File export-bundle32.ps1 -Src "D:\...\QLNL.accdb" -Out "D:\...\qlnl.json"
# Mo file o che do CHI DOC tren BAN SAO. File ra chua du lieu ca nhan (ho ten, ngay sinh) - KHONG commit, xoa sau khi nhap.
param(
    [Parameter(Mandatory = $true)][string]$Src,
    [Parameter(Mandatory = $true)][string]$Out
)
$ErrorActionPreference = 'Stop'
$copy = Join-Path $env:TEMP ('qlnl-export-' + [guid]::NewGuid() + '.accdb')
Copy-Item $Src $copy
$dbe = New-Object -ComObject DAO.DBEngine.120
$db = $dbe.OpenDatabase($copy, $false, $true)

function Rows($sql, $map) {
    $rs = $db.OpenRecordset($sql)
    $list = New-Object System.Collections.ArrayList
    while (-not $rs.EOF) {
        $o = [ordered]@{}
        foreach ($k in $map.Keys) {
            $v = $rs.Fields.Item($map[$k]).Value
            if ($v -is [datetime]) { $v = $v.ToString('yyyy-MM-dd') }
            elseif ($v -is [System.DBNull]) { $v = $null }
            $o[$k] = $v
        }
        [void]$list.Add($o)
        $rs.MoveNext()
    }
    $rs.Close()
    return ,$list
}

$scales = Rows "SELECT * FROM [BANG LUONG]" ([ordered]@{ code = 'Maso_Luong'; grade = 'KyhieuLoai'; group = 'Nhom'; step = 'Bac'; coefficient = 'Heso'; rank = 'KyhieuQH' })
$people = Rows "SELECT * FROM [CAN BO NHAN VIEN]" ([ordered]@{
    ma = 'Maso_CBNV'; ho_ten = 'Hoten'; ngay_sinh = 'Datesinh'; cap_bac = 'Capbac'; chuc_vu = 'Chucvu'; don_vi = 'KyhieuDV';
    nhap_ngu = 'Nhapngu'; giam = 'Giam'; scale_code = 'Maso_Luong'; received_at = 'Ngaynhan_Luong'; check_received_at = 'Ngaynhan_Ktra';
    tnvk = 'TNVK'; reserved_coef = 'HS_BLC'; trinh_do = 'Trinhdo_DT'; nganh = 'Nganh_DT'; nam_tn = 'Nam_TN';
    tinh = 'Tinh'; huyen = 'Huyen'; xa = 'Xa'; tinh_tru = 'Tinh_Tru'; huyen_tru = 'Huyen_Tru'; xa_tru = 'Xa_Tru'; dia_chi = 'Diachi';
    ngay_tang = 'Ngaytang'; ly_do_tang = 'Lydo_tang'; ngay_giam = 'Ngaygiam'; ly_do_giam = 'Lydo_giam' })
$histories = Rows "SELECT * FROM [QUA TRINH LUONG]" ([ordered]@{
    ma = 'Maso_CBNV'; scale_code = 'Maso_Luong'; grade = 'Loai'; group = 'Nhom'; step = 'Bac'; coefficient = 'Heso'; rank = 'Quanham';
    tnvk = 'TNVK'; reserved_coef = 'HSBL'; decision_no = 'SoQD'; signed_at = 'Ngayky'; received_at = 'Ngaynhan'; signer = 'Nguoiky';
    note = 'Ghi_chu'; early = 'Truoc_NK'; reclass = 'Chuyen_Ngach' })

$settings = [ordered]@{}
$rs = $db.OpenRecordset("SELECT * FROM [Lam viec] WHERE ID = 2")
if (-not $rs.EOF) {
    foreach ($f in $rs.Fields) {
        if (@('logo', 'MkND', 'MkSD', 'Nguoidung', 'Nguoisd', 'Nguoilv', 'Ghi chu') -contains $f.Name) { continue }
        $v = $f.Value; if ($v -is [System.DBNull]) { $v = $null }
        $settings[$f.Name] = $v
    }
}
$rs.Close()
$db.Close()
Remove-Item $copy -Force

$bundle = [ordered]@{ source = 'QLNL.accdb'; exported_at = (Get-Date).ToString('s'); scales = $scales; settings = $settings; people = $people; histories = $histories }
[IO.File]::WriteAllText($Out, ($bundle | ConvertTo-Json -Depth 5), (New-Object System.Text.UTF8Encoding($false)))
"Da xuat: $Out (scales=$($scales.Count), people=$($people.Count), histories=$($histories.Count))"
