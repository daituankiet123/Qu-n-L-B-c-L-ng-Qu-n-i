# Runbook: Lùi về Monolith

> Cập nhật 18/09/2026. Chủ dự án quyết định **giữ monolith `tkb` làm đường lùi**.
> Tài liệu này là quy trình đã được **kiểm chứng chạy được** trên cluster.

---

## 1. Khi nào dùng

| Tình huống | Hành động |
|---|---|
| Đã chuyển traffic sang Traefik, web lỗi | **Mục 3** — lùi 1 lệnh |
| Muốn kiểm tra đường lùi trước khi cutover | **Mục 2** — `rollback-ready` |
| Pod monolith CrashLoopBackOff | **Mục 5** — sự cố 17/09 |

---

## 2. Kiểm tra đường lùi có sẵn sàng (KHÔNG đổi traffic)

```bash
gh workflow run cutover-ingress.yaml --ref main -f action=rollback-ready
gh run view --log | grep -A3 'Duong lui'
```

Kết quả mong đợi: `Duong lui SAN SANG: co the chay action=to-monolith bat cu luc nao.`
Nếu là `CHUA SAN SANG` thì làm theo hướng dẫn in ra (thêm key `.env` vào Secret) rồi chạy lại.

Workflow kiểm tra 5 điểm:
1. Secret `tkb-env` có key `.env` — **đây là nguyên nhân làm prod chết 17/09**.
2. Image monolith + `imagePullPolicy`.
3. Pod monolith đang chạy.
4. Deployment `tkb` READY.
5. Backend Ingress hiện tại.

---

## 3. Lùi về monolith (1 lệnh)

```bash
gh workflow run cutover-ingress.yaml --ref main -f action=to-monolith
gh run watch
```

Workflow làm **tuần tự, dừng ngay nếu bước nào không đạt**:
1. **Chặn lại** nếu Secret thiếu key `.env` (vì scale monolith lên sẽ CrashLoopBackOff đúng như sự cố 17/09).
2. `kubectl scale deploy/tkb --replicas=1`.
3. `kubectl rollout status deploy/tkb --timeout=180s` — **chỉ tiếp tục nếu Ready**.
4. Trả Ingress `tkb` về `service tkb:8000`.
5. In hướng dẫn tắt stack mới cho nhẹ node.

**Điểm quan trọng:** stack microservices **không bị xoá**, chỉ ngừng nhận traffic. Có thể bật lại bất cứ lúc nào.

Sau khi lùi, nếu muốn giảm tải node (tuỳ chọn):
```bash
kubectl -n tkb scale deploy tkb-core tkb-lms tkb-tms tkb-grades tkb-scheduler traefik --replicas=0
```

---

## 4. Chuyển sang microservices (khi đã sẵn sàng)

```bash
gh workflow run cutover-ingress.yaml --ref main -f action=to-traefik
```

Workflow **chặn lại** nếu:
- `deploy/traefik` chưa Ready, hoặc
- `GET /up` qua NodePort 30800 không trả **200**.

→ Không bao giờ chuyển traffic sang backend chưa chứng minh được là sống.

---

## 5. Sự cố 17/09: monolith CrashLoopBackOff

**Triệu chứng:**
```
>> Generating APP_KEY...
In KeyGenerateCommand.php line 100:
  file_get_contents(): Read of 8232 bytes failed with errno=21 Is a directory
```

**Nguyên nhân:** Deployment `tkb` (Helm chart `qlhv-0.1.0`) mount:
```yaml
volumeMounts:
  - mountPath: /var/www/.env
    name: env-file
    subPath: .env          # key ".env" trong Secret tkb-env
```
Secret thiếu key `.env` → Kubernetes tạo **THƯ MỤC** `/var/www/.env` → entrypoint **cũ**
trong image monolith gọi `key:generate` → đọc thư mục → `set -e` giết container.

**Xử lý (đã áp dụng, đang chạy tốt):**
```bash
# 1. Lay APP_KEY that
kubectl -n tkb get secret tkb-env -o jsonpath='{.data.APP_KEY}' | base64 -d; echo

# 2. Them key .env (PHAI dung gia tri that, khong dan nguyen chu <APP_KEY>)
kubectl -n tkb patch secret tkb-env --type merge \
  -p '{"stringData":{".env":"APP_KEY=base64:QxLhDm6tg22cy6QcijKCXCYF4fDO3kptPjQSscp9Cs8="}}'

# 3. Tao lai pod
kubectl -n tkb delete pod -l app.kubernetes.io/instance=tkb

# 4. Kiem tra: file phai la FILE ~59 byte, khong phai THU MUC
kubectl -n tkb exec deploy/tkb -- sh -c 'wc -c /var/www/.env; cat /var/www/.env'
kubectl -n tkb get deploy tkb     # READY phai la 1/1
```

**Lưu ý:** app vẫn chạy đúng dù `.env` chỉ có `APP_KEY` (Laravel nạp `.env` ở chế độ
immutable — biến môi trường từ `envFrom` thắng). Nhưng **giá trị APP_KEY phải là giá trị
thật**; nếu sai thì khi biến môi trường thiếu, app sẽ dùng giá trị rác và hỏng dữ liệu mã hoá.

---

## 6. Image monolith

### Trạng thái: ĐÃ chuyển prod sang image đã sửa (18/09/2026)

```
deployment tkb  ->  registry.hc2/cdhc2/tkb:20260918   (1/1 AVAILABLE, 0 restart)
```

| Image | Nội dung | Ghi chú |
|---|---|---|
| `tkb:latest` | Bản cũ `sha256:0550d519…`. Entrypoint **có bug**: nếu `/var/www/.env` không phải file thì `key:generate` làm container chết | Không còn dùng. Vẫn còn trong registry để lùi nếu cần |
| `tkb:20260918` | `sha256:84cb20c9…`, build từ `main` 18/09. Entrypoint **đã sửa** | **Đang chạy prod** |

**Đã xác minh entrypoint trong pod đang chạy** có logic đã sửa:
```sh
42: if [ -n "${APP_KEY}" ]; then
43:     echo ">> APP_KEY lay tu bien moi truong."
51:     echo "!! CANH BAO: khong co APP_KEY trong bien moi truong va khong co /var/www/.env."
```

### Vì sao KHÔNG cần bỏ mount `.env` nữa

Vì `APP_KEY` luôn có trong biến môi trường (`envFrom`), entrypoint **luôn vào nhánh 1** và
**không bao giờ đọc `/var/www/.env`**. Nên dù `.env` là FILE, là **THƯ MỤC**, hay **không
tồn tại**, container vẫn khởi động bình thường → **nguyên nhân gốc đã bị triệt tiêu**, kể cả
khi ai đó xoá key `.env` khỏi Secret.

Bỏ mount chỉ còn là dọn dẹp (không bắt buộc). Nếu vẫn muốn bỏ (gây rollout):

```bash
kubectl -n tkb patch deploy tkb --type=strategic -p '{"spec":{"template":{"spec":{
  "volumes":[{"name":"env-file","$patch":"delete"}],
  "containers":[{"name":"qlhv","volumeMounts":[{"mountPath":"/var/www/.env","$patch":"delete"}]}]
}}}}'
kubectl -n tkb rollout status deploy/tkb --timeout=300s
```
An toàn vì `maxUnavailable: 25%` với 1 replica → pod cũ giữ nguyên cho tới khi pod mới Ready.

### Build lại image monolith khi cần

```bash
gh workflow run build-monolith.yaml --ref main -f tag=<tag-moi> -f rollout=false
```
`rollout=false` là mặc định nên **không đụng prod**. Với `rollout=true` thì workflow tự
lưu image cũ và **tự lùi nếu rollout thất bại**.

### Lưu ý về Helm

`deployment tkb` do Helm quản lý (chart `qlhv-0.1.0` — **không còn trong tay ai**). Việc
`kubectl set image` tạo **drift** so với Helm state; điều này chấp nhận được vì chart đã mất
và sẽ không có `helm upgrade` nào chạy. **Đừng chạy `helm upgrade` cho release này** khi chưa
có chart — nó sẽ ghi đè các thay đổi bằng tay.

---

## 7. Những điều KHÔNG nên làm

| Không nên | Vì sao |
|---|---|
| `helm upgrade tkb ...` khi chưa có chart trong tay | Chart `qlhv-0.1.0` không nằm trong repo; upgrade mù có thể ghi đè cấu hình đang chạy |
| Xoá Deployment/Service `tkb` | Mất đường lùi |
| Xoá key `.env` khỏi Secret `tkb-env` | Tái hiện đúng sự cố 17/09 |
| `kubectl apply -f k8s/legacy-monolith/tkb-rendered-manifest.yaml` | File đó chỉ là snapshot để đối chiếu, không phải nguồn sự thật (Helm là nguồn) |
| Dùng `exists()` của disk `s3` để kiểm tra file | Hàm này **luôn trả `true`** — xem `docs/INCIDENT_2026-09-17.md` mục 4.3 |
