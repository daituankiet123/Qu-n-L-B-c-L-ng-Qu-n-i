# Thông báo đề thi

PR này dựa trên nhánh `fix/essay-approval-local-flow` (#473), không thay thế PR ký/in.

- Theo yêu cầu xác nhận ngày 27/09: dùng chuông chung ở góc phải header. Đã bỏ trang `/essay-exams/notifications`, controller, route và menu riêng từng thêm.
- Dùng `SystemNotification` ở core giống chuông thông báo chung; chỉ đọc/cập nhật bản ghi của chính người đăng nhập thuộc module đề thi. Không thêm bảng ở LMS.
- Gửi lên Khoa đúng đơn vị, Khảo thí, BGH theo vai trò đã có.
- Bổ sung kết quả Khoa duyệt cho giáo viên. Khảo thí/BGH trả kết quả cho người chuyển đề ở cấp trước, lấy lần chuyển gần nhất và bỏ qua log duyệt từng phần.
- Trả lại có lý do; Khoa trả giáo viên chỉ nhận một thông báo. Vẫn giữ thông báo kết thúc cho tác giả và văn bản ký cho Khảo thí.
- Duyệt từng phần chỉ thông báo chuyển cấp khi hoàn tất cấp đó, không lặp khi gửi lại yêu cầu duyệt đã xử lý.
- Đã đồng bộ việc bỏ giao diện riêng về local; giữ xử lý người nhận/lý do và dữ liệu cho chuông chung.

Kiểm tra gồm ba cấp gửi/duyệt/trả lại và API chuông `SystemNotificationController`: thông báo đề thi cùng danh sách với nghỉ phép, số chưa đọc, liên kết duyệt đề, đánh dấu đã đọc và không hiển thị thông báo của người khác. Dữ liệu test tổng hợp, không gửi mail thật.

Production: GET từ Chrome đang đăng nhập tới màn hình duyệt và thông báo trả 468, nên chưa xác nhận UI/luồng thực tế trên server. Không thao tác duyệt/trả lại trên dữ liệu thật.

Chỉ cập nhật PR #475, không merge, không deploy. CI chạy lại trên commit sửa theo yêu cầu dùng chuông chung; xem Checks của PR để biết kết quả mới nhất.
