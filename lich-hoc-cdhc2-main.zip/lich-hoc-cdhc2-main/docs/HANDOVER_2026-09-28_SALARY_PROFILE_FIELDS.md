# Bàn giao tiếp tục thông tin Người dùng và hồ sơ lương — 28/09/2026

## Phạm vi đã chốt

- Tiếp tục commit WIP `2ceece28` trên `feat/salary-profile-fields-b`, dựa trên nhánh báo cáo `feat/salary-access-reports` (#502 đang chờ duyệt).
- Quê quán/trú quán lưu mã tỉnh và xã/phường 2 cấp ở `users` (core), địa chỉ chi tiết ở `residence_address`. Không tự chuyển địa chỉ Access 3 cấp, không tự tạo người dùng thật.
- Salary chỉ lưu ngày/lý do tăng, ngày/lý do giảm, đơn vị đến; báo cáo Nơi thường trú đọc Người dùng; ngày giảm quyết định danh sách đang/không còn quản lý.
- Không merge khi chủ dự án chưa duyệt. Agent không nhập mật khẩu. Dừng khi một cửa sổ usage đạt 95%.

## Trạng thái bàn giao

- **Chủ dự án đã duyệt merge #501, #502, #503 ngày 28/09.** #501 đã merge tại `1ca15a25`, #502 tại `16294831`. [PR #503](https://github.com/cdhc2/lich-hoc-cdhc2/pull/503) đã retarget về `main`, ghép main vào nhánh tại `bea29d5a`; đang kiểm CI tích hợp trước merge. Source fields đã test riêng tại `f93d0be0`.
- Local **765 test qua**, Node **5 test qua**, Pint/build/Blade qua; QA và review độc lập hoàn tất. **[CI 36401754873](https://github.com/cdhc2/lich-hoc-cdhc2/actions/runs/36401754873) xanh** trên source `f93d0be0486b32372abe75a3ce1a7b8cd22f705c`: monolith **764 passed, 1 skipped, 4337 assertions**; DB split **761 passed, 4 skipped, 4326 assertions**.
- Không xin lại duyệt cho ba PR trên. Chờ CI tích hợp của #503, merge đúng SHA đã kiểm rồi theo dõi build/deploy cuối và hậu kiểm production. Công việc Excel/9 bản ghi/căn cứ nghiêng vẫn chưa làm.
- Demo localhost:8123 còn chạy trong worktree; chủ dự án đã tự đăng nhập. Viewport đã reset. Nếu cần khởi động lại: chạy `php artisan serve --host=127.0.0.1 --port=8123` tại worktree, dùng `.env` DB demo đã có, không dùng DB production. 10 ảnh QA ở thư mục ghi trong nhật ký.

## Kế hoạch tiếp tục

1. Sửa test salary dùng địa chỉ core, thêm kiểm tra giảm và phục hồi; thêm test tạo/sửa/xóa địa chỉ Người dùng, xã đúng tỉnh, API danh mục và quyền truy cập.
2. Sửa các lỗi thực tế mà test/QA chỉ ra; giữ Apple Dropdown, phản hồi tải danh mục rõ ràng và chống kết quả tải cũ khi đổi tỉnh nhanh.
3. Chạy test salary + user rồi toàn suite theo thứ tự (DB test dùng chung), Pint, build và Blade; chạy localhost:8123 với DB demo riêng, chủ dự án tự đăng nhập, chụp desktop/mobile và thử lưu form.
4. Review toàn diff với agent độc lập, commit/push đúng nhánh, mở một PR theo PR nền #502; kích hoạt CI trên đúng SHA. Chỉ xin duyệt sau khi có kết quả cụ thể.

## Nhật ký

- 28/09, chủ dự án yêu cầu **merge cả #501/#502/#503**. Review độc lập #501/#502 không phát hiện blocker mới; cả hai có CI monolith/DB split xanh. Merge bằng merge commit giữ ancestry: #501 `1ca15a25989219abaee5085c77a90cb5504efd49` (09:30:14 UTC), #502 `162948316eabe5ce1ef4b3f53181cdbbafb48397` (09:30:36 UTC). Tài khoản PR là tác giả nên dùng quyền admin để đáp ứng duyệt trực tiếp của chủ dự án; không tắt branch protection hoặc bỏ qua test. #503 base đã đổi về main, merge main vào nhánh tại `bea29d5a`; diff vẫn chỉ phần fields/nút/handover, không lặp code #501/#502.
- Baseline trước merge: [diagnostics 36403363042](https://github.com/cdhc2/lich-hoc-cdhc2/actions/runs/36403363042) thành công; deployment Ready, NodePort `/up` và `/login` trả 200, ingress trỏ `traefik-svc:8000`; Chrome production mở trang Salary được. FPM/nginx restart 0; worker các service có 2 restart từ trước merge. Backup mới nhất 27/09 có bản S3 khớp MD5. **Lưu ý workflow diagnostics tuy tên read-only nhưng thực tế có probe ghi/xóa S3, upload lại backup và gửi mail thử; không chạy lặp để hậu kiểm thông thường.** Dùng build/deploy rollout, `service-logs.yaml` và trình duyệt cho hậu kiểm.
- Follow-up ngoài phạm vi: số quyết định trùng qua năm/loại có thể trộn lịch sử khi in lại (đã tồn tại trước #502); datepicker #501 cần đối chiếu riêng các layout LMS/Điểm không include partial chung.
- Code đã commit/push tại **`f93d0be0`**, mở **[PR #503](https://github.com/cdhc2/lich-hoc-cdhc2/pull/503)**, base `feat/salary-access-reports` (#502), nhãn `run-ci`. Checkout gốc `D:\CDHC2\lich-hoc-cdhc2` đã fast-forward; các file lẻ và `.claude/launch.json` của chủ dự án giữ nguyên. CI chạy tay **[36401754873](https://github.com/cdhc2/lich-hoc-cdhc2/actions/runs/36401754873)** trên SHA `f93d0be0486b32372abe75a3ce1a7b8cd22f705c` vì PR base feature không tự kích hoạt workflow chỉ nghe PR vào main. **Cả hai job monolith/DB split đã thành công**; commit nhật ký kết quả không thay code đã test. **Chưa merge/deploy**.
- Hoàn thiện test địa chỉ core và vòng giảm/phục hồi trong báo cáo Salary: lượt đầu **100 passed, 827 assertions** (`tests/Feature/Salary`, `tests/Unit/Salary`, `UserLocalityFieldsTest`, `UserMilitaryPositionSaveTest`). Các bộ test chạy tuần tự, không chạy chung DB song song.
- Sửa đầu vào province/ward dạng mảng gây 500: `bail` trước rule string và validate query API danh mục. Sửa tải xã/phường: bỏ kết quả cũ khi đổi/xóa tỉnh nhanh, báo tải thất bại, phát change để Apple Dropdown đồng bộ. Node regression ban đầu 3 lỗi, sau sửa 3/3 qua.
- Review độc lập tìm hai lỗi P2; đã xử lý và review lại xác nhận đóng: select xã disabled bị bỏ khỏi POST nên giữ mã xã cũ; `UpdateUserRequest::prepareForValidation()` đặt xã null khi tỉnh được gửi nhưng xã bị thiếu, giữ nguyên địa chỉ nếu cả hai không được gửi. Test hai trường hợp omitted ward đỏ 2/2 trước sửa; thêm test giữ địa chỉ khi bỏ toàn nhóm. Turbo Back giữ DOM marker nhưng mất listener: thay marker bằng window WeakSet. Node test khôi phục DOM đỏ trước sửa; hiện **5/5 qua**.
- QA dùng DB **demo riêng** `cdhc_salary_profile_demo`, server worktree cổng **8123**, phiên shell **23645**. Chủ dự án đã tự đăng nhập; agent không nhập mật khẩu. Thử đổi tỉnh/xã, lưu và mở lại Người dùng; xoá tỉnh rồi kiểm DB tỉnh/xã đều null; Back rồi chọn tỉnh/xã vẫn tải và lưu được. Không nhập dữ liệu người thật.
- QA Salary: mở khung sửa hồ sơ, nhập/lưu ngày giảm 28/09/2026, lý do và đơn vị đến cho tài khoản demo; thông báo thành công, mở lại đủ giá trị. Bấm duyệt một dòng đợt demo thấy Chuyển đề nghị bật và đếm 1; bấm Đã duyệt để trả về chưa duyệt. Không chuyển/áp dụng đợt thật.
- Ảnh desktop **1440×900**, mobile **375×812** trong `storage/app/qa-salary-fields-2026-09-28/`: tạo/sửa Người dùng, hồ sơ Salary và khung sửa, nút chi tiết đợt. Desktop hai nút cao **44px**, cùng y; mobile đều rộng **295px**, cao 44px và xếp dọc. Menu quản trị core thu gọn trước chụp mobile; 4 trang liên quan không tràn ngang sau khi hoàn tất khởi tạo menu.
- `npm run build` qua (cảnh báo chunk lớn vốn có); không stage artefact `public/build`. Pint đã qua cả file WIP và `--dirty`; Blade cache và `git diff --check` qua. Lượt toàn suite đầu **698 passed, 64 failed**, cả 64 lỗi là thiếu SQLite driver cục bộ. DLL đã có: bật **chỉ trong tiến trình test** qua `PHP_INI_SCAN_DIR=storage/app/qa-php-conf` (ignored), không đổi PHP ini chung/server. Lượt toàn suite cuối **765 passed, 4339 assertions**, exit 0, 443.78 giây; log `storage/logs/full-suite-green.log`.
- PR #501 datepicker vẫn chưa merge lúc QA: cột CN của lịch cũ trong ô hẹp vẫn có thể bị cắt; bản sửa có sẵn ở #501, không nhân đôi vào PR fields này. Chờ chủ dự án duyệt các PR nền trước khi triển khai.
- Chủ dự án bổ sung ảnh lỗi lệch nút ở Bước tiếp theo của chi tiết đợt: đã chuyển hai form sang flex chung, tách lời nhắc khỏi form Chuyển đề nghị; desktop cùng hàng, mobile nút rộng bằng nhau. Build và QA đã xác minh như trên.
- Bắt đầu tiếp nhận: checkout gốc đang ở `2ceece28`; không sửa các file lẻ của chủ dự án. Worktree riêng: `C:\Users\Admin\.codex\worktrees\salary-profile-fields-continue\lich-hoc-cdhc2` (bắt đầu detached tại commit WIP).
- DB MySQL test cục bộ cổng 3307 đang chạy; chưa có server cổng 8123. Dùng DB demo riêng `cdhc_salary_profile_demo`. Khi test phải ép `DB_{LMS,TMS,GRADES,SALARY}_DATABASE=cdhc_testing` cho tiến trình để không chạm DB demo.
- Handover cũ `HANDOVER_2026-09-22.md` vẫn ghi UI ngày 26/09; tài liệu này là mốc tiếp nhận phần fields mới. #501 (datepicker) và #502 (báo cáo phần 1) còn OPEN lúc tiếp nhận, không tự merge chúng.

## Sau PR này (chưa nằm trong phạm vi đang hoàn thiện)

- Chữ nghiêng/đứng cho từng dòng căn cứ quyết định.
- Nhập/xuất Excel bảng lương và quá trình lương.
- Màn hình xác nhận 9 người khi import.

## Khi chủ dự án duyệt merge

1. PR fields xếp trên #502 (`feat/salary-access-reports`); merge PR nền trước, retarget PR fields về main nếu cần và kiểm tra lại diff không chứa việc khác. #501 là bản sửa datepicker riêng đang chờ duyệt.
2. Kiểm CI trên commit chứa code cuối; ngoài suite monolith cần job `phpunit-split` qua để xác minh migration `users` vào core và migration `salary_profiles` vào salary. Nếu đổi code khi retarget, chạy lại; commit chỉ cập nhật kết quả bàn giao không thay code đã kiểm tra. Chỉ merge sau khi chủ dự án duyệt cụ thể.
3. Theo dõi workflow build/deploy đến thành công; xác minh web production mở được trang Người dùng và Salary, pod/container Ready, log không có 500/lỗi SQL, migration của core và salary không còn pending. Không coi merge thành công là đã triển khai thành công.
4. Kiểm bằng quyền đọc: trang/form lấy đủ danh mục tỉnh/xã; báo cáo không lỗi; không tự sửa địa chỉ người thật, nhập Access cũ hay áp dụng đợt lương thật. Cập nhật handover với commit merge, workflow run, URL web và kết quả hạ tầng.
