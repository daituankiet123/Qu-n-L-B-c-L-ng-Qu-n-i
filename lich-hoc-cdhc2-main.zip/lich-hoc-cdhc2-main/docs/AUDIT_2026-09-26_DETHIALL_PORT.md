# Đối chiếu chuyển tính năng dethiall sau ngày 20/09

## Mốc kiểm tra

- Nguồn `NamMaiNamMai0505/dethiall`: `a0c371ef`, 13 commit từ `004d5d65` đến `a0c371ef` (20–25/09).
- Nhánh đã chuyển trước khi đọc hướng dẫn: PR #445, `d9a545e1`. Mốc này có cả các chỉnh sửa khi chuyển, gồm mã đề không dấu gạch và xử lý năm/kỳ đã chọn.
- Đích `tho076/lich-hoc-cdhc2/main`: `fee9868b`.
- Đọc lại đầy đủ hai hướng dẫn ngày 25/09 (pipeline/microservices) và 26/09 (CI PR #462).
- Đối chiếu các PR #459, #461, #462, #465, #469, #470, #471, #473; so thêm working tree local. Không ký/duyệt/import dữ liệu thật khi audit.

## Nguyên nhân

Hai hướng dẫn yêu cầu chuyển đủ tính năng và giữ các sửa đổi của main, đồng thời đổi kết nối DB, migration, truy vấn quan hệ và pipeline. Không có yêu cầu cắt chức năng.

Lần chuyển bằng tay theo nhóm tính năng đã bỏ sót một số xử lý của controller và dữ liệu seed nằm ngoài thư mục module. Có trường hợp view đã lấy sang nhưng backend còn bản cũ. Bộ test và CI trước đó chưa bao phủ các hành vi này; CI xanh không chứng minh đồng bộ toàn bộ với local.

Không có bằng chứng source commit bị xóa. Sai lệch nằm ở nội dung chuyển sang nhánh đích và việc các PR mới còn chưa merge.

## Theo từng commit nguồn

| Commit | Nội dung | Kết quả đối chiếu |
|---|---|---|
| 004d5d65 | Tổ chức thi, bộ lọc kế hoạch, phân công coi thi | Đã có trong #459; các cải tiến mới của main được giữ. Các chức năng sửa/xóa kế hoạch local phát sinh sau đó chưa nằm trong commit nguồn này. |
| dd9a8654 | Vật tư, khấu hao nhiều năm, xuất biểu mẫu | Đã chuyển vào #461. Lỗi biến nhãn phân cấp phát sinh do ghép view được sửa riêng ở #470. Các khác biệt về layout/paper-size có từ trước phạm vi 13 commit không được tính là phần mới của commit này. |
| d58ad758 | Module NCKH | Có trong #462 nhưng thiếu migration danh mục KH001–KH018 ở StandardHours; bổ sung vào chính #462 trong đợt audit này. |
| a8dc4605 | Thống kê gia hạn báo cáo NCKH | View/export ở #462 khớp source. |
| d44024fb | Bộ lọc ngân hàng đề | View đã chuyển; backend thiếu danh sách năm, chuẩn hóa kỳ, mức độ/dạng đề cũ. Đợt này khôi phục backend và test dữ liệu cũ. |
| c3a100f2 | In PDF đã import trong duyệt | Thiếu ở #459; bản khôi phục riêng #473. |
| a4fb9706 | Gắn sự kiện nút in duyệt | Được xử lý lại trong #473, có hỗ trợ điều hướng Turbo. |
| 62f9bcc1 | Tổng hợp kinh phí NCKH | View/export ở #462 khớp source. |
| cc31fdba | Hoàn thiện luồng đề/đáp án | #459 chỉ chuyển một phần. #473 bổ sung ký/in; đợt này khôi phục ngân hàng, xem và duyệt đáp án tích hợp theo đúng người/khoa. |
| ffe93023 | Mã TL tự động, tên bộ đề tự động | Service đã có; controller vẫn yêu cầu import_code/title cũ. Bổ sung #471 để không còn mâu thuẫn với giao diện và cấp mã tự động. |
| 5f49cdc7 | Chữ ký chủ nhiệm khoa/giáo viên trên đáp án | Khôi phục mẫu đáp án trong #469; không gộp vào PR mẫu in đề. |
| 1a446707 | Mã ngành, trình độ trong bộ lọc | Danh sách có; thiếu biến ngành Import sửa #471, duyệt sửa #473. |
| a0c371ef | Ngày thi theo kế hoạch khi rút đề | Đã có ở #459, có test ngày thi/lớp/môn. |

## Các thiếu sót sửa tiếp trong đợt này

### Import (#471)

- Nhánh #445 đã có khóa duy nhất lớp–môn–năm–kỳ, bản port rút lại còn lớp–môn làm mất các kỳ khác. Khôi phục đủ khóa và giới hạn lớp/môn theo dữ liệu được phép.
- `curriculumMetadata` phải nhận năm/kỳ đã chọn. Không tự thay bằng khóa học mới nhất lúc lưu.
- Xem trước, import, xác nhận và tạo đề phải kiểm tra lớp–môn tồn tại trong đúng năm/kỳ; giữ lựa chọn kỳ hè.
- Loại yêu cầu nhập mã bộ đề và tên bộ đề cũ khi hệ thống đã cấp tự động.
- Test có cùng lớp/môn trong 3 năm/kỳ, xem trước năm cũ không nhập mã, PDF xem trước và trường hợp không có chương trình phù hợp.

### Ngân hàng và đáp án tích hợp (nhánh fix/essay-bank-answer-scope)

- Khôi phục danh sách năm và bộ lọc tương thích dữ liệu cũ (`easy`/`Dễ`, `essay`/`Tự luận`, `HK1`/`semester_1`).
- Giáo viên được mở đáp án mình tạo bằng quyền cá nhân, khoa chỉ xem/duyệt/trả lại đáp án thuộc đơn vị; không mở được đáp án ngoài phạm vi bằng URL đoán ID.
- Dùng `User::pluck('id')` rồi `whereIn`, không phục hồi `whereHas('creator')` qua DB khác.

### NCKH (#462)

- Khôi phục file seed `2026_09_16_000006_seed_research_categories_kh001_kh018.php`, vốn có trong cả nguồn và #445.
- Test tạo đủ 18 mục, đúng số giờ đầu/cuối, chạy hai lần không sinh trùng.

## Những khác biệt không được coi là mất code

- Parser import chuyển vào `App\Support\QuestionImport\QuestionImportParser`; controller không còn hàm riêng không có nghĩa parser đã bị xóa.
- Các model/migration/service đổi connection, đọc S3 bằng get/readStream, tách controller thành service là yêu cầu kiến trúc.
- Mã đề không có dấu gạch trước D là chỉnh sửa người dùng yêu cầu sau cùng, được giữ; không chép migration cũ để khôi phục dấu gạch.
- Root local còn sửa đổi chưa commit ngoài 13 commit nguồn. Đã đối chiếu bổ sung ở đợt 26–27/09 như bảng dưới; không coi việc so riêng source HEAD là kiểm chứng toàn bộ working tree.

## Trạng thái triển khai và giới hạn kết luận

Tại lúc kiểm tra, #459/#461 đã merge; #462/#465/#469/#470/#471/#473 vẫn mở. Có commit/PR không có nghĩa code đã ở main hoặc production. Audit này xác nhận các khác biệt ở mã nguồn và bổ sung các thiếu sót nêu trên; không tuyên bố tất cả thao tác trên production đã được kiểm thử end-to-end.

Vẫn phải giữ #445 cho đến khi các PR thay thế đã merge theo hướng dẫn. Không push main, không thay file pipeline bằng source cũ, không bỏ qua kiểm tra tách DB.

## Bổ sung đối chiếu working tree (26–27/09)

| Chức năng local | Nơi khôi phục / quyết định |
|---|---|
| Thông báo gửi lên Khoa/Khảo thí/BGH, kết quả gửi xuống cấp trước | #475 dựa trên #473. Thêm trang thông báo cá nhân, kết quả Khoa duyệt cho giáo viên, lấy người chuyển gần nhất, lý do trả lại; đồng bộ cả root local. |
| Sửa/xóa kế hoạch, phân công, nhật ký, thí sinh | #476. Giữ import danh sách của main; transaction LMS; xóa dữ liệu con đúng kế hoạch. |
| Dồn túi dùng đề đã rút đúng lớp/môn/ngày/dạng đề | #476. Chặn thiếu phiếu chẵn/lẻ; thêm class_id tránh lớp trùng tên. |
| Chọn kế hoạch trong nhiều ngày của cùng lớp/môn | #477 dựa trên #465. Ngày/giờ tự cập nhật; giữ giới hạn mỗi loại phiếu mỗi ngày. |
| Lịch sử rút: mã, ngày, lớp, loại phiếu, dạng đề, môn; tự lọc | #477. Backend kết hợp đủ tiêu chí, tìm mã TL0001D01, phân trang giữ bộ lọc. |
| NCKH phân quyền hồ sơ/đơn vị, tệp đính kèm và kho riêng tư | Bổ sung vào #462, kèm test HTTP và migration tệp cũ; giữ kết nối core và cách đọc S3 theo hướng dẫn. |
| NCKH nhãn nhật ký và nút về Dashboard | Bổ sung #462; giữ kiểu giao diện main. |
| Lịch/dropdown chung | Main đã có tài nguyên local và widget mới; giữ main, không ghi đè bằng phiên bản flatpickr cũ của root. Các màn hình mới dùng widget chung. |
| Mã đề không dấu gạch, tên/mã bộ đề tự động | Giữ main và #471; không khôi phục migration thêm dấu gạch. |
| In đề, in đáp án, chữ ký, nút xóa | #465, #469, #473 giữ riêng; #477 dựa trên #465 để giữ nút xóa. |

Các file seeder tài khoản, cookie/profile Chrome, bản backup SQL, tài liệu tạm và thư mục app thử nghiệm không phải chức năng của ba module được yêu cầu chuyển theo hai hướng dẫn; không đưa vào PR. Chỉnh căn giữa bảng của `TrainingPlanWordExport` là thay đổi ngoài ba module này, không coi là chức năng đề thi bị cắt. Không xóa thêm các mẫu import chỉ vì thấy bản root đã xóa file.

## Bằng chứng và giới hạn mới

- #475: CI manual trên đúng nhánh/commit `fab9e799`, run 36250589083; blade-lint và phpunit-split thành công.
- #476: CI run 36250545996 trên `dd2e467e`; hai job thành công sau khi sửa cấu hình DB của test fixture.
- #462: CI manual run 36251107476 trên `49d54734`; hai job thành công. Lần tự chạy trước đó không tạo job; không dùng trạng thái đó để kết luận lỗi code.
- #477: test local 21 bài/188 assertions, sáu trigger tự lọc bằng JavaScript mô phỏng DOM; CI riêng đang được theo dõi.
- Các PR chỉ mở để review, `mergedAt` và `autoMergeRequest` đều null tại lúc kiểm tra. #475 phụ thuộc #473, #477 phụ thuộc #465. Có PR/CI đạt chưa đồng nghĩa tính năng đã lên web.
- Production GET trong Chrome trả 468. Local HTTP vào trang thông báo trả 302 tới đăng nhập do cookie hết hạn; syntax/Blade và hành vi controller/service được kiểm tra bằng test, chưa khẳng định thử toàn bộ giao diện bằng tài khoản thật.
- Audit xác nhận các nhóm chức năng và thiếu sót cụ thể ở trên; không chứng minh mọi dữ liệu lịch sử và mọi tổ hợp thao tác trên production đều đúng. Cần kiểm thử nghiệm thu trên server sau khi người có thẩm quyền merge/deploy.
