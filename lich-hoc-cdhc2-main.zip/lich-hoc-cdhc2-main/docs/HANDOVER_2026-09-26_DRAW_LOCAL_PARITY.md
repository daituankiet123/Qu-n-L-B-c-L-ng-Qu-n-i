# Đồng bộ Rút đề từ working tree local

PR này dựa trên #465 (`fix/essay-print-layout`), giữ nút xóa và mẫu in đã sửa riêng.

- Khôi phục bộ lọc lịch sử: mã đề/mã bốc/QR, ngày bốc, lớp, chẵn/lẻ, dạng đề, môn; chọn là lọc, ô mã chờ 500 ms, đổi bộ lọc về trang đầu.
- Backend áp dụng kết hợp các tiêu chí; tìm được mã đề thực tế `TL0001D01`; lịch sử hiển thị mã đề thay vì chỉ mã bộ đề.
- Chọn được nhiều kế hoạch cùng lớp/môn, ngày và giờ thi đổi theo kế hoạch đã chọn. Giữ khóa chẵn/lẻ theo ngày thi của main.
- Dùng lịch chung và dropdown chung của main, không chép đè widget cũ từ local.
- Giữ phân trang, tham số lọc và nút xóa của #465.

Kiểm tra: `EssayExamWorkflowTest` 21 test, 188 assertions; kiểm tra sáu sự kiện tự lọc bằng `node tests/browser/essay-draw-filters.cjs` (mô phỏng DOM, không phải kiểm thử giao diện Chrome). Blade compile, Pint.

Bộ `EssayExamDrawWorkflowTest` dùng migration MySQL nên không chạy được bằng SQLite local (ALTER TABLE MODIFY); cần kết quả CI MySQL, không tính các lỗi môi trường đó là test đạt.

Không merge/deploy. Production đang chặn GET qua Chrome bằng mã 468; chưa xác nhận giao diện mới trên server.
