"""Chuyển "Khung chương trình chi tiết - YSĐK-09.9.2026.xlsx" -> database/seeders/data/curriculum/ysdk-2026.json.

Chạy lại khi file khung thay đổi:
    python docs/curriculum/build_ysdk_2026.py "<đường dẫn file xlsx>"

- Sheet "Khung YSĐK": danh sách môn (mã MH, tín chỉ, giờ LT/tự học/thi, TH/tự học/thi, tổng tự học).
- Sheet "KH học kỳ": môn thuộc học kỳ nào.
- Sheet "Các môn học" (môn 1-26) và "Trang_tính2" (môn 17-26, 31): bài học từng môn. Môn có ở cả hai sheet lấy
  "Các môn học"; môn chỉ có ở "Trang_tính2" (31) lấy từ đó.
Phần/Chương -> Unit (bài con gắn vào); "Kiểm tra"/"Thi"/"Ôn, thi" -> Thi; còn lại -> Bài. Giống khung Y sỹ cũ.
"""
import json
import re
import sys
from pathlib import Path

import openpyxl

sys.stdout.reconfigure(encoding='utf-8')
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / 'Downloads' / 'Khung chương trình chi tiết - YSĐK-09.9.2026.xlsx'
OUT = Path(__file__).resolve().parents[2] / 'database' / 'seeders' / 'data' / 'curriculum' / 'ysdk-2026.json'

wb = openpyxl.load_workbook(SRC, data_only=True)


def num(v):
    if v in (None, ''):
        return 0
    try:
        return int(round(float(v)))
    except (TypeError, ValueError):
        return 0


def clean(s):
    return re.sub(r'\s+', ' ', str(s or '')).strip()


# ---- Môn học (sheet Khung) ----
subjects = []
group = None
for r in wb['Khung YSĐK'].iter_rows(min_row=5, values_only=True):
    a, code = r[0], r[1]
    if clean(r[2]).upper() == 'TỔNG CỘNG':
        break  # bên dưới là bảng kế hoạch học kỳ (lặp lại môn)
    if isinstance(a, str) and re.match(r'^[IVX]+\.', a.strip()):
        group = clean(a)
        continue
    if not isinstance(a, (int, float)) or not code:
        continue
    lt, lt_self, lt_exam, th, th_self, th_exam = (num(x) for x in r[5:11])
    subjects.append({
        'tt': int(a), 'code': clean(code).upper(), 'name': clean(r[2]), 'group': group,
        'credits': num(r[3]), 'total': num(r[4]),
        'theory': lt, 'practice': th, 'exam': lt_exam + th_exam, 'self_study': num(r[11]),
        'theory_self_study': lt_self, 'practice_self_study': th_self,
        'semester': None, 'lessons': [],
    })
by_code = {s['code']: s for s in subjects}
by_tt = {s['tt']: s for s in subjects}

# ---- Học kỳ ----
sem = None
for r in wb['KH học kỳ'].iter_rows(values_only=True):
    if isinstance(r[0], str) and r[0].strip().startswith('Học kỳ'):
        sem = 'semester_' + r[0].strip().split()[-1]
    elif isinstance(r[0], (int, float)) and r[1] and sem:
        by_code[clean(r[1]).upper()]['semester'] = sem

# ---- Bài học ----
def kind_of(name, tt):
    low = name.lower()
    if tt is None and re.match(r'^(phần|chương|phan|chuong)\b', low):
        return 'Unit'
    if re.match(r'^(kiểm tra|thi\b|ôn, thi|ôn thi|thi -|thi-|ôn tập, thi|thi kết thúc)', low):
        return 'Thi'
    return 'Bài'


def lesson(name, tt, total, lt, lt_self, lt_exam, th, th_self, th_exam):
    return {'name': clean(name), 'tt': tt, 'total': num(total), 'theory': num(lt), 'practice': num(th),
            'exam': num(lt_exam) + num(th_exam), 'self_study': num(lt_self) + num(th_self)}


blocks_a, blocks_b = {}, {}
for r in wb['Các môn học'].iter_rows(values_only=True):
    subj, tt, name = r[0], r[1], r[2]
    if not isinstance(subj, (int, float)) or not name or tt in ('Số TT', 'TT') or clean(name) in ('Tên bài, mục', 'Nội dung'):
        continue
    subj = int(subj)
    if r[3] is None and r[4] is None and isinstance(tt, (int, float)) and int(tt) == subj and subj not in blocks_a:
        blocks_a[subj] = []  # dòng tiêu đề môn
        continue
    if clean(name).upper().startswith(('TỔNG', 'CỘNG')):
        continue
    blocks_a.setdefault(subj, []).append(lesson(name, tt if isinstance(tt, (int, float)) else None, *r[3:10]))

current = None
for r in wb['Trang_tính2'].iter_rows(values_only=True):
    tt, name = r[0], r[1]
    if isinstance(tt, (int, float)) and name and r[2] is None and r[3] is None:
        current = int(tt)
        blocks_b[current] = []
        continue
    if current is None or not name or tt == 'TT' or name == 'Tên bài, mục':
        continue
    if clean(name).upper().startswith(('TỔNG', 'CỘNG')):
        continue
    blocks_b[current].append(lesson(name, tt if isinstance(tt, (int, float)) else None, *r[2:9]))

report = []
for tt, s in by_tt.items():
    src = blocks_a.get(tt) or blocks_b.get(tt) or []
    if tt in blocks_a and tt in blocks_b:
        na, nb = [x['name'] for x in blocks_a[tt]], [x['name'] for x in blocks_b[tt]]
        report.append(f'môn {tt} {s["name"]}: Các môn học {len(na)} dòng / Trang_tính2 {len(nb)} dòng'
                      + ('' if na == nb else ' (KHÁC)'))
    # Dòng có STT nhưng là nhóm cộng dồn (vd Thực tập BV: "THỰC TẬP ĐIỀU DƯỠNG" 120 = tổng các mục ngay sau).
    # Lặp tới khi ổn định: nhóm con được nhận trước, nhóm cha (vd "KHỐI NỘI" 148) cộng giờ bỏ qua các dòng nhóm.
    groups = set()
    changed = s['name'].lower().startswith('thực tập')  # chỉ các môn thực tập mới có nhóm đánh số
    while changed:
        changed = False
        for i, l in enumerate(src):
            if i in groups or l['tt'] is None or not l['total'] or re.match(r'^(bài|tl\d|kiểm tra|thi|ôn)', l['name'].lower()):
                continue
            if i + 1 < len(src) and src[i + 1]['tt'] is None and l['name'].upper().startswith('THỰC TẬP'):
                groups.add(i)  # vd "THỰC TẬP TRIỆU CHỨNG" = tổng các Phần ngay sau
                changed = True
                continue
            acc, cnt = 0, 0
            for j in range(i + 1, len(src)):
                nxt = src[j]
                if nxt['tt'] is None:
                    break
                if j in groups:
                    continue
                acc += nxt['total']
                cnt += 1
                if acc >= l['total']:
                    break
            if cnt >= 2 and acc == l['total']:
                groups.add(i)
                changed = True
    unit, n = None, 0
    for i, l in enumerate(src, 1):
        k = 'Unit' if (i - 1) in groups else kind_of(l['name'], l['tt'])
        if k == 'Unit':
            l = {**l, 'theory': 0, 'practice': 0, 'exam': 0, 'self_study': 0, 'total': 0}
            n += 1
            code = f'U{n:02d}'
            unit = code
            parent = None
        else:
            code = f'B{i:02d}'
            parent = unit
        s['lessons'].append({
            'code': code, 'parent_code': parent, 'name': l['name'], 'kind': k, 'order': i,
            'theory_hours': l['theory'], 'practice_hours': l['practice'], 'exam_hours': l['exam'],
            'total_hours': l['total'] or (l['theory'] + l['practice'] + l['exam'] + l['self_study']),
            'description': f'Tự học: {l["self_study"]} giờ' if l['self_study'] else '',
        })

data = {
    'source': SRC.name,
    'specialization': {'code': 'A.5720102', 'major_code': '5720101', 'name': 'Y sỹ đa khoa (CTĐT 2026)',
                       'copy_attributes_from': 'A.5720101',
                       'description': 'Khung chương trình chi tiết ngành Y sỹ đa khoa, trình độ trung cấp, hệ quân sự (ban hành 09/9/2026).'},
    'subjects': [{k: v for k, v in s.items() if k != 'tt'} for s in subjects],
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')

print('Môn:', len(subjects), '| tín chỉ', sum(s['credits'] for s in subjects), '| tổng giờ', sum(s['total'] for s in subjects))
print('Môn thiếu học kỳ:', [s['code'] for s in subjects if not s['semester']])
print('Môn có bài:', sum(1 for s in subjects if s['lessons']), '| tổng dòng bài:', sum(len(s['lessons']) for s in subjects))
print('Môn không có bài:', [f"{s['code']} {s['name']}" for s in subjects if not s['lessons']])
for line in report:
    print(line)
for s in subjects:
    tot = sum(l['theory_hours'] for l in s['lessons']), sum(l['practice_hours'] for l in s['lessons']), sum(l['exam_hours'] for l in s['lessons'])
    if s['lessons'] and tot != (s['theory'], s['practice'], s['exam']):
        print(f"  lệch giờ {s['code']} {s['name']}: bài LT/TH/Thi={tot} vs môn={s['theory'], s['practice'], s['exam']}")
print('->', OUT)
