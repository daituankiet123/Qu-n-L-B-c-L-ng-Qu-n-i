"""Chuyển "Khung chương trình chi tiết - KTCBMA-20.8.2026 (TT55).xlsx" -> database/seeders/data/curriculum/ktcbma-2026.json.

Chạy lại khi file khung thay đổi:
    python docs/curriculum/build_ktcbma_2026.py "<đường dẫn file xlsx>"

Ngành Kỹ thuật chế biến món ăn - CTĐT mới theo TT55 (ban hành 20/8/2026): mã khung A.5810209, mã ngành 5810207;
khung cũ A.5810207 giữ nguyên cho các lớp đang học.
- Sheet "Khung KTCBMA": danh sách môn (mã MH, tín chỉ, giờ LT/tự học/thi, TH/tự học/thi, tổng tự học) + ngay bên dưới
  3 bảng "Học kỳ 1/2/3" (môn thuộc học kỳ nào). Môn 14 thiếu tên ở bảng môn -> lấy tên ở bảng học kỳ.
- Sheet "Các môn học": bài học từng môn, mỗi môn bắt đầu bằng dòng tiêu đề (STT môn + tên, không có giờ).
  Nhận môn theo STT (sheet ghi nhầm tên môn 19 trùng môn 18).
Phần -> Unit (bài con gắn vào); "Kiểm tra"/"Thi"/"Final test"/"Viết thu hoạch" -> Thi; còn lại -> Bài.
"""
import json
import re
import sys
from pathlib import Path

import openpyxl

sys.stdout.reconfigure(encoding='utf-8')
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / 'Downloads' / 'Khung chương trình chi tiết - KTCBMA-20.8.2026 (TT55).xlsx'
OUT = Path(__file__).resolve().parents[2] / 'database' / 'seeders' / 'data' / 'curriculum' / 'ktcbma-2026.json'

wb = openpyxl.load_workbook(SRC, data_only=True)


def num(v):
    if v in (None, ''):
        return 0
    try:
        return int(round(float(v)))
    except (TypeError, ValueError):
        return 0


def clean(s):
    return re.sub(r'\s+', ' ', str(s or '').replace('\xa0', ' ')).strip()


# ---- Môn học + học kỳ (sheet Khung) ----
subjects = []
group = None
sem = None
names_from_semester = {}
in_frame = True
for r in wb['Khung KTCBMA'].iter_rows(min_row=7, values_only=True):
    a, code, name = r[0], r[1], clean(r[2])
    if in_frame:
        if name.upper() == 'TỔNG CỘNG':
            in_frame = False  # bên dưới là các bảng học kỳ (lặp lại môn)
            continue
        if isinstance(a, str) and re.match(r'^[IVX]+(\.\d+)?\.?\s', a.strip()):
            group = clean(a)
            continue
        if not isinstance(a, (int, float)) or not code:
            continue
        lt, lt_self, lt_exam, th, th_self, th_exam = (num(x) for x in r[5:11])
        subjects.append({
            'tt': int(a), 'code': clean(code).upper(), 'name': name, 'group': group,
            'credits': num(r[3]), 'total': num(r[4]),
            'theory': lt, 'practice': th, 'exam': lt_exam + th_exam, 'self_study': num(r[11]),
            'theory_self_study': lt_self, 'practice_self_study': th_self,
            'semester': None, 'lessons': [],
        })
        continue
    m = re.match(r'^Học kỳ\s+(\d+)$', name)
    if m:
        sem = 'semester_' + m.group(1)
    elif isinstance(a, (int, float)) and code and sem:
        names_from_semester[clean(code).upper()] = (name, sem)

by_code = {s['code']: s for s in subjects}
by_tt = {s['tt']: s for s in subjects}
for code, (name, semester) in names_from_semester.items():
    s = by_code[code]
    s['semester'] = semester
    if not s['name']:
        s['name'] = name


# ---- Bài học (sheet Các môn học) ----
def kind_of(name, tt):
    low = name.lower()
    if tt is None and re.match(r'^(phần|chương|phan|chuong)\b', low):
        return 'Unit'
    if re.match(r'^(kiểm tra|thi\b|thi kết thúc|final test|viết thu hoạch)', low):
        return 'Thi'
    return 'Bài'


blocks = {}
current = 0
for r in wb['Các môn học'].iter_rows(values_only=True):
    tt, name = r[0], clean(r[1])
    if not name or tt == 'TT' or name in ('Tên chương, mục',) or all(c is None for c in r[2:9]) and name == '':
        continue
    no_hours = all(c is None for c in r[2:9])
    # Dòng tiêu đề môn: môn đầu không có STT, các môn sau có STT = môn kế tiếp.
    if no_hours and ((current == 0 and tt is None and name.lower() == by_tt[1]['name'].lower())
                     or (isinstance(tt, (int, float)) and int(tt) == current + 1 and int(tt) in by_tt)):
        current = 1 if current == 0 else int(tt)
        blocks[current] = []
        continue
    if current == 0 or name.upper().startswith(('TỔNG', 'CỘNG')):
        continue
    blocks[current].append({
        'name': name, 'tt': int(tt) if isinstance(tt, (int, float)) else None, 'total': num(r[2]),
        'theory': num(r[3]), 'practice': num(r[6]), 'exam': num(r[5]) + num(r[8]),
        'self_study': num(r[4]) + num(r[7]),
    })

for tt, s in by_tt.items():
    unit, n = None, 0
    for i, l in enumerate(blocks.get(tt, []), 1):
        k = kind_of(l['name'], l['tt'])
        if k == 'Unit':
            n += 1
            code, parent, unit = f'U{n:02d}', None, f'U{n:02d}'
            l = {**l, 'theory': 0, 'practice': 0, 'exam': 0, 'self_study': 0, 'total': 0}
        else:
            code, parent = f'B{i:02d}', unit
        s['lessons'].append({
            'code': code, 'parent_code': parent, 'name': l['name'], 'kind': k, 'order': i,
            'theory_hours': l['theory'], 'practice_hours': l['practice'], 'exam_hours': l['exam'],
            'total_hours': l['total'] or (l['theory'] + l['practice'] + l['exam'] + l['self_study']),
            'description': f'Tự học: {l["self_study"]} giờ' if l['self_study'] else '',
        })

data = {
    'source': SRC.name,
    'specialization': {'code': 'A.5810209', 'major_code': '5810207', 'name': 'Kỹ thuật chế biến món ăn (CTĐT 2026 - TT55)',
                       'copy_attributes_from': 'A.5810207',
                       'description': 'Khung chương trình chi tiết ngành Kỹ thuật chế biến món ăn, trình độ trung cấp, hệ quân sự, theo Thông tư 55 (ban hành 20/8/2026).'},
    'subjects': [{k: v for k, v in s.items() if k != 'tt'} for s in subjects],
}
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')

print('Môn:', len(subjects), '| tín chỉ', sum(s['credits'] for s in subjects), '| tổng giờ', sum(s['total'] for s in subjects))
print('Môn thiếu tên:', [s['code'] for s in subjects if not s['name']])
print('Môn thiếu học kỳ:', [s['code'] for s in subjects if not s['semester']])
print('Môn có bài:', sum(1 for s in subjects if s['lessons']), '| tổng dòng bài:', sum(len(s['lessons']) for s in subjects))
print('Môn không có bài:', [f"{s['code']} {s['name']}" for s in subjects if not s['lessons']])
for s in subjects:
    tot = (sum(l['theory_hours'] for l in s['lessons']), sum(l['practice_hours'] for l in s['lessons']), sum(l['exam_hours'] for l in s['lessons']))
    if s['lessons'] and tot != (s['theory'], s['practice'], s['exam']):
        print(f"  lệch giờ {s['code']} {s['name']}: bài LT/TH/Thi={tot} vs môn={s['theory'], s['practice'], s['exam']}")
    hours = sum(l['total_hours'] for l in s['lessons'] if l['kind'] != 'Unit')
    if s['lessons'] and hours != s['total']:
        print(f"  lệch tổng {s['code']}: bài {hours} vs môn {s['total']}")
print('->', OUT)
