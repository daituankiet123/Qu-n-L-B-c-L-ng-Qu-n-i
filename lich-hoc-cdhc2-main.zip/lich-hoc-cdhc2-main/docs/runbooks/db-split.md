# Runbook — chuyển prod sang database theo service (Bước 2)

> Plan: `docs/superpowers/plans/2026-09-23-step2-database-split.md` (Task 8).
> Mục tiêu: bảng của lms / tms / grades rời khỏi DB core `eduka_v2` sang 3 database riêng
> **trên cùng server MariaDB** (`mariadb.data-store.svc.cluster.local`). Core giữ bảng định danh.
>
> Các bước **(CDA)** chỉ chủ dự án làm: cần quyền root MariaDB / sửa secret / scale deployment.
> Agent không có kubectl trực tiếp và không nhập mật khẩu.

## 0. Điều kiện vào (kiểm hết mới bắt đầu)

- [ ] Nhánh `step2-database-split` đã merge và **deploy xanh**, trong đó job CI `phpunit-split` xanh
      (job này chặn deploy — chạy toàn bộ test với 3 DB service riêng).
- [ ] `php artisan cdhc2:db-topology` trong pod core báo cả 3 connection "dùng chung core" (chưa tách).
- [ ] Đã đọc mục **5. Đường lùi** bên dưới.
- [ ] Hệ thống chưa có người dùng thật → cho phép dừng hẳn trong lúc chuyển (~5–10 phút).

## 1. Backup (bắt buộc, xác minh bằng md5)

`backup:run` có thể báo thành công mà S3 không nhận gì (xem `docs/HANDOVER.md` mục backup) —
**phải xác minh md5 của file trên S3**, không tin exit code.

```bash
kubectl -n tkb exec deploy/tkb-core -c fpm -- php artisan backup:run --only-db
```

Ghi lại **tên file backup** — sẽ dùng ở bước 4 (`--confirm-backup=<tên>`).

## 2. (CDA) Dừng các pod ghi dữ liệu

```bash
kubectl -n tkb scale deployment/tkb-lms deployment/tkb-tms deployment/tkb-grades \
  deployment/tkb-scheduler --replicas=0
kubectl -n tkb scale deployment/tkb-core --replicas=1   # giữ 1 pod core để chạy lệnh ở bước 4
```

**Không đụng** `deployment/tkb` (monolith cũ), Moodle, SafeLine, `service/tkb`, Ingress `tkb`.

## 3. (CDA) Tạo 3 database và cấp quyền

Chạy bằng tài khoản root MariaDB. Giữ **một** user ứng dụng hiện tại cho cả 4 schema
(tách user theo service là việc của Bước 3). Thay `<app_user>` bằng user trong `DB_USERNAME`.

```sql
CREATE DATABASE IF NOT EXISTS cdhc2_lms    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS cdhc2_tms    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS cdhc2_grades CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON cdhc2_lms.*    TO '<app_user>'@'%';
GRANT ALL PRIVILEGES ON cdhc2_tms.*    TO '<app_user>'@'%';
GRANT ALL PRIVILEGES ON cdhc2_grades.* TO '<app_user>'@'%';
-- RENAME TABLE can quyen DROP o DB NGUON; user ung dung (cdhc2_admin) mac dinh khong co.
GRANT DROP ON eduka_v2.* TO '<app_user>'@'%';
FLUSH PRIVILEGES;
```

Hoặc tự động: `gh workflow run db-split.yaml --ref main -f step=grant -f confirm=CAP-QUYEN-DB`
(dùng mật khẩu root từ biến môi trường của pod MariaDB, không in ra log).

## 4. Chuyển bảng (trong pod core còn lại, chưa sửa secret)

Truyền 3 biến đích **ngay trên dòng lệnh** (chưa ghi vào secret). Không dùng pod tạm với
`command:` — nó ghi đè ENTRYPOINT (bẫy 5.4 của handover).

```bash
kubectl -n tkb exec deploy/tkb-core -c fpm -- env \
  DB_LMS_DATABASE=cdhc2_lms DB_TMS_DATABASE=cdhc2_tms DB_GRADES_DATABASE=cdhc2_grades \
  php artisan cdhc2:db-split --plan --no-ansi | tee db-split-plan.txt
```

1. Đọc kỹ output `--plan`: chỉ có bảng tiền tố `lms_`, `essay_exam…`, `exam_organization…`,
   `integrated_answer…` (lms), `tms_`, `inventory_`, `leave_` (tms), `grade_` (grades).
   **Không** có `users`, `units`, `migrations`, bảng Moodle. **Lưu lại toàn bộ output** — phần
   `-- DUONG LUI` là câu lệnh lùi.
2. Chạy thật: lặp lại lệnh trên, đổi `--plan` thành `--execute --confirm-backup=<tên file bước 1>`.
   Trong lúc này pod core vẫn nhận request; ghi vào bảng service sẽ lỗi cho tới bước 6 —
   chấp nhận được vì chưa có người dùng thật (nếu có thì chặn ingress trước).
   `RENAME TABLE` trong MariaDB là nguyên tử và chỉ đổi metadata — nhanh, giữ nguyên dữ liệu, index, FK.

## 5. (CDA) Thêm biến vào secret `tkb-env` — CHỈ THÊM

**Sau** bước 4 (nếu thêm trước, pod khởi động sẽ trỏ vào DB rỗng).
**Không xoá / không sửa key `.env`** trong secret (xem `docs/HANDOVER.md` mục 4.5).

```bash
kubectl -n tkb patch secret tkb-env --type merge -p \
  '{"stringData":{"DB_LMS_DATABASE":"cdhc2_lms","DB_TMS_DATABASE":"cdhc2_tms","DB_GRADES_DATABASE":"cdhc2_grades"}}'
```

## 6. Bật lại và kiểm tra

```bash
kubectl -n tkb rollout restart deployment/tkb-core      # nạp lại env từ secret
kubectl -n tkb scale deployment/tkb-core deployment/tkb-lms deployment/tkb-tms deployment/tkb-grades --replicas=2
kubectl -n tkb scale deployment/tkb-scheduler --replicas=1
for d in core lms tms grades; do
  kubectl -n tkb exec deploy/tkb-$d -c fpm -- php artisan cdhc2:db-topology   # phải exit 0, báo "tách riêng"
done
kubectl -n tkb exec deploy/tkb-core -c fpm -- php artisan migrate:status --no-ansi | grep -c Pending  # phải 0
```

(Số replica lấy theo `k8s/<svc>/deployment.yaml` nếu khác 2.)

Sau đó (agent làm được): workflow `cluster-diagnostics`, `service-logs` cho cả 4 service lọc
`production.ERROR`, GET các trang chính (`/dashboard`, `/lms`, `/tms`, `/grades`, `/vat-tu`,
`/quan-ly-phep`, `/trash`), và **một thao tác ghi mỗi service** (lưu môn học → provisioning LMS;
nhập câu hỏi TMS; mở sổ điểm).

## 7. Đường lùi (nếu bước 6 hỏng)

1. (CDA) Scale lms/tms/grades/scheduler về 0, core về 1.
2. (CDA) Gỡ 3 key vừa thêm khỏi `tkb-env`:
   `kubectl -n tkb patch secret tkb-env --type json -p '[{"op":"remove","path":"/data/DB_LMS_DATABASE"},{"op":"remove","path":"/data/DB_TMS_DATABASE"},{"op":"remove","path":"/data/DB_GRADES_DATABASE"}]'`
3. Chạy các câu `RENAME TABLE` dưới dòng `-- DUONG LUI` trong `db-split-plan.txt` (bằng root MariaDB).
   Đã kiểm trên MySQL test: chuyển 181 bảng → 63/44/62/12, chạy câu lùi → về lại 181.
4. (CDA) `rollout restart` core rồi scale lại như bước 6; kiểm `cdhc2:db-topology` báo "dùng chung core".
5. Nếu dữ liệu hỏng: khôi phục từ backup bước 1.

## 8. Sau khi thành công

- Cập nhật `docs/HANDOVER_2026-09-22.md` (mục 4 + nhật ký) và roadmap: Bước 2 xong.
- Nợ chuyển sang Bước 5 (chỉ hợp lệ khi cùng server): FK từ bảng service sang bảng core,
  JOIN qua `DbRef`, 12 chỗ core đọc model của service (`tests/Unit/Architecture/cross-service-baseline.txt`).
