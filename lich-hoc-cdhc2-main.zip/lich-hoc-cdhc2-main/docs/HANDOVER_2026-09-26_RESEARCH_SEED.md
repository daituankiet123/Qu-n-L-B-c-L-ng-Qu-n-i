# Bổ sung danh mục NCKH bị thiếu khi port

Migration StandardHours `2026_09_16_000006_seed_research_categories_kh001_kh018.php` có trong dethiall và PR #445 nhưng chưa được mang vào #462 vì nằm ngoài thư mục ScientificResearch. Khôi phục nguyên 18 danh mục và giờ quy đổi nguồn. Đây là dữ liệu core; không đổi kết nối lms/tms hay pipeline.

Test ResearchCategorySeedTest kiểm tra 18 mục, KH001=1200 giờ, KH018=6 giờ, chạy migration hai lần không trùng. Chỉ chạy trên SQLite in-memory khi kiểm tra; chưa chạy migration này trên production. Khi triển khai, migration sẽ upsert các mã KH001–KH018 theo bộ chuẩn nguồn.
