# Kế hoạch Microservices CDHC2 — Phase 4 → 6

> Tài liệu hợp nhất, thay thế phần "Phase 4/5/6 planned" trong artifact kiến trúc v2.0 (16/09/2026).
> Lập ngày 16/09/2026. Trạng thái: **ĐANG CHỜ DUYỆT — chưa triển khai**.
> Mọi số liệu dưới đây đã được kiểm tra trực tiếp trên working tree `D:\CDHC2\lich-hoc-cdhc2` (branch `dev`).

---

## 0. Cách đọc tài liệu

| Ký hiệu | Nghĩa |
|---|---|
| ✅ | Đã xong, đã kiểm chứng bằng lệnh cụ thể |
| 🟡 | Làm dở — có code nhưng thiếu bước hoàn tất |
| ⛔ | Chặn — phải xử lý trước khi đi tiếp |
| 🔴 | Rủi ro cao cần quyết định của chủ dự án |

Mỗi gate (A/B/C/D) đều có: **mục tiêu → việc cần làm → lệnh chính xác → cách verify → rollback**.
Nguyên tắc bất di bất dịch: **không merge, không deploy cho tới khi có lệnh "ok triển khai"**.

---

## 1. Trạng thái thực tế (đã kiểm chứng)

### 1.1 Nhánh và commit

| Hạng mục | Giá trị | Bằng chứng |
|---|---|---|
| Branch hiện tại | `dev` | `git rev-parse --abbrev-ref HEAD` |
| Commit Phase 0-3 | `756f7480 feat: microservices Phase 0-3 — contracts, internal APIs, K8s deployments` | `git log --oneline -1` |
| Đã push chưa? | **Chưa** — `dev` hơn `origin/dev` 1 commit, kém 1 commit | `git rev-list --left-right --count origin/dev...dev` → `2  1` |
| Commit còn thiếu | `9efd66eb fix(training-schedule): chan vong lap vo han khi mo trang sua chi tiet lich` (PR #357 đã merge) | `git log --oneline dev..origin/dev` |

⛔ **Hệ quả:** nhánh `dev` local đang lệch. Phải đồng bộ `origin/dev` trước khi mở PR mới, nếu không PR sẽ chứa revert ngược của #357.

### 1.2 Phase 4 — S3 Storage

| Hạng mục | Trạng thái | Bằng chứng |
|---|---|---|
| `packages/cdhc2-core/src/Support/StorageHelper.php` | ✅ 132 dòng, 5 method (`resolveAbsolutePath`, `downloadToTemp`, `getContents`, `putContents`, `fileUrl`, `tempPath`) | file tồn tại, `php -l` sạch |
| `app/Console/Commands/MigrateStorageToS3.php` | ✅ 145 dòng, 7 model có cột `disk`, hỗ trợ `--dry-run --model --batch` | `php -l` sạch |
| Call-site đã chuyển sang `StorageHelper` | 🟡 **18 lời gọi / 13 file** | `Inventory` ×7 (3 controller + 2 service), `LeaveManagement` ×3, `TrainingSchedule/Exports` ×3, `DigitalSignature` ×1, `Subject` ×1, `Lms/Teach/AssignmentController` ×1 |
| Call-site còn lại | 🟡 **128 match / 44 file** | xem bảng dưới |
| Xoá phụ thuộc NFS PVC | ⛔ chưa — `k8s/storage/pvc.yaml` vẫn mount ở cả 5 deployment | `k8s/*/deployment.yaml` |

Phân bố 128 điểm cần phân loại tiếp:

| Module | Match | Ghi chú |
|---|---|---|
| Inventory | 35 | phần lớn là `tempnam(storage_path('app'))` cho export template |
| Lms | 18 | SCORM, material, assignment submission |
| Console | 15 | backup/S3 command — **có thể đã đúng, cần soi riêng** |
| ExportTemplates | 14 | version file |
| StandardHours | 9 | export/print |
| EssayExam | 8 | export đề thi |
| Tms | 6 | material, attachment |
| TrainingSchedule | 6 | export (3 đã xong) |
| User / Services / Models / Http / TemplateManagement / LeaveManagement | 17 | lẻ tẻ |

> Lưu ý: pattern đếm gồm cả `Storage::disk(` hợp lệ (ví dụ `TmsMaterial::getUrlAttribute()` dùng đúng). Con số 128 là **cận trên**, cần phân loại thật khi làm Gate B.

### 1.3 Phase 5 — JWT + App Grid + Traefik

| Hạng mục | Trạng thái | Bằng chứng |
|---|---|---|
| `app/Services/JwtTokenService.php` | ✅ `issue()` / `verify()` HS256, TTL từ `config('jwt.ttl')` | `php -l` sạch |
| `firebase/php-jwt ^7.1` | ✅ đã cài | `composer.lock:760`, `vendor/firebase/php-jwt/src/JWT.php` tồn tại |
| `config/jwt.php` | ✅ 7 dòng (`secret`, `algo`, `ttl` 300s) | `php -l` sạch |
| `app/Http/Middleware/JwtServiceAuth.php` | ✅ đã viết + đăng ký alias `jwt.service` trong `bootstrap/app.php` | diff `bootstrap/app.php` |
| `InternalApiAuth` — JWT trước, shared secret sau | ✅ | diff `app/Http/Middleware/InternalApiAuth.php` |
| `InternalClient` — Bearer nếu có `jwt.secret`, else `X-Internal-Token` | ✅ | diff `packages/cdhc2-core/src/Http/InternalClient.php` |
| App Grid component | ✅ `resources/views/components/app-grid.blade.php` — 149 dòng, 22 tile lọc theo permission + route existence | `php artisan view:cache` OK |
| App Grid gắn vào header | ✅ `resources/views/partials/top-header.blade.php` thêm `<x-app-grid />`; sidebar giữ nguyên | diff |
| 22 route name trong App Grid tồn tại | ✅ kiểm bằng `route:list --json` — **0 route thiếu** | script kiểm |
| Traefik manifests | ✅ `k8s/traefik/{deployment,service,ingressroute,middlewares,rbac}.yaml` | NodePort `30800`/`30443` |
| CI bỏ gateway, dùng traefik | ✅ `SERVICES` bỏ `gateway`, xoá step build gateway image, scp `k8s/traefik` thay `k8s/gateway` | diff `.github/workflows/build-and-deploy.yml` |
| Per-service CI path filter | ✅ job `detect-changes` với `dorny/paths-filter@v3` + `shared` cờ gộp | diff yml |
| **`JWT_SECRET` trên cluster** | ⛔ **KHÔNG có** → toàn bộ nhánh JWT đang **inert**, hệ thống vẫn chạy bằng shared secret | `k8s/**` không match `JWT_SECRET` |
| **Dọn deployment `tkb-gateway` cũ** | ⛔ chưa — thư mục `k8s/gateway/` vẫn còn, deployment cũ vẫn chiếm NodePort 30800 | `k8s/gateway/*` vẫn tồn tại |
| TLS termination | 🟡 IngressRoute TLS bị comment, chờ cert-manager | `k8s/traefik/ingressroute.yaml` |

### 1.4 Phase 6 — Database Split

| Hạng mục | Trạng thái | Bằng chứng |
|---|---|---|
| 3 connection mới `tms` / `lms` / `grades` trong `config/database.php` | ✅ 60 dòng, mặc định fallback về `DB_*` gốc → **no-op an toàn khi chưa tách** | diff `config/database.php` |
| `DbRef::table/core/tms/lms/grades` | ✅ 40 dòng, trả tên bảng trần khi cùng DB | `php -l` sạch |
| `protected $connection` trên model | ✅ **70/70** — TMS 26/26, LMS 32/32, Grades 12/12 | script quét: `missing=0` cả 3 |
| Cross-DB JOIN sửa bằng `DbRef::core()` | ✅ **17 dòng / 10 vị trí query / 5 file** | `Grades/{GradeCoverageService ×1, GradeAccess ×3, GradeBookController ×1}`, `Tms/{ReportController ×2, AdminDashboardController ×2}` |
| Migration bỏ FK liên DB | 🟡 `2026_09_16_000001_drop_cross_db_foreign_keys.php` — bỏ `grade_books.{tms_course_id,lms_course_id}` | `php -l` sạch, **nhưng chưa idempotent** |
| **Model `EssayExam` (8) + `ExamOrganization` (4)** | ⛔ **thiếu `$connection`** — 2 module này thuộc service LMS | script quét: `missing=8` và `missing=4` |
| **Bảng core `teaching_assignment` truy cập trần** | ⛔ **4 điểm** — `Lms/Services/LmsCourseProvisioningService.php:309`, `EssayExam/Controllers/EssayExamController.php:394,506,618,636` | grep `DB::table('teaching_assignment')` |
| Tách DB thật (khác `DB_DATABASE`) | ⛔ chưa — chưa set `DB_TMS_DATABASE` / `DB_LMS_DATABASE` / `DB_GRADES_DATABASE` | k8s không match |
| Async events (Redis/RabbitMQ) | ⛔ chưa làm, đúng lộ trình | — |

### 1.5 Kiểm tra sức khoẻ code hiện tại

| Kiểm tra | Kết quả |
|---|---|
| `php -l` 7 file mới | ✅ sạch cả 7 |
| `php artisan view:cache` (blade lint) | ✅ `Blade templates cached successfully` |
| `php artisan route:list` parse JSON | ✅ OK |
| 22 route của App Grid | ✅ không thiếu route nào |
| Test tự động cho JWT / DbRef / StorageHelper | ⛔ **chưa có test nào** |

---

## 2. Phát hiện & rủi ro cần quyết định

| # | Mức | Phát hiện | Đề xuất |
|---|---|---|---|
| R1 | 🔴 | `.env.example` (file **được commit**) chứa `JWT_SECRET=MJlv...K5CG` — có từ commit cũ `b5a7b6bc add comments`. Trước đây vô hại vì chưa có `config/jwt.php`; **nay `JwtTokenService` đọc chính biến này**, nên khoá HMAC đã công khai → ai biết repo đều ký được service token. | **Bắt buộc rotate trước khi bật JWT.** Xoá dòng khỏi `.env.example`, đặt giá trị mới 64 byte vào Secret `tkb-env` trên cluster. |
| R2 | 🔴 | `JWT_SECRET` không tồn tại trong `k8s/**` → Phase 5 coi như chưa bật. Nếu không để ý, "đã xong Phase 5" là kết luận sai. | Thêm `JWT_SECRET` + `JWT_TTL` vào `tkb-env`, rồi rollout lại 4 deployment. |
| R3 | 🔴 | `k8s/gateway/` vẫn còn và `tkb-gateway` (nếu còn chạy) chiếm NodePort `30800` — trùng với `traefik-svc`. `kubectl apply -R` sẽ báo `nodePort already allocated`. | Gate C bước 1: scale `tkb-gateway` về 0, delete deployment + service, rồi mới apply traefik. |
| R4 | 🔴 | Migration `drop_cross_db_foreign_keys` **không idempotent**. Mà `k8s/core/deployment.yaml` có initContainer `migrate` với `RUN_MIGRATIONS=true` → **migrate chạy tự động mỗi lần rollout core**. Nếu FK đã bị bỏ (hoặc tên index khác), `dropForeign` ném exception → initContainer fail → **toàn bộ rollout core treo**. | Bọc `Schema::hasTable` + kiểm tra `information_schema.REFERENTIAL_CONSTRAINTS` trước khi drop; hoặc bọc try/catch có log. |
| R5 | 🟡 | Phase 0-3 (`756f7480`) **chưa từng chạy trên cluster**, nhưng working tree đã có thêm ~90 file Phase 4-6 chồng lên. Gộp tất cả vào 1 PR = không thể rollback từng phần, và bug ở đâu cũng không biết do phase nào. | Tách thành **4 PR riêng theo gate** (A/B/C/D). Gate A phải deploy + verify trước khi merge B. |
| R6 | 🟡 | `modules/Inventory/Controllers/InventoryController.php` diff `198/74` dòng nhưng phần lớn là **Pint format** (`fn($id)` → `fn ($id)`, brace style), trộn với thay đổi thật `StorageHelper`. Làm review không thấy được thay đổi logic. | Tách commit: `style:` (pint) và `refactor:` (StorageHelper) riêng. |
| R7 | 🟡 | 3 connection `tms`/`lms`/`grades` mặc định trỏ về `DB_DATABASE` gốc. An toàn, **nhưng** nếu ai set `DB_TMS_DATABASE` nửa vời (chỉ 1 service) thì `DbRef::table()` sẽ trả `db.table` cho một phần query và gãy JOIN. | Gate D bắt buộc set **cả 3** cùng lúc, và chỉ sau khi `EssayExam`/`ExamOrganization` có `$connection`. |
| R8 | 🟡 | IngressRoute dùng `PathPrefix` cho `/tms/`, `/lms/`, `/grades/`… nhưng **chưa verify route thật sự nằm dưới prefix đó**. Ví dụ menu Vật tư trỏ `/vat-tu/`, Nghỉ phép `/quan-ly-phep/` (đã có trong IngressRoute) — còn các route khác thế nào chưa đối chiếu hết. | Gate C: xuất `route:list --json`, đối chiếu prefix với IngressRoute, tìm route rơi nhầm vào core catch-all. |
| R9 | 🟢 | `InternalClient` retry `retry(1, 200)` trên cả POST không idempotent (finding #9 của artifact, mới ở mức "Noted"). | Giữ nguyên, ghi nhận; hoặc đổi sang chỉ retry GET. |

---

## 3. Lộ trình triển khai

### Gate A — Đồng bộ nhánh & deploy Phase 0-3

**Mục tiêu:** đưa `756f7480` lên `origin/dev`, merge `main`, để CI build 6 image và cluster chạy được kiến trúc multi-container. Đây là **tiên quyết** — Phase 4/5/6 vô nghĩa nếu Phase 0-3 chưa chạy thật.

**Việc cần làm**
- [ ] A1. Đồng bộ `origin/dev` vào `dev` local (merge, không rebase — để không đổi hash commit đã có).
- [ ] A2. Rà soát `k8s/` lần cuối: PVC `tkb-storage`, `tkb-env` có đủ `INTERNAL_API_SECRET`, `SESSION_DRIVER=database`, `CACHE_STORE=database`, `CDHC2_SERVICE`.
- [ ] A3. Mở PR `dev → main`, tiêu đề `feat(microservices): Phase 0-3 — contracts, internal APIs, K8s deployments`.
- [ ] A4. Merge → CI tự chạy: `blade-lint` → build 6 image → mirror Harbor → `kubectl apply -R` → wait 6 rollout.
- [ ] A5. Verify sau deploy.

**Lệnh**

```powershell
# A1
cd D:\CDHC2\lich-hoc-cdhc2
git fetch origin
git merge origin/dev --no-edit
git rev-list --left-right --count origin/dev...dev   # kỳ vọng: 0  1
```

```powershell
# A3
git push -u origin dev
gh pr create --base main --head dev `
  --title "feat(microservices): Phase 0-3 - contracts, internal APIs, K8s deployments" `
  --body "Phase 0-3 microservices: 6 contracts, 12 internal API endpoints, 6 K8s deployments (gateway/core/lms/tms/grades/scheduler), nginx sidecar pattern, NFS PVC. Chua gom Phase 4-6."
```

```bash
# A5 — verify tren cluster (copy-paste)
kubectl -n tkb get deploy
kubectl -n tkb get pods -o wide
kubectl -n tkb get svc
kubectl -n tkb get pvc
kubectl -n tkb rollout status deploy/tkb-core --timeout=300s
kubectl -n tkb rollout status deploy/tkb-lms --timeout=300s
kubectl -n tkb rollout status deploy/tkb-tms --timeout=300s
kubectl -n tkb rollout status deploy/tkb-grades --timeout=300s
kubectl -n tkb rollout status deploy/tkb-gateway --timeout=300s
kubectl -n tkb get events --sort-by=.lastTimestamp | tail -30
```

**Cách verify**

| # | Kiểm tra | Kỳ vọng |
|---|---|---|
| A-V1 | `kubectl -n tkb get deploy` | 6 deployment READY đủ replicas |
| A-V2 | `curl -s -o /dev/null -w '%{http_code}' http://<node-ip>:30800/` | `302` (redirect login) hoặc `200` |
| A-V3 | Đăng nhập `admin@example.com` / `password` | vào được dashboard |
| A-V4 | `kubectl -n tkb exec deploy/tkb-gateway -- nginx -t` | syntax OK |
| A-V5 | Kiểm tra 1 file upload (avatar/đề thi) rồi mở lại | file hiển thị — xác nhận NFS PVC mount đúng ở gateway + sidecar |

**Rollback:** `kubectl -n tkb rollout undo deploy/tkb-core` (và từng service). Nếu CI đã thay đổi `SERVICES`/scp thì phải `git revert` commit trên `main` và deploy lại bản cũ — nên **chụp lại `kubectl -n tkb get deploy -o yaml > backup-pre-phase4.yaml`** trước khi merge.

---

### Gate B — Hoàn tất Phase 4 (S3 Storage)

**Mục tiêu:** mọi file người dùng tải lên nằm trên Viettel S3; xoá được NFS PVC; pod stateless.

**Việc cần làm**
- [ ] B1. Phân loại 128 điểm gọi còn lại thành 3 nhóm: `temp file cục bộ` (→ `StorageHelper::tempPath`), `đọc/ghi file trên disk` (→ `StorageHelper::getContents/putContents/downloadToTemp`), `URL` (→ `StorageHelper::fileUrl`). **Bỏ qua** nhóm Console backup (cố ý dùng local).
- [ ] B2. Thêm cột `disk` cho mọi bảng lưu file nếu thiếu; kiểm tra `MODELS_WITH_DISK` trong `MigrateStorageToS3` đã đủ 7 model chưa, còn model nào lưu file mà chưa có `disk` không.
- [ ] B3. Thêm `Storage::fake('s3')` test cho `StorageHelper` (5 method) + test cho `storage:migrate-s3 --dry-run`.
- [ ] B4. Chạy dry-run trên prod (không ghi), đối chiếu số file.
- [ ] B5. Chạy migrate thật theo từng model (`--model=LmsMaterial` …), verify S3 rồi mới `forceFill(['disk'=>'s3'])`.
- [ ] B6. Chuyển `FILESYSTEM_DISK=s3` + `PUBLIC_DISK=s3`.
- [ ] B7. Chỉ khi B1–B6 xong **và đã quan sát ổn định 1 tuần**: bỏ mount NFS PVC khỏi 5 deployment, xoá `k8s/storage/pvc.yaml`.

**Lệnh**

```bash
# B4 — dry run truoc, KHONG ghi gi
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --dry-run
```

```bash
# B5 — migrate tung model
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=LmsMaterial
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=TmsMaterial
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=TmsAttachment
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=LmsAssignmentSubmission
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=LmsAssignmentSubmissionVersion
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=ExportTemplateVersion
kubectl -n tkb exec deploy/tkb-core -- php artisan storage:migrate-s3 --model=LeaveReportTemplate
```

> ⚠️ B5 `forceFill(['disk'=>'s3'])->save()` — nếu migrate chạy trên container `lms`/`tms` mà model thuộc connection khác DB (`Phase 6`) thì có thể ghi nhầm DB. **Chạy B5 trên `deploy/tkb-core` khi Phase 6 chưa tách DB** (đúng thứ tự Gate B trước Gate D).

**Verify**

| # | Kiểm tra | Kỳ vọng |
|---|---|---|
| B-V1 | `--dry-run` output | khớp số bản ghi kỳ vọng, `Missing` = 0 hoặc giải thích được |
| B-V2 | Sau migrate 1 model: mở 1 file trên UI | tải được, URL trỏ S3 |
| B-V3 | `kubectl -n tkb exec deploy/tkb-core -- php artisan tinker --execute="echo Storage::disk('s3')->exists('…');"` | `1` |
| B-V4 | Export Word/Excel/PDF có ảnh chữ ký số | ảnh nhúng đúng (test riêng vì `resolveAbsolutePath` đổi hành vi) |
| B-V5 | Upload đề thi tự luận (PhpWord/PhpSpreadsheet temp file) | tải về mở được |

**Rollback:** `disk` cột trong DB đổi ngược về `public`; file gốc vẫn còn trên NFS (chỉ đọc, chưa xoá) → rollback an toàn trong suốt Gate B. **Không xoá file NFS cho tới B7.**

---

### Gate C — Hoàn tất Phase 5 (JWT + App Grid + Traefik)

**Mục tiêu:** xác thực service-to-service bằng JWT; điều hướng bằng Traefik; UI dùng App Grid.

**Việc cần làm**
- [ ] C1. **Xử lý R1/R2 trước tiên**: xoá `JWT_SECRET` khỏi `.env.example`; sinh khoá mới; nạp vào Secret `tkb-env`.
- [ ] C2. Viết test: `JwtTokenService::issue/verify` (happy path, hết hạn, sai chữ ký), `JwtServiceAuth` (401 thiếu/sai token), `InternalApiAuth` (JWT trước → fallback shared secret → 403).
- [ ] C3. Rollout lại 4 deployment để nhận `JWT_SECRET`; verify internal API vẫn hoạt động **qua cả 2 đường** (JWT và fallback).
- [ ] C4. Đối chiếu R8: `route:list --json` vs `IngressRoute` — liệt kê route rơi nhầm vào core catch-all.
- [ ] C5. Sequence deploy Traefik **an toàn**: scale `tkb-gateway` về 0 → verify site chết → apply traefik → verify site sống → delete hẳn `tkb-gateway`. Xoá thư mục `k8s/gateway/`.
- [ ] C6. Verify App Grid trên browser thật (desktop + mobile ≤639px), đủ 22 tile theo permission, `admin@example.com` thấy hết.
- [ ] C7. TLS: chờ cert-manager hoặc Secret `tkb-tls` thủ công → uncomment IngressRoute TLS + redirect 80→443.

**Lệnh**

```bash
# C1 — sinh khoa moi (chay noi bo, KHONG commit ket qua)
openssl rand -base64 48
```

```bash
# C1 — nap vao Secret (thay <NEW_SECRET>)
kubectl -n tkb get secret tkb-env -o jsonpath='{.data.JWT_SECRET}' | base64 -d; echo
kubectl -n tkb patch secret tkb-env --type merge -p "{\"stringData\":{\"JWT_SECRET\":\"<NEW_SECRET>\",\"JWT_TTL\":\"300\"}}"
```

```bash
# C3 — rollout lai 4 service
for d in tkb-core tkb-lms tkb-tms tkb-grades; do kubectl -n tkb rollout restart deploy/$d; done
kubectl -n tkb rollout status deploy/tkb-core --timeout=300s
kubectl -n tkb rollout status deploy/tkb-lms --timeout=300s
kubectl -n tkb rollout status deploy/tkb-tms --timeout=300s
kubectl -n tkb rollout status deploy/tkb-grades --timeout=300s
```

```bash
# C5 — doi gateway -> traefik, tung buoc, KHONG apply mu
kubectl -n tkb scale deploy/tkb-gateway --replicas=0
kubectl -n tkb get pods -l app=tkb-gateway

# apply traefik
kubectl apply -f k8s/traefik/rbac.yaml
kubectl apply -f k8s/traefik/deployment.yaml
kubectl apply -f k8s/traefik/service.yaml
kubectl apply -f k8s/traefik/middlewares.yaml
kubectl apply -f k8s/traefik/ingressroute.yaml

kubectl -n tkb rollout status deploy/traefik --timeout=180s
kubectl -n tkb get svc traefik-svc
kubectl -n tkb get ingressroute
```

```bash
# C5 — chi xoa gateway SAU KHI traefik da chay dung
kubectl -n tkb delete deploy tkb-gateway
kubectl -n tkb delete svc tkb-gateway 2>/dev/null
git rm -r k8s/gateway
```

**Verify**

| # | Kiểm tra | Kỳ vọng |
|---|---|---|
| C-V1 | `kubectl -n tkb get svc traefik-svc -o jsonpath='{.spec.ports[0].nodePort}'` | `30800` |
| C-V2 | `curl -I http://<node-ip>:30800/` | `302`/`200`, không `404` |
| C-V3 | `curl -s -o /dev/null -w '%{http_code}' http://<node-ip>:30800/api/internal/lms/stats` (không token) | `403` (không được `200`) |
| C-V4 | Đăng nhập, mở `/lms`, `/tms`, `/grades`, `/vat-tu/`, `/quan-ly-phep/` | cả 5 vào đúng service |
| C-V5 | UI: icon lưới 3×3 cạnh chuông → mở được, tile lọc đúng theo tài khoản `giangvien@example.com` | GV thấy ít tile hơn admin |
| C-V6 | Mobile 390px: App Grid mở dạng bottom sheet | không tràn, không che nút |
| C-V7 | `kubectl -n tkb logs deploy/tkb-lms --tail=50` sau khi bấm vài trang | không có `401 Invalid service token` |
| C-V8 | `kubectl -n tkb get svc` | **không còn** `tkb-gateway` |

**Rollback:** `kubectl apply -f k8s/gateway/` + `kubectl -n tkb scale deploy/tkb-gateway --replicas=1`, xoá traefik. Vì đã `git rm k8s/gateway`, cần `git revert` — **khuyến nghị chưa `git rm` ở lần deploy đầu**, chỉ delete trên cluster, giữ file trong repo tới khi ổn định.

---

### Gate D — Hoàn tất Phase 6 (Database Split)

**Mục tiêu:** 3 database riêng (`cdhc_core`, `cdhc_tms`, `cdhc_lms`, `cdhc_grades`) hoặc tối thiểu: mọi model/query đã sẵn sàng để chỉ việc đổi env.

**Việc cần làm**
- [ ] D1. Gán `protected $connection` cho **12 model còn thiếu**: `EssayExam` (8) + `ExamOrganization` (4) → `lms`.
- [ ] D2. Bọc `DbRef::core()` cho **4 điểm `teaching_assignment`**: `Lms/Services/LmsCourseProvisioningService.php:309`, `EssayExam/Controllers/EssayExamController.php:394,506,618,636`.
- [ ] D3. Sửa R4: làm `drop_cross_db_foreign_keys` **idempotent**.
- [ ] D4. Quét lại toàn bộ: đảm bảo 0 query trần tới bảng không thuộc service. Viết script kiểm tra tự động (parse `DB::table('x')` + `->join('x'`) đối chiếu danh sách bảng theo service.
- [ ] D5. Viết test: mỗi service chạy được với DB riêng (SQLite in-memory 4 connection, hoặc MySQL test 4 schema).
- [ ] D6. Tạo 4 database + user + grant; chạy `php artisan migrate` cho từng connection; `mysqldump` dữ liệu hiện tại và import lại theo bảng.
- [ ] D7. Cutover: bật `DB_TMS_DATABASE` / `DB_LMS_DATABASE` / `DB_GRADES_DATABASE` **cùng lúc cho cả 4 deployment**, rollout, verify.
- [ ] D8. (Sau) Async events Redis/RabbitMQ cho grade transfer — chỉ làm khi D7 ổn định.

**Lệnh**

```php
// D3 — mau migration idempotent
public function up(): void
{
    foreach (['tms_course_id', 'lms_course_id'] as $col) {
        $fk = DB::selectOne(
            "SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'grade_books'
               AND COLUMN_NAME = ? AND REFERENCED_TABLE_NAME IS NOT NULL LIMIT 1",
            [$col]
        );
        if ($fk) {
            Schema::table('grade_books', fn (Blueprint $t) => $t->dropForeign($fk->CONSTRAINT_NAME));
        }
    }
}
```

```bash
# D4 — quet query tran (chay trong container)
kubectl -n tkb exec deploy/tkb-core -- bash -lc '
  grep -rEn "DB::table\(.(users|units|classes|subjects|training_schedules|schedule_details|academic_years|teaching_assignment|instructors|buildings|classrooms)" modules/Lms modules/Tms modules/Grades modules/EssayExam modules/ExamOrganization || echo "CLEAN"
'
```

```bash
# D7 — bat 3 connection cung luc
kubectl -n tkb patch secret tkb-env --type merge -p '{"stringData":{
  "DB_TMS_DATABASE":"cdhc_tms",
  "DB_LMS_DATABASE":"cdhc_lms",
  "DB_GRADES_DATABASE":"cdhc_grades"}}'
for d in tkb-core tkb-lms tkb-tms tkb-grades; do kubectl -n tkb rollout restart deploy/$d; done
```

**Verify**

| # | Kiểm tra | Kỳ vọng |
|---|---|---|
| D-V1 | `php artisan migrate:status` trên cả 4 connection | không bảng nào lệch |
| D-V2 | Đăng nhập, mở `/lms`, `/tms`, `/grades` | không `SQLSTATE` cross-database |
| D-V3 | Chuyển điểm từ LMS → Grades (grade transfer) | bảng điểm tạo đúng, audit log ghi |
| D-V4 | `kubectl -n tkb logs deploy/tkb-grades \| grep -i "table.*doesn't exist"` | rỗng |
| D-V5 | `SHOW TABLES FROM cdhc_core LIKE 'grade_%'` | `0 rows` |

**Rollback:** bỏ 3 env `DB_*_DATABASE` → tất cả về lại `DB_DATABASE` gốc (vì `config/database.php` fallback). Dữ liệu vẫn nằm ở DB gốc, **với điều kiện chưa migrate ghi vào DB mới**. Khuyến nghị chạy D7 kiểu read-only (chỉ core giữ nguyên, tách TMS trước) theo đúng ADR-005.

---

## 4. Đề xuất thứ tự & phạm vi PR

| Gate | PR | Nhánh | Nội dung | Phụ thuộc |
|---|---|---|---|---|
| A | #1 | `dev` → `main` | Phase 0-3 (đã commit `756f7480`) | — |
| B | #2 | `feat/phase4-s3-storage` | Hoàn tất StorageHelper + call-site + test + bỏ NFS | A đã deploy |
| C | #3 | `feat/phase5-jwt-traefik` | JWT + App Grid + Traefik + rotate secret | B đã deploy |
| D | #4 | `feat/phase6-db-split` | 12 model + 4 `teaching_assignment` + migration idempotent | C đã deploy |

Trong mỗi PR, commit phải tách:
1. `fix:` / `feat:` — thay đổi logic
2. `style:` — Pint format (R6)
3. `test:` — test mới
4. `chore(infra):` — k8s/CI

---

## 5. Câu hỏi cần chủ dự án quyết định

| # | Câu hỏi | Phương án |
|---|---|---|
| Q1 | Triển khai Gate A ngay bây giờ? | (a) Có — merge `dev` → `main` → deploy; (b) Chỉ push `dev` mở PR, chưa merge; (c) Chưa, để sau |
| Q2 | Xử lý Phase 4-6 đang dở trong working tree thế nào? | (a) Tách 3 nhánh `feat/phase4|5|6` từ `dev` rồi commit riêng (sạch, khuyến nghị); (b) Gộp hết vào 1 nhánh `dev`; (c) `git stash` rồi làm lại từng gate |
| Q3 | Rotate `JWT_SECRET` (R1) — ai làm? | (a) Tôi sinh khoá + patch Secret, bạn chỉ duyệt; (b) Bạn tự làm; (c) Tạm **không bật JWT**, để Phase 5 chỉ còn App Grid + Traefik |
| Q4 | Xử lý `tkb-gateway` cũ (R3)? | (a) Scale 0 rồi delete, giữ file trong repo để rollback (khuyến nghị); (b) Delete + `git rm k8s/gateway` ngay; (c) Giữ cả hai, đổi NodePort traefik sang cổng khác |
| Q5 | Phase 4 có bắt buộc xong mới làm Phase 5/6? | (a) Tuần tự A→B→C→D (khuyến nghị, dễ rollback); (b) Song song B+C để nhanh; (c) Ưu tiên Phase 6 trước (chuẩn bị tách DB) |
| Q6 | Có cần bổ sung test trước khi merge không? | (a) Có, bắt buộc test JWT/DbRef/StorageHelper (khuyến nghị); (b) Không, merge rồi test trên staging |

---

## 8. Trạng thái R1–R9 sau khi hoàn thiện (17/09/2026)

| # | Rủi ro | Trạng thái | Cách xử lý |
|---|---|---|---|
| R1 | `.env.example` lộ `JWT_SECRET` | ✅ Đã xử lý | Xoá giá trị thật, thay placeholder + hướng dẫn sinh khoá. Commit `ee7b32a6` (nhánh Phase 5) |
| R2 | `JWT_SECRET` không có trên cluster | ✅ Đã xử lý | Thêm `k8s/secret.example.yaml`; `config/app.php` có `cdhc2_service`; `CoreServiceProvider` bind lazy đọc config. **Còn phải làm khi deploy:** nạp `JWT_SECRET` vào Secret `tkb-env` |
| R3 | Trùng NodePort 30800 gateway/traefik | ✅ Đã xử lý | CI xoá `tkb-gateway` + `gateway-svc` trước `kubectl apply`; xoá `k8s/gateway/` khỏi repo |
| R4 | Migration bỏ FK không idempotent | ✅ Đã xử lý | Tra `information_schema.KEY_COLUMN_USAGE`, bỏ qua khi không còn FK |
| R5 | 1 PR khổng lồ | ✅ Đã xử lý | Tách 3 nhánh `feat/phase4-s3-storage`, `feat/phase5-jwt-traefik`, `feat/phase6-db-split` |
| R6 | Pint noise lẫn logic | ✅ Đã xử lý | Tách commit `style:` riêng; diff logic `InventoryController` 198/74 → 4/3 dòng |
| R7 | Tách DB nửa vời | ✅ Đã xử lý | `php artisan cdhc2:db-topology` — fail (exit 1) khi tách không đồng bộ |
| R8 | IngressRoute thiếu prefix | ✅ Đã xử lý | `Path(x) \|\| PathPrefix(x/)` + `priority` tường minh (100/50/1) |
| R9 | Retry cả POST | ✅ Đã xử lý | Chỉ retry khi `idempotent: true` (GET); thêm `connectTimeout` 5s |

### Phát hiện MỚI trong quá trình hoàn thiện

| # | Phát hiện | Mức | Trạng thái |
|---|---|---|---|
| N1 | `CoreServiceProvider` đọc `env('CDHC2_SERVICE')` lúc register → nếu bật `config:cache` thì **mọi service bind nhầm sang Direct** (truy cập bảng không thuộc quyền) | 🔴 | ✅ Đã sửa: bind lazy đọc `config('app.cdhc2_service')` + test chống hồi quy |
| N2 | `DbRef::core()` so với connection **mặc định** (vốn là core) nên **luôn trả tên bảng trần** — vô tác dụng sau khi tách DB | 🔴 | ✅ Đã sửa: suy ra database của service từ `app.cdhc2_service` |
| N3 | Gán `$connection` cho model sinh **deadlock chéo connection** khi nhiều PDO cùng trỏ một database (`Lock wait timeout exceeded`, 50s) | 🔴 | ✅ Đã sửa: alias connection con về connection mặc định khi chưa tách DB. Test `LmsCourseEnrollsEntireClassTest` fail 114s → pass 63s |
| N4 | `InternalApiAuth` khi Bearer sai vẫn rơi xuống shared secret → hạ cấp bảo mật âm thầm | 🟡 | ✅ Đã sửa: Bearer sai thì chặn ngay (403) |
| N5 | `JwtTokenService` chấp nhận cả thuật toán ngoài HMAC (kể cả `none`) và không kiểm tra độ dài khoá | 🟡 | ✅ Đã sửa: chỉ HS256/384/512, yêu cầu khoá ≥ 32 ký tự |
| N6 | **7 test fail sẵn trên `origin/main`** (production), CI không chạy test nên lọt | 🔴 | ⏳ **Chưa sửa** — xem mục 9 |

---

## 9. 7 test đang fail sẵn trên `origin/main` (không do microservices)

Xác minh: 7 file test này **giống hệt nhau** giữa `origin/main` và `dev`
(`git diff --stat origin/main...dev -- <các file test>` → rỗng), nên lỗi có từ trước.

| Test | Assertion | Nhận định |
|---|---|---|
| `Unit\FacultyTrainingPlanGroupingTest:39` | `subject_short` trả tên môn đầy đủ (`Thể thao`) thay vì mã (`TTT`) | Nghi lệch hành vi thật ở `FacultyTrainingPlanExport::rowsFromDetails()` |
| `Unit\ScheduleDetailFormScriptTest:47` | Blade thiếu chuỗi `{{-- Legacy Tom Select API … --}}` | Test khẳng định theo **nội dung chuỗi** trong blade → dễ cũ sau refactor Tom Select |
| `Unit\TrainingScheduleSprint20UiTest:37` | Cùng lý do trên | Cùng nhóm |
| `Unit\TrainingScheduleSprint23ExportUiTest:20` | Blade thiếu `@extends('layouts.admin')` | Cùng nhóm |
| `Feature\ApplicationRegistryPermissionTest:94` | `assertTrue(false)` — quyền `exam manager` / `legacy manage` | Cần review lại bảng quyền |
| `Feature\ExternalActivityAndAuthStabilityTest:28` | `assertTrue(false)` | Cần điều tra |
| `Feature\LessonsImportTest:137` | Thiếu dòng `subject_lessons` `code=B02, parent_id=null` | Nghi lỗi import thật |

**Đề xuất:** xử lý thành task riêng, và **bổ sung bước chạy test vào CI** — hiện `build-and-deploy.yml` chỉ chạy `blade-lint` (`view:cache`), không chạy `php artisan test`, nên test đỏ vẫn deploy được.

---

## 10. Phụ lục — Bảng bằng chứng

```powershell
# Tái lập toàn bộ số liệu trong tài liệu này
cd D:\CDHC2\lich-hoc-cdhc2
git rev-list --left-right --count origin/dev...dev
git log --oneline origin/dev..dev

# Phase 4
Get-ChildItem modules,app -Recurse -Filter *.php |
  Select-String -Pattern 'storage_path\(|public_path\(|Storage::disk\(|->disk\(' |
  Group-Object { ($_.Path -replace '^.*?\\(modules|app)\\([^\\]+).*$','$2') } |
  Sort-Object Count -Descending | Select-Object Count,Name

# Phase 6 — model thieu connection
foreach ($m in 'Tms','Lms','Grades','EssayExam','ExamOrganization') {
  $d = "modules\$m\Models"
  if (Test-Path $d) {
    $f = Get-ChildItem $d -Filter *.php
    $miss = $f | Where-Object { -not (Select-String -Path $_.FullName -Pattern 'protected \$connection' -Quiet) }
    "$m total=$($f.Count) missing=$($miss.Count)"
  }
}

# Phase 6 — query tran toi bang core
Select-String -Path modules\*\*.php -Pattern "DB::table\('(users|units|classes|subjects|training_schedules|schedule_details|academic_years|teaching_assignment)'"

# Phase 5 — JWT_SECRET tren cluster
Select-String -Path k8s\*\*.yaml,k8s\* -Pattern 'JWT_SECRET'
```

---

---

## 7. Nhật ký thực thi

### 16/09/2026 — Gate A (một phần) + tách nhánh Phase 4/5/6

Đã làm, theo uỷ quyền của chủ dự án ("chỉ sync + push dev, mở PR, chưa merge" và "tách thành 3 nhánh feat/phase4|5|6 rồi commit riêng"):

| Việc | Kết quả |
|---|---|
| Merge `origin/dev` → `dev` | ✅ `6fb2f60d` — sạch, chỉ chạm `schedule-detail-form-scripts.blade.php` + `tom-select-init.blade.php` (không đè file đang sửa) |
| Push `dev` | ✅ `50c4a279..6fb2f60d` |
| Mở PR Phase 0-3 | ✅ [PR #359](https://github.com/tho076/lich-hoc-cdhc2/pull/359) `dev → main` — **chưa merge** |
| Tách nhánh Phase 4 | ✅ `feat/phase4-s3-storage` — 2 commit, 17 file: `957ed7c0 style:` (277 dòng Pint) + `be036dd8 feat:` (logic) |
| Tách nhánh Phase 5 | ✅ `feat/phase5-jwt-traefik` — 1 commit `de3ba899`, 17 file |
| Tách nhánh Phase 6 | ✅ `feat/phase6-db-split` — 2 commit, 79 file: `7b04f44f` (70 model) + `80d199ab` (DbRef/config/migration) |
| Push 3 nhánh | ✅ cả 3 đã lên `origin`, **chưa mở PR** |
| Cây làm việc | ✅ sạch (`git diff` = 0), `dev` == `origin/dev` |

Kiểm chứng trên cả 3 nhánh: `php -l` file mới OK · `php artisan view:cache` OK · quét file rác (`.docx`, `AGENTS.md`, `quanham/`, `.claude/`, `StandardHours-*`, `.tmp*`) → **không nhánh nào chứa**.

Xử lý R6 (Pint noise): đo được chỉ 2 file có Pint thuần (`InventoryController` 271 dòng, `InventoryReportTemplateController` 6 dòng); 13 file còn lại diff là logic thuần. Đã tách 2 file đó sang commit `style:` riêng → diff logic của `InventoryController` từ 198/74 xuống **4/3 dòng**.

**Chưa làm (chờ lệnh):** merge PR #359 · mở PR cho 3 nhánh Phase 4/5/6 · mọi thứ thuộc Gate B/C/D · rotate `JWT_SECRET` (R1) · dọn `tkb-gateway` cũ (R3) · làm migration idempotent (R4).

### 16/09/2026 — Review Phase 0-3 bằng test suite

Chạy `php artisan test` trên `dev` (Phase 0-3): **35 pass, 2 fail, 359 pending**.

| # | Test | Nguyên nhân | Xử lý |
|---|---|---|---|
| 1 | `GradeScoreSheetDataProviderTest` | Phase 0-3 (`756f7480`) **di chuyển** 5 Grade data provider: `modules/ExportTemplates/Data/` → `modules/Grades/Data/`, đăng ký lại đầy đủ trong `GradesServiceProvider`, **nhưng test còn import namespace cũ** → `BindingResolutionException` | ✅ Đã sửa import → commit `012263db`, 2 test pass |
| 2 | `FacultyTrainingPlanGroupingTest` | `rowsFromDetails()` trả về tên môn đầy đủ (`Thể thao`) thay vì mã viết tắt (`TTT`) | 🔴 **Lỗi có sẵn trên `main`** — `git diff origin/main...dev -- tests/Unit/FacultyTrainingPlanGroupingTest.php modules/TrainingSchedule/Exports/FacultyTrainingPlanExport.php` rỗng, tức Phase 0-3 không chạm 2 file này. **Không do Phase 0-3.** Cần xử lý riêng. |

Xác minh bổ sung: việc di chuyển 5 provider là **đúng** — cả 5 đều được `GradesServiceProvider` (dòng 7–11, 22–26) `$registry->register(...)`, không có tham chiếu namespace cũ nào khác ngoài test đã sửa.

---

*Tài liệu này là kế hoạch. Gate A đã thực thi một phần (xem mục 7). Gate B/C/D chưa thực thi — chỉ tiến hành sau khi chủ dự án trả lời mục 5.*
