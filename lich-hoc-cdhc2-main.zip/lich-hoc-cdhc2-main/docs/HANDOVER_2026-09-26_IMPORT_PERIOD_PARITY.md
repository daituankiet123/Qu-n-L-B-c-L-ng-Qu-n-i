# Bổ sung PR #471 sau đối chiếu #445

Khôi phục chuỗi Năm → Kỳ → Ngành → Lớp → Môn: curriculumOptions giữ đủ lớp/môn/năm/kỳ và phạm vi được phân công. curriculumMetadata chọn đúng năm/kỳ gửi lên; import, preview, confirm, create không ghi đè bằng kỳ mới nhất. Hỗ trợ kỳ hè. Bỏ yêu cầu nhập import_code và title đã lỗi thời vì mã/tên được cấp tự động.

Kiểm tra local: EssayExamWorkflowTest 19 tests / 148 assertions; thêm dữ liệu cùng lớp/môn trong 3 kỳ, đối chiếu ngành, giữ năm/kỳ cũ khi preview, preview không cần import_code, file PDF được tạo, chưa tiêu hao mã TL trước xác nhận. Kiến trúc lms/core và phiên preview riêng theo tài khoản được giữ.

Khác biệt này có trong #445, đã bị bỏ sót khi port #459; không phải yêu cầu cắt chức năng của hai hướng dẫn pipeline/microservices.

Sau khi CI MySQL chạy lại, hai test import cũ phát hiện hồi quy khi lớp/môn chưa có khóa học LMS. Đã giữ khả năng import trực tiếp bằng năm/kỳ người dùng gửi trong trường hợp chưa cấu hình LMS. Khi lớp/môn đã có khóa học, vẫn yêu cầu đúng kỳ đã mở, không tự lấy kỳ mới nhất. Không xóa hoặc đổi kỳ vọng hai test cũ để làm CI đạt.
