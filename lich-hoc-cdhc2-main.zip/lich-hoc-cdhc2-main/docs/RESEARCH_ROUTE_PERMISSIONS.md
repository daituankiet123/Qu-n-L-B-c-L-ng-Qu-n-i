# NCKH — route và quyền

Xuất từ route:list của nhánh #462. Mọi route dùng web + auth; các quyền bên dưới là điều kiện OR khi có nhiều quyền.

| Method | URI | Route | Quyền |
| --- | --- | --- | --- |
| GET / HEAD | nghien-cuu-khoa-hoc | scientific-research.index | scientific-research.index |
| GET / HEAD | nghien-cuu-khoa-hoc/bao-cao | scientific-research.reports.index | scientific-research.reports.view |
| GET / HEAD | nghien-cuu-khoa-hoc/bao-cao/csv | scientific-research.reports.csv | scientific-research.reports.export |
| GET / HEAD | nghien-cuu-khoa-hoc/bao-cao/excel | scientific-research.reports.excel | scientific-research.reports.export |
| GET / HEAD | nghien-cuu-khoa-hoc/bao-cao/word | scientific-research.reports.word | scientific-research.reports.export |
| GET / HEAD | nghien-cuu-khoa-hoc/bo-sung-gia-han | scientific-research.registrations.requests | scientific-research.registrations.submit<br>scientific-research.registrations.edit |
| GET / HEAD | nghien-cuu-khoa-hoc/can-bo | scientific-research.staff.index | scientific-research.staff.index |
| POST | nghien-cuu-khoa-hoc/can-bo | scientific-research.staff.store | scientific-research.staff.create |
| PATCH | nghien-cuu-khoa-hoc/can-bo/{staffProfile} | scientific-research.staff.update | scientific-research.staff.edit |
| DELETE | nghien-cuu-khoa-hoc/can-bo/{staffProfile} | scientific-research.staff.destroy | scientific-research.staff.delete |
| GET / HEAD | nghien-cuu-khoa-hoc/cong-thong-tin | scientific-research.portal | scientific-research.portal<br>scientific-research.index |
| GET / HEAD | nghien-cuu-khoa-hoc/dang-ky | scientific-research.registrations.create | scientific-research.registrations.create |
| POST | nghien-cuu-khoa-hoc/dang-ky | scientific-research.registrations.store | scientific-research.registrations.create<br>scientific-research.registrations.submit |
| GET / HEAD | nghien-cuu-khoa-hoc/dang-ky/{registration} | scientific-research.registrations.show | scientific-research.registrations.show<br>scientific-research.registrations.index |
| PATCH | nghien-cuu-khoa-hoc/dang-ky/{registration} | scientific-research.registrations.update | scientific-research.registrations.edit<br>scientific-research.registrations.submit |
| DELETE | nghien-cuu-khoa-hoc/dang-ky/{registration} | scientific-research.registrations.destroy | scientific-research.registrations.delete |
| POST | nghien-cuu-khoa-hoc/dang-ky/{registration}/dong-bo-gio-chuan | scientific-research.registrations.sync-standard-hours | scientific-research.registrations.sync-standard-hours |
| PATCH | nghien-cuu-khoa-hoc/dang-ky/{registration}/duyet-gia-han | scientific-research.registrations.extension.review | scientific-research.registrations.status<br>scientific-research.registrations.agency-approve |
| POST | nghien-cuu-khoa-hoc/dang-ky/{registration}/gui-bo-sung | scientific-research.registrations.revision.submit | scientific-research.registrations.edit<br>scientific-research.registrations.submit |
| POST | nghien-cuu-khoa-hoc/dang-ky/{registration}/ket-qua | scientific-research.results.store | scientific-research.results.create<br>scientific-research.results.submit |
| PATCH | nghien-cuu-khoa-hoc/dang-ky/{registration}/trang-thai | scientific-research.registrations.status | scientific-research.registrations.status<br>scientific-research.registrations.unit-approve<br>scientific-research.registrations.agency-approve<br>scientific-research.registrations.return |
| POST | nghien-cuu-khoa-hoc/dang-ky/{registration}/xin-gia-han | scientific-research.registrations.extension.request | scientific-research.registrations.edit<br>scientific-research.registrations.submit |
| GET / HEAD | nghien-cuu-khoa-hoc/de-tai | scientific-research.registrations.index | scientific-research.registrations.index |
| PATCH | nghien-cuu-khoa-hoc/gia-han/{extension} | scientific-research.registrations.extension.update | scientific-research.registrations.edit<br>scientific-research.registrations.submit<br>scientific-research.registrations.status<br>scientific-research.registrations.agency-approve |
| DELETE | nghien-cuu-khoa-hoc/gia-han/{extension} | scientific-research.registrations.extension.destroy | scientific-research.registrations.edit<br>scientific-research.registrations.submit<br>scientific-research.registrations.status<br>scientific-research.registrations.agency-approve |
| GET / HEAD | nghien-cuu-khoa-hoc/hoi-dong | scientific-research.councils.index | scientific-research.councils.index |
| POST | nghien-cuu-khoa-hoc/hoi-dong | scientific-research.councils.store | scientific-research.councils.create |
| DELETE | nghien-cuu-khoa-hoc/hoi-dong-thanh-vien/{member} | scientific-research.councils.members.destroy | scientific-research.councils.delete |
| PATCH | nghien-cuu-khoa-hoc/hoi-dong/{council} | scientific-research.councils.update | scientific-research.councils.edit |
| DELETE | nghien-cuu-khoa-hoc/hoi-dong/{council} | scientific-research.councils.destroy | scientific-research.councils.delete |
| POST | nghien-cuu-khoa-hoc/hoi-dong/{council}/thanh-vien | scientific-research.councils.members.store | scientific-research.councils.create |
| GET / HEAD | nghien-cuu-khoa-hoc/ke-hoach | scientific-research.plans.index | scientific-research.plans.index |
| POST | nghien-cuu-khoa-hoc/ke-hoach | scientific-research.plans.store | scientific-research.plans.create |
| PATCH | nghien-cuu-khoa-hoc/ke-hoach/{plan} | scientific-research.plans.update | scientific-research.plans.edit |
| DELETE | nghien-cuu-khoa-hoc/ke-hoach/{plan} | scientific-research.plans.destroy | scientific-research.plans.delete |
| PATCH | nghien-cuu-khoa-hoc/ke-hoach/{plan}/nhiem-vu/{taskKey} | scientific-research.plans.tasks.update | scientific-research.plans.index<br>scientific-research.plans.edit |
| GET / HEAD | nghien-cuu-khoa-hoc/ket-qua | scientific-research.results.index | scientific-research.results.index |
| PATCH | nghien-cuu-khoa-hoc/ket-qua/{result} | scientific-research.results.update | scientific-research.results.edit<br>scientific-research.results.approve |
| DELETE | nghien-cuu-khoa-hoc/ket-qua/{result} | scientific-research.results.destroy | scientific-research.results.delete |
| GET / HEAD | nghien-cuu-khoa-hoc/kho-du-lieu | scientific-research.repository.index | scientific-research.repository.index |
| POST | nghien-cuu-khoa-hoc/kho-du-lieu | scientific-research.repository.store | scientific-research.repository.create |
| PATCH | nghien-cuu-khoa-hoc/kho-du-lieu/{document} | scientific-research.repository.update | scientific-research.repository.edit |
| DELETE | nghien-cuu-khoa-hoc/kho-du-lieu/{document} | scientific-research.repository.destroy | scientific-research.repository.delete |
| GET / HEAD | nghien-cuu-khoa-hoc/kho-du-lieu/{document}/tai-ve | scientific-research.repository.download | scientific-research.repository.show<br>scientific-research.repository.index |
| GET / HEAD | nghien-cuu-khoa-hoc/kinh-phi | scientific-research.funding.index | scientific-research.funding.index |
| POST | nghien-cuu-khoa-hoc/kinh-phi | scientific-research.funding.store | scientific-research.funding.create |
| PATCH | nghien-cuu-khoa-hoc/kinh-phi/{funding} | scientific-research.funding.update | scientific-research.funding.edit |
| DELETE | nghien-cuu-khoa-hoc/kinh-phi/{funding} | scientific-research.funding.destroy | scientific-research.funding.delete |
| GET / HEAD | nghien-cuu-khoa-hoc/nhat-ky | scientific-research.audit.index | scientific-research.audit.index |
| GET / HEAD | nghien-cuu-khoa-hoc/san-pham | scientific-research.products.index | scientific-research.products.index |
| POST | nghien-cuu-khoa-hoc/san-pham | scientific-research.products.store | scientific-research.products.create |
| PATCH | nghien-cuu-khoa-hoc/san-pham/{product} | scientific-research.products.update | scientific-research.products.edit |
| DELETE | nghien-cuu-khoa-hoc/san-pham/{product} | scientific-research.products.destroy | scientific-research.products.delete |
| GET / HEAD | nghien-cuu-khoa-hoc/tep-dinh-kem/{file}/tai-ve | scientific-research.files.download | scientific-research.registrations.show<br>scientific-research.registrations.index<br>scientific-research.registrations.unit-approve<br>scientific-research.registrations.agency-approve<br>scientific-research.registrations.return<br>scientific-research.registrations.status<br>scientific-research.results.show<br>scientific-research.results.index<br>scientific-research.results.approve |
| GET / HEAD | nghien-cuu-khoa-hoc/tham-dinh-de-tai | scientific-research.registrations.review | scientific-research.registrations.status<br>scientific-research.registrations.unit-approve<br>scientific-research.registrations.agency-approve<br>scientific-research.registrations.return |
| GET / HEAD | nghien-cuu-khoa-hoc/tham-dinh-de-tai/{registration} | scientific-research.registrations.review.show | scientific-research.registrations.status<br>scientific-research.registrations.unit-approve<br>scientific-research.registrations.agency-approve<br>scientific-research.registrations.return |
| GET / HEAD | nghien-cuu-khoa-hoc/thong-bao | scientific-research.announcements.index | scientific-research.announcements.index |
| POST | nghien-cuu-khoa-hoc/thong-bao | scientific-research.announcements.store | scientific-research.announcements.create |
| PATCH | nghien-cuu-khoa-hoc/thong-bao/{announcement} | scientific-research.announcements.update | scientific-research.announcements.edit |
| DELETE | nghien-cuu-khoa-hoc/thong-bao/{announcement} | scientific-research.announcements.destroy | scientific-research.announcements.delete |
