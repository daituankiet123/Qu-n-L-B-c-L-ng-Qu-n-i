<?php
// Local-only UAT: in-memory database and Laravel fake filesystem, no production data.
foreach (['APP_ENV'=>'testing','DB_CONNECTION'=>'sqlite','DB_DATABASE'=>':memory:','CACHE_STORE'=>'array','SESSION_DRIVER'=>'array','MAIL_MAILER'=>'array','QUEUE_CONNECTION'=>'sync'] as $key=>$value) { putenv("$key=$value"); $_ENV[$key]=$value; $_SERVER[$key]=$value; }
require __DIR__.'/../../vendor/autoload.php';
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Schema\Blueprint;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Modules\EssayExam\Models\EssayExam;
use Modules\EssayExam\Models\EssayExamApprovalDocument;
use Modules\EssayExam\Models\EssayExamDraw;

$fixture = new Tests\Feature\EssayExamWorkflowTest('test_real_user_signature_does_not_require_a_position_relation');
(new ReflectionMethod($fixture,'setUp'))->invoke($fixture);
(new ReflectionMethod($fixture,'prepareSignedApproval'))->invoke($fixture);
(new ReflectionMethod($fixture,'withoutVite'))->invoke($fixture);
Schema::table('users', function(Blueprint $t){$t->string('email')->nullable();$t->boolean('status')->default(true);});
foreach (['2025_08_20_114244_create_permission_tables.php','2026_07_10_000001_create_system_notifications_table.php','2026_07_11_000001_add_email_fields_to_system_notifications_table.php'] as $file) {(require base_path('database/migrations/'.$file))->up();}
foreach(['instructor','faculty-manager','exam-office','bgh'] as $role) Role::findOrCreate($role,'web');
$permissions=['essay-exams.submission.create','essay-exams.approval.approve','essay-exams.approval.index','essay-exams.index','essay-exams.show','essay-exams.draw.export'];
foreach($permissions as $permission) Permission::findOrCreate($permission,'web');
foreach([[1,'BGH UAT','bgh',10],[2,'Giáo viên UAT','instructor',10],[3,'Giáo viên khoa khác','instructor',20],[4,'Khoa UAT','faculty-manager',10],[5,'Khảo thí UAT','exam-office',30],[6,'Khoa khác UAT','faculty-manager',20]] as [$id,$name,$role,$unit]) {
 DB::table('users')->updateOrInsert(['id'=>$id],['name'=>$name,'email'=>"uat$id@example.test",'status'=>1,'unit_id'=>$unit]);
 $u=User::findOrFail($id);$u->assignRole($role);$u->givePermissionTo($permissions);
}
$out=base_path('docs/evidence/473');@mkdir($out,0777,true);$results=[];
$call=function(int $actor,string $method,string $path,array $data=[],int $expected=302)use($fixture,&$results){
 $u=User::findOrFail($actor);$response=$fixture->actingAs($u)->{$method}($path,$data);$status=$response->getStatusCode();
 $results[]=['actor'=>$u->name,'method'=>strtoupper($method),'path'=>$path,'http'=>$status,'expected'=>$expected];
 echo "$actor $method $path => $status\n";
 if($status!==$expected){file_put_contents(storage_path('uat-error.html'),$response->getContent());throw new RuntimeException("Expected $expected; response in storage/uat-error.html");}return $response;
};
// A synthetic mark, clearly labelled UAT, never a real person's signature.
$im=imagecreatetruecolor(300,90);imagefill($im,0,0,imagecolorallocate($im,255,255,255));$ink=imagecolorallocate($im,15,40,120);imagestring($im,5,25,30,'UAT - SAMPLE ONLY',$ink);ob_start();imagepng($im);$png=ob_get_clean();imagedestroy($im);
Storage::disk('public')->put('signatures/own.png',$png);DB::table('digital_signatures')->where('id',1)->update(['display_name'=>'BGH UAT']);
foreach(['digital','direct'] as $mode){
 $exam=EssayExam::findOrFail(1);$exam->update(['status'=>'DRAFT','locked'=>false,'source_pdf_path'=>'essay-exam/imports/uat-'.$mode.'.pdf']);
 $pdf=new Mpdf\Mpdf(['tempDir'=>storage_path('app/mpdf-test'),'default_font'=>'dejavusans','margin_bottom'=>55]);
 $pdf->WriteHTML('<h1>ĐỀ THI MẪU UAT</h1><p>Dữ liệu giả lập để kiểm tra PR #473 — không sử dụng thi thật.</p><p>Câu 1: Trình bày nội dung bài học mẫu.</p>');
 $pdf->AddPage();$pdf->WriteHTML('<h1>ĐÁP ÁN MẪU UAT</h1><p>Đáp án câu 1: Nội dung trả lời mẫu. Điểm: 10.</p>');
 $original=$pdf->Output('', 'S');Storage::disk('local')->put($exam->source_pdf_path,$original);file_put_contents("$out/$mode-original.pdf",$original);
 $exam->questions()->update(['paper_status'=>'DRAFT','content'=>'Câu hỏi mẫu UAT','answer'=>'Đáp án mẫu UAT']);
 $call(2,'post','/essay-exams/1/submit');
 $call(3,'get','/essay-exams/1/source-pdf',[],403);
 $call(6,'get','/essay-exams/1/source-pdf',[],403);
 $call(6,'post','/essay-exams/1/approve',['stage'=>'PENDING_DEPT','paper_numbers'=>[1,2]],403);
 $call(3,'post','/essay-exams/approval/print/1',['print_mode'=>'digital'],403);
 $call(4,'post','/essay-exams/1/approve',['stage'=>'PENDING_DEPT','paper_numbers'=>[1,2]]);
 $call(5,'post','/essay-exams/1/approve',['stage'=>'PENDING_EXAM_OFFICE','paper_numbers'=>[1,2]]);
 $source=$call(1,'get','/essay-exams/1/source-pdf',[],200);file_put_contents("$out/$mode-served-original.pdf",$source->getContent());
 if($source->getContent()!==$original)throw new RuntimeException('Original PDF changed before signing');
 $template=str_replace(["@extends('layouts.admin')", "@include('partials.module-menu', ['module' => 'exam'])"],'',file_get_contents(base_path('modules/EssayExam/Views/approval.blade.php')));
 $css='';foreach(glob(dirname(base_path()).'/.pr-shared-layout-review/storage/frontend-build/public/build/assets/app-*.css') as $cssFile)$css.=file_get_contents($cssFile);
 $html=Illuminate\Support\Facades\Blade::render($template."\n@yield('content')",['stage'=>'PENDING_BGH','exams'=>collect([$exam->fresh()->load(['questions','subject'])]),'lmsBanks'=>collect(),'specializations'=>collect(),'subjects'=>collect(),'examOptions'=>collect(),'currentDigitalSignature'=>app(Modules\EssayExam\Services\EssayExamSignedPdfService::class)->currentSignature(User::find(1))]);
 file_put_contents("$out/bgh.html",'<!doctype html><meta charset="utf-8"><style>'.$css.'</style><h1>LOCAL UAT — mẫu kiểm tra chữ ký BGH</h1>'.$html);
 $directPng=is_file("$out/canvas-signature.png")?file_get_contents("$out/canvas-signature.png"):$png;
 $data=['stage'=>'PENDING_BGH','paper_numbers'=>[1,2]];if($mode==='direct')$data['signature_data']='data:image/png;base64,'.base64_encode($directPng);
 $call(1,'post','/essay-exams/1/approve',$data);
 $document=EssayExamApprovalDocument::where('essay_exam_id',1)->firstOrFail();
 $signed=$call(1,'get','/essay-exams/approval-documents/'.$document->id,[],200);file_put_contents("$out/$mode-signed.pdf",$signed->getContent());
 $results[]=['mode'=>$mode,'status'=>EssayExam::find(1)->status,'signature_method'=>$document->signature_method,'pdf_bytes'=>strlen($signed->getContent())];
}
DB::table('essay_exam_draws')->insert(['id'=>1,'essay_exam_id'=>1,'paper_number'=>1,'draw_code'=>'UAT-DRAW-01','draw_type'=>'EVEN','class_name'=>'Lớp mẫu UAT','exam_date'=>'2026-09-27','exam_time'=>'08:00','drawn_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);
foreach(['questions'=>'','answers'=>'?answers=1'] as $name=>$query){$response=$call(1,'get','/essay-exams/draw/1/print'.$query,[],200);file_put_contents("$out/print-$name.html",$response->getContent());}
file_put_contents("$out/http-results.json",json_encode($results,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo "UAT complete: $out\n";
