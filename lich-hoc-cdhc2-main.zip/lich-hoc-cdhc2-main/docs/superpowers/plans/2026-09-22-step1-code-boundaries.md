# Bước 1 — Ranh giới code giữa các service: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Không service nào (kể cả core) import class của service khác, ngoài các adapter in-process đã được cho phép; một test kiến trúc chặn việc thêm mới.

**Architecture:** Chủ sở hữu module lấy từ `App\Support\ServiceTopology` (có từ PR #418). Một test "ratchet" quét mã nguồn, so với file baseline: thêm tham chiếu chéo mới → đỏ; gỡ xong một tham chiếu mà chưa xoá khỏi baseline → cũng đỏ (baseline chỉ được co lại). Các task sau gỡ từng cụm coupling bằng 4 cách đã có sẵn trong repo: đưa năng lực nền về core, `resolveRelationUsing` ở provider của module sở hữu, registry `extend()`, và contract Direct/Http trong `packages/cdhc2-core`.

**Tech Stack:** Laravel 12, PHPUnit 11 (`php artisan test`), MySQL (test dùng MySQL thật, `RefreshDatabase`), Symfony Finder, Laravel HTTP client fake.

**Spec:** `docs/superpowers/plans/2026-09-22-microservices-roadmap.md` (Bước 1) + `docs/HANDOVER_2026-09-22.md` mục 7.

## Global Constraints

- Tiền đề: PR #418 (`fix/cross-service-nav-links`) đã merge vào `main` — plan dùng `App\Support\ServiceTopology` và `App\Providers\CrossServiceRoutesServiceProvider` của PR đó.
- Nhánh làm việc: tạo từ `main` mới nhất, ví dụ `step1-code-boundaries`. Mỗi task một commit. Mở PR vào `main`; mọi push lên `main` đều deploy prod.
- Monolith (không đặt `CDHC2_SERVICE`) phải boot và chạy y như cũ sau mỗi task.
- Không đụng Moodle; không đổi k8s manifest trong bước này.
- Chạy `vendor/bin/pint --dirty` trước mỗi commit.
- Git: chỉ `git add <file cụ thể>`, không `git add .` / `-A`. Lệnh `gh` luôn kèm `-R tho076/lich-hoc-cdhc2`. Trong Git Bash, lệnh có đường dẫn bắt đầu bằng `/` thì thêm `MSYS_NO_PATHCONV=1`.
- Service ↔ module (theo `ServiceTopology` sau Task 2): **lms** = Lms, EssayExam, ExamOrganization · **tms** = Tms, Inventory, LeaveManagement · **grades** = Grades · **dashboard** = Dashboard, Home · mọi module còn lại + `app/` + `resources/views` + `packages/cdhc2-core/src` = **core**.
- Được phép tham chiếu chéo: `packages/cdhc2-core/src/Direct/**` (adapter in-process), `app/Support/ServiceTopology.php`, `app/Providers/CrossServiceRoutesServiceProvider.php`. Service → core luôn được phép.
- Cuối mỗi task: cập nhật `docs/HANDOVER_2026-09-22.md` (mục 4 + nhật ký) — yêu cầu thường trực của chủ dự án.

## File Structure

| File | Trách nhiệm |
|---|---|
| `tests/Unit/Architecture/CrossServiceImportsTest.php` (mới) | Quét tham chiếu chéo service, so baseline |
| `tests/Unit/Architecture/cross-service-baseline.txt` (mới, sinh tự động) | Danh sách nợ coupling hiện có, chỉ được co lại |
| `app/Support/ServiceTopology.php` | Thêm `core()`; bỏ ExportTemplates khỏi grades |
| `bootstrap/providers.php` | Dùng `ServiceTopology::core()` |
| `app/Support/QuestionImport/QuestionImportParser.php` (chuyển từ EssayExam) | Parser đọc file câu hỏi dùng chung LMS + TMS |
| `modules/Lms/Services/LmsStatisticsService.php` (chuyển từ Dashboard) | Thống kê LMS thuộc về LMS |
| `modules/Inventory/Providers/InventoryServiceProvider.php`, `modules/Lms/Providers/LmsServiceProvider.php` | Khai relation chéo cho model của core |
| `app/Models/User.php`, `modules/Grades/Providers/GradesServiceProvider.php` | Quyền vào Điểm qua Gate |
| `app/Support/TrashRegistry.php`, `app/Providers/AppServiceProvider.php`, provider Lms/EssayExam | Thùng rác: module tự đăng ký model |
| `packages/cdhc2-core/src/{Contracts,Direct,Http}/…LmsProvisioning.php` (mới) | Contract tạo khoá học LMS khi core đổi lớp/môn/phân công |
| `modules/{Lms,Tms,Grades}/Console/Commands/*` (chuyển từ `app/Console/Commands`) | Lệnh artisan thuộc module |

---

### Task 1: Test kiến trúc dạng ratchet + baseline

**Files:**
- Create: `tests/Unit/Architecture/CrossServiceImportsTest.php`
- Create (sinh ra): `tests/Unit/Architecture/cross-service-baseline.txt`

**Interfaces:**
- Consumes: `App\Support\ServiceTopology::services(): array<string, list<class-string>>`
- Produces: `CrossServiceImportsTest::scan(): list<string>` — mỗi dòng dạng `đường/dẫn/tương/đối.php|Modules\Module\Class`. Các task sau chạy `php artisan test --filter=CrossServiceImportsTest` để thấy dòng "stale" rồi xoá dòng đó khỏi baseline.

- [ ] **Step 1: Viết test**

```php
<?php

namespace Tests\Unit\Architecture;

use App\Support\ServiceTopology;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Finder\Finder;

/**
 * Ratchet ranh gioi service: chi duoc GIAM tham chieu cheo, khong duoc them.
 *
 * Them moi  -> dung contract trong packages/cdhc2-core (Direct/Http), event,
 *              hoac resolveRelationUsing o provider cua module so huu.
 * Go bo xong -> xoa dong tuong ung khoi cross-service-baseline.txt.
 * Sinh lai baseline (chi khi co ly do): CDHC2_UPDATE_COUPLING_BASELINE=1 php artisan test --filter=CrossServiceImportsTest
 */
class CrossServiceImportsTest extends TestCase
{
    private const BASELINE = __DIR__.'/cross-service-baseline.txt';

    private const ALLOWED_FILES = [
        'app/Support/ServiceTopology.php',
        'app/Providers/CrossServiceRoutesServiceProvider.php',
    ];

    private const ALLOWED_PREFIXES = [
        'packages/cdhc2-core/src/Direct/',
    ];

    public function test_no_new_cross_service_references(): void
    {
        $current = self::scan();

        if (getenv('CDHC2_UPDATE_COUPLING_BASELINE') === '1') {
            file_put_contents(self::BASELINE, implode("\n", $current)."\n");
            $this->markTestSkipped('Da ghi baseline: '.count($current).' dong');
        }

        $baseline = self::readBaseline();
        $new = array_values(array_diff($current, $baseline));
        $stale = array_values(array_diff($baseline, $current));

        $this->assertSame([], $new, "Tham chieu cheo service MOI - dung contract/event thay vi import thang:\n".implode("\n", $new));
        $this->assertSame([], $stale, "Da go xong - xoa cac dong nay khoi tests/Unit/Architecture/cross-service-baseline.txt:\n".implode("\n", $stale));
    }

    public function test_scanner_flags_a_service_to_service_import(): void
    {
        $owners = self::moduleOwners();

        $this->assertSame('lms', $owners['Lms']);
        $this->assertSame('tms', $owners['Tms']);
        $this->assertSame(
            ['modules/Tms/X.php|Modules\EssayExam\Controllers\EssayExamController'],
            self::violationsIn('modules/Tms/X.php', "<?php\nuse Modules\\EssayExam\\Controllers\\EssayExamController;\n", $owners)
        );
        $this->assertSame(
            [],
            self::violationsIn('modules/Tms/X.php', "<?php\n// Modules\\Lms\\Models\\LmsCourse chi la comment\nuse Modules\\Unit\\Models\\Unit;\n", $owners),
            'Comment va module core khong duoc tinh'
        );
    }

    /** @return list<string> */
    public static function scan(): array
    {
        $root = realpath(dirname(__DIR__, 3));
        $owners = self::moduleOwners();
        $rows = [];

        $finder = (new Finder)->files()->name('*.php')
            ->in([$root.'/app', $root.'/modules', $root.'/resources/views', $root.'/packages/cdhc2-core/src'])
            ->notPath('#(^|/)Tests/#');

        foreach ($finder as $file) {
            $rel = str_replace('\\', '/', substr($file->getRealPath(), strlen($root) + 1));
            if (in_array($rel, self::ALLOWED_FILES, true)) {
                continue;
            }
            foreach (self::ALLOWED_PREFIXES as $prefix) {
                if (str_starts_with($rel, $prefix)) {
                    continue 2;
                }
            }
            array_push($rows, ...self::violationsIn($rel, $file->getContents(), $owners));
        }

        $rows = array_values(array_unique($rows));
        sort($rows);

        return $rows;
    }

    /**
     * @param  array<string, string>  $owners
     * @return list<string>
     */
    private static function violationsIn(string $rel, string $code, array $owners): array
    {
        $src = preg_match('#^modules/([^/]+)/#', $rel, $m) ? ($owners[$m[1]] ?? 'core') : 'core';
        preg_match_all('/Modules\\\\{1,2}([A-Za-z0-9_]+)\\\\{1,2}([A-Za-z0-9_\\\\]+)/', self::withoutComments($code), $hits, PREG_SET_ORDER);

        $rows = [];
        foreach ($hits as [, $module, $class]) {
            $dst = $owners[$module] ?? 'core';
            if ($dst !== 'core' && $dst !== $src) {
                $rows[] = $rel.'|Modules\\'.$module.'\\'.rtrim(str_replace('\\\\', '\\', $class), '\\');
            }
        }

        return array_values(array_unique($rows));
    }

    /** @return array<string, string> module => service */
    private static function moduleOwners(): array
    {
        $owners = [];
        foreach (ServiceTopology::services() as $service => $providers) {
            foreach ($providers as $provider) {
                if (preg_match('/^Modules\\\\([^\\\\]+)\\\\/', $provider, $m)) {
                    $owners[$m[1]] = $service;
                }
            }
        }

        return $owners;
    }

    private static function withoutComments(string $code): string
    {
        $out = '';
        foreach (token_get_all($code) as $token) {
            if (is_array($token) && in_array($token[0], [T_COMMENT, T_DOC_COMMENT], true)) {
                continue;
            }
            $out .= is_array($token) ? $token[1] : $token;
        }

        return $out;
    }

    /** @return list<string> */
    private static function readBaseline(): array
    {
        if (! is_file(self::BASELINE)) {
            return [];
        }

        return array_values(array_filter(array_map('trim', file(self::BASELINE) ?: []), fn ($l) => $l !== ''));
    }
}
```

- [ ] **Step 2: Chạy test, xác nhận đỏ vì chưa có baseline**

Run: `php artisan test --filter=CrossServiceImportsTest`
Expected: `test_scanner_flags_a_service_to_service_import` PASS; `test_no_new_cross_service_references` FAIL "Tham chieu cheo service MOI" kèm danh sách dài (toàn bộ nợ hiện có).

- [ ] **Step 3: Sinh baseline**

Run: `CDHC2_UPDATE_COUPLING_BASELINE=1 php artisan test --filter=CrossServiceImportsTest`
Expected: test đầu SKIPPED "Da ghi baseline: N dong". Ghi lại N vào handover (con số xuất phát).

Mở `tests/Unit/Architecture/cross-service-baseline.txt`, kiểm có các dòng:
- `modules/Tms/Controllers/ExamController.php|Modules\EssayExam\Controllers\EssayExamController`
- `modules/Tms/Controllers/QuestionBankController.php|Modules\EssayExam\Controllers\EssayExamController`
- `app/Models/User.php|Modules\Grades\Services\GradeAccess`

Không có dòng nào của `packages/cdhc2-core/src/Direct/`.

- [ ] **Step 4: Thử phá để chắc test bắt được**

Thêm tạm dòng `use Modules\Lms\Models\LmsCourse;` vào `modules/Inventory/Providers/InventoryServiceProvider.php`, chạy `php artisan test --filter=CrossServiceImportsTest` → FAIL, liệt kê đúng `modules/Inventory/Providers/InventoryServiceProvider.php|Modules\Lms\Models\LmsCourse`. Bỏ dòng tạm, chạy lại → PASS.

- [ ] **Step 5: Commit**

```bash
git add tests/Unit/Architecture/CrossServiceImportsTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "test(arch): ratchet chan them tham chieu cheo service"
```

---

### Task 2: ExportTemplates về core

Lý do: bộ chuyển đổi tài liệu (`DocumentConverterInterface`, LibreOffice) và registry mẫu xuất được TMS (Inventory, LeaveManagement), TrainingSchedule, TemplateManagement và Grades cùng dùng; Traefik vốn đã đưa `/export-templates` về core (không có rule prefix riêng). ExportTemplates chỉ phụ thuộc module core (ScheduleDetail, TrainingSchedule).

**Files:**
- Modify: `app/Support/ServiceTopology.php`
- Modify: `bootstrap/providers.php` (khối `$core`)
- Modify: `tests/Feature/CrossServiceRoutesTest.php:49` và vòng nạp route trong `test_navigation_routes_resolve_in_every_split_service`
- Create: `tests/Feature/ServiceProvidersListTest.php`
- Modify: `tests/Unit/Architecture/cross-service-baseline.txt`

**Interfaces:**
- Produces: `ServiceTopology::core(): list<class-string>` — danh sách provider core (trước đây là biến `$core` trong `bootstrap/providers.php`), có thêm `ExportTemplatesServiceProvider`.

- [ ] **Step 1: Viết test đỏ**

`tests/Feature/ServiceProvidersListTest.php`:

```php
<?php

namespace Tests\Feature;

use App\Support\ServiceTopology;
use Modules\ExportTemplates\Providers\ExportTemplatesServiceProvider;
use Modules\Lms\Providers\LmsServiceProvider;
use Tests\TestCase;

class ServiceProvidersListTest extends TestCase
{
    /** @return list<class-string> */
    private function providersFor(string $service): array
    {
        $_ENV['CDHC2_SERVICE'] = $_SERVER['CDHC2_SERVICE'] = $service;
        putenv("CDHC2_SERVICE={$service}");

        try {
            return require base_path('bootstrap/providers.php');
        } finally {
            unset($_ENV['CDHC2_SERVICE'], $_SERVER['CDHC2_SERVICE']);
            putenv('CDHC2_SERVICE');
        }
    }

    public function test_export_templates_is_core_and_loaded_by_every_service(): void
    {
        $this->assertContains(ExportTemplatesServiceProvider::class, ServiceTopology::core());
        $this->assertNotContains(ExportTemplatesServiceProvider::class, ServiceTopology::serviceModuleProviders());

        foreach (['tms', 'lms', 'grades', 'core', 'monolith'] as $service) {
            $this->assertContains(ExportTemplatesServiceProvider::class, $this->providersFor($service), $service);
        }
    }

    public function test_split_service_does_not_load_other_service_modules(): void
    {
        $this->assertNotContains(LmsServiceProvider::class, $this->providersFor('tms'));
        $this->assertContains(LmsServiceProvider::class, $this->providersFor('lms'));
    }
}
```

- [ ] **Step 2: Chạy, xác nhận đỏ**

Run: `php artisan test --filter=ServiceProvidersListTest`
Expected: FAIL `Call to undefined method App\Support\ServiceTopology::core()`.

- [ ] **Step 3: Chuyển danh sách core vào ServiceTopology**

Trong `app/Support/ServiceTopology.php`: xoá `ExportTemplatesServiceProvider::class,` khỏi mảng `'grades'` (mảng còn `[GradesServiceProvider::class]`), và thêm method (các `use` tương ứng chuyển từ `bootstrap/providers.php` sang file này):

```php
    /**
     * Module nen tang: moi service (ke ca service tach le) deu nap.
     *
     * @return list<class-string>
     */
    public static function core(): array
    {
        return [
            AuthenticationServiceProvider::class,
            UserServiceProvider::class,
            UnitServiceProvider::class,
            ClassServiceProvider::class,
            SubjectServiceProvider::class,
            InstructorServiceProvider::class,
            BuildingServiceProvider::class,
            ClassroomServiceProvider::class,
            SpecializationServiceProvider::class,
            TrainingScheduleServiceProvider::class,
            TeachingAssignmentServiceProvider::class,
            ScheduleDetailServiceProvider::class,
            InstructorScheduleServiceProvider::class,
            StudentServiceProvider::class,
            StudentScheduleServiceProvider::class,
            StandardHoursServiceProvider::class,
            TrashServiceProvider::class,
            SystemSettingsServiceProvider::class,
            DatabaseManagementServiceProvider::class,
            // Bo chuyen doi tai lieu + registry mau xuat dung chung TMS/Grades/TrainingSchedule.
            ExportTemplatesServiceProvider::class,
        ];
    }
```

Trong `bootstrap/providers.php`: thay cả khối `$core = [ ... ];` bằng `$core = ServiceTopology::core();` và xoá các dòng `use` của 19 provider core (giờ nằm ở ServiceTopology). Giữ nguyên `$shared` và phần `return`.

- [ ] **Step 4: Sửa CrossServiceRoutesTest cho topology mới**

`tests/Feature/CrossServiceRoutesTest.php`:
- Dòng 49: bỏ `'ExportTemplates'` khỏi mảng → `foreach (['Dashboard', 'Tms', 'Grades', 'Inventory', 'LeaveManagement'] as $m) {`
- Trong `test_navigation_routes_resolve_in_every_split_service`, ngay trước vòng `foreach ($own as $provider)`, thêm vòng nạp route core (service tách lẻ thật cũng nạp chúng):

```php
            foreach (ServiceTopology::core() as $provider) {
                $file = ServiceTopology::webRoutesFile($provider);
                if ($file !== null && is_file(base_path($file))) {
                    require base_path($file);
                }
            }
```

- [ ] **Step 5: Chạy lại**

Run: `php artisan test --filter="ServiceProvidersListTest|CrossServiceRoutesTest|CrossServiceImportsTest"`
Expected: 2 test đầu PASS; `CrossServiceImportsTest` FAIL "Da go xong" liệt kê các dòng `…|Modules\ExportTemplates\…` (tms→grades cũ, nay là tms→core). Xoá đúng các dòng đó khỏi baseline, chạy lại → PASS.

- [ ] **Step 6: Boot từng service**

Run (Git Bash):
```bash
for s in monolith core lms tms grades; do CDHC2_SERVICE=$s php artisan route:list --name=export-templates.portal.index >/dev/null && echo "$s OK" || echo "$s FAIL"; done
```
Expected: 5 dòng `OK`.

- [ ] **Step 7: Commit**

```bash
vendor/bin/pint --dirty
git add app/Support/ServiceTopology.php bootstrap/providers.php tests/Feature/ServiceProvidersListTest.php tests/Feature/CrossServiceRoutesTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(topology): ExportTemplates la module core, moi service deu nap"
```

---

### Task 3: Parser nhập câu hỏi dùng chung — sửa luôn lỗi nhập đề TMS

Phát hiện khi khảo sát: TMS gọi `app(EssayExamController::class)->readImportText()` / `->parseImportRows()`, nhưng hai method này đã chuyển sang `EssayExamImportService` từ commit 756f7480 — controller **không còn** method đó. Hậu quả: `POST tms/question-banks/{id}/import` (route `question-banks.import`) luôn lỗi `Call to undefined method`, và `courses.bank.questions.import` lỗi với file `.doc/.docx`. `EssayExamImportService` không phụ thuộc model nào (chỉ `UploadedFile` + PhpWord) nên chuyển nguyên về core.

**Files:**
- Move: `modules/EssayExam/Services/EssayExamImportService.php` → `app/Support/QuestionImport/QuestionImportParser.php`
- Create: `modules/EssayExam/Services/EssayExamImportService.php` (lớp con rỗng, giữ tương thích cho EssayExam)
- Modify: `modules/Tms/Controllers/ExamController.php:9,384,437`
- Modify: `modules/Tms/Controllers/QuestionBankController.php:8,167-168`
- Create: `tests/Unit/QuestionImportParserTest.php`
- Modify: `tests/Unit/Architecture/cross-service-baseline.txt`

**Interfaces:**
- Produces: `App\Support\QuestionImport\QuestionImportParser` với `readImportText(UploadedFile $file): string`, `parseImportRows(string $text): array`, `parseAnswerRows(string $text): array`, `ensureAnswerHasPoint(string $answer, float $point): string` (y hệt chữ ký cũ).

- [ ] **Step 1: Viết test đỏ**

`tests/Unit/QuestionImportParserTest.php`:

```php
<?php

namespace Tests\Unit;

use App\Support\QuestionImport\QuestionImportParser;
use Illuminate\Http\UploadedFile;
use Modules\EssayExam\Services\EssayExamImportService;
use Tests\TestCase;

class QuestionImportParserTest extends TestCase
{
    private const SAMPLE = "De so\tCau hoi\tNoi dung\tDap an\tDiem\n1\t1\tCau hoi test so 1\tDap an test\t4\n";

    public function test_reads_txt_and_parses_rows(): void
    {
        $parser = app(QuestionImportParser::class);
        $file = UploadedFile::fake()->createWithContent('mau.txt', self::SAMPLE);

        $rows = $parser->parseImportRows($parser->readImportText($file));

        $this->assertCount(1, $rows);
        $this->assertStringContainsString('Cau hoi test so 1', json_encode($rows, JSON_UNESCAPED_UNICODE));
    }

    public function test_essay_exam_keeps_its_service_name(): void
    {
        $this->assertInstanceOf(QuestionImportParser::class, app(EssayExamImportService::class));
    }
}
```

- [ ] **Step 2: Chạy, xác nhận đỏ**

Run: `php artisan test --filter=QuestionImportParserTest`
Expected: FAIL `Class "App\Support\QuestionImport\QuestionImportParser" not found`.

- [ ] **Step 3: Chuyển file**

```bash
mkdir -p app/Support/QuestionImport
git mv modules/EssayExam/Services/EssayExamImportService.php app/Support/QuestionImport/QuestionImportParser.php
```

Trong `app/Support/QuestionImport/QuestionImportParser.php` sửa đúng hai dòng:
- `namespace Modules\EssayExam\Services;` → `namespace App\Support\QuestionImport;`
- `class EssayExamImportService` → `class QuestionImportParser`

Tạo lại `modules/EssayExam/Services/EssayExamImportService.php`:

```php
<?php

namespace Modules\EssayExam\Services;

use App\Support\QuestionImport\QuestionImportParser;

/** Giu ten cu cho EssayExamController; logic nam o core (TMS dung chung). */
class EssayExamImportService extends QuestionImportParser {}
```

- [ ] **Step 4: TMS dùng parser core**

`modules/Tms/Controllers/ExamController.php`:
- dòng 9: `use Modules\EssayExam\Controllers\EssayExamController;` → `use App\Support\QuestionImport\QuestionImportParser;`
- dòng 384: `return app(EssayExamController::class)->readImportText($uploaded);` → `return app(QuestionImportParser::class)->readImportText($uploaded);`
- dòng 437: `$parser = app(EssayExamController::class);` → `$parser = app(QuestionImportParser::class);`
- docblock dòng 424: `(EssayExamController::readImportText + parseImportRows)` → `(QuestionImportParser::readImportText + parseImportRows)`

`modules/Tms/Controllers/QuestionBankController.php`:
- dòng 8: `use Modules\EssayExam\Controllers\EssayExamController;` → `use App\Support\QuestionImport\QuestionImportParser;`
- dòng 167: `$parser = app(EssayExamController::class);` → `$parser = app(QuestionImportParser::class);`

- [ ] **Step 5: Chạy test**

Run: `php artisan test --filter="QuestionImportParserTest|EssayExamDrawWorkflowTest|CrossServiceImportsTest"`
Expected: 2 test đầu PASS; ratchet FAIL "Da go xong" với 2 dòng `modules/Tms/Controllers/{ExamController,QuestionBankController}.php|Modules\EssayExam\Controllers\EssayExamController`. Xoá 2 dòng đó khỏi baseline → PASS.

- [ ] **Step 6: Commit**

```bash
vendor/bin/pint --dirty
git add app/Support/QuestionImport/QuestionImportParser.php modules/EssayExam/Services/EssayExamImportService.php modules/Tms/Controllers/ExamController.php modules/Tms/Controllers/QuestionBankController.php tests/Unit/QuestionImportParserTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "fix(tms): nhap cau hoi goi method khong ton tai tren EssayExamController; parser ve core"
```

Sau deploy: vào một ngân hàng câu hỏi TMS, nhập file `.docx` mẫu → không còn 500 (ghi kết quả vào handover).

---

### Task 4: LmsStatisticsService về module Lms

File đang ở `modules/Dashboard` (service dashboard) nhưng chỉ đọc model LMS và chỉ được `InternalLmsController` (lms) + `DirectDashboardLms` gọi; Dashboard không tự dùng.

**Files:**
- Move: `modules/Dashboard/Services/LmsStatisticsService.php` → `modules/Lms/Services/LmsStatisticsService.php`
- Modify: `modules/Lms/Controllers/Api/InternalLmsController.php` (dòng `use Modules\Dashboard\Services\LmsStatisticsService;`)
- Modify: `packages/cdhc2-core/src/Direct/DirectDashboardLms.php` (dòng `use` tương ứng)
- Create: `tests/Unit/LmsStatisticsServiceLocationTest.php`

- [ ] **Step 1: Test đỏ**

```php
<?php

namespace Tests\Unit;

use Modules\Lms\Services\LmsStatisticsService;
use Tests\TestCase;

class LmsStatisticsServiceLocationTest extends TestCase
{
    public function test_service_lives_in_lms_module(): void
    {
        $this->assertInstanceOf(LmsStatisticsService::class, app(LmsStatisticsService::class));
        $this->assertFalse(class_exists('Modules\\Dashboard\\Services\\LmsStatisticsService'));
    }
}
```

Run: `php artisan test --filter=LmsStatisticsServiceLocationTest` → FAIL (class không tồn tại).

- [ ] **Step 2: Chuyển**

```bash
git mv modules/Dashboard/Services/LmsStatisticsService.php modules/Lms/Services/LmsStatisticsService.php
```

Sửa dòng 3 file đã chuyển: `namespace Modules\Dashboard\Services;` → `namespace Modules\Lms\Services;`.
Trong `InternalLmsController.php` và `DirectDashboardLms.php`: `use Modules\Dashboard\Services\LmsStatisticsService;` → `use Modules\Lms\Services\LmsStatisticsService;`.
Kiểm không còn chỗ nào: `grep -rn "Dashboard\\\\Services\\\\LmsStatisticsService" app modules packages resources` → rỗng.

- [ ] **Step 3: Chạy test + ratchet**

Run: `composer dump-autoload -q && php artisan test --filter="LmsStatisticsServiceLocationTest|CrossServiceImportsTest"`
Expected: test đầu PASS; ratchet có thể báo stale `modules/Lms/Controllers/Api/InternalLmsController.php|Modules\Dashboard\Services\LmsStatisticsService` → xoá dòng đó → PASS.

- [ ] **Step 4: Commit**

```bash
vendor/bin/pint --dirty
git add modules/Lms/Services/LmsStatisticsService.php modules/Dashboard/Services/LmsStatisticsService.php modules/Lms/Controllers/Api/InternalLmsController.php packages/cdhc2-core/src/Direct/DirectDashboardLms.php tests/Unit/LmsStatisticsServiceLocationTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(lms): LmsStatisticsService ve module Lms"
```

---

### Task 5: Relation chéo khai ở provider của module sở hữu

`Classroom::inventoryAssets()` (core → tms, dùng ở `InventoryWorkflowController:2254` qua `withCount`) và `ScheduleDetail::lmsAttendanceSession()` (core → lms). Pattern đã có: `LmsServiceProvider` khai `GradeBook::resolveRelationUsing('lmsCourse', …)`.

**Files:**
- Modify: `modules/Classroom/Models/Classroom.php:117-120` (xoá method `inventoryAssets`)
- Modify: `modules/ScheduleDetail/Models/ScheduleDetail.php:11,73-76` (xoá `use` + method `lmsAttendanceSession`)
- Modify: `modules/Inventory/Providers/InventoryServiceProvider.php` (`boot()`)
- Modify: `modules/Lms/Providers/LmsServiceProvider.php` (`boot()`)
- Create: `tests/Feature/CrossServiceRelationsTest.php`

- [ ] **Step 1: Test bảo vệ hành vi (xanh trước và sau refactor)**

```php
<?php

namespace Tests\Feature;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Modules\Classroom\Models\Classroom;
use Modules\Inventory\Models\InventoryAsset;
use Modules\Lms\Models\LmsAttendanceSession;
use Modules\ScheduleDetail\Models\ScheduleDetail;
use Tests\TestCase;

class CrossServiceRelationsTest extends TestCase
{
    public function test_classroom_inventory_assets_relation_still_resolves(): void
    {
        $relation = (new Classroom)->inventoryAssets();

        $this->assertInstanceOf(HasMany::class, $relation);
        $this->assertInstanceOf(InventoryAsset::class, $relation->getRelated());
        $this->assertSame('classroom_id', $relation->getForeignKeyName());
        $this->assertStringContainsString('inventory_assets_count', Classroom::query()->withCount('inventoryAssets')->toSql());
    }

    public function test_schedule_detail_attendance_session_relation_still_resolves(): void
    {
        $relation = (new ScheduleDetail)->lmsAttendanceSession();

        $this->assertInstanceOf(HasOne::class, $relation);
        $this->assertInstanceOf(LmsAttendanceSession::class, $relation->getRelated());
        $this->assertSame('schedule_detail_id', $relation->getForeignKeyName());
    }
}
```

Run: `php artisan test --filter=CrossServiceRelationsTest` → PASS (đây là lưới an toàn; "đỏ" của task này là ratchet ở Step 3).

- [ ] **Step 2: Chuyển relation**

Xoá khỏi `modules/Classroom/Models/Classroom.php`:

```php
    public function inventoryAssets()
    {
        return $this->hasMany(\Modules\Inventory\Models\InventoryAsset::class, 'classroom_id');
    }
```

Xoá khỏi `modules/ScheduleDetail/Models/ScheduleDetail.php` dòng `use Modules\Lms\Models\LmsAttendanceSession;` và:

```php
    public function lmsAttendanceSession()
    {
        return $this->hasOne(LmsAttendanceSession::class, 'schedule_detail_id');
    }
```

Thêm vào đầu `boot()` của `modules/Inventory/Providers/InventoryServiceProvider.php` (kèm `use Modules\Classroom\Models\Classroom;` và `use Modules\Inventory\Models\InventoryAsset;`):

```php
        // Relation cheo service khai o phia so huu du lieu (core khong biet Inventory).
        Classroom::resolveRelationUsing('inventoryAssets', fn (Classroom $room) => $room->hasMany(InventoryAsset::class, 'classroom_id'));
```

Thêm vào `boot()` của `modules/Lms/Providers/LmsServiceProvider.php`, ngay sau khối `GradeBook::resolveRelationUsing` (kèm `use Modules\Lms\Models\LmsAttendanceSession;` và `use Modules\ScheduleDetail\Models\ScheduleDetail;`):

```php
        ScheduleDetail::resolveRelationUsing('lmsAttendanceSession', fn (ScheduleDetail $detail) => $detail->hasOne(LmsAttendanceSession::class, 'schedule_detail_id'));
```

- [ ] **Step 3: Chạy lại**

Run: `php artisan test --filter="CrossServiceRelationsTest|CrossServiceImportsTest"`
Expected: relation test PASS; ratchet FAIL stale với 2 dòng `modules/Classroom/Models/Classroom.php|Modules\Inventory\Models\InventoryAsset` và `modules/ScheduleDetail/Models/ScheduleDetail.php|Modules\Lms\Models\LmsAttendanceSession` → xoá 2 dòng → PASS.

- [ ] **Step 4: Commit**

```bash
vendor/bin/pint --dirty
git add modules/Classroom/Models/Classroom.php modules/ScheduleDetail/Models/ScheduleDetail.php modules/Inventory/Providers/InventoryServiceProvider.php modules/Lms/Providers/LmsServiceProvider.php tests/Feature/CrossServiceRelationsTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(models): relation cheo service khai o provider cua module so huu"
```

---

### Task 6: Quyền vào Quản lý điểm qua Gate

`User::canAccessGrades()` (app/Models/User.php:182-195) gọi thẳng `GradeAccess::canEnter`. Đổi sang Gate `cdhc2.grades.enter` do `GradesServiceProvider` định nghĩa. Ở service không nạp Grades (lms/tms), Gate không tồn tại → dùng luật thô (chỉ để quyết định có hiện ô Điểm trên App Grid; quyền thật vẫn kiểm ở service grades). Tên Gate cố ý không theo `module.action` để không đụng permission Spatie.

**Files:**
- Modify: `app/Models/User.php:16,179-195`
- Modify: `modules/Grades/Providers/GradesServiceProvider.php` (`boot()`)
- Create: `tests/Feature/UserCanAccessGradesTest.php`

- [ ] **Step 1: Test đỏ**

```php
<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Gate;
use Tests\TestCase;

class UserCanAccessGradesTest extends TestCase
{
    use RefreshDatabase;

    public function test_grades_module_defines_the_gate(): void
    {
        $this->assertTrue(Gate::has('cdhc2.grades.enter'));
    }

    public function test_user_follows_the_gate(): void
    {
        $user = User::factory()->create();

        Gate::define('cdhc2.grades.enter', fn () => true);
        $this->assertTrue($user->canAccessGrades());

        Gate::define('cdhc2.grades.enter', fn () => false);
        $this->assertFalse($user->canAccessGrades());
    }
}
```

Run: `php artisan test --filter=UserCanAccessGradesTest` → FAIL ở `test_grades_module_defines_the_gate` và ở assert thứ hai của `test_user_follows_the_gate`.

- [ ] **Step 2: Sửa User**

Trong `app/Models/User.php`: xoá `use Modules\Grades\Services\GradeAccess;` (dòng 16), thêm `use App\Support\ApplicationGate;`, `use App\Support\ApplicationRegistry;`, `use Illuminate\Support\Facades\Gate;` (nếu chưa có). Thay method:

```php
    /**
     * Được vào portal Quản lý điểm (GV / Manager / Super-admin / permission).
     *
     * Luật đầy đủ do module Grades khai qua Gate `cdhc2.grades.enter`. Ở service
     * không nạp Grades (lms/tms) chỉ dùng luật thô để hiện lối vào; service grades
     * vẫn kiểm lại bằng luật đầy đủ.
     */
    public function canAccessGrades(): bool
    {
        if ($this->isSuperAdmin()) {
            return true;
        }
        if (Gate::has('cdhc2.grades.enter')) {
            return Gate::forUser($this)->allows('cdhc2.grades.enter');
        }

        return $this->isManager()
            || $this->isInstructor()
            || ApplicationGate::allows($this, 'grades', ApplicationRegistry::ACTION_VIEW)
            || ApplicationGate::allows($this, 'grades.books', ApplicationRegistry::ACTION_VIEW);
    }
```

(`isSuperAdmin()` đã là `hasRole('super-admin')` nên bỏ điều kiện trùng.)

- [ ] **Step 3: Định nghĩa Gate ở Grades**

Thêm vào đầu `boot()` của `modules/Grades/Providers/GradesServiceProvider.php` (kèm `use App\Models\User;`, `use Illuminate\Support\Facades\Gate;`, `use Modules\Grades\Services\GradeAccess;`):

```php
        Gate::define('cdhc2.grades.enter', fn (User $user) => GradeAccess::canEnter($user));
```

- [ ] **Step 4: Chạy**

Run: `php artisan test --filter="UserCanAccessGradesTest|CrossServiceImportsTest"`
Expected: PASS test đầu; ratchet stale `app/Models/User.php|Modules\Grades\Services\GradeAccess` → xoá → PASS. Chạy thêm `php artisan test --filter=Grade` → không có test đỏ mới.

- [ ] **Step 5: Commit**

```bash
vendor/bin/pint --dirty
git add app/Models/User.php modules/Grades/Providers/GradesServiceProvider.php tests/Feature/UserCanAccessGradesTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(auth): quyen vao Quan ly diem qua Gate do module Grades khai"
```

---

### Task 7: Thùng rác — module tự đăng ký model

`app/Support/TrashRegistry.php` khai tĩnh `lms-courses` (dòng 178-191) và `essay-exams`, `essay-exam-questions`, `essay-exam-draws` (dòng 301-345). Thêm `extend()`; module Lms/EssayExam tự đăng ký. `AppServiceProvider` gắn observer sau khi **mọi** provider boot xong (hiện nó chạy trước provider module).

**Files:**
- Modify: `app/Support/TrashRegistry.php`
- Modify: `app/Providers/AppServiceProvider.php:83-87`
- Modify: `modules/Lms/Providers/LmsServiceProvider.php`, `modules/EssayExam/Providers/EssayExamServiceProvider.php`
- Create: `tests/Feature/TrashRegistryExtendTest.php`

**Interfaces:**
- Produces: `TrashRegistry::extend(string $key, array $definition): void` — `$definition` cùng shape với phần tử của `definitions()`.

- [ ] **Step 1: Test đỏ**

```php
<?php

namespace Tests\Feature;

use App\Support\TrashRegistry;
use Modules\EssayExam\Models\EssayExam;
use Modules\Lms\Models\LmsCourse;
use Tests\TestCase;

class TrashRegistryExtendTest extends TestCase
{
    public function test_modules_register_their_own_trash_definitions(): void
    {
        $this->assertSame(LmsCourse::class, TrashRegistry::find('lms-courses')['model'] ?? null);
        $this->assertSame(EssayExam::class, TrashRegistry::find('essay-exams')['model'] ?? null);
        $this->assertNotNull(TrashRegistry::find('essay-exam-questions'));
        $this->assertNotNull(TrashRegistry::find('essay-exam-draws'));
    }

    public function test_extend_adds_a_definition(): void
    {
        $extensions = new \ReflectionProperty(TrashRegistry::class, 'extensions');
        $before = $extensions->getValue();

        try {
            TrashRegistry::extend('test-lms-courses-copy', TrashRegistry::find('lms-courses'));

            $this->assertArrayHasKey('test-lms-courses-copy', TrashRegistry::options());
            $this->assertContains(LmsCourse::class, TrashRegistry::modelClasses());
        } finally {
            // Trạng thái tĩnh sống suốt tiến trình PHPUnit -> trả lại cho test khác.
            $extensions->setValue(null, $before);
        }
    }
}
```

Run: `php artisan test --filter=TrashRegistryExtendTest` → test đầu PASS (định nghĩa tĩnh), test hai FAIL `Call to undefined method … extend()`.

- [ ] **Step 2: Thêm extend() và bỏ định nghĩa của service**

Trong `app/Support/TrashRegistry.php`:
- Thêm thuộc tính và method ngay sau `class TrashRegistry {`:

```php
    /** @var array<string, array<string, mixed>> Định nghĩa do module đăng ký lúc boot. */
    private static array $extensions = [];

    /** Module của service (Lms, EssayExam…) tự đăng ký model vào thùng rác. */
    public static function extend(string $key, array $definition): void
    {
        self::$extensions[$key] = $definition;
    }
```

- Đổi `return [` đầu tiên trong `definitions()` thành `return array_merge([`, và `];` cuối của mảng đó thành `], self::$extensions);`.
- Cắt nguyên khối `'lms-courses' => [ … ],` (dòng 178-191) và ba khối `'essay-exams'`, `'essay-exam-questions'`, `'essay-exam-draws'` (dòng 301-345) ra khỏi mảng; xoá `use Modules\Lms\Models\LmsCourse;`.

Trong `modules/Lms/Providers/LmsServiceProvider.php::boot()` thêm (kèm `use App\Support\TrashRegistry;`, `use Illuminate\Database\Eloquent\Model;`):

```php
        TrashRegistry::extend('lms-courses', [
            'model' => LmsCourse::class,
            'label' => 'Khóa học LMS',
            'icon' => 'bi-collection-play',
            'title' => fn (Model $m) => (string) ($m->title ?? 'Khóa học #'.$m->getKey()),
            'identifier' => fn (Model $m) => $m->code ?? null,
            'summary' => fn (Model $m) => array_filter([
                'Mã' => $m->code,
                'Tên' => $m->title,
                'Môn ID' => $m->subject_id,
                'Lớp ID' => $m->class_id,
                'Trạng thái' => $m->status,
            ], fn ($v) => $v !== null && $v !== ''),
        ]);
```

Trong `modules/EssayExam/Providers/EssayExamServiceProvider.php::boot()` thêm (kèm `use App\Support\TrashRegistry;`, `use Illuminate\Database\Eloquent\Model;`, `use Illuminate\Support\Str;`, `use Modules\EssayExam\Models\EssayExam;`, `use Modules\EssayExam\Models\EssayExamDraw;`, `use Modules\EssayExam\Models\EssayExamQuestion;`):

```php
        TrashRegistry::extend('essay-exams', [
            'model' => EssayExam::class,
            'label' => 'Bộ đề tự luận',
            'icon' => 'bi-journal-richtext',
            'title' => fn (Model $m) => (string) ($m->title ?: 'Bộ đề #'.$m->getKey()),
            'identifier' => fn (Model $m) => $m->code ?? null,
            'summary' => fn (Model $m) => array_filter([
                'Mã bộ đề' => $m->code,
                'Tên' => $m->title,
                'Môn ID' => $m->subject_id,
                'Lớp ID' => $m->class_id,
                'Trạng thái' => $m->status,
                'Năm học' => $m->academic_year,
                'Học kỳ' => $m->semester,
            ], fn ($v) => $v !== null && $v !== ''),
        ]);
        TrashRegistry::extend('essay-exam-questions', [
            'model' => EssayExamQuestion::class,
            'label' => 'Câu hỏi đề tự luận',
            'icon' => 'bi-question-circle',
            'title' => fn (Model $m) => 'Đề #'.$m->essay_exam_id.'-D'.str_pad((string) $m->paper_number, 2, '0', STR_PAD_LEFT).' · Câu '.$m->question_number,
            'identifier' => fn (Model $m) => (string) $m->getKey(),
            'summary' => fn (Model $m) => array_filter([
                'Bộ đề ID' => $m->essay_exam_id,
                'Đề số' => $m->paper_number,
                'Câu số' => $m->question_number,
                'Điểm' => $m->points,
                'Nội dung' => Str::limit((string) $m->getRawOriginal('content'), 120),
            ], fn ($v) => $v !== null && $v !== ''),
        ]);
        TrashRegistry::extend('essay-exam-draws', [
            'model' => EssayExamDraw::class,
            'label' => 'Phiếu bốc đề',
            'icon' => 'bi-shuffle',
            'title' => fn (Model $m) => 'Phiếu '.($m->draw_code ?: '#'.$m->getKey()),
            'identifier' => fn (Model $m) => $m->draw_code ?? null,
            'summary' => fn (Model $m) => array_filter([
                'Mã bốc đề' => $m->draw_code,
                'Mã QR' => $m->qr_code,
                'Bộ đề ID' => $m->essay_exam_id,
                'Đề số' => $m->paper_number,
                'Lớp thi' => $m->class_name,
                'Ngày bốc' => optional($m->drawn_at)->format('d/m/Y H:i'),
            ], fn ($v) => $v !== null && $v !== ''),
        ]);
```

- [ ] **Step 3: Gắn observer sau khi mọi provider boot**

Trong `app/Providers/AppServiceProvider.php`, thay vòng:

```php
        foreach (TrashRegistry::modelClasses() as $modelClass) {
            if (class_exists($modelClass) && TrashRegistry::usesSoftDeletes($modelClass)) {
                $modelClass::observe(TrashModelObserver::class);
            }
        }
```

bằng:

```php
        // Chạy sau khi MỌI provider boot: module (Lms, EssayExam…) đăng ký model
        // qua TrashRegistry::extend() trong boot() của chúng, sau AppServiceProvider.
        $this->app->booted(function () {
            foreach (TrashRegistry::modelClasses() as $modelClass) {
                if (class_exists($modelClass) && TrashRegistry::usesSoftDeletes($modelClass)) {
                    $modelClass::observe(TrashModelObserver::class);
                }
            }
        });
```

- [ ] **Step 4: Chạy**

Run: `php artisan test --filter="TrashRegistryExtendTest|Trash|CrossServiceImportsTest"`
Expected: Trash test PASS; ratchet stale các dòng `app/Support/TrashRegistry.php|Modules\Lms\Models\LmsCourse` và `app/Support/TrashRegistry.php|Modules\EssayExam\Models\…` → xoá → PASS.

- [ ] **Step 5: Commit**

```bash
vendor/bin/pint --dirty
git add app/Support/TrashRegistry.php app/Providers/AppServiceProvider.php modules/Lms/Providers/LmsServiceProvider.php modules/EssayExam/Providers/EssayExamServiceProvider.php tests/Feature/TrashRegistryExtendTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(trash): module tu dang ky model vao thung rac qua TrashRegistry::extend"
```

---

### Task 8: Contract tạo khoá học LMS (core → lms)

`ClassController` (dòng 141, 239), `SubjectController` (224, 452-455, 473, 506, 523, 543, 757, 879, 1064), `TeachingAssignmentController` (109, 154, 180) gọi thẳng `LmsCourseProvisioningService`. Thêm contract theo pattern `TmsCalendarContract`. Core (`CDHC2_SERVICE=core`) sẽ gọi HTTP sang lms; monolith và lms gọi in-process.

Hai quyết định (ghi vào handover):
1. **Http chạy sau commit** (`DB::afterCommit`): `ClassController::store` tạo lớp và provisioning trong cùng `DB::transaction`; nếu gọi HTTP ngay thì lms (tiến trình khác) chưa thấy lớp chưa commit. Direct giữ nguyên trong transaction như cũ.
2. **Lỗi HTTP không làm hỏng thao tác của người dùng**: `report()` rồi bỏ qua; lịch `lms:provision-courses` (01:10 hằng ngày, `bootstrap/app.php:102`) tự bù. Kết quả trả về (`array` summary) hiện không nơi gọi nào dùng → contract trả `void`.

**Files:**
- Create: `packages/cdhc2-core/src/Contracts/LmsProvisioningContract.php`
- Create: `packages/cdhc2-core/src/Direct/DirectLmsProvisioning.php`
- Create: `packages/cdhc2-core/src/Http/HttpLmsProvisioning.php`
- Modify: `packages/cdhc2-core/src/CoreServiceProvider.php` (hằng `OWNERSHIP` + `use`)
- Modify: `modules/Lms/Routes/api.php`, `modules/Lms/Controllers/Api/InternalLmsController.php`
- Modify: 3 controller ở trên
- Create: `tests/Feature/LmsProvisioningContractTest.php`

**Interfaces:**
- Produces:
```php
interface LmsProvisioningContract
{
    public function provisionClass(int $classId, ?int $actorId = null): void;
    public function provisionSpecialization(int $specializationId, ?int $actorId = null): void;
    /** @param list<int> $subjectIds */
    public function syncTeachingAssignmentsForSubjects(array $subjectIds): void;
}
```
- Endpoint nội bộ (middleware `internal.auth`): `POST /api/internal/lms/provisioning/class` `{class_id, actor_id?}`, `POST /api/internal/lms/provisioning/specialization` `{specialization_id, actor_id?}`, `POST /api/internal/lms/provisioning/teaching-assignments` `{subject_ids: int[]}` → `{"ok": true}`.

- [ ] **Step 1: Test đỏ**

```php
<?php

namespace Tests\Feature;

use Cdhc2\Core\Contracts\LmsProvisioningContract;
use Cdhc2\Core\Direct\DirectLmsProvisioning;
use Cdhc2\Core\Http\HttpLmsProvisioning;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Modules\Lms\Services\LmsCourseProvisioningService;
use Tests\TestCase;

class LmsProvisioningContractTest extends TestCase
{
    // Cần bảng `classes` cho provisionClass. afterCommit bỏ qua transaction gốc của
    // RefreshDatabase nên beginTransaction/commit trong test vẫn mô phỏng đúng.
    use RefreshDatabase;

    private const SHARED = 'shared-internal-secret-for-tests';

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'jwt.secret' => null,
            'jwt.enforce' => false,
            'services.internal_api_secret' => self::SHARED,
            'services.internal_urls.lms' => 'http://lms.test',
        ]);
    }

    public function test_binding_follows_service(): void
    {
        foreach (['monolith' => DirectLmsProvisioning::class, 'lms' => DirectLmsProvisioning::class, 'core' => HttpLmsProvisioning::class, 'tms' => HttpLmsProvisioning::class] as $service => $expected) {
            config(['app.cdhc2_service' => $service]);
            $this->app->forgetInstance(LmsProvisioningContract::class);
            $this->assertInstanceOf($expected, app(LmsProvisioningContract::class), $service);
        }
    }

    public function test_direct_delegates_to_lms_service(): void
    {
        $this->mock(LmsCourseProvisioningService::class, function ($mock) {
            $mock->shouldReceive('provisionForSpecialization')->once()->with(9, null);
            $mock->shouldReceive('syncTeachingAssignmentsForSubjects')->once()->with([3, 4]);
            $mock->shouldNotReceive('provisionFromClassCurriculum');
        });

        $direct = app(DirectLmsProvisioning::class);
        $direct->provisionSpecialization(9);
        $direct->syncTeachingAssignmentsForSubjects([3, 4]);
        $direct->provisionClass(987654321); // lop khong ton tai -> bo qua
    }

    public function test_http_waits_for_commit_then_posts(): void
    {
        Http::fake(['lms.test/*' => Http::response(['ok' => true])]);

        DB::beginTransaction();
        app(HttpLmsProvisioning::class)->provisionSpecialization(9, 5);
        Http::assertNothingSent();
        DB::commit();

        Http::assertSent(fn (Request $r) => $r->url() === 'http://lms.test/api/internal/lms/provisioning/specialization'
            && $r['specialization_id'] === 9 && $r['actor_id'] === 5);
    }

    public function test_http_failure_is_reported_not_thrown(): void
    {
        Http::fake(['lms.test/*' => Http::response(['message' => 'down'], 503)]);

        app(HttpLmsProvisioning::class)->syncTeachingAssignmentsForSubjects([1]);

        Http::assertSentCount(1);
    }

    public function test_internal_endpoint_calls_the_contract(): void
    {
        $this->mock(LmsProvisioningContract::class, function ($mock) {
            $mock->shouldReceive('provisionSpecialization')->once()->with(9, 5);
        });

        $this->withHeaders(['X-Internal-Token' => self::SHARED])
            ->postJson('/api/internal/lms/provisioning/specialization', ['specialization_id' => 9, 'actor_id' => 5])
            ->assertOk()
            ->assertJson(['ok' => true]);
    }
}
```

Run: `php artisan test --filter=LmsProvisioningContractTest` → FAIL `Interface "Cdhc2\Core\Contracts\LmsProvisioningContract" not found`.

- [ ] **Step 2: Contract + 2 implementation**

`packages/cdhc2-core/src/Contracts/LmsProvisioningContract.php`:

```php
<?php

namespace Cdhc2\Core\Contracts;

/**
 * Core đổi lớp / môn / phân công giảng dạy -> LMS tạo/cập nhật khoá học tương ứng.
 * Fire-and-forget: lịch `lms:provision-courses` hằng ngày bù nếu một lần gọi hỏng.
 */
interface LmsProvisioningContract
{
    public function provisionClass(int $classId, ?int $actorId = null): void;

    public function provisionSpecialization(int $specializationId, ?int $actorId = null): void;

    /** @param list<int> $subjectIds */
    public function syncTeachingAssignmentsForSubjects(array $subjectIds): void;
}
```

`packages/cdhc2-core/src/Direct/DirectLmsProvisioning.php`:

```php
<?php

namespace Cdhc2\Core\Direct;

use App\Models\User;
use Cdhc2\Core\Contracts\LmsProvisioningContract;
use Modules\Class\Models\ClassModel;
use Modules\Lms\Services\LmsCourseProvisioningService;

class DirectLmsProvisioning implements LmsProvisioningContract
{
    public function __construct(private LmsCourseProvisioningService $service) {}

    public function provisionClass(int $classId, ?int $actorId = null): void
    {
        $class = ClassModel::find($classId);
        if ($class === null) {
            return;
        }

        $this->service->provisionFromClassCurriculum($class, $this->actor($actorId));
    }

    public function provisionSpecialization(int $specializationId, ?int $actorId = null): void
    {
        $this->service->provisionForSpecialization($specializationId, $this->actor($actorId));
    }

    public function syncTeachingAssignmentsForSubjects(array $subjectIds): void
    {
        $this->service->syncTeachingAssignmentsForSubjects($subjectIds);
    }

    private function actor(?int $actorId): ?User
    {
        return $actorId ? User::find($actorId) : null;
    }
}
```

`packages/cdhc2-core/src/Http/HttpLmsProvisioning.php`:

```php
<?php

namespace Cdhc2\Core\Http;

use Cdhc2\Core\Contracts\LmsProvisioningContract;
use Illuminate\Support\Facades\DB;

class HttpLmsProvisioning implements LmsProvisioningContract
{
    /** Provisioning theo chuyên ngành duyệt nhiều lớp -> lâu hơn timeout mặc định 10s. */
    private const TIMEOUT_SECONDS = 120;

    public function provisionClass(int $classId, ?int $actorId = null): void
    {
        $this->postAfterCommit('/api/internal/lms/provisioning/class', ['class_id' => $classId, 'actor_id' => $actorId]);
    }

    public function provisionSpecialization(int $specializationId, ?int $actorId = null): void
    {
        $this->postAfterCommit('/api/internal/lms/provisioning/specialization', ['specialization_id' => $specializationId, 'actor_id' => $actorId]);
    }

    public function syncTeachingAssignmentsForSubjects(array $subjectIds): void
    {
        $this->postAfterCommit('/api/internal/lms/provisioning/teaching-assignments', ['subject_ids' => array_values($subjectIds)]);
    }

    /**
     * Gọi SAU khi transaction hiện tại commit: lms là tiến trình khác, không thấy
     * dòng chưa commit (vd. lớp vừa tạo trong ClassController::store). Không có
     * transaction thì chạy ngay. Lỗi chỉ report — thao tác của người dùng đã lưu xong.
     */
    private function postAfterCommit(string $path, array $payload): void
    {
        DB::afterCommit(function () use ($path, $payload) {
            try {
                InternalClient::for('lms')->timeout(self::TIMEOUT_SECONDS)->post($path, $payload)->throw();
            } catch (\Throwable $e) {
                report($e);
            }
        });
    }
}
```

Trong `packages/cdhc2-core/src/CoreServiceProvider.php`: thêm 3 `use` (`Contracts\LmsProvisioningContract`, `Direct\DirectLmsProvisioning`, `Http\HttpLmsProvisioning`) và một dòng vào `OWNERSHIP`:

```php
        LmsProvisioningContract::class => ['lms', DirectLmsProvisioning::class, HttpLmsProvisioning::class],
```

- [ ] **Step 3: Endpoint nội bộ ở lms**

`modules/Lms/Routes/api.php`, trong group hiện có, thêm:

```php
        Route::post('provisioning/class', [InternalLmsController::class, 'provisionClass']);
        Route::post('provisioning/specialization', [InternalLmsController::class, 'provisionSpecialization']);
        Route::post('provisioning/teaching-assignments', [InternalLmsController::class, 'syncTeachingAssignments']);
```

`modules/Lms/Controllers/Api/InternalLmsController.php` (kèm `use Cdhc2\Core\Contracts\LmsProvisioningContract;`), thêm:

```php
    public function provisionClass(Request $request, LmsProvisioningContract $provisioning): JsonResponse
    {
        $data = $request->validate(['class_id' => 'required|integer', 'actor_id' => 'nullable|integer']);
        $provisioning->provisionClass((int) $data['class_id'], isset($data['actor_id']) ? (int) $data['actor_id'] : null);

        return response()->json(['ok' => true]);
    }

    public function provisionSpecialization(Request $request, LmsProvisioningContract $provisioning): JsonResponse
    {
        $data = $request->validate(['specialization_id' => 'required|integer', 'actor_id' => 'nullable|integer']);
        $provisioning->provisionSpecialization((int) $data['specialization_id'], isset($data['actor_id']) ? (int) $data['actor_id'] : null);

        return response()->json(['ok' => true]);
    }

    public function syncTeachingAssignments(Request $request, LmsProvisioningContract $provisioning): JsonResponse
    {
        $data = $request->validate(['subject_ids' => 'present|array', 'subject_ids.*' => 'integer']);
        $provisioning->syncTeachingAssignmentsForSubjects(array_map('intval', $data['subject_ids']));

        return response()->json(['ok' => true]);
    }
```

Run: `php artisan test --filter=LmsProvisioningContractTest` → 5 PASS.

- [ ] **Step 4: Đổi các nơi gọi trong core**

Ở cả 3 controller: xoá `use Modules\Lms\Services\LmsCourseProvisioningService;`, thêm `use Cdhc2\Core\Contracts\LmsProvisioningContract;`. Thay từng lời gọi:

| File:dòng | Cũ | Mới |
|---|---|---|
| `ClassController.php:141` | `app(LmsCourseProvisioningService::class)->provisionFromClassCurriculum($class, $request->user());` | `app(LmsProvisioningContract::class)->provisionClass($class->id, $request->user()?->id);` |
| `ClassController.php:239` | `app(LmsCourseProvisioningService::class)->provisionFromClassCurriculum($class->fresh(), $request->user());` | `app(LmsProvisioningContract::class)->provisionClass($class->id, $request->user()?->id);` |
| `SubjectController.php:224-227` | `app(LmsCourseProvisioningService::class)->provisionForSpecialization((int) $subject->specialization_id, $request->user());` | `app(LmsProvisioningContract::class)->provisionSpecialization((int) $subject->specialization_id, $request->user()?->id);` |
| `SubjectController.php:452-455` | `$provisioning = app(LmsCourseProvisioningService::class);` + 2 lời gọi `->provisionForSpecialization(…, $request->user())` | `$provisioning = app(LmsProvisioningContract::class);` + `->provisionSpecialization(…, $request->user()?->id)` |
| `SubjectController.php:473, 523-526, 543-546` | `…provisionForSpecialization(…, request()->user())` | `app(LmsProvisioningContract::class)->provisionSpecialization(…, request()->user()?->id)` |
| `SubjectController.php:506, 757-760, 879-882` | `…provisionForSpecialization(…, $request->user())` | `app(LmsProvisioningContract::class)->provisionSpecialization(…, $request->user()?->id)` |
| `SubjectController.php:1064` | `app(LmsCourseProvisioningService::class)->syncTeachingAssignmentsForSubjects([$subject->id]);` | `app(LmsProvisioningContract::class)->syncTeachingAssignmentsForSubjects([$subject->id]);` |
| `TeachingAssignmentController.php:109, 154, 180` | `app(LmsCourseProvisioningService::class)->syncTeachingAssignmentsForSubjects(…)` | `app(LmsProvisioningContract::class)->syncTeachingAssignmentsForSubjects(…)` (tham số giữ nguyên) |

Kiểm: `grep -rn "LmsCourseProvisioningService" modules/Class modules/Subject modules/TeachingAssignment` → rỗng.

- [ ] **Step 5: Chạy test liên quan**

Run: `php artisan test --filter="LmsProvisioningContractTest|LmsCourse|Subject|TeachingAssignment|ClassController|CrossServiceImportsTest"`
Expected: tất cả PASS trừ ratchet báo stale các dòng `modules/{Class,Subject,TeachingAssignment}/Controllers/…|Modules\Lms\Services\LmsCourseProvisioningService` → xoá → PASS. (Test chạy ở monolith → Direct, hành vi cũ giữ nguyên, kể cả `LmsCourseEnrollsEntireClassTest`.)

- [ ] **Step 6: Commit**

```bash
vendor/bin/pint --dirty
git add packages/cdhc2-core/src/Contracts/LmsProvisioningContract.php packages/cdhc2-core/src/Direct/DirectLmsProvisioning.php packages/cdhc2-core/src/Http/HttpLmsProvisioning.php packages/cdhc2-core/src/CoreServiceProvider.php modules/Lms/Routes/api.php modules/Lms/Controllers/Api/InternalLmsController.php modules/Class/Controllers/ClassController.php modules/Subject/Controllers/SubjectController.php modules/TeachingAssignment/Controllers/TeachingAssignmentController.php tests/Feature/LmsProvisioningContractTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(lms): core tao khoa hoc LMS qua LmsProvisioningContract (Direct/Http)"
```

Sau deploy (chỉ đọc): chạy workflow `service-logs` cho `lms`, tìm `provisioning/` → có request 200 sau khi sửa một môn học trên prod; không có `Duplicate entry`/500.

---

### Task 9: Lệnh artisan về module sở hữu

10 lệnh trong `app/Console/Commands` dùng class của service: `BackfillGradeColumns` (grades), `BackfillLmsLessonPublish`, `MigrateLmsSubmissionFiles`, `ProvisionLmsCourses`, `PruneLmsSubmissions`, `SyncLmsCourseMembers` (lms), `TmsCheckRecertifications`, `TmsMarkOverdue`, `TmsNotifyDeadlines`, `TmsNotifyDocumentDeadlines` (tms). Giữ `MigrateStorageToS3` ở core (lệnh một lần, chạm 3 service; để lại baseline, ghi "có chủ đích"). Tên lệnh không đổi nên lịch trong `bootstrap/app.php` và workflow `lms-prune-dryrun` vẫn chạy (scheduler chạy `CDHC2_SERVICE=core` → nạp mọi module; pod lms nạp LmsServiceProvider).

**Files:**
- Move: 6 file → `modules/Lms/Console/Commands/`, 4 file → `modules/Tms/Console/Commands/`, 1 file → `modules/Grades/Console/Commands/`
- Modify: `modules/{Lms,Tms,Grades}/Providers/*ServiceProvider.php`
- Create: `tests/Feature/ModuleCommandsRegisteredTest.php`

- [ ] **Step 1: Test bảo vệ (xanh trước và sau)**

```php
<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Artisan;
use Tests\TestCase;

class ModuleCommandsRegisteredTest extends TestCase
{
    public function test_module_commands_keep_their_names(): void
    {
        $all = Artisan::all();

        foreach ([
            'grades:backfill-columns' => 'Modules\\Grades\\Console\\Commands\\BackfillGradeColumns',
            'lms:backfill-lesson-publish' => 'Modules\\Lms\\Console\\Commands\\BackfillLmsLessonPublish',
            'lms:migrate-submissions-private' => 'Modules\\Lms\\Console\\Commands\\MigrateLmsSubmissionFiles',
            'lms:provision-courses' => 'Modules\\Lms\\Console\\Commands\\ProvisionLmsCourses',
            'lms:prune-submissions' => 'Modules\\Lms\\Console\\Commands\\PruneLmsSubmissions',
            'lms:sync-members' => 'Modules\\Lms\\Console\\Commands\\SyncLmsCourseMembers',
            'tms:check-recertifications' => 'Modules\\Tms\\Console\\Commands\\TmsCheckRecertifications',
            'tms:mark-overdue' => 'Modules\\Tms\\Console\\Commands\\TmsMarkOverdue',
            'tms:notify-deadlines' => 'Modules\\Tms\\Console\\Commands\\TmsNotifyDeadlines',
            'tms:notify-document-deadlines' => 'Modules\\Tms\\Console\\Commands\\TmsNotifyDocumentDeadlines',
        ] as $name => $class) {
            $this->assertArrayHasKey($name, $all, $name);
            $this->assertInstanceOf($class, $all[$name], $name);
        }
    }
}
```

Run: `php artisan test --filter=ModuleCommandsRegisteredTest` → FAIL ở `assertInstanceOf` (class còn ở `App\Console\Commands`).

- [ ] **Step 2: Chuyển file và đổi namespace**

```bash
mkdir -p modules/Lms/Console/Commands modules/Tms/Console/Commands modules/Grades/Console/Commands
for c in BackfillLmsLessonPublish MigrateLmsSubmissionFiles ProvisionLmsCourses PruneLmsSubmissions SyncLmsCourseMembers; do git mv app/Console/Commands/$c.php modules/Lms/Console/Commands/$c.php; sed -i 's/^namespace App\\Console\\Commands;/namespace Modules\\Lms\\Console\\Commands;/' modules/Lms/Console/Commands/$c.php; done
for c in TmsCheckRecertifications TmsMarkOverdue TmsNotifyDeadlines TmsNotifyDocumentDeadlines; do git mv app/Console/Commands/$c.php modules/Tms/Console/Commands/$c.php; sed -i 's/^namespace App\\Console\\Commands;/namespace Modules\\Tms\\Console\\Commands;/' modules/Tms/Console/Commands/$c.php; done
git mv app/Console/Commands/BackfillGradeColumns.php modules/Grades/Console/Commands/BackfillGradeColumns.php
sed -i 's/^namespace App\\Console\\Commands;/namespace Modules\\Grades\\Console\\Commands;/' modules/Grades/Console/Commands/BackfillGradeColumns.php
grep -n "^namespace" modules/*/Console/Commands/*.php
```

Expected: 10 dòng namespace đúng module. Nếu file nào `extends` / dùng class khác cùng namespace cũ `App\Console\Commands\…` (không `use`), thêm `use App\Console\Commands\<Tên>;` — kiểm bằng `php -l` và Step 4.

- [ ] **Step 3: Đăng ký trong provider**

`modules/Lms/Providers/LmsServiceProvider.php::boot()`:

```php
        if ($this->app->runningInConsole()) {
            $this->commands([
                \Modules\Lms\Console\Commands\BackfillLmsLessonPublish::class,
                \Modules\Lms\Console\Commands\MigrateLmsSubmissionFiles::class,
                \Modules\Lms\Console\Commands\ProvisionLmsCourses::class,
                \Modules\Lms\Console\Commands\PruneLmsSubmissions::class,
                \Modules\Lms\Console\Commands\SyncLmsCourseMembers::class,
            ]);
        }
```

`modules/Tms/Providers/TmsServiceProvider.php::boot()`:

```php
        if ($this->app->runningInConsole()) {
            $this->commands([
                \Modules\Tms\Console\Commands\TmsCheckRecertifications::class,
                \Modules\Tms\Console\Commands\TmsMarkOverdue::class,
                \Modules\Tms\Console\Commands\TmsNotifyDeadlines::class,
                \Modules\Tms\Console\Commands\TmsNotifyDocumentDeadlines::class,
            ]);
        }
```

`modules/Grades/Providers/GradesServiceProvider.php::boot()`:

```php
        if ($this->app->runningInConsole()) {
            $this->commands([\Modules\Grades\Console\Commands\BackfillGradeColumns::class]);
        }
```

- [ ] **Step 4: Chạy**

```bash
composer dump-autoload -q
php artisan test --filter="ModuleCommandsRegisteredTest|CrossServiceImportsTest"
CDHC2_SERVICE=lms php artisan list lms | grep -c "lms:"
CDHC2_SERVICE=core php artisan schedule:list | grep -E "lms:|tms:"
```

Expected: test đầu PASS; ratchet stale các dòng `app/Console/Commands/{10 file}.php|…` → xoá → PASS. `lms` liệt kê ≥ 5 lệnh `lms:`. `schedule:list` vẫn thấy `lms:provision-courses`, `lms:sync-members`, `lms:prune-submissions` và các `tms:*`.

- [ ] **Step 5: Commit**

```bash
vendor/bin/pint --dirty
git add app/Console/Commands modules/Lms/Console modules/Tms/Console modules/Grades/Console modules/Lms/Providers/LmsServiceProvider.php modules/Tms/Providers/TmsServiceProvider.php modules/Grades/Providers/GradesServiceProvider.php tests/Feature/ModuleCommandsRegisteredTest.php tests/Unit/Architecture/cross-service-baseline.txt
git commit -m "refactor(console): lenh artisan ve module so huu"
```

---

### Task 10: Chốt bước 1 — đo lại, PR, deploy, handover

**Files:**
- Modify: `docs/HANDOVER_2026-09-22.md` (mục 4, 6, 7)
- Modify: `docs/superpowers/plans/2026-09-22-step1-code-boundaries.md` (điền mục "Còn lại có chủ đích")

- [ ] **Step 1: Toàn bộ test**

Run: `php artisan test`
Expected: xanh toàn bộ (so với `main` trước khi bắt đầu: không có test đỏ mới).

- [ ] **Step 2: Đo baseline còn lại**

Run: `wc -l tests/Unit/Architecture/cross-service-baseline.txt` và `cut -d'|' -f1 tests/Unit/Architecture/cross-service-baseline.txt | cut -d/ -f1-2 | sort | uniq -c | sort -rn`
Ghi số dòng trước (Task 1 Step 3) / sau vào handover mục 7. Mỗi nhóm còn lại xếp vào một trong hai loại ở mục dưới.

- [ ] **Step 3: Boot mọi service**

```bash
for s in monolith core lms tms grades; do CDHC2_SERVICE=$s php artisan about --only=environment >/dev/null && echo "$s OK" || echo "$s FAIL"; done
```
Expected: 5 `OK`.

- [ ] **Step 4: PR + deploy (chờ chủ dự án cho phép merge)**

```bash
git push -u origin step1-code-boundaries
gh pr create -R tho076/lich-hoc-cdhc2 --base main --title "refactor: ranh gioi code giua cac service (buoc 1)" --body-file docs/superpowers/plans/2026-09-22-step1-code-boundaries.md
```
Sau khi merge + deploy xanh: chạy workflow `cluster-diagnostics` (pod Running), `service-logs` cho `core` và `lms` (không có 500 mới). Thử: sửa một môn học (provisioning qua HTTP), nhập `.docx` vào ngân hàng câu hỏi TMS (Task 3), mở `/trash` thấy mục "Khóa học LMS" / "Bộ đề tự luận".

- [ ] **Step 5: Handover + commit**

Cập nhật `docs/HANDOVER_2026-09-22.md`: mục 4 (bước 1 xong/còn gì), nhật ký ngày làm, mục 7 (số liệu mới). Điền mục dưới đây của plan này.

```bash
git add docs/HANDOVER_2026-09-22.md docs/superpowers/plans/2026-09-22-step1-code-boundaries.md
git commit -m "docs(handover): ket qua buoc 1 ranh gioi code"
```

## Còn lại có chủ đích (điền ở Task 10 — 22/09)

Baseline: **78 → 25 dòng** (15 file). 0 dòng thêm mới trong suốt bước 1. Đầu vào cho Bước 1b / Bước 2:

| Nhóm | File (số dòng) | Hướng xử lý | Làm cùng |
|---|---|---|---|
| Lệnh chuyển dữ liệu một lần | `app/Console/Commands/MigrateStorageToS3.php` (6) | Xoá lệnh khi Bước 4 (S3) xong | Bước 4 |
| Quyền hiển thị lối vào (UI dùng chung) | `resources/views/{components/app-grid,partials/sidebar,partials/portal-switcher,layouts/lms-learner}.blade.php`, `modules/Home/Views/index.blade.php` (6) — dùng `LmsAccess`/`GradeAccess` | Gate `cdhc2.lms.enter` như Task 6, hoặc `User::canAccessLms()`; view gọi method trên User | Bước 1b |
| Core ↔ LeaveManagement | `app/Support/PermissionCheck.php`, `modules/User/Controllers/{DigitalSignatureController,UserController}.php` (4) | Gate do LeaveManagement khai; `LeavePersonnel/LeavePosition` qua contract đọc | Bước 1b |
| Core ↔ Inventory | `app/Support/InventoryRoomAccess.php` (3) | Chuyển file về `modules/Inventory/Support` (chỉ Inventory dùng — kiểm lại) | Bước 1b |
| Core đọc model LMS/Grades | `ClassController` + `CourseCleanupController` → `LmsCourse`; `StudentController` → `Grades StudentProfile` (3) | Thêm method đọc vào `LmsDataContract` / contract Grades | Bước 2 (tách DB làm hỏng chúng trước tiên) |
| Relation LMS → Grades | `modules/Lms/Providers/LmsServiceProvider.php` → `GradeBook` (1) | Relation chéo DB không còn hợp lệ sau tách DB → thay bằng `GradeBookReaderContract` | Bước 2 |
| Chọn provider theo service | `modules/ModuleServiceProvider.php` → Dashboard/Home provider (2) | Chuyển logic sang `ServiceTopology` (được phép) | Bước 1b |
