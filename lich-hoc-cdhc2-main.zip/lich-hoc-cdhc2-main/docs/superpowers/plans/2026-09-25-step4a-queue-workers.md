# Bước 4A — Queue riêng từng service + ghi chéo service bất đồng bộ: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Mỗi service có queue + worker của riêng nó; lời gọi GHI sang service khác (provisioning LMS, chuyển điểm bài thi) đi qua job bền vững có retry, nên service đích tạm chết không làm mất dữ liệu.

**Architecture:** Không thêm hạ tầng (cụm 1 node, không có Redis). Giữ driver queue `database` nhưng **mỗi service dùng bảng job trong DB của chính nó** (`lms_jobs`, `tms_jobs`, `grade_jobs`; core giữ `jobs`). Vì bảng job nằm cùng DB với dữ liệu nghiệp vụ của service gửi, việc `dispatch()` bên trong transaction là **atomic** — bảng job đóng vai outbox, không cần bảng outbox riêng. Worker chạy như **container thứ 3** (`worker`) trong pod của mỗi service: cùng image, cùng env, deploy độc lập của Bước 3 tự áp dụng. Lời gọi ghi chéo service chuyển từ "HTTP ngay, lỗi thì chỉ `report()`" sang job `DeliverInternalCall` (retry + backoff, hết lượt → `failed_jobs` của service gửi + log lỗi).

**Tech Stack:** Laravel 12 queue (database driver), PHPUnit, k8s manifest, GitHub Actions.

**Spec:** `docs/superpowers/plans/2026-09-22-microservices-roadmap.md` (dòng Bước 4) + khảo sát 25/09 (mục "Hiện trạng" dưới).

## Global Constraints

- Không đụng Moodle. Không `helm upgrade tkb`. Không xoá `deployment/tkb`, `service/tkb`, Ingress `tkb`, key `.env` trong `tkb-env`.
- Mọi thay đổi qua PR; `php artisan test` + split (`CDHC2_TEST_SPLIT_DB=1 …`) xanh; `vendor/bin/pint --dirty`.
- Monolith (`CDHC2_SERVICE` không đặt) vẫn boot và chạy được (dev dùng `queue:listen` trong `composer run dev`).
- Bảng mới phải khớp `TableOwnership` (tiền tố `lms_`/`tms_`/`grade_`) để các test kiến trúc hiện có canh giữ.
- Heredoc gửi sang node: không dựa vào word-splitting, không backtick trong comment (bẫy 24/09).
- Sau mỗi task: cập nhật `docs/HANDOVER_2026-09-22.md`. Trả lời chủ dự án ngắn, tiếng Việt.

## Hiện trạng (khảo sát 25/09)

| Chỗ | Hiện tại | Hệ quả |
|---|---|---|
| Worker | **Không có `queue:work` ở đâu trên cụm** (supervisord chỉ php-fpm + nginx; scheduler chỉ `schedule:run`) | `SendSystemNotificationEmail` (dispatch ở `app/Support/SystemNotifier.php:455`, `Lms/Controllers/Teach/AssignmentController.php:262`, `EngageController.php:94`) **không bao giờ chạy trên prod** — email thông báo không được gửi |
| Bảng job | `QUEUE_CONNECTION=database`, `DB_QUEUE_CONNECTION` trống → mọi service ghi vào `jobs` của **core** (`eduka_v2`) | Queue nằm trong DB chung, trái mục tiêu tách dữ liệu |
| `config/queue.php` `failed`/`batching` | `database => env('DB_CONNECTION')`, bảng cố định `failed_jobs`/`job_batches` | Không cấu hình theo service được |
| `HttpLmsProvisioning` (core → lms) | `DB::afterCommit` rồi POST ngay, lỗi → `report()` | lms chết/timeout lúc đó = **mất** việc tạo khoá cho lớp mới |
| `LmsExamService::submit` → `transferExam` (lms → grades) | Gọi đồng bộ trong request nộp bài, lỗi → `report()` | grades chết = điểm bài thi không sang sổ điểm, không ai biết |
| `transferCourseSnapshot`, `viewBookForCourse` | Đồng bộ, người dùng chờ kết quả (trả id sổ điểm) | **Giữ đồng bộ** — tương tác, cần kết quả ngay |

## File Structure

- Create `database/migrations/2026_09_26_000001_create_service_queue_tables.php` — `lms_jobs`/`lms_failed_jobs`, `tms_*`, `grade_*` trên đúng connection.
- Modify `config/queue.php` — `failed`/`batching` đọc env.
- Create `packages/cdhc2-core/src/Jobs/DeliverInternalCall.php` — job gửi 1 lời gọi ghi nội bộ, retry/backoff.
- Modify `packages/cdhc2-core/src/Http/HttpLmsProvisioning.php` — dispatch job thay vì POST ngay.
- Create `modules/Lms/Jobs/TransferExamToGrades.php`; Modify `modules/Lms/Services/LmsExamService.php`.
- Modify `k8s/{core,lms,tms,grades}/deployment.yaml` — env queue + container `worker`.
- Create `tests/Feature/ServiceQueueTablesTest.php`, `tests/Feature/DeliverInternalCallTest.php`, `tests/Unit/Architecture/InternalWritesAreQueuedTest.php`.
- Create `.github/workflows/queue-status.yaml` (chỉ-đọc: đếm job chờ / failed mỗi service).

---

### Task 1: Đo backlog + workflow `queue-status` (chỉ đọc) — **có điểm dừng chờ chủ dự án**

Bật worker core sẽ xử lý **mọi job cũ** đang nằm trong `jobs` (email thông báo có thể từ nhiều tuần trước). Phải biết trước có bao nhiêu và từ khi nào.

**Files:** Create `.github/workflows/queue-status.yaml`

- [ ] **Step 1:** Copy khung Tailscale/SSH từ `service-logs.yaml`. Bước remote (`bash -s <<'REMOTE_EOF'`, heredoc có quote):

```bash
set +e
NS=tkb
POD=$(kubectl -n $NS get pods -l app=tkb-core --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')
kubectl -n $NS exec "$POD" -c fpm -- php artisan tinker --execute='
foreach (["mysql" => ["jobs", "failed_jobs"], "lms" => ["lms_jobs", "lms_failed_jobs"], "tms" => ["tms_jobs", "tms_failed_jobs"], "grades" => ["grade_jobs", "grade_failed_jobs"]] as $conn => $tables) {
    $c = \Cdhc2\Core\Support\TableOwnership::resolve($conn);
    foreach ($tables as $t) {
        if (! \Illuminate\Support\Facades\Schema::connection($c)->hasTable($t)) { echo "$c.$t: (chua co)\n"; continue; }
        $q = \Illuminate\Support\Facades\DB::connection($c)->table($t);
        $col = str_contains($t, "failed") ? "failed_at" : "created_at";
        $min = $q->min($col); $max = $q->max($col);
        $fmt = fn ($v) => $v === null ? "-" : (is_numeric($v) ? date("Y-m-d H:i", (int) $v) : $v);
        echo "$c.$t: ".$q->count()." dong, cu nhat ".$fmt($min).", moi nhat ".$fmt($max)."\n";
    }
}
echo "Theo job class (jobs core):\n";
foreach (\Illuminate\Support\Facades\DB::table("jobs")->get(["payload"]) ->groupBy(fn ($j) => json_decode($j->payload)->displayName ?? "?") as $k => $v) { echo "  $k: ".count($v)."\n"; }
'
```

- [ ] **Step 2:** Kiểm cú pháp YAML; commit `ci: workflow queue-status (chi doc)`; PR; sau merge chạy `gh workflow run queue-status.yaml --ref main`.
- [ ] **Step 3: DỪNG — báo chủ dự án** số job cũ theo loại + khoảng thời gian, đề xuất: job `SendSystemNotificationEmail` cũ hơn 3 ngày **xoá** (thông báo đã lỗi thời, gửi lại gây nhiễu) — chỉ làm khi chủ dự án đồng ý, bằng bước `purge` có chuỗi xác nhận thêm vào chính workflow này:

```bash
# chi chay khi input step=purge va confirm=XOA-JOB-CU
DELETE FROM jobs WHERE payload LIKE '%SendSystemNotificationEmail%' AND created_at < UNIX_TIMESTAMP(NOW() - INTERVAL 3 DAY);
```

---

### Task 2: Bảng queue theo service + config

**Files:** Create migration, `tests/Feature/ServiceQueueTablesTest.php`; Modify `config/queue.php`

**Interfaces — Produces:** bảng `{lms,tms,grade}_jobs`, `{lms,tms,grade}_failed_jobs` (schema giống `jobs`/`failed_jobs` của Laravel); env mới `QUEUE_FAILED_CONNECTION`, `QUEUE_FAILED_TABLE`, `QUEUE_BATCHING_CONNECTION`.

- [ ] **Step 1: Test (RED)**

```php
<?php

namespace Tests\Feature;

use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Support\Facades\Schema;
use Tests\Concerns\RefreshDatabase;
use Tests\TestCase;

/** Buoc 4A: moi service co bang job + failed_jobs trong DB cua chinh no. */
class ServiceQueueTablesTest extends TestCase
{
    use RefreshDatabase;

    public function test_each_service_has_its_own_job_tables_on_its_own_connection(): void
    {
        foreach (['lms' => 'lms_', 'tms' => 'tms_', 'grades' => 'grade_'] as $conn => $prefix) {
            foreach (['jobs', 'failed_jobs'] as $base) {
                $table = $prefix.$base;
                $this->assertSame($conn, TableOwnership::connectionFor($table), "{$table} phai thuoc {$conn}");
                $this->assertTrue(Schema::connection($conn)->hasTable($table), "thieu {$table}");
            }
            $this->assertTrue(Schema::connection($conn)->hasColumns($prefix.'jobs', ['queue', 'payload', 'attempts', 'reserved_at', 'available_at', 'created_at']));
            $this->assertTrue(Schema::connection($conn)->hasColumns($prefix.'failed_jobs', ['uuid', 'connection', 'queue', 'payload', 'exception', 'failed_at']));
        }
    }

    public function test_failed_job_storage_is_configurable_per_service(): void
    {
        putenv('QUEUE_FAILED_CONNECTION=lms');
        putenv('QUEUE_FAILED_TABLE=lms_failed_jobs');
        $config = require base_path('config/queue.php');
        putenv('QUEUE_FAILED_CONNECTION');
        putenv('QUEUE_FAILED_TABLE');

        $this->assertSame('lms', $config['failed']['database']);
        $this->assertSame('lms_failed_jobs', $config['failed']['table']);
    }
}
```

- [ ] **Step 2:** `php artisan test --filter=ServiceQueueTablesTest` → FAIL (thiếu bảng, config cứng).
- [ ] **Step 3: Migration** (một file, 3 connection — pattern `$connection` giống `2026_09_03_074624_add_is_trial_to_lms_exam_attempts.php`, nhưng lặp qua connection nên dùng `Schema::connection($conn)`):

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Buoc 4A: queue cua moi service nam trong DB cua service do (bang job = outbox, dispatch trong transaction la atomic). */
return new class extends Migration
{
    private const SERVICES = ['lms' => 'lms_', 'tms' => 'tms_', 'grades' => 'grade_'];

    public function up(): void
    {
        foreach (self::SERVICES as $conn => $prefix) {
            if (! Schema::connection($conn)->hasTable($prefix.'jobs')) {
                Schema::connection($conn)->create($prefix.'jobs', function (Blueprint $table) {
                    $table->id();
                    $table->string('queue')->index();
                    $table->longText('payload');
                    $table->unsignedTinyInteger('attempts');
                    $table->unsignedInteger('reserved_at')->nullable();
                    $table->unsignedInteger('available_at');
                    $table->unsignedInteger('created_at');
                });
            }
            if (! Schema::connection($conn)->hasTable($prefix.'failed_jobs')) {
                Schema::connection($conn)->create($prefix.'failed_jobs', function (Blueprint $table) {
                    $table->id();
                    $table->string('uuid')->unique();
                    $table->text('connection');
                    $table->text('queue');
                    $table->longText('payload');
                    $table->longText('exception');
                    $table->timestamp('failed_at')->useCurrent();
                });
            }
        }
    }

    public function down(): void
    {
        foreach (self::SERVICES as $conn => $prefix) {
            Schema::connection($conn)->dropIfExists($prefix.'failed_jobs');
            Schema::connection($conn)->dropIfExists($prefix.'jobs');
        }
    }
};
```

  Nếu `MigrationConnectionTest` (test kiến trúc Bước 2) cấm migration nhiều connection → tách thành 3 file, mỗi file `protected $connection = '<svc>'`.

- [ ] **Step 4: Config**

```php
    'batching' => [
        'database' => env('QUEUE_BATCHING_CONNECTION', env('DB_CONNECTION', 'sqlite')),
        'table' => env('QUEUE_BATCHING_TABLE', 'job_batches'),
    ],
    // ...
    'failed' => [
        'driver' => env('QUEUE_FAILED_DRIVER', 'database-uuids'),
        'database' => env('QUEUE_FAILED_CONNECTION', env('DB_CONNECTION', 'sqlite')),
        'table' => env('QUEUE_FAILED_TABLE', 'failed_jobs'),
    ],
```

- [ ] **Step 5:** Test PASS cả 2 chế độ; full suite 2 chế độ; Pint; commit `feat(queue): bang job theo service`.

---

### Task 3: Job `DeliverInternalCall` + provisioning LMS qua queue

**Files:** Create `packages/cdhc2-core/src/Jobs/DeliverInternalCall.php`, `tests/Feature/DeliverInternalCallTest.php`; Modify `packages/cdhc2-core/src/Http/HttpLmsProvisioning.php`

**Interfaces — Produces:** `DeliverInternalCall::dispatch(string $service, string $path, array $payload, int $timeoutSeconds = 30)`; `$tries = 8`; `$timeout = $timeoutSeconds + 30` (worker giết job chạy quá lâu); `backoff() = [10, 60, 300, 900, 1800, 3600, 3600]`; `failed()` ghi `Log::error('internal call gave up', …)`.

- [ ] **Step 1: Test (RED)**

```php
<?php

namespace Tests\Feature;

use Cdhc2\Core\Http\HttpLmsProvisioning;
use Cdhc2\Core\Jobs\DeliverInternalCall;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Queue;
use Tests\TestCase;

class DeliverInternalCallTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        config(['jwt.secret' => str_repeat('k', 48), 'app.cdhc2_service' => 'core']);
    }

    public function test_provisioning_is_queued_instead_of_posted_inline(): void
    {
        Queue::fake();
        Http::fake();

        app(HttpLmsProvisioning::class)->provisionClass(42, 7);

        Http::assertNothingSent();
        Queue::assertPushed(DeliverInternalCall::class, fn ($job) => $job->service === 'lms'
            && $job->path === '/api/internal/lms/provisioning/class'
            && $job->payload === ['class_id' => 42, 'actor_id' => 7]);
    }

    public function test_job_is_not_visible_to_workers_if_the_business_transaction_rolls_back(): void
    {
        config(['queue.default' => 'database']);
        $before = DB::table('jobs')->count();

        try {
            DB::transaction(function () {
                app(HttpLmsProvisioning::class)->provisionClass(42, 7);
                throw new \RuntimeException('rollback');
            });
        } catch (\RuntimeException) {
        }

        $this->assertSame($before, DB::table('jobs')->count(), 'job phai rollback cung transaction (bang job = outbox)');
    }

    public function test_job_posts_and_throws_on_failure_so_the_queue_retries(): void
    {
        Http::fake(['*' => Http::response(['message' => 'down'], 503)]);

        $this->expectException(\Illuminate\Http\Client\RequestException::class);
        (new DeliverInternalCall('lms', '/api/internal/lms/provisioning/class', ['class_id' => 1]))->handle();
    }

    public function test_giving_up_is_logged_as_an_error(): void
    {
        Log::spy();
        (new DeliverInternalCall('lms', '/x', ['a' => 1]))->failed(new \RuntimeException('boom'));
        Log::shouldHaveReceived('error')->withArgs(fn ($m, $c) => $m === 'internal call gave up' && $c['service'] === 'lms' && $c['path'] === '/x')->once();
    }

    public function test_it_retries_with_backoff(): void
    {
        $job = new DeliverInternalCall('lms', '/x', []);
        $this->assertSame(8, $job->tries);
        $this->assertSame([10, 60, 300, 900, 1800, 3600, 3600], $job->backoff());
    }
}
```

- [ ] **Step 2:** RED (class chưa có).
- [ ] **Step 3: Job**

```php
<?php

namespace Cdhc2\Core\Jobs;

use Cdhc2\Core\Http\InternalClient;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

/**
 * Mot loi goi GHI sang service khac, gui tu queue cua service goi (Buoc 4A).
 * Dispatch trong transaction -> job ghi cung DB voi du lieu nghiep vu -> atomic (bang job = outbox).
 * Endpoint dich phai idempotent: job co the chay lai sau timeout.
 */
class DeliverInternalCall implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 8;

    /** Gioi han cua worker cho 1 lan chay (lon hon timeout HTTP). */
    public int $timeout;

    public function __construct(
        public string $service,
        public string $path,
        public array $payload,
        public int $timeoutSeconds = 30,
    ) {
        $this->timeout = $timeoutSeconds + 30;
    }

    /** @return list<int> */
    public function backoff(): array
    {
        return [10, 60, 300, 900, 1800, 3600, 3600];
    }

    public function handle(): void
    {
        InternalClient::for($this->service)->timeout($this->timeoutSeconds)->post($this->path, $this->payload)->throw();
    }

    public function failed(\Throwable $e): void
    {
        Log::error('internal call gave up', [
            'service' => $this->service,
            'path' => $this->path,
            'payload' => $this->payload,
            'error' => $e->getMessage(),
        ]);
    }
}
```

  `InternalClient::issueToken` lấy `auth()->id()` — trong worker là 0; payload đã mang `actor_id` nên đủ.

- [ ] **Step 4: `HttpLmsProvisioning`** — thay `postAfterCommit()` bằng:

```php
    /**
     * Xep hang tren queue cua service goi (khong POST ngay): job nam cung transaction voi du lieu
     * vua ghi, lms chet thi job cho va thu lai (Buoc 4A). Truoc day loi chi report() va mat viec.
     */
    private function queue(string $path, array $payload): void
    {
        // Provisioning ca lop co the mat toi 120s (TIMEOUT_SECONDS san co).
        DeliverInternalCall::dispatch('lms', $path, $payload, self::TIMEOUT_SECONDS);
    }
```

  Cập nhật 3 lời gọi `postAfterCommit(` → `queue(`. Test thêm: `$job->timeoutSeconds === 120` và `$job->timeout === 150`.

  **Bẫy `retry_after`:** driver `database` coi job đang chạy quá `retry_after` (mặc định 90s, `DB_QUEUE_RETRY_AFTER`) là chết và giao cho worker khác → chạy **2 lần song song**. Phải đặt `DB_QUEUE_RETRY_AFTER=300` (> job dài nhất 150s) — Task 6 Step 1.
- [ ] **Step 5: Idempotent phía lms** — test gọi `POST /api/internal/lms/provisioning/class` **hai lần** với cùng lớp (JWT hợp lệ, pattern `tests/Feature/LmsProvisioningContractTest.php`) → số `lms_courses` và `lms_course_members` không đổi ở lần 2. Nếu đổi → sửa `LmsCourseProvisioningService` dùng `updateOrCreate` theo khoá tự nhiên (môn+lớp — đã có unique `lms_courses_subject_class_unique`).
- [ ] **Step 6:** Test 2 chế độ + full suite; Pint; commit `feat(queue): provisioning LMS qua job co retry`.

---

### Task 4: Chuyển điểm bài thi qua queue

**Files:** Create `modules/Lms/Jobs/TransferExamToGrades.php`; Modify `modules/Lms/Services/LmsExamService.php:111-118`; Test mới trong `tests/Feature/`.

- [ ] **Step 1: Test (RED):** `Queue::fake()`; nộp bài qua `LmsExamService` → `Queue::assertPushed(TransferExamToGrades::class, fn ($j) => $j->examId === $exam->id)`; và `GradeTransferContract` **không** được gọi trong request (mock `shouldNotReceive('transferExam')`).
- [ ] **Step 2: Job**

```php
<?php

namespace Modules\Lms\Jobs;

use Cdhc2\Core\Contracts\GradeTransferContract;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

/** Chuyen diem bai thi sang Grades sau khi nop (Buoc 4A): grades chet thi cho va thu lai, khong mat diem. */
class TransferExamToGrades implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable;

    public int $tries = 8;

    public function __construct(public int $examId) {}

    /** @return list<int> */
    public function backoff(): array
    {
        return [10, 60, 300, 900, 1800, 3600, 3600];
    }

    public function handle(GradeTransferContract $transfer): void
    {
        $transfer->transferExam($this->examId, 'lms');
    }

    public function failed(\Throwable $e): void
    {
        Log::error('exam grade transfer gave up', ['exam_id' => $this->examId, 'error' => $e->getMessage()]);
    }
}
```

- [ ] **Step 3:** Trong `LmsExamService` thay khối `try { $this->gradeTransfer->transferExam(...) } catch …` bằng `TransferExamToGrades::dispatch($exam->id);` (giữ comment lý do: không chặn nộp bài). Lỗi nghiệp vụ "sổ điểm đang khoá" sẽ làm job thử lại 8 lần rồi `failed` → chấp nhận (log rõ); nếu `transferExam` ném lỗi nghiệp vụ có kiểu riêng, bắt kiểu đó trong `handle()` và `$this->fail()` ngay thay vì retry.
- [ ] **Step 4:** Test idempotent phía grades: gọi `transferExam` 2 lần cho cùng exam → cột điểm/giá trị không nhân đôi.
- [ ] **Step 5:** Test 2 chế độ; Pint; commit `feat(queue): chuyen diem bai thi qua job`.

---

### Task 5: Test canh giữ — ghi chéo service phải qua queue

**Files:** Create `tests/Unit/Architecture/InternalWritesAreQueuedTest.php`

- [ ] **Step 1:** Quét `packages/cdhc2-core/src/Http/*.php`: mọi `InternalClient::post(` / `->post(` phải nằm trong danh sách **cho phép đồng bộ** có lý do:

```php
    /** Loi goi GHI dong bo duoc phep: nguoi dung dang cho ket qua ngay. */
    private const SYNC_ALLOWED = [
        'HttpGradeTransfer.php|/api/internal/grades/view-book' => 'tra sổ điểm cho người dùng xem ngay',
        'HttpGradeTransfer.php|/api/internal/grades/transfer-snapshot' => 'trả id sổ điểm để redirect',
        'HttpGradeTransfer.php|/api/internal/grades/transfer-exam' => 'chỉ gọi từ job TransferExamToGrades',
    ];
```

  và `HttpLmsProvisioning.php` không còn `InternalClient::` (chỉ `DeliverInternalCall::dispatch`). Kiểm ngược: thêm tạm 1 `InternalClient::post` vào `HttpLmsProvisioning` → test FAIL.
- [ ] **Step 2:** Commit `test(arch): ghi cheo service phai qua queue`.

---

### Task 6: Worker trong pod mỗi service + env queue

**Files:** Modify `k8s/{core,lms,tms,grades}/deployment.yaml`; Modify `tests/deploy/render-manifests.test.sh` (worker nhận cùng tag).

- [ ] **Step 1:** Env queue — thêm vào **cả `fpm` và `worker`** của lms/tms/grades (core giữ mặc định `jobs`/`failed_jobs`):

```yaml
            # Buoc 4A: queue nam trong DB cua chinh service (bang job = outbox).
            - name: DB_QUEUE_CONNECTION
              value: "lms"
            - name: DB_QUEUE_TABLE
              value: "lms_jobs"
            - name: QUEUE_FAILED_CONNECTION
              value: "lms"
            - name: QUEUE_FAILED_TABLE
              value: "lms_failed_jobs"
            # > $timeout dai nhat (provisioning 150s) - neu nho hon, job dang chay bi giao lai -> chay 2 lan.
            - name: DB_QUEUE_RETRY_AFTER
              value: "300"
```

  Core cũng cần `DB_QUEUE_RETRY_AFTER=300` (job provisioning xếp ở queue core).

  (tms: `tms`/`tms_jobs`/`tms_failed_jobs`; grades: `grades`/`grade_jobs`/`grade_failed_jobs`.)

- [ ] **Step 2:** Container `worker` (copy `envFrom`, `volumeMounts`, env `CDHC2_SERVICE`/`JWT_ENFORCE`/session/cache của `fpm`):

```yaml
        - name: worker
          image: registry.hc2/cdhc2/cdhc2-lms:latest
          imagePullPolicy: IfNotPresent
          # `args` (khong phai `command`) de entrypoint van chay. --max-time: tu thoat moi gio de
          # nhan code/config moi khi pod khong doi; k8s khoi dong lai container.
          args: ["php", "/var/www/artisan", "queue:work", "--sleep=3", "--max-time=3600", "--no-interaction"]
          resources:
            requests: { cpu: 20m, memory: 96Mi }
            limits: { memory: 256Mi }
```

- [ ] **Step 3:** `render-manifests.test.sh` thêm assert: sau `render "lms sidecar"`, `grep -c 'cdhc2-lms:sha-1234567' lms/deployment.yaml` = 2 (fpm + worker). Chạy test.
- [ ] **Step 4:** Merge **sau** khi Task 1 Step 3 đã xử lý backlog (worker core sẽ chạy job cũ ngay khi lên). Deploy build + rollout cả 4 (manifest đổi) — bình thường.
- [ ] **Step 5:** Commit `feat(k8s): worker queue trong pod moi service`.

---

### Task 7: Nghiệm thu trên prod + tài liệu

- [ ] **Step 1:** `queue-status`: 4 bảng job tồn tại, job chờ ≈ 0 sau vài phút; `failed_jobs` không tăng.
- [ ] **Step 2 — Chịu lỗi service đích:** `kubectl scale deploy/tkb-lms --replicas=0` (qua workflow có xác nhận, hoặc chủ dự án chạy) → tạo 1 lớp thử trong core → `queue-status` thấy 1 `DeliverInternalCall` chờ trong `jobs` core, log core có lần thử thất bại → scale lms về 1 → trong ≤ 2 phút job hết, khoá LMS của lớp được tạo. Xoá lớp thử.
- [ ] **Step 3 — Email:** tạo 1 thông báo thử (theo luồng `SystemNotifier`) → job chạy (không còn trong `jobs`), log mail/`failed_jobs` sạch.
- [ ] **Step 4:** `service-logs` 4 service lọc `gave up` → không có.
- [ ] **Step 5:** Handover (mục 0, 1, 4, nhật ký) + roadmap dòng Bước 4 (4A xong). Commit `docs: buoc 4A xong`.

## Rủi ro & quyết định cần chủ dự án

1. **Backlog job cũ** (Task 1): xoá hay cho gửi. Đề xuất xoá email > 3 ngày.
2. **Worker chung pod với web:** scale web là scale worker. Đủ cho 1 node; tách Deployment riêng khi cần scale độc lập (Bước 5).
3. **Job chạy với `auth()->id() = 0`:** JWT `sub=0`; mọi payload ghi chéo phải tự mang `actor_id` (provisioning đã có).
4. **Không có hàng đợi trung gian ngoài DB:** chấp nhận ở 1 node; Redis/RabbitMQ để Bước 5.
