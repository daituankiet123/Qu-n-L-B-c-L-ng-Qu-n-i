# Bước 3 — Deploy độc lập: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Push code của một service chỉ rollout đúng service đó; image gắn tag theo commit; lùi được từng service; bật `JWT_ENFORCE` trên cả 4 service.

**Architecture:** CI đã có `detect-changes` (dorny/paths-filter) và chỉ build service đổi, nhưng bước deploy vẫn kéo cả 5 image `:latest`, `apply` manifest `:latest` rồi `rollout restart` **tất cả** deployment. Bước này đổi sang: build image tag `sha-<7 ký tự>`; trên node, một script thuần (không gọi kubectl) "render" manifest — service đổi nhận tag mới, service không đổi giữ **đúng image đang chạy** (đọc từ cluster) → `kubectl apply` chỉ làm đổi pod template của service đổi → chỉ service đó tạo ReplicaSet mới. Bỏ `rollout restart` hàng loạt và `imagePullPolicy: Always`.

**Tech Stack:** GitHub Actions, bash, kubectl, registry nội bộ `registry.hc2/cdhc2`, GHCR, PHPUnit (test kiến trúc đọc file workflow).

**Spec:** `docs/superpowers/plans/2026-09-22-microservices-roadmap.md` (dòng Bước 3) + `docs/HANDOVER_2026-09-22.md` mục 7.C.

## Global Constraints

- Không đụng Moodle. Không `helm upgrade tkb`. Không xoá `deployment/tkb`, `service/tkb`, Ingress `tkb`, key `.env` trong secret `tkb-env`.
- Mỗi push lên `main` đều deploy prod → mọi thay đổi qua PR, PHPUnit (cả `phpunit-split`) xanh trước.
- Monolith (`CDHC2_SERVICE` không đặt) phải luôn boot được.
- Vẫn push thêm tag `:latest` cho mọi image build ra (đường lùi thủ công + `deployment/tkb` cũ không phụ thuộc tag sha).
- Đĩa node đã từng đầy (sự cố 20–21/09): tag sha tích luỹ → **bắt buộc** có bước dọn image cũ trên node trong cùng PR đổi tag.
- Không merge hai PR sát nhau (GHCR `unknown blob`).
- Sau mỗi task: cập nhật `docs/HANDOVER_2026-09-22.md` (mục 4 + nhật ký). Trả lời chủ dự án ngắn, tiếng Việt.

## Hiện trạng (đọc code 24/09)

| Chỗ | Hiện tại | Vấn đề |
|---|---|---|
| `build-and-deploy.yml` job `detect-changes` | 5 nhóm: shared/core/lms/tms/grades | Không có nhóm cho `k8s/<svc>/**`, `k8s/traefik/**`, `k8s/scheduler/**`; không có test bảo đảm mọi module nằm trong đúng 1 nhóm |
| job `build-and-push-ghcr` | Build service đổi, tag `:latest` | Không có tag bất biến → không lùi được, không biết pod chạy commit nào |
| job `mirror-and-deploy` | Kéo cả `core lms tms grades sidecar`, `apply -R`, `rollout restart` 6 deployment | Mọi push restart toàn bộ |
| `k8s/*/deployment.yaml` | `image: …:latest`, `imagePullPolicy: Always` | Cần `IfNotPresent` khi tag bất biến |
| Migration | Chỉ initContainer `migrate` của **core** chạy `migrate --force` (`docker/entrypoint.sh:66`) | Nếu PR chỉ sửa `modules/Lms/**` mà có migration mới, core không rollout → migration **không chạy** |
| `config/jwt.php` | `JWT_ENFORCE` mặc định `false` | Chưa bật trên prod |

## File Structure

- Create `scripts/deploy/render-manifests.sh` — hàm thuần: (thư mục manifest, danh sách service đổi, tag mới, file ảnh-đang-chạy) → manifest đã thay image. Không gọi kubectl để test được trong CI.
- Create `tests/deploy/render-manifests.test.sh` — test bash cho script trên (fixture trong `tests/deploy/fixtures/`).
- Create `tests/Unit/Architecture/DeployPathFilterTest.php` — mọi thư mục `modules/*` thuộc đúng 1 nhóm filter; migration kéo theo core.
- Create `.github/workflows/service-rollback.yaml` — lùi 1 service (`kubectl rollout undo`).
- Modify `.github/workflows/build-and-deploy.yml` — filter, tag sha, mirror/deploy có chọn lọc, dọn image.
- Modify `k8s/{core,lms,tms,grades,scheduler,traefik}/deployment.yaml` — `imagePullPolicy: IfNotPresent`; env `JWT_ENFORCE` (task 5).
- Modify `docs/HANDOVER_2026-09-22.md`, `docs/superpowers/plans/2026-09-22-microservices-roadmap.md` (Bước 3 → link plan này).

---

### Task 1: Path filter đúng và có test canh giữ

**Files:**
- Modify: `.github/workflows/build-and-deploy.yml:132-183`
- Create: `tests/Unit/Architecture/DeployPathFilterTest.php`

**Interfaces:**
- Produces: output job `detect-changes`: `core`, `lms`, `tms`, `grades`, `shared`, `traefik`, `scheduler` (`"true"`/`"false"`). Task 3 dùng các output này.

- [ ] **Step 1: Viết test (RED)**

```php
<?php

namespace Tests\Unit\Architecture;

use PHPUnit\Framework\TestCase;

/**
 * Deploy độc lập dựa vào path filter: module nằm sai nhóm -> sửa code mà service chạy code đó
 * không rollout (lỗi im lặng). Migration chỉ chạy ở initContainer của core -> mọi thư mục
 * Migrations phải kéo theo core.
 */
class DeployPathFilterTest extends TestCase
{
    private const SERVICES = ['core', 'lms', 'tms', 'grades'];

    /** @return array<string, list<string>> */
    private function filters(): array
    {
        $yaml = file_get_contents(dirname(__DIR__, 3).'/.github/workflows/build-and-deploy.yml');
        preg_match('/filters: \|\n(.*?)\n\n/s', $yaml, $m);
        $groups = [];
        $current = null;
        foreach (explode("\n", $m[1]) as $line) {
            if (preg_match('/^\s{12}([a-z]+):\s*$/', $line, $g)) {
                $current = $g[1];
                $groups[$current] = [];
            } elseif ($current && preg_match("/^\s+- '([^']+)'/", $line, $p)) {
                $groups[$current][] = $p[1];
            }
        }

        return $groups;
    }

    public function test_every_module_belongs_to_exactly_one_service_group(): void
    {
        $filters = $this->filters();
        $problems = [];
        foreach (glob(dirname(__DIR__, 3).'/modules/*', GLOB_ONLYDIR) as $dir) {
            $path = 'modules/'.basename($dir).'/';
            $owners = array_values(array_filter(self::SERVICES, fn ($svc) => in_array($path.'**', $filters[$svc] ?? [], true)));
            if (count($owners) !== 1) {
                $problems[] = $path.' -> '.(implode(',', $owners) ?: 'khong nhom nao');
            }
        }

        $this->assertSame([], $problems, "Module phai thuoc dung 1 nhom path filter:\n".implode("\n", $problems));
    }

    public function test_migrations_and_service_manifests_trigger_the_right_group(): void
    {
        $filters = $this->filters();
        $this->assertContains('**/Migrations/**', $filters['core']);
        $this->assertContains('database/**', $filters['core']);
        foreach (self::SERVICES as $svc) {
            $this->assertContains("k8s/{$svc}/**", $filters[$svc]);
        }
        $this->assertContains('k8s/traefik/**', $filters['traefik']);
        $this->assertContains('k8s/scheduler/**', $filters['scheduler']);
    }
}
```

- [ ] **Step 2: Chạy, thấy FAIL**

Run: `php artisan test --filter=DeployPathFilterTest`
Expected: FAIL — thiếu `**/Migrations/**`, `k8s/*/**`, nhóm `traefik`/`scheduler`; có thể lộ module chưa thuộc nhóm nào.

- [ ] **Step 3: Sửa filter**

Trong `filters:` thêm vào `core`: `'**/Migrations/**'`, `'database/**'`, `'k8s/core/**'`; thêm `'k8s/lms/**'`, `'k8s/tms/**'`, `'k8s/grades/**'` vào nhóm tương ứng; thêm hai nhóm mới và output:

```yaml
            traefik:
              - 'k8s/traefik/**'
            scheduler:
              - 'k8s/scheduler/**'
```

```yaml
      traefik: ${{ steps.filter.outputs.traefik }}
      scheduler: ${{ steps.filter.outputs.scheduler }}
```

Module nào test báo "khong nhom nao" → thêm vào nhóm của service phục vụ route đó (tra `packages/cdhc2-core` / `bootstrap/providers.php` theo `CDHC2_SERVICE`).

- [ ] **Step 4: Chạy lại → PASS.** `php artisan test --filter=DeployPathFilterTest`
- [ ] **Step 5: Commit** `ci: path filter du nhom + test canh giu`

---

### Task 2: Image tag theo commit

**Files:**
- Modify: `.github/workflows/build-and-deploy.yml` (job `build-and-push-ghcr`, ~dòng 185-251)

**Interfaces:**
- Consumes: output `detect-changes` (Task 1).
- Produces: env/ output `IMAGE_TAG=sha-${GITHUB_SHA::7}`; output job `built` = danh sách service đã build, cách nhau dấu cách (vd `"lms sidecar"`). Mọi image build ra có **cả** `:$IMAGE_TAG` và `:latest`.

- [ ] **Step 1:** Thêm ở đầu job: `outputs: { built: ${{ steps.svc.outputs.built }}, tag: ${{ steps.tag.outputs.tag }} }` và step:

```yaml
      - name: Image tag
        id: tag
        run: echo "tag=sha-${GITHUB_SHA::7}" >> "$GITHUB_OUTPUT"
```

- [ ] **Step 2:** Trong "Build and push service images" (id `svc`), mỗi service build: `-t "$REPO/cdhc2-${svc}:$TAG" -t "$REPO/cdhc2-${svc}:latest"`, push cả hai, gom `BUILT="$BUILT $svc"`; cuối: `echo "built=${BUILT# }" >> "$GITHUB_OUTPUT"`.
  Thêm input `workflow_dispatch` `force_all` (boolean) — khi `true` coi như `SHARED=true` (dùng cho lần deploy đầu sau khi đổi, và khi cần dựng lại toàn bộ).
- [ ] **Step 3:** Sidecar chỉ build khi `BUILT` khác rỗng, tag `:$TAG` + `:latest`, thêm `sidecar` vào `built`.
- [ ] **Step 4:** Kiểm tra cú pháp: `actionlint .github/workflows/build-and-deploy.yml` (nếu không có actionlint: `python -c "import yaml,sys;yaml.safe_load(open(sys.argv[1]))" .github/workflows/build-and-deploy.yml`).
- [ ] **Step 5: Commit** `ci: tag image theo commit (giu :latest)`

---

### Task 3: Render manifest + deploy chỉ service đổi

**Files:**
- Create: `scripts/deploy/render-manifests.sh`
- Create: `tests/deploy/render-manifests.test.sh`, `tests/deploy/fixtures/current-images.txt`
- Modify: `.github/workflows/build-and-deploy.yml` (job `mirror-and-deploy`; thêm `needs: [build-and-push-ghcr, detect-changes]`)
- Modify: `k8s/{core,lms,tms,grades,scheduler}/deployment.yaml` — `imagePullPolicy: Always` → `IfNotPresent`
- Modify: `.github/workflows/blade-lint` job hoặc thêm step trong `phpunit-split`: chạy `bash tests/deploy/render-manifests.test.sh`

**Interfaces:**
- Consumes: `IMAGE_TAG`, `built` (Task 2); output `detect-changes` (Task 1).
- Produces: `render-manifests.sh <src_dir> <out_dir> <tag> "<changed deployments>" <current_images_file>`; file current-images mỗi dòng `<deployment> <container> <image>`.

Quy tắc render cho từng `deployment.yaml` (deployment = `tkb-core|tkb-lms|tkb-tms|tkb-grades|tkb-scheduler`):
- deployment thuộc danh sách đổi → mọi dòng `image: registry.hc2/cdhc2/cdhc2-<x>:latest` thành `:<tag>`.
- deployment không đổi → mỗi container lấy đúng image đang chạy trong file current-images; nếu deployment chưa tồn tại trên cluster → dùng `:<tag>` (lần đầu tạo) — nếu `<tag>` của image đó chưa được build thì dùng `:latest`.
- Bảng "đổi": `tkb-core` ⇐ core‖shared; `tkb-scheduler` ⇐ core‖shared‖scheduler; `tkb-lms` ⇐ lms‖shared; `tkb-tms` ⇐ tms‖shared; `tkb-grades` ⇐ grades‖shared; `traefik` ⇐ traefik (Traefik dùng image ngoài, chỉ `apply`, không render).

- [ ] **Step 1: Viết test (RED)**

`tests/deploy/fixtures/current-images.txt`:
```
tkb-core migrate registry.hc2/cdhc2/cdhc2-core:sha-aaaaaaa
tkb-core fpm registry.hc2/cdhc2/cdhc2-core:sha-aaaaaaa
tkb-core nginx registry.hc2/cdhc2/cdhc2-sidecar:sha-aaaaaaa
tkb-lms fpm registry.hc2/cdhc2/cdhc2-lms:sha-bbbbbbb
tkb-lms nginx registry.hc2/cdhc2/cdhc2-sidecar:sha-bbbbbbb
```

`tests/deploy/render-manifests.test.sh`:
```bash
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
fail() { echo "FAIL: $*"; exit 1; }

bash "$ROOT/scripts/deploy/render-manifests.sh" "$ROOT/k8s" "$OUT" sha-1234567 "tkb-lms" "$ROOT/tests/deploy/fixtures/current-images.txt"

grep -q 'cdhc2-lms:sha-1234567' "$OUT/lms/deployment.yaml" || fail "lms phai nhan tag moi"
grep -q 'cdhc2-sidecar:sha-1234567' "$OUT/lms/deployment.yaml" || fail "sidecar cua lms phai nhan tag moi"
grep -q 'cdhc2-core:sha-aaaaaaa' "$OUT/core/deployment.yaml" || fail "core khong doi phai giu image dang chay"
grep -q 'cdhc2-sidecar:sha-aaaaaaa' "$OUT/core/deployment.yaml" || fail "sidecar core giu image dang chay"
! grep -rq 'cdhc2-[a-z]*:latest' "$OUT/core" "$OUT/lms" || fail "con :latest trong service da biet image"
# tms chua co trong current-images (chua ton tai) -> duoc tao voi tag moi
grep -q 'cdhc2-tms:sha-1234567' "$OUT/tms/deployment.yaml" || fail "deployment moi dung tag moi"
cmp -s "$ROOT/k8s/traefik/deployment.yaml" "$OUT/traefik/deployment.yaml" || fail "traefik chi copy nguyen"
echo "render-manifests: OK"
```

- [ ] **Step 2: Chạy, thấy FAIL** — `bash tests/deploy/render-manifests.test.sh` → "No such file" (script chưa có).

- [ ] **Step 3: Viết script**

```bash
#!/usr/bin/env bash
# Render manifest cho deploy doc lap: deployment doi -> tag moi; khong doi -> giu DUNG image
# dang chay (tu file current-images) de `kubectl apply` khong doi pod template -> khong rollout.
# Khong goi kubectl: test duoc trong CI (tests/deploy/render-manifests.test.sh).
set -euo pipefail
SRC="$1"; OUT="$2"; TAG="$3"; CHANGED=" $4 "; CURRENT="$5"

rm -rf "$OUT"; mkdir -p "$OUT"; cp -R "$SRC"/. "$OUT"/
for f in "$OUT"/*/deployment.yaml; do
  deploy="$(awk '/^metadata:/{m=1} m && /^  name:/{print $2; exit}' "$f")"
  case "$deploy" in tkb-*) ;; *) continue ;; esac
  if [[ "$CHANGED" == *" $deploy "* ]] || ! grep -q "^$deploy " "$CURRENT"; then
    sed -i -E "s#(image: registry\.hc2/cdhc2/cdhc2-[a-z]+):latest#\1:${TAG}#" "$f"
    continue
  fi
  # khong doi: thay tung container bang image dang chay (khop theo ten image cdhc2-<x>)
  while read -r d _container image; do
    [ "$d" = "$deploy" ] || continue
    repo="${image%:*}"
    sed -i -E "s#image: ${repo//./\\.}:latest#image: ${image}#" "$f"
  done < "$CURRENT"
done
```

Chỉ giữ trong `$OUT` các thư mục deploy thật (`traefik core lms tms grades scheduler`) — `rm -rf "$OUT"/legacy-monolith "$OUT"/storage "$OUT"/*.yaml "$OUT"/*.bak` sau `cp` (giữ nguyên hành vi scp hiện tại, **không** apply PVC hay manifest monolith).

- [ ] **Step 4: Chạy test → `render-manifests: OK`.** Thêm step CI chạy test này trong job `blade-lint`.

- [ ] **Step 5: Sửa job `mirror-and-deploy`**
  1. `scp` thêm `scripts/deploy/render-manifests.sh`.
  2. Mirror: chỉ `for svc in ${BUILT}` (từ `needs.build-and-push-ghcr.outputs.built`), kéo `:$TAG`, tag + push lên registry nội bộ với **cả** `:$TAG` và `:latest`.
  3. Tính `CHANGED` theo bảng quy tắc ở trên từ output `detect-changes` (+ `force_all`).
  4. Trên node: `kubectl get deploy -n $NS -o jsonpath='{range .items[*]}{range .spec.template.spec.initContainers[*]}{..}{end}…'` — đơn giản hơn: vòng `for d in tkb-core tkb-lms tkb-tms tkb-grades tkb-scheduler` gọi
     `kubectl get deploy $d -n $NS -o jsonpath='{range .spec.template.spec.initContainers[*]}{"'$d' "}{.name}{" "}{.image}{"\n"}{end}{range .spec.template.spec.containers[*]}{"'$d' "}{.name}{" "}{.image}{"\n"}{end}' >> /tmp/current-images.txt 2>/dev/null || true`.
  5. `bash render-manifests.sh /tmp/cdhc2-k8s /tmp/cdhc2-k8s-rendered "$TAG" "$CHANGED" /tmp/current-images.txt`; in `diff -r` tóm tắt ra log; `kubectl apply -R -f /tmp/cdhc2-k8s-rendered/`.
  6. **Xoá** vòng `rollout restart` 6 deployment. `rollout status` + tự khôi phục chỉ lặp qua deployment trong `CHANGED` (+ `traefik` nếu nhóm traefik đổi).
  7. Giữ nguyên toàn bộ phần sao lưu nodePort 30800 / kiểm CRD / kiểm PVC.

- [ ] **Step 6: Đổi `imagePullPolicy: Always` → `IfNotPresent`** trong 5 deployment (tag bất biến nên không cần kéo lại). Cập nhật comment ở dòng ~433 của workflow cho khớp (lý do cũ là `:latest` không đổi template — nay tag đổi template).

- [ ] **Step 7:** `php artisan test --filter=DeployPathFilterTest`, `bash tests/deploy/render-manifests.test.sh`, kiểm cú pháp YAML.
- [ ] **Step 8: Commit** `ci: deploy chi service doi (render manifest theo image dang chay)`

> Lần deploy đầu tiên sau khi merge: mọi deployment đổi `imagePullPolicy` + tag → rollout **tất cả một lần** (bình thường). Chạy bằng `workflow_dispatch` với `force_all=true` để rõ ràng.

---

### Task 4: Dọn image cũ + lùi từng service

**Files:**
- Modify: `.github/workflows/build-and-deploy.yml` (cuối `mirror-and-deploy`, sau khi rollout thành công)
- Create: `.github/workflows/service-rollback.yaml`

**Interfaces:**
- Produces: workflow `service-rollback.yaml` inputs `service` (choice core|lms|tms|grades|scheduler), `confirm` (phải = `LUI-SERVICE`).

- [ ] **Step 1: Dọn image trên node** (chống lặp lại sự cố đầy đĩa 20–21/09) — sau rollout OK:

```bash
echo "== Don image cdhc2 cu tren node (giu 5 tag sha moi nhat moi repo + image dang chay) =="
IN_USE=$(kubectl get pods -n $NS -o jsonpath='{range .items[*]}{range .spec.containers[*]}{.image}{"\n"}{end}{range .spec.initContainers[*]}{.image}{"\n"}{end}{end}' | sort -u)
for repo in $(docker images --format '{{.Repository}}' | grep -E '/cdhc2-(core|lms|tms|grades|sidecar)$' | sort -u); do
  docker images "$repo" --format '{{.CreatedAt}}\t{{.Repository}}:{{.Tag}}' | grep ':sha-' | sort -r | tail -n +6 | cut -f2 \
    | while read -r img; do echo "$IN_USE" | grep -qx "$img" || docker rmi "$img" || true; done
done
df -h / | tail -1
```

Nếu registry nội bộ là Harbor: ghi vào handover việc **chủ dự án** đặt retention policy (giữ 10 tag `sha-*` mới nhất mỗi repo) trong UI Harbor — agent không có quyền đổi cấu hình này.

- [ ] **Step 2: Workflow lùi** — copy khung SSH/Tailscale từ `service-logs.yaml`; bước chạy:

```bash
[ "${{ inputs.confirm }}" = "LUI-SERVICE" ] || { echo "::error::confirm phai la LUI-SERVICE"; exit 1; }
D="tkb-${{ inputs.service }}"
kubectl rollout history deployment/$D -n $NS | tail -5
kubectl rollout undo deployment/$D -n $NS
kubectl rollout status deployment/$D -n $NS --timeout=300s
kubectl get deploy $D -n $NS -o jsonpath='{range .spec.template.spec.containers[*]}{.name}={.image}{"\n"}{end}'
```

  Chỉ chạy trên `main` (`if: github.ref == 'refs/heads/main'`). Ghi chú trong workflow: `undo` lùi pod template (image + env), **không** lùi migration.
- [ ] **Step 3:** Kiểm cú pháp YAML; commit `ci: don image cu tren node + workflow lui tung service`.

---

### Task 5: Bật `JWT_ENFORCE` trên 4 service

**Files:**
- Modify: `k8s/{core,lms,tms,grades}/deployment.yaml` (env container `fpm`)
- Test: test hiện có của `InternalApiAuth` / `InternalClient` (tìm bằng `grep -rln "InternalApiAuth\|jwt.enforce" tests`)

- [ ] **Step 1: Preflight chỉ-đọc trên prod** — chạy `cluster-diagnostics.yaml` hoặc thêm dòng vào đó: kiểm secret `tkb-env` **có** key `JWT_SECRET` (chỉ in có/không, không in giá trị) và log 4 service 24h không có `401` từ `/internal/`. Thiếu `JWT_SECRET` → **dừng**, báo chủ dự án tạo theo `k8s/secret.example.yaml:23-31` (thao tác trên secret là việc của chủ dự án).
- [ ] **Step 2: Test (RED nếu chưa có)** — bảo đảm khi `jwt.enforce=true`: request `/internal/*` thiếu/ sai token → 401; `InternalClient` gửi token hợp lệ → 200. Nếu test đã có, chỉ chạy: `php artisan test --filter=InternalApi`.
- [ ] **Step 3:** Thêm vào env container `fpm` của 4 deployment:

```yaml
            - name: JWT_ENFORCE
              value: "true"
```

  (Monolith `deployment/tkb` không đổi — không gọi internal API qua HTTP.)
- [ ] **Step 4:** Full `php artisan test` + `composer test:split` xanh; Pint; commit `feat(security): bat JWT_ENFORCE tren 4 service`.
- [ ] **Step 5 (sau deploy):** `service-logs.yaml` 4 service lọc `401` và `.ERROR`; mở `/lms`, `/tms`, trang điểm (gọi chéo service) bằng Chrome đã đăng nhập → 200.

---

### Task 6: Nghiệm thu trên prod + tài liệu

Làm **tuần tự**, mỗi PR merge riêng, chờ deploy xanh rồi mới sang PR sau.

- [ ] **Step 1:** Trước mỗi lần kiểm, ghi `kubectl get rs -n tkb -l 'app in (tkb-core,tkb-lms,tkb-tms,tkb-grades,tkb-scheduler)' --sort-by=.metadata.creationTimestamp` (qua `cluster-diagnostics.yaml`, thêm lệnh này nếu chưa có).
- [ ] **Step 2 — PR chỉ sửa docs:** không service nào có ReplicaSet mới; job build báo "Skipping" cả 4.
- [ ] **Step 3 — PR chỉ sửa `modules/Lms/**`** (thay đổi nhỏ có ích thật, vd comment/copy): chỉ `tkb-lms` có ReplicaSet mới, image `cdhc2-lms:sha-<commit>`; 4 deployment còn lại giữ image cũ.
- [ ] **Step 4 — Lùi:** chạy `service-rollback.yaml` `service=lms confirm=LUI-SERVICE` → `tkb-lms` về image trước; chạy deploy lại (`workflow_dispatch`) để về bản mới.
- [ ] **Step 5 — Migration:** PR có migration trong `modules/Lms/Migrations/` → `tkb-core` cũng rollout (initContainer `migrate` chạy), `migrate:status` pending 0 (qua `migrate.yaml`).
- [ ] **Step 6:** `df -h /` trên node không tăng quá ~2 GB sau 3 lần deploy.
- [ ] **Step 7:** Cập nhật handover (mục 0, 1, 4 hàng H, nhật ký) + roadmap dòng Bước 3 → "xong, link plan này". Commit `docs: buoc 3 xong`.

---

## Rủi ro & quyết định cần chủ dự án

1. **Lệch phiên bản giữa service:** lms chạy commit mới, core chạy commit cũ. An toàn vì contract/`packages/cdhc2-core/**` nằm trong nhóm `shared` → đổi contract là rollout cả 4. Quy ước: **không** đổi hình dạng response internal API trong `modules/<svc>` mà không đổi contract.
2. **Nhóm `shared` rộng** (`app/**`, `resources/**`, `config/**`): phần lớn PR hiện nay vẫn rollout cả 4. Chấp nhận ở bước này; thu hẹp thêm thuộc Bước 4 (tách view/asset theo service).
3. **Harbor retention** (Task 4 Step 1) và **tạo `JWT_SECRET`** (Task 5 Step 1) là thao tác của chủ dự án.
