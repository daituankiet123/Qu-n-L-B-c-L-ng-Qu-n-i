# Bước 2 — Tách database theo service: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Mỗi service (lms, tms, grades) chạy trên database riêng của nó; core giữ bảng định danh/tham chiếu; bộ test chạy xanh ở chế độ tách DB; prod được chuyển dữ liệu bằng runbook có đường lùi.

**Architecture:** Giữ thiết kế "Gate D" đã có: **mỗi service một schema trên cùng một server MariaDB**. Model của service đã gắn `$connection` (trừ Inventory/LeaveManagement), `CoreServiceProvider::aliasUnsplitConnections()` làm các connection `lms/tms/grades` trỏ về DB core khi chưa tách, `DbRef` định danh bảng khác schema (`db.table`) cho JOIN. Việc còn thiếu nằm ở 4 chỗ: model chưa gắn connection, migration chưa gắn connection, FK trỏ sang schema khác, và truy vấn Eloquent chạy chéo connection (`whereHas`/`withCount`). Mọi thay đổi của phần 2A **không đổi hành vi prod** (connection vẫn alias về cùng DB); chỉ phần 2B mới chuyển dữ liệu.

**Tech Stack:** Laravel 12, MariaDB (prod: `mariadb.data-store.svc.cluster.local`, DB `eduka_v2`), MySQL 8.4 (CI), PHPUnit 11.

**Spec:** `docs/superpowers/plans/2026-09-22-microservices-roadmap.md` (Bước 2), `docs/HANDOVER_2026-09-22.md`.

## Global Constraints

- **Không đụng database của Moodle** (cùng server MariaDB). Mọi lệnh SQL trên prod chỉ chạm các bảng liệt kê trong `TableOwnership` (Task 1).
- **Không `migrate:fresh`/`db:wipe` trên prod.** Không xoá cột. FK chỉ được drop ở Task 4 (2 FK service↔service, giữ nguyên cột và index).
- Phần 2A (Task 1–6) phải giữ prod chạy y như cũ: mọi connection vẫn trỏ về `eduka_v2` cho tới Task 8.
- Ranh giới này **cho phép** FK và `DbRef` JOIN từ service sang bảng core (users, units, classes, subjects, classrooms, instructors, schedule_details, standard_positions, academic_years, …) — hợp lệ vì cùng server. Chúng thành nợ của Bước 5 (tách server), không phải của bước này.
- 12 dòng còn lại trong `tests/Unit/Architecture/cross-service-baseline.txt` (core đọc model của service) **không hỏng** khi tách schema trên cùng server (model tự mang connection). Để Bước 5.
- Nhánh: `step2-database-split` từ `main`. Commit từng task. `vendor/bin/pint --dirty` trước commit. `git add <file cụ thể>`.
- Trong phiên agent: tool Bash nuốt dấu `\` → sửa PHP bằng Edit, hoặc script python ghi bằng Write (xem nhật ký handover 22/09).
- Chỉ commit khi thấy dòng `Tests:` thật của PHPUnit.
- Cuối mỗi task: cập nhật `docs/HANDOVER_2026-09-22.md`.

## Số liệu xuất phát (khảo sát 23/09)

| Hạng mục | Số lượng |
|---|---|
| Bảng theo chủ sở hữu (tiền tố) | core 63 · lms 44 · tms 62 · grades 12 |
| Model service chưa gắn `$connection` | 35 (toàn bộ `Inventory` + `LeaveManagement`) |
| Migration chỉ chạm bảng 1 service | lms 41 · tms 70 · grades 8 (· core 112) — **0 cái gắn `$connection`** |
| Migration lẫn core + service | 9 |
| FK từ bảng service sang bảng khác schema | 129 — trong đó **2 FK service↔service**: `grade_books.lms_course_id → lms_courses`, `grade_books.tms_course_id → tms_courses` |
| JOIN thô sang bảng service khác | 0 (đã qua `DbRef`) |

Tiền tố (nguồn: khảo sát bảng trong `cdhc_testing` sau migrate):
- **lms**: `lms_`, `essay_exam`, `exam_organization`, `integrated_answer`
- **tms**: `tms_`, `inventory_`, `leave_`
- **grades**: `grade_`
- còn lại: **core** (kể cả `cache`, `sessions`, `jobs`, `failed_jobs`, `migrations`, `export_template*`, `campus_network_settings`)

## File Structure

| File | Trách nhiệm |
|---|---|
| `packages/cdhc2-core/src/Support/TableOwnership.php` (mới) | Nguồn duy nhất: bảng nào thuộc connection nào |
| `packages/cdhc2-core/src/Support/DbRef.php` | Thêm `forMigration()`; `ownership()` uỷ quyền `TableOwnership` |
| `tests/Unit/Architecture/ModelConnectionTest.php` (mới) | Model service phải mang đúng connection |
| `tests/Unit/Architecture/MigrationConnectionTest.php` (mới) | Migration service phải gắn đúng connection |
| `tests/Concerns/RefreshDatabase.php`, `tests/Concerns/SplitDatabase.php` (mới) | Chạy test ở chế độ tách DB |
| `database/migrations/2026_09_23_000001_drop_service_to_service_foreign_keys.php` (mới) | Bỏ 2 FK service↔service |
| `tests/Feature/CrossServiceForeignKeysTest.php` (mới) | Không còn FK service↔service |
| `app/Console/Commands/DbSplitCommand.php` (mới) | Sinh/chạy kế hoạch chuyển bảng trên prod |
| `.github/workflows/build-and-deploy.yml` | Job PHPUnit chế độ tách DB |
| `docs/runbooks/db-split.md` (mới) | Runbook prod + đường lùi |

---

## Phần 2A — Chuẩn bị trong code (không đổi hành vi prod)

### Task 1: `TableOwnership` + model mang đúng connection

**Files:**
- Create: `packages/cdhc2-core/src/Support/TableOwnership.php`
- Modify: `packages/cdhc2-core/src/Support/DbRef.php` (`ownership()`)
- Modify: 35 model trong `modules/Inventory/Models/*.php`, `modules/LeaveManagement/Models/*.php`
- Create: `tests/Unit/Architecture/ModelConnectionTest.php`

**Interfaces:**
- Produces: `TableOwnership::connectionFor(string $table): string` (trả `'mysql'|'lms'|'tms'|'grades'`), `TableOwnership::serviceConnections(): list<string>` (= `['lms','tms','grades']`), `TableOwnership::PREFIXES` (const).

- [ ] **Step 1: Test đỏ**

```php
<?php

namespace Tests\Unit\Architecture;

use App\Support\ServiceTopology;
use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Database\Eloquent\Model;
use Tests\TestCase;

/** Model cua service phai doc/ghi dung database cua service do. */
class ModelConnectionTest extends TestCase
{
    public function test_ownership_follows_prefixes(): void
    {
        $this->assertSame('lms', TableOwnership::connectionFor('lms_courses'));
        $this->assertSame('lms', TableOwnership::connectionFor('essay_exam_draws'));
        $this->assertSame('tms', TableOwnership::connectionFor('inventory_assets'));
        $this->assertSame('tms', TableOwnership::connectionFor('leave_personnel'));
        $this->assertSame('grades', TableOwnership::connectionFor('grade_books'));
        $this->assertSame('mysql', TableOwnership::connectionFor('users'));
        $this->assertSame('mysql', TableOwnership::connectionFor('export_templates'));
    }

    public function test_every_service_model_uses_the_connection_of_its_table(): void
    {
        $wrong = [];
        foreach (ServiceTopology::services() as $providers) {
            foreach ($providers as $provider) {
                $module = explode('\\', $provider)[1];
                foreach (glob(base_path("modules/{$module}/Models/*.php")) as $file) {
                    $class = "Modules\\{$module}\\Models\\".basename($file, '.php');
                    if (! class_exists($class) || ! is_subclass_of($class, Model::class) || (new \ReflectionClass($class))->isAbstract()) {
                        continue;
                    }
                    $model = new $class;
                    $expected = TableOwnership::connectionFor($model->getTable());
                    if (($model->getConnectionName() ?? 'mysql') !== $expected) {
                        $wrong[] = "{$class} ({$model->getTable()}): ".var_export($model->getConnectionName(), true)." != {$expected}";
                    }
                }
            }
        }

        $this->assertSame([], $wrong, "Model dung sai connection:\n".implode("\n", $wrong));
    }
}
```

Run: `php artisan test --filter=ModelConnectionTest` → FAIL (`TableOwnership` chưa có).

- [ ] **Step 2: Viết `TableOwnership`**

```php
<?php

namespace Cdhc2\Core\Support;

/**
 * Nguon duy nhat: bang nao thuoc connection nao.
 *
 * Dung cho: model/migration test, DbRef::ownership(), lenh cdhc2:db-split (Buoc 2).
 * Quy tac theo tien to — khao sat 23/09/2026: moi bang cua service deu co tien to rieng.
 */
final class TableOwnership
{
    /** @var array<string, list<string>> connection => tien to bang */
    public const PREFIXES = [
        'lms' => ['lms_', 'essay_exam', 'exam_organization', 'integrated_answer'],
        'tms' => ['tms_', 'inventory_', 'leave_'],
        'grades' => ['grade_'],
    ];

    public static function connectionFor(string $table): string
    {
        foreach (self::PREFIXES as $connection => $prefixes) {
            foreach ($prefixes as $prefix) {
                if (str_starts_with($table, $prefix)) {
                    return $connection;
                }
            }
        }

        return 'mysql';
    }

    /** @return list<string> */
    public static function serviceConnections(): array
    {
        return array_keys(self::PREFIXES);
    }
}
```

Trong `DbRef::ownership()`: giữ chữ ký, thân hàm thành gọi `TableOwnership::connectionFor()` cho danh sách bảng hiện có (để `cdhc2:db-topology` không đổi output):

```php
    public static function ownership(): array
    {
        $tables = ['users', 'units', 'classes', 'subjects', 'instructors', 'buildings', 'classrooms',
            'training_schedules', 'schedule_details', 'teaching_assignment', 'academic_years', 'specializations',
            'tms_courses', 'tms_assignments', 'tms_materials', 'tms_attachments',
            'lms_courses', 'lms_lessons', 'lms_exam_questions', 'essay_exams', 'exam_organization_plans',
            'grade_books', 'grade_columns', 'grade_cells', 'grade_graduation_profiles'];

        return array_combine($tables, array_map(TableOwnership::connectionFor(...), $tables));
    }
```

(Lưu ý: bản cũ ghi `graduation_profiles` — bảng thật tên `grade_graduation_profiles`.)

- [ ] **Step 3: Gắn connection cho 35 model** — script (ghi bằng Write, chạy python):

```python
import glob, re
for mod in ['Inventory', 'LeaveManagement']:
    for p in glob.glob(f'modules/{mod}/Models/*.php'):
        s = open(p, encoding='utf-8').read()
        if 'protected $connection' in s:
            continue
        s2, n = re.subn(r"(class \w+ extends [^{]+\{\n)", r"\1    protected $connection = 'tms';\n\n", s, count=1)
        if n:
            open(p, 'w', encoding='utf-8', newline='\n').write(s2)
            print('ok', p)
        else:
            print('KIEM TAY', p)
```

Mọi file in `KIEM TAY` sửa bằng Edit.

- [ ] **Step 4: Chạy** `php artisan test --filter="ModelConnectionTest|Inventory|Leave"` → PASS (monolith: `tms` alias về `mysql`, hành vi không đổi).

- [ ] **Step 5: Commit** — `refactor(db): TableOwnership + model Inventory/LeaveManagement dung connection tms`.

---

### Task 2: Migration của service chạy trên connection của service

Laravel: `Migrator::runMethod()` đặt default connection = `$migration->getConnection()` trước khi gọi `up()`, nên `Schema::create(...)` bên trong tự rơi vào đúng DB. Khi chưa tách, `lms/tms/grades` alias về DB core → prod không đổi.

**Files:**
- Modify: 119 migration (lms 41, tms 70, grades 8) — thêm `protected $connection = '<svc>';`
- Modify: 9 migration lẫn — bọc phần bảng service bằng `Schema::connection('<svc>')`
- Create: `tests/Unit/Architecture/MigrationConnectionTest.php`

- [ ] **Step 1: Test đỏ** (quét tĩnh, không cần DB)

```php
<?php

namespace Tests\Unit\Architecture;

use Cdhc2\Core\Support\TableOwnership;
use PHPUnit\Framework\TestCase;

class MigrationConnectionTest extends TestCase
{
    public function test_service_migrations_declare_their_connection(): void
    {
        $root = dirname(__DIR__, 3);
        $problems = [];
        $files = array_merge(glob($root.'/database/migrations/*.php'), glob($root.'/modules/*/Database/Migrations/*.php'));

        foreach ($files as $file) {
            $code = file_get_contents($file);
            preg_match_all("/Schema::(?:create|table|dropIfExists|drop|rename)\\(\\s*'([a-z0-9_]+)'/", $code, $m);
            $owners = array_values(array_unique(array_map([TableOwnership::class, 'connectionFor'], $m[1])));
            preg_match("/protected\\s+\\\$connection\\s*=\\s*'([a-z]+)'/", $code, $declared);
            $declared = $declared[1] ?? 'mysql';

            if (count($owners) === 1 && $owners[0] !== $declared) {
                $problems[] = basename($file)." : bang cua '{$owners[0]}' nhung migration chay tren '{$declared}'";
            }
            if (count($owners) > 1) {
                // Migration lan: bang cua service phai qua Schema::connection('<svc>')->create(...).
                // Loi goi dang `Schema::connection(...)->create(` khong khop mau `Schema::create(`
                // ben duoi, nen chi con lai cac loi goi tran (sai).
                preg_match_all("/Schema::(?:create|table|dropIfExists|drop)\\(\\s*'([a-z0-9_]+)'/", $code, $bare);
                foreach ($bare[1] as $table) {
                    if (TableOwnership::connectionFor($table) !== $declared) {
                        $problems[] = basename($file)." : bang '{$table}' phai dung Schema::connection('".TableOwnership::connectionFor($table)."')";
                    }
                }
            }
        }

        $this->assertSame([], $problems, implode("\n", $problems));
    }
}
```

Run → FAIL, liệt kê ~128 dòng.

- [ ] **Step 2: Script gắn `$connection` cho migration một-service**

```python
import glob, re, sys
sys.path.insert(0, '.')
PREFIX = {'lms': ('lms_', 'essay_exam', 'exam_organization', 'integrated_answer'),
          'tms': ('tms_', 'inventory_', 'leave_'), 'grades': ('grade_',)}
def owner(t):
    for s, ps in PREFIX.items():
        if t.startswith(ps): return s
    return 'mysql'
for p in sorted(glob.glob('database/migrations/*.php') + glob.glob('modules/*/Database/Migrations/*.php')):
    s = open(p, encoding='utf-8').read()
    ts = set(re.findall(r"Schema::(?:create|table|dropIfExists|drop|rename)\(\s*'([a-z0-9_]+)'", s))
    owners = {owner(t) for t in ts}
    if len(owners) != 1 or owners == {'mysql'} or 'protected $connection' in s:
        continue
    svc = owners.pop()
    s2, n = re.subn(r"(return new class extends Migration\s*\{\n)", r"\1    protected $connection = '%s';\n\n" % svc, s, count=1)
    if not n:
        s2, n = re.subn(r"(class \w+ extends Migration\s*\{\n)", r"\1    protected $connection = '%s';\n\n" % svc, s, count=1)
    print(('ok ' if n else 'KIEM TAY ') + svc + ' ' + p)
    if n: open(p, 'w', encoding='utf-8', newline='\n').write(s2)
```

- [ ] **Step 3: Sửa tay 9 migration lẫn** — với mỗi lời gọi `Schema::create|table|drop...('<bảng service>', ...)` đổi thành `Schema::connection('<svc>')->create(...)` (tương tự `table`, `dropIfExists`, `hasTable`, `hasColumn`). Danh sách:

| Migration | Bảng service trong đó |
|---|---|
| `2026_07_17_100000_create_lms_tables.php` | lms_courses, lms_lessons, lms_course_members |
| `2026_07_18_100000_create_training_systems_and_lms_tweaks.php` | lms_courses, lms_assignments |
| `2026_07_18_140000_campus_wifi_and_attendance_network.php` | lms_attendance_sessions, lms_attendance_records |
| `2026_07_21_100000_create_grades_module_tables.php` | grade_* (export_templates giữ core) |
| `2026_08_01_100000_integrate_lms_course_foundation.php` | lms_* |
| `2026_08_04_000005_link_academic_year_across_subsystems.php` | grade_books (grades), lms_courses (lms) |
| `2026_08_26_000001_expand_inventory_locations_and_room_operations.php` | inventory_room_* (tms) |
| `2026_08_29_000000_create_tms_workflows_tables.php` | tms_* |
| `2026_08_31_000001_remove_leave_position_pollution_from_standard_positions.php` | leave_positions (tms) |

Trong các migration lẫn, `DB::table('<bảng service>')` cũng đổi thành `DB::connection('<svc>')->table(...)`.

- [ ] **Step 4: Chạy** `php artisan test --filter=MigrationConnectionTest` → PASS; rồi `php artisan migrate:fresh --env=testing` + `php artisan test` → xanh như trước (monolith, alias).

- [ ] **Step 5: Commit** — `refactor(db): migration cua service chay tren connection cua service`.

---

### Task 3: FK trỏ sang schema khác được định danh đầy đủ

Khi tách DB, `constrained('classes')` trong migration chạy trên connection `lms` sẽ tìm bảng `classes` **trong DB lms** → lỗi. MariaDB/MySQL cho FK xuyên schema trên cùng server nếu ghi `db.table`.

**Files:**
- Modify: `packages/cdhc2-core/src/Support/DbRef.php` — thêm `forMigration()`
- Modify: migration service có FK sang bảng khác chủ (script)
- Test: `tests/Unit/DbRefForMigrationTest.php`

**Interfaces:**
- Produces: `DbRef::forMigration(string $table, ?string $from = null): string` — tên bảng trần nếu `$table` nằm cùng database với connection `$from` (mặc định: **default connection hiện tại**, mà Migrator đã đặt = connection của migration), ngược lại `database.table`. Migration lẫn truyền `$from` tường minh.

- [ ] **Step 1: Test đỏ**

```php
<?php

namespace Tests\Unit;

use Cdhc2\Core\Support\DbRef;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class DbRefForMigrationTest extends TestCase
{
    public function test_bare_name_when_same_database(): void
    {
        $this->assertSame('classes', DbRef::forMigration('classes'));
    }

    public function test_qualified_name_when_migration_runs_on_another_database(): void
    {
        config(['database.connections.lms.database' => 'cdhc_testing_lms']);
        $previous = DB::getDefaultConnection();
        DB::setDefaultConnection('lms');

        try {
            $this->assertSame(config('database.connections.mysql.database').'.classes', DbRef::forMigration('classes'));
            $this->assertSame('lms_courses', DbRef::forMigration('lms_courses'));
        } finally {
            DB::setDefaultConnection($previous);
        }
    }

    public function test_explicit_source_connection_for_mixed_migrations(): void
    {
        config(['database.connections.lms.database' => 'cdhc_testing_lms']);

        // Default connection van la mysql, nhung bang dang tao nam o lms.
        $this->assertSame(config('database.connections.mysql.database').'.classes', DbRef::forMigration('classes', 'lms'));
        $this->assertSame('classes', DbRef::forMigration('classes'));
    }
}
```

- [ ] **Step 2: Cài đặt** (thêm vào `DbRef`)

```php
    /**
     * Ten bang cho FK trong migration. Migrator dat default connection = connection
     * cua migration, nen so sanh voi database cua default connection hien tai.
     */
    public static function forMigration(string $table, ?string $from = null): string
    {
        $target = static::databaseFor(TableOwnership::connectionFor($table));
        $current = static::databaseFor($from ?? DB::getDefaultConnection());

        return ($target === '' || $target === $current) ? $table : $target.'.'.$table;
    }
```

- [ ] **Step 3: Script đổi FK trong migration service** — chỉ đổi khi bảng được tham chiếu **khác chủ** với connection của migration:

```python
import glob, re
PREFIX = {'lms': ('lms_', 'essay_exam', 'exam_organization', 'integrated_answer'),
          'tms': ('tms_', 'inventory_', 'leave_'), 'grades': ('grade_',)}
def owner(t):
    for s, ps in PREFIX.items():
        if t.startswith(ps): return s
    return 'mysql'
for p in sorted(glob.glob('database/migrations/*.php') + glob.glob('modules/*/Database/Migrations/*.php')):
    s = open(p, encoding='utf-8').read()
    m = re.search(r"protected \$connection = '([a-z]+)'", s)
    if not m: continue
    mine = m.group(1)
    def fix(mt):
        kw, t = mt.group(1), mt.group(2)
        return mt.group(0) if owner(t) == mine else f"{kw}(\\Cdhc2\\Core\\Support\\DbRef::forMigration('{t}'))"
    s2 = re.sub(r"(constrained|->on)\(\s*'([a-z0-9_]+)'\s*\)", fix, s)
    if s2 != s:
        open(p, 'w', encoding='utf-8', newline='\n').write(s2); print('ok', p)
```

Dạng `foreignId('unit_id')->constrained()` (không tham số) mà bảng suy ra khác chủ: script trên không bắt — tìm bằng `grep -n "constrained()" <migration service>` và thêm tham số `DbRef::forMigration('<bảng>')` bằng tay.

Migration lẫn (Task 2 Step 3): `Schema::connection('<svc>')` **không** đổi default connection, nên FK trong khối đó phải truyền nguồn tường minh: `->constrained(DbRef::forMigration('classes', 'lms'))`. Sửa tay 9 file này (script trên bỏ qua chúng vì không có `protected $connection`).

- [ ] **Step 4: Chạy** `php artisan test --filter=DbRefForMigrationTest` → PASS; `php artisan test` (monolith) → xanh như trước.

- [ ] **Step 5: Commit** — `refactor(db): FK sang schema khac dung DbRef::forMigration`.

---

### Task 4: Bỏ 2 FK service↔service

`grade_books.lms_course_id → lms_courses` và `grade_books.tms_course_id → tms_courses`: dữ liệu của hai service **khác** nhau ràng buộc cứng. Giữ cột + index, bỏ ràng buộc; toàn vẹn do code (`GradeTransferContract`) lo.

**Files:**
- Create: `database/migrations/2026_09_23_000001_drop_service_to_service_foreign_keys.php`
- Create: `tests/Feature/CrossServiceForeignKeysTest.php`

- [ ] **Step 1: Test đỏ** — đọc `information_schema`, chỉ cấm FK giữa **hai service** (service → core được phép ở bước này):

```php
<?php

namespace Tests\Feature;

use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class CrossServiceForeignKeysTest extends TestCase
{
    use RefreshDatabase;

    public function test_no_foreign_key_between_two_services(): void
    {
        $rows = DB::select('SELECT table_name AS t, referenced_table_name AS r, constraint_name AS c
            FROM information_schema.referential_constraints
            WHERE constraint_schema IN (?, ?, ?, ?)', [
            config('database.connections.mysql.database'), config('database.connections.lms.database'),
            config('database.connections.tms.database'), config('database.connections.grades.database'),
        ]);

        $bad = [];
        foreach ($rows as $row) {
            $from = TableOwnership::connectionFor($row->t ?? $row->T);
            $to = TableOwnership::connectionFor($row->r ?? $row->R);
            if ($from !== 'mysql' && $to !== 'mysql' && $from !== $to) {
                $bad[] = ($row->c ?? $row->C)." ({$from} -> {$to})";
            }
        }

        $this->assertSame([], array_values(array_unique($bad)), implode("\n", $bad));
    }
}
```

Run → FAIL: `grade_books_lms_course_id_foreign (grades -> lms)`, `grade_books_tms_course_id_foreign (grades -> tms)`. (Nếu tên constraint khác, lấy tên thật từ thông báo lỗi cho Step 2.)

- [ ] **Step 2: Migration**

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Bo rang buoc cung giua du lieu cua hai service khac nhau (grades -> lms, grades -> tms).
 * Giu cot va index; toan ven do GradeTransferContract dam bao. Chay lai an toan.
 */
return new class extends Migration
{
    protected $connection = 'grades';

    public function up(): void
    {
        foreach (['lms_course_id', 'tms_course_id'] as $column) {
            if (! Schema::hasColumn('grade_books', $column)) {
                continue;
            }
            $name = "grade_books_{$column}_foreign";
            $exists = collect(Schema::getForeignKeys('grade_books'))->contains(fn ($fk) => $fk['name'] === $name);
            if ($exists) {
                Schema::table('grade_books', function (Blueprint $table) use ($name, $column) {
                    $table->dropForeign($name);
                    $table->index($column);
                });
            }
        }
    }

    public function down(): void
    {
        // Co y khong tao lai: FK xuyen service la dieu Buoc 2 muon loai bo.
    }
};
```

- [ ] **Step 3: Chạy** `php artisan test --filter="CrossServiceForeignKeysTest|Grade"` → PASS.

- [ ] **Step 4: Commit** — `refactor(db): bo FK grade_books -> lms_courses/tms_courses`.

Rủi ro prod: migration chạy trong initContainer lần deploy kế tiếp; chỉ drop 2 constraint, không đụng dữ liệu. Nếu `index($column)` báo trùng (index đã tồn tại do FK tạo) thì bỏ dòng `index` — kiểm bằng `Schema::getIndexes('grade_books')` trên DB test trước khi merge.

---

### Task 5: Chạy bộ test ở chế độ tách DB

**Files:**
- Create: `tests/Concerns/SplitDatabase.php`, `tests/Concerns/RefreshDatabase.php`
- Modify: mọi test đang `use Illuminate\Foundation\Testing\RefreshDatabase;` → `use Tests\Concerns\RefreshDatabase;` (script, 66+ file)
- Modify: `composer.json` (script `test:split`)
- Modify: `.github/workflows/build-and-deploy.yml` (job `phpunit-split`, **chưa chặn deploy**: `continue-on-error: true`)

Hai lý do phải có trait riêng:
1. Hook của `RefreshDatabase` định nghĩa **trong trait** của Laravel nên lớp cha `Tests\TestCase` không ghi đè được.
2. **Không dùng được transaction** ở chế độ tách DB: 4 connection là 4 PDO/phiên riêng; test tạo `users` (phiên core, chưa commit) rồi tạo `lms_courses` có FK tới `users` (phiên lms) → InnoDB chờ khoá → `Lock wait timeout exceeded` (đúng lỗi `CoreServiceProvider::aliasUnsplitConnections()` đã ghi). Nên ở chế độ tách: migrate **một lần**, chụp mốc dữ liệu có sẵn sau migrate (seed trong migration), và **dọn về mốc sau mỗi test**.

- [ ] **Step 1: Helper**

```php
<?php

namespace Tests\Concerns;

use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class SplitDatabase
{
    /** @var array<string, array<string, int|null>> connection => [bang => max id luc chup moc; null = rong] */
    private static array $baseline = [];

    /** Bat bang CDHC2_TEST_SPLIT_DB=1 va DB_{LMS,TMS,GRADES}_DATABASE khac DB_DATABASE. */
    public static function enabled(): bool
    {
        return getenv('CDHC2_TEST_SPLIT_DB') === '1';
    }

    /** @return list<string> */
    public static function connections(): array
    {
        return TableOwnership::serviceConnections();
    }

    /** @return list<string> connection mac dinh + 3 connection service */
    public static function allConnections(): array
    {
        return [config('database.default'), ...self::connections()];
    }

    public static function dropServiceTables(): void
    {
        foreach (self::connections() as $connection) {
            Schema::connection($connection)->dropAllTables();
        }
    }

    /** Chup moc ngay sau migrate: bang nao da co du lieu seed thi nho max(id). */
    public static function snapshot(): void
    {
        self::$baseline = [];
        foreach (self::allConnections() as $connection) {
            foreach (Schema::connection($connection)->getTableListing(schemaQualified: false) as $table) {
                if ($table === 'migrations') {
                    continue;
                }
                $db = DB::connection($connection);
                $hasRows = $db->table($table)->exists();
                self::$baseline[$connection][$table] = ! $hasRows ? null
                    : (Schema::connection($connection)->hasColumn($table, 'id') ? (int) $db->table($table)->max('id') : PHP_INT_MAX);
            }
        }
    }

    /** Dua moi bang ve moc: bang rong luc chup -> TRUNCATE; bang co seed -> xoa dong moi (id > moc). */
    public static function cleanUp(): void
    {
        foreach (self::$baseline as $connection => $tables) {
            $db = DB::connection($connection);
            $db->statement('SET FOREIGN_KEY_CHECKS=0');
            try {
                foreach ($tables as $table => $maxId) {
                    if ($maxId === null) {
                        $db->table($table)->truncate();
                    } elseif ($maxId !== PHP_INT_MAX) {
                        $db->table($table)->where('id', '>', $maxId)->delete();
                    }
                    // PHP_INT_MAX: bang co seed nhung khong co cot id (vd. pivot quyen) — giu nguyen.
                }
            } finally {
                $db->statement('SET FOREIGN_KEY_CHECKS=1');
            }
        }
    }
}
```

```php
<?php

namespace Tests\Concerns;

use Illuminate\Foundation\Testing\RefreshDatabase as LaravelRefreshDatabase;
use Illuminate\Foundation\Testing\RefreshDatabaseState;

/**
 * Monolith: y het RefreshDatabase cua Laravel (transaction moi test).
 * Tach DB (CDHC2_TEST_SPLIT_DB=1): migrate mot lan cho ca 4 database, chup moc,
 * khong dung transaction, don ve moc sau moi test.
 */
trait RefreshDatabase
{
    use LaravelRefreshDatabase {
        refreshDatabase as laravelRefreshDatabase;
    }

    public function refreshDatabase()
    {
        if (! SplitDatabase::enabled()) {
            $this->laravelRefreshDatabase();

            return;
        }

        if (! RefreshDatabaseState::$migrated) {
            // migrate:fresh chi xoa bang cua database mac dinh -> tu xoa 3 database service.
            SplitDatabase::dropServiceTables();
            $this->artisan('migrate:fresh', $this->migrateFreshUsing());
            SplitDatabase::snapshot();
            RefreshDatabaseState::$migrated = true;
        }

        $this->beforeApplicationDestroyed(fn () => SplitDatabase::cleanUp());
    }
}
```

Giới hạn đã biết của cách dọn này: bảng seed không có cột `id` bị test ghi thêm thì dòng thêm không được dọn — nếu gặp test phụ thuộc thứ tự vì lý do này, bổ sung bảng đó vào `cleanUp()` theo khoá riêng của nó.

- [ ] **Step 2: Đổi import trong test** (script python: thay đúng dòng `use Illuminate\Foundation\Testing\RefreshDatabase;` bằng `use Tests\Concerns\RefreshDatabase;` trong `tests/**/*.php`). Chạy `php artisan test` (monolith) → xanh như trước.

- [ ] **Step 3: Script composer**

```json
"test:split": [
    "@putenv CDHC2_TEST_SPLIT_DB=1",
    "@putenv DB_LMS_DATABASE=cdhc_testing_lms",
    "@putenv DB_TMS_DATABASE=cdhc_testing_tms",
    "@putenv DB_GRADES_DATABASE=cdhc_testing_grades",
    "@php artisan config:clear --ansi",
    "@php artisan test"
]
```

Tạo 3 DB test local một lần: `mysql -h127.0.0.1 -P3307 -uroot -p -e "CREATE DATABASE IF NOT EXISTS cdhc_testing_lms; CREATE DATABASE IF NOT EXISTS cdhc_testing_tms; CREATE DATABASE IF NOT EXISTS cdhc_testing_grades;"`

- [ ] **Step 4: Job CI** — nhân bản job PHPUnit hiện có thành `phpunit-split`: thêm bước tạo 3 database bằng `mysql` client trước `php artisan test`, và các biến `CDHC2_TEST_SPLIT_DB=1`, `DB_LMS_DATABASE=cdhc_testing_lms`, `DB_TMS_DATABASE=cdhc_testing_tms`, `DB_GRADES_DATABASE=cdhc_testing_grades`. `continue-on-error: true`; build/deploy **không** `needs` job này.

- [ ] **Step 5: Chạy** `composer test:split`, lưu output. Ghi số test đỏ + nhóm lỗi vào handover. Commit — `test(db): che do chay test tach database`.

---

### Task 6: Sửa truy vấn chạy chéo connection cho tới khi `test:split` xanh

Khi tách DB, Eloquent sinh subquery **trên connection của model cha** với tên bảng trần của model con → lỗi `Table '...' doesn't exist`. Dự kiến gặp ở `whereHas`/`has`/`withCount`/`whereDoesntHave`/`orderBy` subquery giữa model service và model core (ví dụ `LmsCourse::whereHas('class')`, `Classroom::withCount('inventoryAssets')`).

Quy trình cho **mỗi** test đỏ của Task 5:
1. Đọc SQL trong lỗi, xác định bảng nằm sai DB.
2. Chọn một trong 3 cách sửa, theo thứ tự ưu tiên:

**(a) Hai bước bằng id** (mặc định, không phụ thuộc cùng server):

```php
// Truoc: LmsCourse::whereHas('class', fn ($q) => $q->where('unit_id', $unitId))
$classIds = ClassModel::where('unit_id', $unitId)->pluck('id');
LmsCourse::whereIn('class_id', $classIds);
```

**(b) Subquery định danh bằng `DbRef`** (khi danh sách id có thể rất lớn):

```php
LmsCourse::whereExists(fn ($q) => $q->selectRaw('1')
    ->from(DbRef::core('classes').' as c')
    ->whereColumn('c.id', 'lms_courses.class_id')
    ->where('c.unit_id', $unitId));
```

**(c) `withCount` chéo** → đếm riêng rồi gắn:

```php
$counts = InventoryAsset::whereIn('classroom_id', $rooms->pluck('id'))
    ->selectRaw('classroom_id, count(*) as n')->groupBy('classroom_id')->pluck('n', 'classroom_id');
$rooms->each(fn ($r) => $r->inventory_assets_count = (int) ($counts[$r->id] ?? 0));
```

3. Chạy lại test đó ở cả hai chế độ (`php artisan test --filter=...` và `composer test:split -- --filter=...`), commit từng nhóm nhỏ.

Điều kiện xong Task 6: `composer test:split` xanh toàn bộ **và** `php artisan test` (monolith) xanh. Khi đó bỏ `continue-on-error` ở job `phpunit-split` và cho `build-and-push-ghcr` `needs: [phpunit, phpunit-split]`.

---

## Phần 2B — Chuyển prod (cần chủ dự án thực hiện/duyệt từng bước)

### Task 7: Lệnh `cdhc2:db-split`

**Files:**
- Create: `app/Console/Commands/DbSplitCommand.php`
- Test: `tests/Feature/DbSplitCommandTest.php`

**Hành vi:**
- `php artisan cdhc2:db-split --plan` (mặc định): đọc bảng thật của DB core (`information_schema.tables`), phân theo `TableOwnership`, in: `CREATE DATABASE IF NOT EXISTS <db>` cho từng service (tên lấy từ `DB_LMS_DATABASE`… — lệnh **từ chối** nếu tên trùng DB core) và **một** câu `RENAME TABLE core.t1 TO lms.t1, core.t2 TO lms.t2, …` cho mỗi service (RENAME nhiều bảng trong một câu là nguyên tử trong MariaDB). In thêm câu RENAME ngược (đường lùi).
- `--execute --confirm-backup=<tên bản backup>`: chạy đúng các câu trên. Chặn nếu: thiếu `--confirm-backup`; có bảng không phân loại được; đích đã có bảng trùng tên.
- Không bao giờ chạm bảng không thuộc `TableOwnership` (bảo vệ DB Moodle và bảng core).

- [ ] **Step 1: Test đỏ** — dùng DB test: kiểm output `--plan` chứa `RENAME TABLE`, chứa `lms_courses` trong câu của lms, **không** chứa `users`; và `--execute` không có `--confirm-backup` trả exit code 1.

```php
<?php

namespace Tests\Feature;

use Tests\Concerns\RefreshDatabase;
use Tests\TestCase;

class DbSplitCommandTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        if (\Tests\Concerns\SplitDatabase::enabled()) {
            $this->markTestSkipped('Lenh doc bang tu DB core; o che do tach DB core khong con bang service.');
        }
        config([
            'database.connections.lms.database' => 'cdhc_plan_lms',
            'database.connections.tms.database' => 'cdhc_plan_tms',
            'database.connections.grades.database' => 'cdhc_plan_grades',
        ]);
    }

    public function test_plan_moves_only_service_tables(): void
    {
        $this->artisan('cdhc2:db-split', ['--plan' => true])
            ->expectsOutputToContain('RENAME TABLE')
            ->expectsOutputToContain('`cdhc_plan_lms`.`lms_courses`')
            ->doesntExpectOutputToContain('`users`')
            ->assertExitCode(0);
    }

    public function test_execute_requires_backup_confirmation(): void
    {
        $this->artisan('cdhc2:db-split', ['--execute' => true])->assertExitCode(1);
    }
}
```

- [ ] **Step 2: Cài đặt lệnh** (khung chính)

```php
<?php

namespace App\Console\Commands;

use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class DbSplitCommand extends Command
{
    protected $signature = 'cdhc2:db-split {--plan : Chi in ke hoach (mac dinh)} {--execute : Chay that} {--confirm-backup= : Ten ban backup vua tao}';

    protected $description = 'Chuyen bang cua lms/tms/grades tu DB core sang database rieng (RENAME TABLE, co duong lui)';

    public function handle(): int
    {
        $core = (string) config('database.connections.mysql.database');
        $targets = [];
        foreach (TableOwnership::serviceConnections() as $c) {
            $db = (string) config("database.connections.{$c}.database");
            if ($db === '' || $db === $core) {
                $this->error("Connection {$c} chua tro sang database rieng (DB_".strtoupper($c).'_DATABASE).');

                return self::FAILURE;
            }
            $targets[$c] = $db;
        }

        $tables = collect(DB::select('SELECT table_name AS t FROM information_schema.tables WHERE table_schema = ? AND table_type = ?', [$core, 'BASE TABLE']))
            ->map(fn ($r) => $r->t ?? $r->T);

        $forward = [];
        $backward = [];
        foreach ($targets as $c => $db) {
            $mine = $tables->filter(fn ($t) => TableOwnership::connectionFor($t) === $c)->values();
            if ($mine->isEmpty()) {
                continue;
            }
            $forward[] = "CREATE DATABASE IF NOT EXISTS `{$db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            $forward[] = 'RENAME TABLE '.$mine->map(fn ($t) => "`{$core}`.`{$t}` TO `{$db}`.`{$t}`")->implode(', ');
            $backward[] = 'RENAME TABLE '.$mine->map(fn ($t) => "`{$db}`.`{$t}` TO `{$core}`.`{$t}`")->implode(', ');
        }

        $this->line('-- KE HOACH CHUYEN');
        foreach ($forward as $sql) {
            $this->line($sql.';');
        }
        $this->line('-- DUONG LUI');
        foreach ($backward as $sql) {
            $this->line($sql.';');
        }

        if (! $this->option('execute')) {
            return self::SUCCESS;
        }
        if (! $this->option('confirm-backup')) {
            $this->error('Thieu --confirm-backup=<ten ban backup>. Khong chay.');

            return self::FAILURE;
        }
        foreach ($forward as $sql) {
            DB::statement($sql);
        }
        $this->info('Da chuyen. Kiem lai: php artisan cdhc2:db-topology');

        return self::SUCCESS;
    }
}
```

Lưu ý khi viết test: `--execute` không có `--confirm-backup` phải trả 1 **trước** khi chạy SQL — test Step 1 kiểm điều đó (với config trỏ DB đích giả).

- [ ] **Step 3: Chạy test** → PASS. **Step 4: Commit** — `feat(db): lenh cdhc2:db-split (ke hoach + duong lui)`.

---

### Task 8: Runbook chuyển prod

**Files:**
- Create: `docs/runbooks/db-split.md`

Runbook gồm các bước dưới; **mỗi bước có dấu (CDA) là việc chủ dự án làm hoặc duyệt** (agent không có quyền root DB / sửa secret, không nhập mật khẩu):

1. Điều kiện vào: Task 1–7 đã deploy; `phpunit-split` xanh và đang chặn deploy; handover cập nhật.
2. (CDA) Chọn giờ bảo trì. Hệ thống chưa có người dùng thật → cho phép dừng hẳn.
3. Backup: chạy workflow/lệnh `backup:run --only-db` lên S3, ghi tên bản backup.
4. (CDA) Scale `deployment/tkb-core,tkb-lms,tkb-tms,tkb-grades,tkb-scheduler` về 0. **Không đụng** `deployment/tkb`, Moodle.
5. (CDA) Trên MariaDB: tạo 3 database và cấp quyền cho user ứng dụng hiện tại trên cả 4 schema (bước này giữ **một** user; tách user theo service là việc của Bước 3):
   `CREATE DATABASE cdhc2_lms …; GRANT ALL ON cdhc2_lms.* TO '<user>'@'%';` (tương tự tms, grades).
6. Chạy `php artisan cdhc2:db-split --plan` trong một pod tạm (image hiện tại, env có `DB_LMS_DATABASE=cdhc2_lms`…), đối chiếu danh sách bảng với `TableOwnership`.
7. `php artisan cdhc2:db-split --execute --confirm-backup=<tên>`.
8. (CDA) **Thêm** vào secret `tkb-env` các key `DB_LMS_DATABASE`, `DB_TMS_DATABASE`, `DB_GRADES_DATABASE` (không xoá/sửa key `.env` hiện có).
9. Scale lại; chạy `php artisan cdhc2:db-topology` trong từng pod (exit 0); workflow `cluster-diagnostics`, `service-logs` 4 service; GET các trang chính; thử một thao tác ghi mỗi service.
10. Đường lùi (nếu bước 9 hỏng): scale 0 → chạy các câu `-- DUONG LUI` đã in ở bước 6 → gỡ 3 key vừa thêm khỏi secret → scale lại.

- [ ] **Step 1:** Viết `docs/runbooks/db-split.md` theo khung trên, điền tên workflow và lệnh `kubectl` cụ thể từ `docs/HANDOVER.md`.
- [ ] **Step 2:** Commit — `docs(runbook): chuyen prod sang database theo service`.
- [ ] **Step 3:** (CDA) Thực hiện runbook. Ghi kết quả vào handover.

---

## Điều kiện hoàn thành Bước 2

- `composer test:split` và `php artisan test` cùng xanh; job `phpunit-split` chặn deploy.
- Trên prod: `php artisan cdhc2:db-topology` ở cả 4 pod báo 3 database tách riêng, exit 0.
- `CrossServiceForeignKeysTest` xanh (0 FK service↔service).
- Runbook có đường lùi đã được kiểm bằng `--plan` trên prod trước khi `--execute`.

## Ngoài phạm vi (ghi lại để không quên)

- FK service → core (127 cái) và `DbRef` JOIN: hợp lệ khi cùng server; phải bỏ ở **Bước 5** nếu tách server.
- 12 dòng baseline "đọc model service khác" (vd. `ClassController` → `LmsCourse`): chạy được sau Bước 2; thay bằng contract đọc ở Bước 5.
- User DB riêng cho từng service, quyền tối thiểu: **Bước 3**.
- `cache`/`sessions`/`jobs` dùng chung trong DB core: **Bước 4** (queue riêng).
