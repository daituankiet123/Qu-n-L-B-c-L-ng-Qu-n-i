# Bước 4B — File người dùng lên S3, bỏ volume NFS dùng chung: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Không deployment nào mount PVC `tkb-storage`; file người dùng (upload, tài liệu, bài nộp, mẫu xuất) nằm trên object storage; `tkb-lms` chạy 2 replica mà upload/tải về vẫn đúng.

**Architecture:** Một disk logic duy nhất cho file người dùng: `config('filesystems.files_disk')` (env `FILES_DISK`, mặc định `public` → dev/monolith không đổi). Code module thôi gọi cứng `Storage::disk('public')` mà đi qua disk này (hoặc cột `disk` sẵn có trên model). Trên cụm đặt `FILES_DISK` = disk S3 **đã được spike xác nhận dùng được** (Task 1). Dữ liệu cũ chuyển bằng `storage:migrate-s3` (đã có) mở rộng + xác minh md5 bằng `get()`. Log ra stdout, file tạm ra `emptyDir`, cuối cùng gỡ PVC khỏi manifest.

**Tech Stack:** Laravel filesystem (Flysystem), driver `viettel-s3` hiện có và/hoặc `league/flysystem-aws-s3-v3`, PHPUnit, k8s.

**Spec:** roadmap dòng Bước 4 + `docs/HANDOVER.md` mục 4.1 (bẫy driver S3).

## Global Constraints

- Như 4A. Thêm: **không đổi driver/cấu hình disk `s3` đang dùng cho backup** (`config/backup.php`, `VerifyBackup`); disk mới (nếu cần) là disk **riêng**.
- **Không dùng `exists()`/`size()`/`files()`/`lastModified()` trên disk `viettel-s3`** — driver trả sai (exists luôn true, size 0, list rỗng). Xác minh bằng `get()` + md5.
- Không xoá file trên PVC cho tới khi chủ dự án xác nhận sau nghiệm thu (giữ làm bản lùi ≥ 2 tuần).

## Hiện trạng (khảo sát 25/09)

- PVC `tkb-storage` (NFS, `ReadWriteOnce`, 20Gi) mount `/var/www/storage/app` + `storage/logs` (subPath `_service-logs`) ở **mọi** deployment. RWO trên 1 node thì chạy được; lên nhiều node (Bước 5) là vỡ.
- Gọi cứng `disk('public')` (≈54 chỗ): Lms 18, StandardHours 9, EssayExam 5, Inventory 4, Tms 4, User 4, app 6. `storage_path/public_path` cho file nghiệp vụ: TrainingSchedule 6, ExportTemplates 5, packages 6 (StorageHelper), app 2.
- Model có cột `disk` (đã hỗ trợ đa disk): `LmsMaterial`, `LmsAssignmentSubmission(+Version)`, `TmsMaterial`, `TmsAttachment`, `ExportTemplateVersion`, `LeaveReportTemplate` — đúng danh sách của `storage:migrate-s3`.
- `StorageHelper` (packages) đã có `downloadToTemp`, `getContents`, `fileUrl` (nhánh s3 = URL ký tạm) — 26 file đang dùng.
- Scheduler ghi `->appendOutputTo(storage_path('logs/...'))` (`bootstrap/app.php:105-140`).

---

### Task 1: Spike S3 — **điểm dừng, chủ dự án chọn driver**

**Files:** Create `app/Console/Commands/S3Probe.php` (chỉ ghi/xoá dưới tiền tố `_probe/`), workflow step trong `cluster-diagnostics.yaml` (hoặc `s3-probe.yaml` riêng).

- [ ] **Step 1:** Lệnh `cdhc2:s3-probe {disk}` in bảng kết quả cho từng thao tác trên disk được chỉ định, với file 1 KB và 5 MB ngẫu nhiên: `put` → `get` (so md5) → `readStream` (so md5) → `size` → `mimeType` → `temporaryUrl` (curl từ pod: HTTP 200 + md5) → `url` → `delete` → `get` sau delete (phải lỗi/null) → `exists` file không tồn tại (phải false). Không in secret.
- [ ] **Step 2:** Chạy với disk `s3` (viettel) trên cụm. Kết quả mong đợi theo HANDOVER 4.1: `exists`/`size` sai.
- [ ] **Step 3:** Thêm tạm disk `s3files` dùng `league/flysystem-aws-s3-v3` (driver `s3` chuẩn của Laravel) với **cùng** endpoint/bucket/khoá Viettel (`use_path_style_endpoint=true`), chạy lại probe. (Cần `composer require league/flysystem-aws-s3-v3` — PR riêng, không đổi disk `s3` cũ.)
- [ ] **Step 4: DỪNG — báo chủ dự án bảng so sánh** và đề xuất: nếu `s3files` qua hết → dùng nó cho file người dùng (đầy đủ API, không phải né `exists/size`); nếu không → dùng `viettel-s3` + quy ước "chỉ put/get/delete/temporaryUrl" + test canh giữ cấm các hàm hỏng. Ghi quyết định vào handover. **Các task sau dùng `FILES_DISK=<disk đã chọn>`.**

### Task 2: Disk logic `files` + test canh giữ

**Files:** Modify `config/filesystems.php`; Create `tests/Unit/Architecture/UserFilesDiskTest.php`.

- [ ] **Step 1: Test (RED):** quét `modules/**/*.php`, `app/**/*.php` (trừ `Console/Commands/MigrateStorageToS3.php`, `VerifyBackup.php`, backup): không còn `disk('public')` / `Storage::disk("public")` ngoài danh sách cho phép có lý do (vd. asset tĩnh công khai thật sự). Ban đầu FAIL với ≈54 chỗ — test in danh sách theo module làm checklist cho Task 3.
- [ ] **Step 2:** `config/filesystems.php`: `'files_disk' => env('FILES_DISK', 'public'),` + helper `App\Support\UserFiles::disk(): Filesystem` và `UserFiles::name(): string`.
- [ ] **Step 3:** Commit (test đánh dấu `markTestIncomplete` cho tới hết Task 3 để CI không đỏ — hoặc allowlist tạm từng file, gỡ dần). Chọn allowlist tạm: mỗi PR Task 3 xoá file của mình khỏi allowlist.

### Task 3: Chuyển code module sang disk `files` — **mỗi module 1 PR** (deploy độc lập của Bước 3: chỉ service đó rollout)

Thứ tự (ít rủi ro → nhiều): Tms → Inventory → StandardHours → EssayExam → User → Lms → ExportTemplates/TrainingSchedule (pipeline Word/PDF qua LibreOffice: tải về temp bằng `StorageHelper::downloadToTemp`, xử lý, `putContents` lên lại).

Mỗi PR:
- [ ] Thay `Storage::disk('public')` → `UserFiles::disk()`; khi lưu model có cột `disk` → ghi `UserFiles::name()`; đọc file cũ luôn theo cột `disk` của bản ghi (file cũ vẫn ở `public` cho tới Task 4).
- [ ] Link tải: thay URL `/storage/...` (nginx sidecar phục vụ từ PVC) bằng `StorageHelper::fileUrl($disk, $path)` hoặc route tải có kiểm quyền (`response()->streamDownload` từ `readStream`).
- [ ] Test feature cho luồng upload + tải của module với `Storage::fake('files')` + `FILES_DISK=files`, và với `public` (monolith).
- [ ] Gỡ file khỏi allowlist của `UserFilesDiskTest`; 2 chế độ test xanh; Pint.

### Task 4: Chuyển dữ liệu cũ

**Files:** Modify `app/Console/Commands/MigrateStorageToS3.php`; workflow `storage-migrate.yaml` (dry-run mặc định, `confirm=CHUYEN-FILE` để chạy thật).

- [ ] Mở rộng: bảng/cột của mọi file mà Task 3 chạm (không chỉ 7 model); `--dry-run` in số file + tổng dung lượng theo bảng; chạy thật: `writeStream` → `get()` so md5 với bản trên PVC → mới cập nhật cột `disk`/đường dẫn; ghi CSV kết quả vào log; **không xoá** file nguồn.
- [ ] Nghiệm thu: số bản ghi `disk=<files>` = số file dry-run; lấy mẫu 20 file tải qua web khớp md5.

### Task 5: Log ra stdout, file tạm ra `emptyDir`, gỡ PVC

- [ ] `LOG_CHANNEL=stderr` trên 4 service + scheduler; `appendOutputTo(storage_path('logs/...'))` → bỏ (output đã về stdout của container scheduler) và sửa `service-logs.yaml` chỉ đọc `kubectl logs`.
- [ ] `storage/app/tmp`, `storage/framework/*` → `emptyDir`.
- [ ] Gỡ `volumeMounts`/`volumes` `tkb-storage` khỏi 5 deployment; bỏ precheck PVC trong `build-and-deploy.yml`; **không xoá** PVC trên cụm (bản lùi).
- [ ] Nghiệm thu: `kubectl scale deploy/tkb-lms --replicas=2`; upload tài liệu LMS, nộp bài, tải về từ cả 2 pod (lặp 10 lần) → đều đúng; xuất Word TrainingSchedule OK; scale về 1.

### Task 6: Tài liệu

- [ ] Handover + roadmap (Bước 4 xong). Hẹn ngày chủ dự án quyết định xoá dữ liệu trên PVC.

## Quyết định cần chủ dự án

1. **Driver cho file người dùng** (Task 1 Step 4).
2. **Thời hạn giữ PVC** sau khi chuyển (đề xuất ≥ 2 tuần).
3. File mẫu/asset nào thật sự công khai (được phép giữ `public` + URL tĩnh).
