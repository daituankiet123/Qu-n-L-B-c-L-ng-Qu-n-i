# Service mới "Bậc lương QNCN" (chuyển từ MS Access QLNL) — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (chủ dự án chỉ định) hoặc superpowers:subagent-driven-development để thực hiện plan task-by-task. Steps dùng checkbox (`- [ ]`).

**Goal:** Đưa phần mềm Access *Quản lý nâng bậc lương QNCN* (`QLNL.accdb`) lên web thành **service thứ 5** — pod riêng, DB riêng, pipeline riêng, như lms/tms/grades — có nút riêng trên thanh chuyển cổng (header). Đây đồng thời là **bài kiểm tra kiến trúc microservices**: thêm một tính năng mới mà không phải sửa/khởi động lại service khác.

**Architecture:** Service key `salary`, connection `salary`, DB `cdhc2_salary`, tiền tố bảng `salary_`, route `/salary`, deployment `tkb-salary`. Không lặp tài nguyên đã có: quân nhân là **Người dùng** (`users`), đơn vị `units`, quân hàm `military_ranks` — đều của core, đọc trực tiếp (mọi service đọc được core); in ấn qua `ExportTemplates` (module nền tảng, service nào cũng nạp) với data provider riêng. Toàn bộ quy tắc nâng lương viết thành **một lớp tính toán thuần** (không DB) có test bám sát từng query của Access. Ghi chéo service (thăng quân hàm → `users.military_rank_id`) đi qua job `DeliverInternalCall` của Bước 4A tới endpoint nội bộ của **core**.

**Tech Stack:** Laravel 12, module custom (`php artisan module:scaffold Salary`), MariaDB schema-per-service, `ExportTemplates` (Word/Excel + LibreOffice PDF), Alpine.js + Tailwind v4 + Apple Design System của dự án, TypeSafe (chỉ 1 bước AI, xem Task 6), GitHub Actions + k8s.

**Spec / nguồn:** `C:\Users\Admin\Downloads\QLNBL\QLNBL\QLNL.accdb` (26 bảng, 87 query, 41 form, 43 report, 29 module VBA — đã xuất bằng Access 16 COM, macro tắt, trên bản sao). Bản xuất: scratchpad `qlnl/` (`schema.md`, `queries.sql`, `forms/`, `reports/`, `data/*.tsv` — **chỉ danh mục, không dữ liệu cá nhân**). Task 0 chép phần cần giữ vào `docs/salary/access-spec/`.

## Quyết định của chủ dự án (25/09) — ưu tiên hơn mọi chỗ khác trong plan

1. **Tên:** service `salary`, đường dẫn `/salary`; nút trên thanh chuyển cổng ghi **"QL Bậc Lương QNCN"** (tên đầy đủ: Quản Lý Bậc Lương QNCN).
2. **Giá trị bảng lương tuỳ chỉnh được, không hard-code:** bảng lương (hệ số, quân hàm, số bậc) sửa trên giao diện, có **phiên bản theo ngày hiệu lực** và **kiểm tra tự động** (hệ số phải tăng dần theo bậc trong cùng loại/nhóm; bậc không trùng; mã = loại+nhóm+bậc). Dòng `TC7/10` của Access (bậc 6/10, hệ số 5) bị kiểm tra đánh dấu lỗi khi import; người dùng sửa trên màn hình Bảng lương (quy luật TC là +0,3/bậc nên giá trị **gợi ý** là bậc `7/10`, hệ số `5,3` — chỉ là gợi ý hiển thị, **không** tự ghi). Ngưỡng/thời hạn (5,4; 2/3 năm; vượt khung 5%, +1%/năm) là **cấu hình**, xem mục 5.
3. **TypeSafe được phép** dùng cho đối chiếu quân nhân (gửi họ tên, năm sinh, đơn vị, cấp bậc, chức vụ). Vẫn cần người xác nhận trước khi liên kết.
4. **Danh sách quản lý = MỌI người dùng có cấp bậc QNCN** (`users.military_rank_id` ∈ `military_ranks.group_key = professional`, mã `qpc_*`) — tự động, không nhập/tạo user; hồ sơ lương trống tự tạo (`QncnRoster::syncProfiles`). **Nguồn quân nhân = Người dùng (`users`, core)** — KHÔNG dùng `leave_personnel`. `salary_profiles.user_id` (không FK chéo DB). Ngày sinh, ngày nhập ngũ (users không có) lưu trong `salary_profiles`. Quân nhân có trong Access mà chưa có user → **chỉ báo thiếu** ở màn hình import, KHÔNG tạo user (chủ dự án chốt lại 25/09 tối); admin tạo user ở module Người dùng rồi import lại. Thăng quân hàm → cập nhật `users.military_rank_id` qua job `DeliverInternalCall` tới core.
5. **Ngưỡng hệ số 5,4 và thời hạn 2/3 năm** là mặc định trong `salary_rule_settings`; **mỗi đợt được sửa** (lưu snapshot vào đợt để in lại đúng).

## Global Constraints

- Không đụng Moodle. Không `helm upgrade tkb`. Không xoá `deployment/tkb`, `service/tkb`, Ingress `tkb`, key `.env` trong `tkb-env`.
- **Bài học #417** (module Payroll của `daituankiet123` bị revert toàn bộ): mọi thay đổi qua PR nhỏ, CI xanh cả `phpunit` + `phpunit-split`; migration chạy lại được (`hasTable`/`hasColumn`), **không FK chéo DB**, không `dropIfExists` bảng đang được FK trỏ tới.
- Bảng mới đúng `TableOwnership` (tiền tố `salary_`); test kiến trúc hiện có (`RuntimeTableConnectionTest`, `MigrationConnectionTest`, `CrossConnectionRelationQueryTest`, `ModelConnectionTest`, `DeployPathFilterTest`) phải bao cả service mới — **không** thêm allowlist để né.
- Không `whereHas/withCount` xuyên connection; `DbRef` chỉ `relativeTo`; ghi chéo service qua job (4A).
- Dữ liệu quân nhân là dữ liệu nhạy cảm: không in ra log/CI; import từ Access chạy trên cụm, file tạm xoá sau khi xong.
- Quyền theo `module.action`: `salary.index/show/create/edit/delete/approve/export`; khai báo **chỉ** trong `SyncPermissionsAndRoles`.
- Sau mỗi task: cập nhật `docs/HANDOVER_2026-09-22.md`; dừng khi usage 5h ≥ 95%.

## Phụ thuộc

- **Bước 4A Task 2–3, 6** (queue theo service + `DeliverInternalCall` + worker) phải xong trước Task 5 apply + Task 6 tạo user (ghi sang core qua job). Task 1–6 làm song song được.
- Bước 4B (S3) **không** chặn: service này không có upload file người dùng ngoài file import Access (xử lý tạm, không lưu).

---

## Đặc tả nghiệp vụ rút từ Access (nguồn sự thật cho test)

**Bảng lương** (`BANG LUONG`, 42 dòng): `Maso_Luong = KyhieuLoai & Nhom & Bac` (vd `CC13/12`), Loại ∈ {Cao cấp CC, Trung cấp TC, Sơ cấp SC}, Nhóm (CC: 1/2; TC/SC: rỗng), Bậc dạng `k/n` (bậc/số bậc tối đa: CC `/12`, TC·SC `/10`), Hệ số, Quân hàm gắn theo bậc (`KyhieuQH`: `1/CN`…`4/CN` = Thiếu uý…Đại uý QNCN, `1//CN`…`3//CN` = Thiếu tá…Thượng tá QNCN, `0/CN` Chuẩn uý).
> **Lỗi dữ liệu phát hiện:** dòng `TC7/10` có `Bac = 6/10`, `Heso = 5` (trùng TC6/10). Import phải **dừng và báo** dòng này để chủ dự án xác nhận hệ số đúng; không tự sửa.

**Bậc mới** (`Q_Danh sach kiem tra he so luong`): `k < n` → `(k+1)/n`; `k = n` → giữ nguyên.
**Thâm niên vượt khung – VKM** (%): ở bậc cuối (`k = n`) và `TNVK = 0` → **5**; ở bậc cuối và `TNVK > 0` → `TNVK + 1`; chưa ở bậc cuối → null.
**Đến hạn thường xuyên** (`Q_Danh sach den han nang luong`, form đặt `DK1 = DK2 = 5.4`, `NamLV = năm hiện tại`): mốc = `Ngaynhan_Ktra` (ngày nhận khi chuyển lương) nếu có, ngược lại `Ngaynhan_Luong`:
- `Heso < DK1` và `year(mốc) ≤ NamLV − 2`; hoặc
- `Heso ≥ DK2` và `year(mốc) ≤ NamLV − 3`; hoặc
- `TNVK ≥ 5` và `year(mốc) < year(hôm nay)` (vượt khung: xét hằng năm).
**Ngày nhận mới:** `month(mốc) / NamLV`. Có `Ngaynhan_Ktra` thì ghi chú "Chuyển lương".
**Trước thời hạn:** không được 2 lần liên tiếp (form báo "vừa được nâng trước niên hạn… không đủ điều kiện"); bắt buộc lý do + ngày nhận mới.
**Kéo dài:** bắt buộc lý do + số tháng; ngày nhận mới = mốc + số tháng.
**Chuyển loại/ngạch/nhóm:** "xếp bậc ở loại/ngạch/nhóm mới có hệ số **bằng** hệ số hiện hưởng; không có bậc bằng thì xếp bậc có hệ số **cao hơn gần nhất**"; phần chênh lệch nếu thấp hơn thì **bảo lưu** (`HS_BLC` → `HS_BLM`); bắt buộc trình độ, ngành đào tạo, năm tốt nghiệp.
**Thăng quân hàm:** khi quân hàm của bậc mới (`QHM`) khác quân hàm hiện tại (`KyhieuQH`) → quyết định ghi "Thăng quân hàm: …".
**Quy trình mỗi loại** (5 loại: Thường xuyên, Trước niên hạn, Kéo dài thời gian, Chuyển ngạch, Thường xuyên khác): Xét danh sách → Duyệt xét (chọn người) → Duyệt đề nghị (chốt ngày nhận mới) → In danh sách / phụ lục / quyết định → **Cập nhật lương mới** = (a) ghi danh sách quyết định (`L NANG LUONG`), (b) ghi quá trình lương (`QUA TRINH LUONG`, mã = `Maso_CBNV & mm & yyyy`), (c) cập nhật hồ sơ (mã lương, TNVK, bảo lưu, ngày nhận), (d) xoá cờ đề nghị. Bắt buộc số QĐ, ngày ký, người ký, chức danh người ký trước khi cập nhật.
**Mẫu quyết định** (`R_Quyet dinh nang luong thuong xuyen`…): quốc hiệu; đơn vị trên/đơn vị ra QĐ; số hiệu (`Số: … /QĐ-TCHC`); địa danh, ngày; tên QĐ theo loại (`TenQD_NL`, `_NLTH`, `_NLK`, `_CN`, `_KD`); căn cứ theo loại (`Cancu_*`); Điều 1 mỗi người: họ tên, nhập ngũ `mm/yyyy`, cấp bậc, chức vụ, đơn vị; "Từ bậc: Loại · Hệ số · TNVK · Năm nhận" → "Lên bậc: Loại · Hệ số · TNVK"; "Thăng quân hàm" nếu có; Điều 2 hiệu lực; Điều 3 thi hành; nơi nhận; chức danh + người ký; khối **Trích sao** (số, người sao, chức danh). Tham số lấy từ bảng cấu hình `Lam viec` (id=2).

**Không mang sang** (đã có trên web hoặc không thuộc nghiệp vụ lương — nguyên tắc Rams #10): `DANH MUC VAT TU` (12.081 dòng — dữ liệu kho, đã có Inventory), `HOC VIEN` (0 dòng — web có Student), `DAN TOC`, `TON GIAO`, tỉnh/huyện/xã (không dùng trong quy trình lương), `user`/`User_Account`/`MAT KHAU` (dùng đăng nhập + RBAC của web), `Copy Of …`, `_TAM`, `Paste Errors`, các module VBA đổi bảng mã VNI/TCVN3 (web dùng Unicode), chọn máy in (in qua PDF).

**Ánh xạ tài nguyên đã có (không tạo lại):**

| Access | Web đã có | Cách dùng |
|---|---|---|
| `CAN BO NHAN VIEN` (họ tên, cấp bậc, chức vụ, đơn vị, tăng/giảm) | `users` (core): `name`, `code`, `unit_id`, `military_rank_id`, `position_id`, `status` | Đọc trực tiếp (core); salary lưu `user_id`; ngày sinh/nhập ngũ lưu ở `salary_profiles` |
| `DANH MUC DON VI` | `units` (core) | `unit_id` qua personnel |
| `QUAN HAM` (QNCN) | `military_ranks` (core, `App\Models\MilitaryRank`) | Seed bổ sung hạng QNCN còn thiếu vào bảng này |
| `CHUC VU`, `CNQS` | `positions` qua `users.position_id` (core) | Hiển thị |
| `TRINH DO`, `DANH MUC NGANH/CHUYEN NGANH` | `specializations` (core) nếu khớp; phần còn lại lưu text trên hồ sơ lương | Chỉ cần cho chuyển ngạch |
| 43 report | `ExportTemplates` (Word/Excel/PDF, biến + nhân dòng bảng) | 1 data provider/loại chứng từ |
| Duyệt, thùng rác, nhật ký | `TrashService`, soft delete, `SystemNotifier` | Như module khác |

---

## Thiết kế giao diện — kết quả `design-is` (verdict: **NEW DESIGN**)

Chưa có thiết kế web → theo `design-is` bỏ qua chấm điểm, đi thẳng NEW DESIGN. Đích: Apple Design System của dự án (`.claude/skills/apple-design`, glassmorphism nhẹ, 8px grid, `-apple-system`), thêm **theme thứ 5** cho cổng Bậc lương.

- **Người dùng chính:** cán bộ Quân lực (Phòng Chính trị/Tham mưu) lập hồ sơ nâng lương; lãnh đạo duyệt/ký.
- **Việc chính:** mỗi đợt, chọn loại nâng lương → ra danh sách đúng người đến hạn → duyệt → in quyết định → áp dụng.
- **Nguyên tắc ưu tiên:** (1) **Hữu ích #2** — 1 luồng cho cả 5 loại, không 5 form gần giống nhau như Access (41 form → 7 màn hình). (2) **Dễ hiểu #4** — mỗi bước có 1 hành động chính, nhãn bằng nghiệp vụ ("Xét danh sách", "Duyệt", "In quyết định", "Áp dụng lương mới") thay vì `Chuyen DL`/`Cap nhat`. (3) **Ít thiết kế nhất #10** — 43 report → ~8 mẫu có biến theo loại; không trang trí.

**Kiến trúc thông tin (7 màn hình):**
1. **Tổng quan** `/salary` — đếm "đến hạn năm nay" theo 5 loại, đợt đang mở, việc chờ tôi duyệt.
2. **Đợt nâng lương** `/salary/rounds` → chi tiết đợt: thanh bước `Xét → Duyệt → Đề nghị → Quyết định → Áp dụng`; bảng người với cột *Từ bậc → Lên bậc* (loại · hệ số · TNVK · quân hàm), cờ lý do; hành động hàng loạt.
3. **Hồ sơ lương quân nhân** `/salary/people/{id}` — hiện hưởng + dòng thời gian quá trình lương.
4. **Bảng lương** `/salary/scales` — lưới Loại × Nhóm × Bậc, sửa hệ số/quân hàm (có hiệu lực từ ngày).
5. **Căn cứ & người ký** `/salary/settings` — theo loại quyết định (thay 5 form `F CAN CU …`).
6. **Báo cáo** `/salary/reports` — bậc lương hiện hưởng (tất cả / theo loại / theo đơn vị / theo quân nhân), thống kê nâng lương.
7. **Tra cứu quyết định** `/salary/decisions` — thay 10 report `_Timkiem`/`_Timkiem all`.

**Trạng thái bắt buộc mỗi màn hình:** trống (vd "Chưa ai đến hạn năm 2026"), đang tải, lỗi (kèm cách sửa — vd "Chưa nhập số quyết định"), thành công (toast nêu đúng việc: "Đã áp dụng lương mới cho 15 quân nhân"), focus bàn phím, vô hiệu (nút "Áp dụng" mờ + lý do khi thiếu số QĐ/người ký). **Job ghi sang core đang chờ** (core tạm lỗi) → nhãn "Đang chờ cập nhật cấp bậc" trên hồ sơ, không chặn thao tác.
**Chống lỗi:** "Áp dụng lương mới" là thao tác không hoàn tác → hộp xác nhận nêu số người + số QĐ; mọi thay đổi ghi lịch sử (quá trình lương) nên luôn truy vết được.
**Chữ:** tiếng Việt Unicode chuẩn, không viết hoa toàn câu (trừ tiêu đề văn bản in theo mẫu hành chính).

---

### Task 0: Đóng băng đặc tả Access vào repo

**Files:** Create `docs/salary/access-spec/{README.md,queries.sql,schema.md,bang-luong.tsv,can-cu.md}`

- [ ] Chép `schema.md`, `queries.sql` (87 query), `data/BANG LUONG.tsv`, nội dung căn cứ/người ký (`data/Lam viec.tsv` — **bỏ** cột mật khẩu/người dùng, đã loại khi xuất) và bảng tóm tắt mục "Đặc tả nghiệp vụ" ở trên. README ghi cách tái xuất (script PowerShell 32-bit DAO + `SaveAsText`, macro tắt, làm trên bản sao).
- [ ] Commit `docs(salary): dac ta nghiep vu tu Access QLNL`.

### Task 1: Khung service thứ 5 (không nghiệp vụ) — **bài test microservices phần 1**

Mục tiêu: `GET /salary/health` → 200 qua Traefik, chạy trong pod `tkb-salary`, dùng DB `cdhc2_salary`; PR chỉ sửa `modules/Salary/**` chỉ build + rollout `tkb-salary`.

**Files (checklist điểm chạm — lấy từ grep `grades` trong hạ tầng 25/09):**
- [ ] `php artisan module:scaffold Salary` → `modules/Salary/{Controllers,Models,Providers,Routes,Views,…}`; route `/salary/health` (không auth, trả `{service, db}`).
- [ ] `app/Support/ServiceTopology.php`: `'salary' => [SalaryServiceProvider::class]`; `bootstrap/providers.php` tự nhận.
- [ ] `packages/cdhc2-core/src/Support/TableOwnership.php`: `'salary' => ['salary_']`.
- [ ] `config/database.php`: connection `salary` (env `DB_SALARY_DATABASE`, alias về core khi chưa tách — theo `aliasUnsplitConnections`); `config/backup.php` thêm `salary`; `app/Console/Commands/DbTopologyCheck.php` `SERVICE_CONNECTIONS`; `DbRef`; `QueueStatus::TABLES` (`salary_jobs`…).
- [ ] `docker/fpm/salary.conf` (copy grades); `k8s/salary/{deployment,service,hpa}.yaml` (copy grades: `CDHC2_SERVICE=salary`, `JWT_ENFORCE`, queue env 4A `salary_jobs`, container `worker`, `imagePullPolicy: IfNotPresent`).
- [ ] `k8s/traefik/ingressroute.yaml`: `Path(/salary) || PathPrefix(/salary/)` + `PathPrefix(/api/internal/salary/)` → `salary-svc`.
- [ ] `.github/workflows/build-and-deploy.yml`: nhóm filter `salary` (`modules/Salary/**`, `k8s/salary/**`), vòng build `core lms tms grades salary`, `scp k8s/salary`, danh sách rollout/rev-before thêm `tkb-salary`; `scripts/deploy/render-manifests.sh` `service_of` + `DIRS`; `scripts/deploy/prune-node-images.sh` regex; `tests/deploy/*.test.sh` thêm case salary; `tests/Unit/Architecture/DeployPathFilterTest.php` `SERVICES` + `ServiceTopology` tự bao.
- [ ] `service-logs.yaml`, `service-rollback.yaml`: thêm option `salary`.
- [ ] `phpunit.xml`/job `phpunit-split`: DB `cdhc_testing_salary` + env `DB_SALARY_DATABASE`.
- [ ] Tạo DB prod: workflow mới `service-db.yaml` (`step=create`, `service=salary`, `confirm=TAO-DB`) — tái dùng khối grant của `db-split.yaml` (root trong pod `mariadb-0`), tạo `cdhc2_salary` + `GRANT ALL ON cdhc2_salary.* TO cdhc2_admin@'%'`, thêm key `DB_SALARY_DATABASE` vào `tkb-env` (chỉ thêm key, kiểm `.env` còn nguyên như E4 của db-split).
- [ ] Test: `SalaryHealthTest` (monolith + split), test kiến trúc hiện có xanh; `render-manifests.test.sh` case "chỉ salary build".
- [ ] **Thứ tự merge:** (1) PR hạ tầng + DB (chạy `service-db` trước khi deploy manifest salary), (2) PR module rỗng. Nghiệm thu: `curl /salary/health` 200; `kubectl get rs` chỉ `tkb-salary` mới ở PR (2).

### Task 2: Lớp tính toán thuần `SalaryRules` (TDD, bám query Access)

**Files:** Create `modules/Salary/Domain/{SalaryStep.php,SalaryRules.php,DueCheck.php,ReclassResult.php}`; `tests/Unit/Salary/SalaryRulesTest.php`

**Interfaces — Produces:**
- `SalaryStep::parse(string "k/n"): SalaryStep` (`current`, `max`, `isLast()`, `next(): SalaryStep`, `__toString`).
- `SalaryRules::nextStep(SalaryStep): SalaryStep`
- `SalaryRules::nextSeniorityPercent(SalaryStep $step, int $tnvk): ?int` — 5 / tnvk+1 / null.
- `SalaryRules::isDueRegular(float $coef, ?CarbonImmutable $receivedAt, ?CarbonImmutable $checkReceivedAt, int $tnvk, int $workYear, CarbonImmutable $today, float $threshold = 5.4): DueCheck` (`due`, `baseDate`, `newReceiveDate` = tháng mốc/`workYear`, `note` "Chuyển lương" khi dùng mốc kiểm tra).
- `SalaryRules::extendedReceiveDate(CarbonImmutable $base, int $months): CarbonImmutable`
- `SalaryRules::canEarlyRaise(?string $previousRaiseType): bool` — false khi lần gần nhất là "Trước niên hạn".
- `SalaryRules::reclassify(float $currentCoef, iterable $targetScaleRows): ReclassResult` — bậc hệ số bằng, không có thì cao hơn gần nhất; `reservedCoef` = chênh lệch khi hệ số mới thấp hơn (bảo lưu); null khi không có bậc phù hợp.
- `SalaryRules::rankChanges(string $oldRankCode, string $newRankCode): bool`.

- [ ] **Step 1: Test (RED)** — mỗi quy tắc 1 nhóm test, dữ liệu thật từ `bang-luong.tsv`:

```php
public function test_next_step_and_seniority_follow_access_formulas(): void
{
    $this->assertSame('4/12', (string) SalaryRules::nextStep(SalaryStep::parse('3/12')));
    $this->assertSame('12/12', (string) SalaryRules::nextStep(SalaryStep::parse('12/12')));
    $this->assertNull(SalaryRules::nextSeniorityPercent(SalaryStep::parse('11/12'), 0));
    $this->assertSame(5, SalaryRules::nextSeniorityPercent(SalaryStep::parse('12/12'), 0));
    $this->assertSame(8, SalaryRules::nextSeniorityPercent(SalaryStep::parse('10/10'), 7));
}

public function test_regular_due_uses_2_or_3_years_by_coefficient_and_yearly_beyond_frame(): void
{
    $today = CarbonImmutable::parse('2026-09-25');
    $d = fn ($s) => CarbonImmutable::parse($s);
    $this->assertTrue(SalaryRules::isDueRegular(4.55, $d('2024-07-01'), null, 0, 2026, $today)->due);   // <5.4, 2 nam
    $this->assertFalse(SalaryRules::isDueRegular(4.55, $d('2025-07-01'), null, 0, 2026, $today)->due);
    $this->assertTrue(SalaryRules::isDueRegular(5.6, $d('2023-01-01'), null, 0, 2026, $today)->due);    // >=5.4, 3 nam
    $this->assertFalse(SalaryRules::isDueRegular(5.6, $d('2024-01-01'), null, 0, 2026, $today)->due);
    $this->assertTrue(SalaryRules::isDueRegular(7.7, $d('2025-03-01'), null, 6, 2026, $today)->due);    // TNVK>=5: hang nam
    $check = SalaryRules::isDueRegular(4.2, $d('2020-01-01'), $d('2024-05-01'), 0, 2026, $today);        // co moc chuyen luong
    $this->assertTrue($check->due);
    $this->assertSame('2026-05', $check->newReceiveDate->format('Y-m'));
    $this->assertSame('Chuyển lương', $check->note);
}

public function test_reclassify_picks_equal_else_nearest_higher_coefficient_and_reserves_difference(): void
{
    $cc1 = [['code' => 'CC12/12', 'coef' => 4.2], ['code' => 'CC13/12', 'coef' => 4.55], ['code' => 'CC14/12', 'coef' => 4.9]];
    $this->assertSame('CC13/12', SalaryRules::reclassify(4.55, $cc1)->code);
    $this->assertSame('CC14/12', SalaryRules::reclassify(4.7, $cc1)->code);
    $this->assertNull(SalaryRules::reclassify(9.9, $cc1));
}
```

  Thêm test: `canEarlyRaise`, `extendedReceiveDate` (cộng tháng qua năm), `SalaryStep::parse` từ chối chuỗi sai (`'6'`, `'7/6'`), `rankChanges('3/CN','4/CN')`.
- [ ] **Step 2–4:** RED → cài đặt (thuần PHP, không Eloquent) → GREEN. **Kiểm ngược:** đổi ngưỡng 5.4 → 5.0 phải làm test đỏ.
- [ ] **Step 5:** Commit `feat(salary): quy tac nang luong thuan (bam query Access)`.

### Task 3: Schema + model trên connection `salary`

**Files:** migrations `database/migrations/2026_10_0x_create_salary_*` (mỗi file `protected $connection = 'salary'`), models `modules/Salary/Models/*` (`protected $connection = 'salary'`).

| Bảng | Cột chính | Nguồn Access |
|---|---|---|
| `salary_scales` | `code` (unique theo `effective_from`, `CC13/12`), `grade` (CC/TC/SC), `group` (nullable), `step` (`3/12`), `coefficient` decimal(5,2), `rank_code` (`3/CN`), `effective_from` | `BANG LUONG` |
| `salary_profiles` | `user_id` (unique, id `users` — **không FK**), `birth_date`, `enlistment_date`, `scale_id`, `received_at`, `check_received_at`, `seniority_percent`, `reserved_coef`, `education_level`, `education_major`, `graduation_year`, `note` | cột lương của `CAN BO NHAN VIEN` |
| `salary_histories` | `user_id`, `scale_code`, `grade`, `group`, `step`, `coefficient`, `rank_code`, `seniority_percent`, `reserved_coef`, `decision_id` (nullable), `decision_no`, `signed_at`, `received_at`, `signer`, `raise_type`, `early`, `reclass`, `note`; unique (`personnel_id`,`received_at`,`raise_type`) | `QUA TRINH LUONG` (mã `Maso_CBNV&mm&yyyy` → unique này) |
| `salary_rule_settings` | `threshold` (5.4), `years_below` (2), `years_above` (3), `seniority_first` (5), `seniority_step` (1), `seniority_yearly_from` (5) — mặc định, sửa được | form Access (VBA `TxtDK1/2 = 5.4`) |
| `salary_rounds` | `raise_type` (enum 5 loại), `work_year`, **snapshot quy tắc** (`threshold`, `years_below`, `years_above`…) sửa được theo đợt, `status` (draft/reviewing/proposed/decided/applied), `created_by` | form `F DE NGHI …` |
| `salary_round_items` | `round_id`, `user_id`, snapshot cũ/mới (scale, coef, TNVK, rank, reserved), `new_received_at`, `reason`, `extend_months`, `selected`, `approved` | cờ `Denghi_*`/`Duyet*` + `L NANG LUONG` |
| `salary_decisions` | `round_id`, `decision_no`, `signed_at`, `signer`, `signer_title`, `copy_no`, `copy_signer`, `copy_signer_title`, `applied_at` | textbox form + `L NANG LUONG` |
| `salary_decision_settings` | `raise_type`, `title`, `legal_basis` (text), `issuer_parent`, `issuer`, `decider_title`, `signer_title`, `signer`, `recipients`, `doc_suffix`, `place` | `Lam viec` id=2 / `CAN CU` |

- [ ] Test: `SalaryTablesTest` (bảng tồn tại đúng connection ở cả 2 chế độ); test kiến trúc hiện có xanh (không FK sang `users`/`units`).
- [ ] Seed `military_ranks` bổ sung hạng QNCN (Chuẩn uý → Thượng tá QNCN) nếu thiếu — migration core idempotent (theo `code`).

### Task 4: Endpoint nội bộ của core cho salary (ghi) + đọc người dùng

**Files:** `modules/User/Routes/api.php` (hoặc module core phù hợp) `POST /api/internal/core/users/military-rank` (body `user_id`, `military_rank_code`; idempotent: đặt đúng giá trị, gọi lại không đổi gì). Không có endpoint tạo user; `packages/cdhc2-core/src/Contracts/UserDirectoryWriterContract.php` + Direct/Http + `CoreServiceProvider::OWNERSHIP` (`['core', …]`).

- [ ] Đọc: salary đọc `users`/`units`/`military_ranks` trực tiếp (core connection) — **không** `whereHas` từ model salary sang user; lấy id trước rồi `whereIn`.
- [ ] Ghi: chỉ qua job `DeliverInternalCall('core', …)` (4A) — test kiến trúc `InternalWritesAreQueuedTest` bao cả contract này.
- [ ] Test contract hai phía (pattern `LmsProvisioningContractTest`), gọi 2 lần không nhân đôi.

### Task 5: Nghiệp vụ đợt nâng lương (service layer)

**Files:** `modules/Salary/Services/{RoundService.php,RoundApplier.php}`, requests `Create/Update…Request`, tests `tests/Feature/Salary/*`.

- [ ] `RoundService::open(type, workYear, threshold=5.4)` → sinh `round_items` từ `salary_profiles` theo `SalaryRules` (loại Thường xuyên: `isDueRegular`; Trước niên hạn: `canEarlyRaise` + chọn tay; Kéo dài: chọn tay + lý do/tháng; Chuyển ngạch: chọn tay + `reclassify`; Khác: chọn tay).
- [ ] `select/approve/unapprove` (Duyệt xét / Bỏ duyệt), `propose` (chốt ngày nhận mới), `decide` (số QĐ/ngày ký/người ký/chức danh — bắt buộc, như form Access).
- [ ] `RoundApplier::apply(round)` trong **một transaction trên connection `salary`**: ghi `salary_histories`, cập nhật `salary_profiles`, đánh dấu `applied_at`; với người đổi quân hàm → `DeliverInternalCall::dispatch('core', "/api/internal/core/users/{id}/military-rank", ['military_rank_id' => …, 'decision_no' => …])` (atomic với transaction nhờ `salary_jobs` — 4A). Chạy lại `apply` lần 2 → không nhân đôi (unique history).
- [ ] Test: đợt thường xuyên đầy đủ từ dữ liệu mẫu tái hiện đúng 15 dòng "Thường xuyên" trong `L NANG LUONG` của Access (so bậc/hệ số/TNVK — dùng bản xuất ẩn danh hoá mã quân nhân); apply idempotent; core tạm lỗi → job chờ trong `salary_jobs`, lương vẫn áp dụng.

### Task 6: Import từ Access (một lần) + đối chiếu quân nhân (bước AI duy nhất)

**Files:** `docs/salary/access-spec/export-bundle.ps1` (chạy trên máy Windows có Access: xuất JSON gói gồm scales, settings, profiles, histories, decisions — **không** ảnh/mật khẩu); lệnh `salary:import {bundle.json} {--dry-run} {--apply}`; màn hình `/salary/import` (chỉ super-admin) để duyệt đối chiếu.

- [ ] **Đối chiếu tất định trước:** chuẩn hoá tên (bỏ dấu, gộp khoảng trắng), khoá = tên + đơn vị + cấp bậc (so với `users`; users không có ngày sinh) (`KyhieuDV` ↔ `units` qua bảng map đơn vị do người dùng xác nhận 1 lần, 21 dòng). Khớp đúng 1 → tự liên kết.
- [ ] **TypeSafe (chỉ cho ca mơ hồ, opt-in):** với mỗi hồ sơ Access còn 2–5 ứng viên, một câu hỏi **Choice** "Hồ sơ nào là cùng một người?" — `state` = {hồ sơ Access: họ tên, năm sinh, cấp bậc, chức vụ, đơn vị} + danh sách ứng viên cùng trường; `criteria` = mỗi ứng viên + `"none": "Không ứng viên nào là cùng người"`. `confidence ≥ 0.9` và không phải `none` → đề xuất sẵn (vẫn **cần người bấm xác nhận**); còn lại → xếp hàng đối chiếu tay. API key `TYPESAFE_API_KEY` chỉ ở server; **chủ dự án đã đồng ý 25/09** (bật mặc định; thiếu `TYPESAFE_API_KEY` thì mọi ca mơ hồ đi hàng đối chiếu tay). Không khớp user nào → **báo thiếu** (không tạo user). Đọc lại `https://docs.typesafe.ai/api.md` + `primitives/choice.md` trước khi code (endpoint `POST https://api.typesafe.ai/v1/systemone`, `model: "jev-latest"`, xử lý 429/529 bằng backoff).
- [ ] **Không dùng AI** cho: xếp bậc chuyển ngạch, hạn nâng lương, TNVK — đó là quy tắc cố định (Task 2).
- [ ] Dry-run in: số scales (và lỗi `TC7/10`), số hồ sơ khớp tự động / gợi ý / chưa khớp, số dòng lịch sử; apply chỉ khi 0 lỗi chặn.

### Task 7: Giao diện 7 màn hình + nút cổng

**Files:** `modules/Salary/Views/**`, `resources/views/partials/portal-switcher.blade.php` (nút "QL Bậc Lương QNCN" — `@can('salary.index')`), `app/Support/ApplicationRegistry.php` (subsystem `salary`), `app/Support/ApplicationGate.php`, `RoleCatalog`, `SyncPermissionsAndRoles` (quyền `salary.*`), `CrossServiceRoutesServiceProvider` (route salary sinh URL từ service khác).

- [ ] Theo mục "Thiết kế giao diện": 7 màn hình, trạng thái đủ 6 loại + nhãn "đang chờ cập nhật cấp bậc"; dùng component/select sẵn có (Apple Dropdown — **không** Tom Select), token của theme dự án.
- [ ] Mỗi màn hình có feature test (render 200, quyền 403 khi thiếu `salary.*`) + test luồng đợt thường xuyên end-to-end.
- [ ] Kiểm bằng Chrome (đã đăng nhập) sau deploy: header có nút; mọi màn hình; dark mode; màn hình hẹp.

### Task 8: Mẫu in có biến (ExportTemplates)

**Files:** `modules/Salary/Data/{SalaryDecisionDataProvider,SalaryProposalListDataProvider,SalaryAppendixDataProvider,SalaryDueListDataProvider,SalaryHistoryDataProvider,SalaryCurrentScaleReportDataProvider}.php` (implements `TemplateDataProviderInterface`: `featureKey`, `schema`, `mockData`, `load`), lệnh `salary:seed-templates` (theo `SeedGradesExportTemplates`), file mẫu `.docx` trong `modules/Salary/Templates/`.

- [ ] Biến (tên = ý nghĩa, tiếng Việt không dấu): `{{ don_vi_tren }}`, `{{ don_vi_ra_qd }}`, `{{ so_qd }}`, `{{ dia_danh }}`, `{{ ngay_ky }}`, `{{ ten_qd }}`, `{{ can_cu }}`, `{{ nguoi_quyet_dinh }}`, `{{ noi_nhan }}`, `{{ chuc_danh_ky }}`, `{{ nguoi_ky }}`, bảng `nguoi[]` { `ho_ten`, `nhap_ngu`, `cap_bac`, `chuc_vu`, `don_vi`, `tu_bac`, `tu_loai`, `tu_he_so`, `tu_tnvk`, `nam_nhan`, `len_bac`, `len_loai`, `len_he_so`, `len_tnvk`, `thang_quan_ham` }, khối trích sao `{{ so_trich_sao }}`, `{{ nguoi_sao }}`, `{{ chuc_danh_sao }}`.
- [ ] 5 mẫu quyết định (1/loại) + danh sách đề nghị + phụ lục + danh sách đến hạn + quá trình lương + báo cáo bậc lương hiện hưởng (Excel). Đối chiếu bằng mắt với bản in Access (chụp preview Access → so PDF web) cho ít nhất quyết định thường xuyên.
- [ ] Test: mỗi provider `load()` trả đủ khoá theo `schema()`; `BindingSchemaValidator` chấp nhận mẫu.

### Task 9: Nghiệm thu microservices (mục tiêu "bài kiểm tra")

- [ ] **Deploy độc lập:** PR chỉ sửa `modules/Salary/**` → chỉ `tkb-salary` có ReplicaSet mới (cluster-diagnostics trước/sau).
- [ ] **Cô lập lỗi:** scale `tkb-salary` = 0 → `/lms`, `/tms`, `/grades`, `/dashboard` vẫn 200; nút "QL Bậc Lương QNCN" dẫn tới trang lỗi rõ ràng, không làm hỏng header.
- [ ] **Phụ thuộc có kiểm soát:** chặn tạm endpoint core (hoặc scale core=0 trong khung bảo trì) → áp dụng một đợt có thăng quân hàm vẫn thành công, job nằm trong `salary_jobs`; core hoạt động lại → `users.military_rank_id` được cập nhật (queue-status + log).
- [ ] **DB riêng:** `cdhc2:db-topology` báo `salary` tách riêng; `cdhc2_salary` chỉ chứa bảng `salary_*`; backup có dump `cdhc2_salary`.
- [ ] **Lùi riêng:** `service-rollback service=salary`.
- [ ] Handover + roadmap (ghi "service thứ 5 thêm được không đụng service khác" hoặc liệt kê chỗ phải đụng — đó là nợ ranh giới cần trả).

## Quyết định cần chủ dự án

Đã trả lời hết (25/09) — xem mục "Quyết định của chủ dự án" ở đầu plan.
