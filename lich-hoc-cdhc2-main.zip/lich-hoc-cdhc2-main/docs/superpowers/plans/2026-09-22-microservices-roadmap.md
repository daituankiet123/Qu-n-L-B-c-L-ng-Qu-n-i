# Lộ trình CDHC2: distributed monolith → microservices hoàn toàn

> Tài liệu điều phối. Mỗi bước có plan chi tiết riêng, **chỉ viết plan bước N+1 khi bước N
> đạt điều kiện hoàn thành** (mã nguồn thay đổi sau mỗi bước, plan viết trước sẽ sai).
> Trạng thái hiện tại + số liệu coupling: `docs/HANDOVER_2026-09-22.md` mục 7.

## Điểm xuất phát (22/09/2026)

- 4 service (core/lms/tms/grades) + Traefik trên k3s một node, namespace `tkb`.
- Chung: 1 MySQL, 1 image (chọn module bằng `CDHC2_SERVICE`), 1 PVC NFS `tkb-storage`.
- Core nạp toàn bộ module → thực chất vẫn là monolith.
- Đã có: 6 contract Direct/Http (`packages/cdhc2-core`), `DbRef` (0 query thẳng bảng service khác),
  connection `tms`/`lms`/`grades` + alias khi chưa tách DB (`CoreServiceProvider::aliasUnsplitConnections`),
  lệnh `php artisan cdhc2:db-topology`, JWT service token (chưa enforce).

## 5 bước

| Bước | Mục tiêu | Điều kiện hoàn thành (đo được) | Phụ thuộc | Plan |
|---|---|---|---|---|
| 1. Ranh giới code | Service không import class của service khác; core không import class của service | `tests/Unit/Architecture/CrossServiceImportsTest` xanh và baseline chỉ còn các dòng ghi trong mục "Còn lại có chủ đích" của plan 1 | #418 đã merge | `2026-09-22-step1-code-boundaries.md` — **XONG** (#420, #423; baseline 78→12) |
| 2. Tách DB | Mỗi service một schema riêng trên **cùng** server MariaDB; core giữ bảng định danh/tham chiếu | `composer test:split` + `php artisan test` cùng xanh và chặn deploy; `cdhc2:db-topology` trên prod báo 3 DB tách; 0 FK service↔service (`grade_books.lms_course_id`, `grade_books.tms_course_id`) | Bước 1 | `2026-09-23-step2-database-split.md` — **code xong (Task 1–8), chờ merge + chạy runbook `docs/runbooks/db-split.md` trên prod** |
| 3. Deploy độc lập | Đẩy code của một service chỉ rollout service đó | Image tag theo commit (bỏ `:latest`); push chỉ sửa `modules/Lms/**` → chỉ `deployment/lms` đổi ReplicaSet; `JWT_ENFORCE=true` trên cả 4 service | Bước 1 (ranh giới quyết định path filter đúng) | **Xong 25/09** — [2026-09-24-step3-independent-deploy.md](2026-09-24-step3-independent-deploy.md) |
| 4. Event/queue + S3 | Ghi chéo service (chuyển điểm, provisioning LMS) đi qua queue; file qua S3 thay NFS | Queue worker riêng từng service; bỏ PVC `tkb-storage` khỏi mọi deployment; upload/export chạy được khi scale lms lên 2 replica | Bước 2 (queue không nằm trong DB chung), Bước 3 | [4A queue](2026-09-25-step4a-queue-workers.md) · [4B S3](2026-09-25-step4b-object-storage.md) |
| 5. Cụm nhiều node | Hỏng một node / đầy một đĩa không làm chết toàn hệ thống. Nợ chuyển từ Bước 2: 127 FK service→core, JOIN qua `DbRef`, 12 chỗ core đọc model service — chỉ hợp lệ khi cùng server | ≥ 2 node worker; MySQL không nằm trên node chạy app hoặc có replica; `kubectl drain` một node mà web vẫn 200 | Bước 4 (không còn volume RWO dùng chung) | viết sau — cần phần cứng, chủ dự án quyết |

## Ràng buộc cho mọi bước

- Không đụng Moodle. Không `helm upgrade tkb`. Không xoá `deployment/tkb`, `service/tkb`, Ingress `tkb`,
  key `.env` trong secret `tkb-env`. Không apply `k8s/legacy-monolith/tkb-rendered-manifest.yaml`.
- Không đổi driver `s3`; không gọi `exists()` trên disk s3.
- Mỗi push lên `main` đều deploy prod → mọi thay đổi đi qua PR, PHPUnit xanh trước.
- Monolith (`CDHC2_SERVICE` không đặt) phải luôn boot và chạy được — đó là đường lùi.
- Sau mỗi việc: cập nhật `docs/HANDOVER_2026-09-22.md` (mục 4 + nhật ký).
- Skill TypeSafe **không** áp dụng cho các bước này (chỉ dùng cho tính năng AI).
