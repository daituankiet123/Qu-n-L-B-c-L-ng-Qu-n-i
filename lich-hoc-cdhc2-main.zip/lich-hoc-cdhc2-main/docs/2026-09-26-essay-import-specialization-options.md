# Sửa HTTP 500 khi mở Import đề thi

- Log production `AQR8FAZS`, 26/09/2026 19:11:18: `$specializationOptions` chưa khai báo khi render `essay-exam::create`.
- Controller trả `$specializations` dạng metadata, còn JavaScript ở view cần `$specializationOptions` dạng `id` / `label`.
- Sửa controller tạo đúng collection `specializationOptions`, dùng accessor `selection_label` sẵn có để giữ mã ngành, trình độ, hệ và hình thức đào tạo. Giữ phạm vi ngành từ danh sách môn học và các connection sau tách DB.
- Test gọi `create()` rồi render nội dung Blade thực tế với dữ liệu trả về, kiểm tra cả ngành có dữ liệu và danh sách trống. Layout/menu quản trị được bỏ khỏi test để cô lập trang Import.
- PR riêng, không thay đổi dữ liệu hay migration. MySQL test local cổng 3307 không sẵn có; cần CI chung/tách DB xanh trước merge.
