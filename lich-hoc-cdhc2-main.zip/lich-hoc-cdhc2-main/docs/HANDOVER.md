# BÀN GIAO CÔNG VIỆC — CDHC2 Microservices

> **MỚI NHẤT (tài liệu sống, cập nhật sau mỗi việc):** [`HANDOVER_2026-09-22.md`](HANDOVER_2026-09-22.md).
>
> **Cập nhật mới hơn:** xem [`HANDOVER_2026-09-20.md`](HANDOVER_2026-09-20.md) để biết
> trạng thái sau các PR #381–#386, kết quả deploy/hậu kiểm và checklist bắt buộc từ
> commit → PR → merge → kiểm tra website/hạ tầng.

> Ngày 18/09/2026. Người bàn giao: agent (deepseek-v4-flash) theo uỷ quyền của chủ dự án.
> Đọc hết mục 1–3 trước khi làm bất cứ gì. Mục 4 là **những cái bẫy thật đã gây sự cố** —
> phần quan trọng nhất của tài liệu này.

---

## 1. Bối cảnh

**Dự án:** Lịch học CDHC2 — hệ thống quản lý đào tạo Laravel 12 (kiến trúc module tự viết
trong `modules/`, KHÔNG phải nanobox/laravel-modules), phục vụ môi trường quân sự.

**Công việc đang làm:** chuyển monolith → 4 microservices + API Gateway (Phase 0–6).
- Phase 0–3: đã code xong, merge `main`, **đã deploy**.
- Phase 4 (S3 storage): code xong, **bị chặn** (xem mục 5).
- Phase 5 (JWT + App Grid + Traefik): code xong, deploy, **chưa cutover traffic**.
- Phase 6 (tách DB): code xong, **chưa tách DB** (mọi connection vẫn trỏ 1 database).

**Sự việc quan trọng nhất trong phiên này:** ngày 17/09 việc merge `dev → main` làm
**prod chết 8 tiếng**. Nguyên nhân và bài học ở mục 4. Đã hồi phục hoàn toàn.

---

## 2. Môi trường & truy cập

| Hạng mục | Giá trị |
|---|---|
| Repo | `D:\CDHC2\lich-hoc-cdhc2`, branch `dev` (đã push, đồng bộ `origin/dev`) |
| Remote | `origin = https://github.com/tho076/lich-hoc-cdhc2.git` |
| **Luồng deploy** | **merge `dev → main`** → CI `Build and Deploy` chạy (chỉ trigger khi push `main`) |
| Cluster | k3s 1 node `cdhc2-itn-precision-3640-tower`, IP `10.0.6.201`, namespace `tkb` |
| Truy cập cluster | **Không có kubectl trực tiếp.** Chỉ qua GitHub Actions: SSH `cdhc2-itn@<DEST_IPv4>` sau khi join Tailscale. Agent có `gh` CLI |
| Container runtime | containerd (k3s). `docker` trên node dùng cho registry, KHÔNG thấy image của k8s |
| Registry | `registry.hc2/cdhc2/*` (Harbor nội bộ) — CI mirror từ GHCR về |
| Local dev | PHP 8.4 (prod là **8.3**), composer 2.10.2, DB local `127.0.0.1:3307/cdhc`, test DB `cdhc_testing` |

### Workflow có sẵn (dùng `gh workflow run ... --ref main`)

| Workflow | Kiểu | Việc |
|---|---|---|
| `build-and-deploy.yml` | push `main` | Deploy microservices: build 6 image → mirror Harbor → apply `k8s/` → rollout |
| `cluster-diagnostics.yaml` | dispatch | **Chẩn đoán toàn diện, chỉ đọc** (+ ghi 1 file nhỏ vào S3 để test). Đây là "mắt" của bạn |
| `cutover-ingress.yaml` | dispatch | `status` \| `rollback-ready` \| `to-traefik` \| `to-monolith` |
| `build-monolith.yaml` | dispatch | Build image monolith chạy tay (`tag`, `rollout=false/true`) |
| `migrate.yaml` | dispatch | Chạy migration bằng Job riêng (**thường KHÔNG cần** — xem mục 4.7) |

### Lệnh chẩn đoán chuẩn

```bash
gh workflow run cluster-diagnostics.yaml --ref main
gh run watch
gh run view --log | less        # xem các mục [A]..[H]
```

---

## 3. Trạng thái hiện tại (đã kiểm chứng 18/09/2026)

```
deployment      READY  containers   image
tkb             1/1    qlhv         registry.hc2/cdhc2/tkb:20260918   <-- PROD
tkb-core        1/1    fpm,nginx    cdhc2-core  + cdhc2-sidecar
tkb-lms         1/1    fpm,nginx    cdhc2-lms   + cdhc2-sidecar
tkb-tms         1/1    fpm,nginx    cdhc2-tms   + cdhc2-sidecar
tkb-grades      1/1    fpm,nginx    cdhc2-grades+ cdhc2-sidecar
tkb-scheduler   1/1    scheduler    cdhc2-core
traefik         1/1    traefik      traefik:v3.3
```

- Tất cả **0 restart**. `composer audit` sạch.
- **Prod đang phục vụ bằng monolith `tkb`** qua Ingress `tkb` (class nginx, host
  `tkb.cdhc2.edu.vn`, backend `/ -> service tkb:8000`).
- **Stack microservices ĐANG CHẠY nhưng KHÔNG nhận traffic** — an toàn để thử nghiệm.
- Traefik NodePort 30800: `/up -> 200`, `/login -> 200`.
- **Đường lùi về monolith đã kiểm chứng SẴN SÀNG** (`rollback-ready` 5/5 điểm).

---

## 4. NHỮNG CÁI BẪY THẬT — đọc kỹ, đã gây sự cố

### 4.1 `exists()` của disk `s3` LUÔN trả `true`

Driver `viettel-s3` (`kaibatech/viettel-cloud-s3`) là bản cài đặt dở dang, tự ký SigV4
thủ công:

```php
// vendor/kaibatech/viettel-cloud-s3/src/ViettelCloudS3Adapter.php
public function fileSize(...)     { /* For simplicity, return 0 */ }
public function lastModified(...) { /* For simplicity, return current time */ }
public function listContents(...) { /* For simplicity, return empty array */ }
// fileExists() tra $httpCode === 200, nhung endpoint tra 200 ca voi key KHONG ton tai
```

**Đã kiểm chứng trên cluster:** `exists('_probe/khong-ton-tai-xxx.bin') === true`.

⇒ **KHÔNG dùng `exists()`** cho bất cứ file nào có thể nằm trên S3.
⇒ **Xác minh file trên S3 bằng `get()` + so md5** (đã có trong diagnostics mục `[D3]`).

**Trạng thái thật:** ghi/đọc/xoá CHẠY ĐÚNG — backup 1.792.280 bytes trên S3 **khớp md5
từng byte** với bản local. Chỉ những thứ cần *liệt kê* hoặc *kiểm tra tồn tại* mới hỏng.

### 4.2 Endpoint Viettel KHÔNG tương thích driver S3 chính thức

Đã thử đổi sang `league/flysystem-aws-s3-v3` (+ `use_path_style_endpoint`) → **thất bại
hoàn toàn**, cả `throw=true` lẫn `false`:
```
exists() -> UnableToCheckDirectoryExistence
put()    -> UnableToWriteFile
list()   -> UnableToListContents: Error executing "ListObjects"
get()    -> nội dung KHÔNG khớp (md5 KHÁC)
```
⇒ **Phải giữ driver `viettel-s3`.** Ghi chú đầy đủ nằm ngay trong `config/filesystems.php`.
**Đừng thử lại.** (Bài học: đã đổi dựa trên khuyết điểm *liệt kê* mà không chứng minh driver
mới chạy được với endpoint thật.)

### 4.3 `throw => false` + spatie không kiểm tra kết quả = lỗi ghi S3 bị nuốt im lặng

`vendor/spatie/laravel-backup/.../BackupDestination.php::write()` gọi
`$this->disk->getDriver()->writeStream(...)` và **KHÔNG kiểm tra giá trị trả về**.
Nên `backup:run` có thể báo "thành công" mà S3 không nhận gì.
⇒ Sau mỗi lần backup, **phải xác minh bằng md5**, đừng tin exit code.

### 4.4 Deployment `tkb` do HELM quản lý, manifest KHÔNG nằm trong repo

```yaml
labels: { helm.sh/chart: qlhv-0.1.0, app.kubernetes.io/managed-by: Helm }
annotations: { meta.helm.sh/release-name: tkb }
```
- **Chart `qlhv-0.1.0` đã MẤT** — không ai còn giữ.
- ⛔ **ĐỪNG chạy `helm upgrade` cho release `tkb`** — sẽ ghi đè mọi thay đổi thủ công.
- `k8s/` trong repo là manifest của **microservices**, KHÔNG phải của prod monolith.
  Đừng suy luận về prod từ thư mục đó (tôi từng làm vậy và phân tích sai suốt).
- Snapshot manifest thật: `k8s/legacy-monolith/tkb-rendered-manifest.yaml`
  (**chỉ để đối chiếu — ĐỪNG `kubectl apply`**).

### 4.5 Secret `tkb-env` PHẢI có key `.env`

Deployment `tkb` mount: `mountPath: /var/www/.env`, `subPath: .env`, `secretName: tkb-env`.
Với `subPath` trỏ key **không tồn tại**, Kubernetes **tạo THƯ MỤC rỗng** tại đường dẫn đó.
Entrypoint **cũ** trong image monolith cũ gọi `php artisan key:generate` → đọc thư mục →
`errno=21 Is a directory` → `set -e` giết container → **CrashLoopBackOff → prod chết**.

⇒ **Đảm bảo key `.env` luôn tồn tại** trong `tkb-env` (giá trị APP_KEY **thật**):
```bash
kubectl -n tkb patch secret tkb-env --type merge \
  -p '{"stringData":{".env":"APP_KEY=base64:QxLhDm6tg22cy6QcijKCXCYF4fDO3kptPjQSscp9Cs8="}}'
```
Từ image `20260918` trở đi rủi ro này đã bị vô hiệu (entrypoint mới ưu tiên biến môi
trường, không bao giờ đọc `/var/www/.env`), nhưng **giữ key đó cho an toàn khi lùi image cũ**.

### 4.6 `Deploy completed successfully!` KHÔNG có nghĩa prod còn sống

CI chỉ báo việc deploy microservices xong. Trong sự cố 17/09, **pod monolith đã chết
nhưng CI vẫn báo thành công**. Luôn kiểm tra thêm `deployment/tkb`.

### 4.7 Migration TỰ CHẠY — thường KHÔNG cần `migrate.yaml`

`k8s/core/deployment.yaml` có initContainer `migrate` với `RUN_MIGRATIONS=true`, và
`docker/entrypoint.sh` khi `CDHC2_SERVICE=core` sẽ chạy `php artisan migrate --force` +
`permissions:sync`. **Mỗi lần `tkb-core` rollout là một lần migrate.**

Kiểm tra đã chạy hết chưa:
```bash
kubectl -n tkb exec deploy/tkb-core -c fpm -- php artisan migrate:status --no-ansi | grep -c Pending
```

### 4.8 Shell trên node là **zsh** — không dùng biến tên `path`

`path` trong zsh gắn với `PATH`. Đặt `for path in ...` sẽ xoá `PATH` → mọi lệnh sau đó
"command not found" (exit 127). Tôi đã làm diagnostics fail một lần vì lỗi này.
Dùng `route`, `item`, `f`… — **đừng dùng `path`**.

### 4.9 Ingress trả **468** cho request từ node → đừng dùng để phán app

`curl -H 'Host: tkb.cdhc2.edu.vn' http://127.0.0.1/up` trả **468** (kể cả health endpoint
không throttle) trong khi `http://127.0.0.1:30800/up` trả **200**. 468 đến từ **tầng
ingress** (Ingress resource không có annotation/snippet nào → nằm ở controller hoặc lớp trước).
⇒ **Kiểm chứng prod bằng trình duyệt**, hoặc bằng `/up` qua Traefik. Đừng kết luận từ curl
từ node. (Tôi từng kết luận sai 468 là rate-limit của app.)

### 4.10 `imagePullPolicy: Always` + tag `:latest` → pod KHÔNG được thay

Khi chỉ **nội dung image** đổi mà pod template không đổi, Deployment **không tạo pod mới**;
pod cũ (đang lỗi) nằm nguyên và `rollout status` báo `exceeded its progress deadline`.
⇒ Cần `kubectl rollout restart`, và `imagePullPolicy: Always` để kéo bản mới (không dùng cache).
Đã áp dụng cho các deployment microservices.

### 4.11 `pathForProcessing`/`resolveAbsolutePath` có thể trả **file tạm**

`StorageHelper::pathForProcessing()` với disk từ xa sẽ tải về `storage/app/tmp` và trả
đường dẫn tạm; **caller phải gọi `StorageHelper::cleanup($tmp)`**. Nếu S3 không bao giờ
được dùng làm disk chính thì các hàm này luôn trả đường dẫn thật (không copy).

### 4.12 Scheduler CHƯA TỪNG chạy trước 18/09

Trước đó không có `CronJob` nào và supervisord của monolith chỉ chạy `php-fpm` + `nginx`.
Từ 18/09 `tkb-scheduler` chạy `schedule:run` mỗi 60s → **người dùng sẽ BẮT ĐẦU nhận email
nhắc deadline lúc 07:00** (đúng thiết kế, nhưng là lần đầu — nên thông báo trước cho họ).

Lịch rủi ro (đọc kỹ `bootstrap/app.php` nếu cần xác nhận lại):
| Lệnh | Lịch | Rủi ro |
|---|---|---|
| `app:prune-old-records --days=90` | CN 00:00 | **THẤP** — chỉ xoá `system_notifications` đã đọc + `trash_logs` đã phục hồi |
| `lms:prune-submissions --months=24` | ngày 1 hằng tháng 03:30 | Trung bình — xoá FILE bài nộp cũ >24 tháng (giữ metadata). **Có `--dry-run`, nên chạy thử trước** |
| `tms:notify-deadlines` / `...-document-deadlines` | 07:00 / 07:15 | Gửi email |
| `backup:clean` | CN 02:00 | Chỉ dọn được disk local; **S3 không dọn được** → dùng lifecycle rule |

---

## 5. Việc đang mở & bước tiếp theo

### 5.1 ⛔ Phase 4 bị chặn — cần helper kiểm tra tồn tại bằng NỘI DUNG

Vì không thể đổi driver S3 (mục 4.2), `exists()` luôn `true`. Các chỗ này sẽ SAI nếu
chuyển file người dùng lên S3:
- `StorageHelper::downloadToTemp()` → `if (! $storage->exists($path)) return null;`
- `StorageHelper::fileUrl()` → tương tự
- `LmsMaterialService` → `Storage::disk($disk)->exists($file_path)`

**Việc cần làm:**
1. Thêm `StorageHelper::fileExists(string $disk, string $path): bool` dùng **nội dung**
   (`strlen((string) get($path)) > 0`) cho disk từ xa, và `exists()` cho disk local.
2. Thay các chỗ gọi `exists()` trên disk có thể là S3.
3. Viết test với `Storage::fake()` cho cả 2 nhánh.
4. **Sau đó** mới bàn tới `FILESYSTEM_DISK=s3`.

### 5.2 Cutover microservices — TẠM DỪNG, điều kiện để tiếp tục

Stack mới chạy tốt nhưng chưa nhận traffic. **Chỉ cutover khi:**
1. Có người trực cluster (đây là thay đổi traffic người dùng thật).
2. Đã xác nhận `/up -> 200` qua Traefik và `rollback-ready` báo SẴN SÀNG.
3. Chủ dự án đồng ý.

```bash
gh workflow run cutover-ingress.yaml --ref main -f action=to-traefik
# neu loi:
gh workflow run cutover-ingress.yaml --ref main -f action=to-monolith
```
**Cách kiểm chứng đúng:** mở `http://tkb.cdhc2.edu.vn` bằng **trình duyệt** (không curl).

### 5.3 Việc nhỏ nên làm

| # | Việc | Ghi chú |
|---|---|---|
| a | Lifecycle rule xoá backup cũ trên bucket `data.qlhl` | Cần quyền console Viettel (**chủ dự án làm**) — vì `backup:clean` không dọn được S3 |
| b | Bỏ `s3` khỏi `monitor_backups` trong `config/backup.php` | `backup:monitor` luôn báo động giả vì không liệt kê được |
| c | Thêm bước **xác minh backup bằng md5** sau `backup:run` | Đã có logic trong diagnostics mục `[D3]`, nên đưa thành command `cdhc2:verify-backup` |
| d | Chạy `lms:prune-submissions --months=24 --dry-run` trước 1/10 | Xem khối lượng trước khi nó tự chạy |
| e | **Bổ sung `php artisan test` vào CI** | CI hiện chỉ chạy `view:cache` — **7 test đỏ vẫn deploy được** |
| f | Sửa 7 test đỏ có sẵn trên `main` | Trong đó `FacultyTrainingPlanGroupingTest` và `LessonsImportTest` nghi là **lỗi thật** (không phải test cũ) |
| g | `TRUSTED_PROXIES` không có trong Secret) | Ảnh hưởng điểm danh Wi-Fi/GPS — kiểm tra xem prod cũ có biến này không |

### 5.4 7 test đỏ có sẵn trên `origin/main` (KHÔNG do microservices)

Xác minh: các file test này **giống hệt** giữa `origin/main` và `dev`.

| Test | Nhận định |
|---|---|
| `FacultyTrainingPlanGroupingTest:39` | `subject_short` trả tên môn đầy đủ thay vì mã (`TTT`) → nghi **lệch hành vi thật** |
| `LessonsImportTest:137` | Bài học đứng sau một mục con không được tạo → nghi **lỗi import thật** |
| `ApplicationRegistryPermissionTest:94` | `assertTrue(false)` — quyền `exam manager` / `legacy manage` |
| `ExternalActivityAndAuthStabilityTest:28` | `assertTrue(false)` |
| `ScheduleDetailFormScriptTest:47`, `TrainingScheduleSprint20UiTest:37`, `TrainingScheduleSprint23ExportUiTest:20` | Test khẳng định theo **nội dung chuỗi** trong blade → dễ cũ sau refactor |

---

## 6. ⛔ NHỮNG ĐIỀU KHÔNG ĐƯỢC LÀM

| Không làm | Vì sao |
|---|---|
| `helm upgrade` cho release `tkb` | Chart `qlhv-0.1.0` đã mất; sẽ ghi đè thay đổi thủ công |
| Xoá `deployment/tkb`, `service/tkb`, hoặc Ingress `tkb` | Mất đường lùi |
| Xoá key `.env` khỏi Secret `tkb-env` | Tái hiện đúng sự cố 17/09 (với image cũ) |
| `kubectl apply -f k8s/legacy-monolith/tkb-rendered-manifest.yaml` | Chỉ là snapshot đối chiếu, Helm mới là nguồn sự thật |
| Đổi driver disk `s3` | Đã thử, endpoint Viettel không tương thích (mục 4.2) |
| Dùng `exists()` cho disk `s3` | Luôn trả `true` (mục 4.1) |
| Push `main` khi chưa chắc | Mỗi lần push `main` = **deploy prod** |
| Dùng biến `path` trong script chạy trên node | zsh: ghi đè `PATH` (mục 4.8) |
| Kết luận sức khoẻ app từ curl Ingress ở node | Trả 468 (mục 4.9) |
| `git add -A` / `git add .` | Working tree có nhiều file rác + file của agent khác (`AGENTS.md`, `quanham/`, `*.docx`, `public/.tmp*`, `StandardHours-*.md`, `.claude/scratchpad/`…) — **stage từng đường dẫn cụ thể** |

---

## 7. File & tài liệu quan trọng

| File | Nội dung |
|---|---|
| `docs/HANDOVER.md` | Tài liệu này |
| `docs/INCIDENT_2026-09-17.md` | Báo cáo sự cố đầy đủ + 6 vấn đề vận hành + lịch scheduler + roadmap |
| `docs/ROLLBACK_RUNBOOK.md` | **Quy trình lùi về monolith đã kiểm chứng** + sự cố 17/09 + điều không nên làm |
| `docs/MICROSERVICES_PHASE_4-6_PLAN.md` | Kế hoạch Phase 4–6, 9 rủi ro R1–R9, nhật ký thực thi |
| `docs/MICROSERVICES_PROD_READINESS_REVIEW.md` | Đánh giá sẵn sàng prod (mục 10–11: hardening + kết quả deploy) |
| `k8s/legacy-monolith/tkb-rendered-manifest.yaml` | Snapshot manifest thật của prod (chỉ đối chiếu) |
| `config/filesystems.php` | Ghi chú **tại sao không được đổi driver S3** |
| `docker/entrypoint.sh` | Đã sửa lỗi `APP_KEY`/`.env` — dùng cho cả microservices và monolith |
| `.github/workflows/cluster-diagnostics.yaml` | "Mắt" của bạn: chẩn đoán toàn diện, chỉ đọc |
| `.github/workflows/cutover-ingress.yaml` | Chuyển/lùi traffic, có chặn an toàn |
| `.github/workflows/build-monolith.yaml` | Build image monolith chạy tay, có tự động lùi |

### Thay đổi code đã commit (ngoài microservices)

- `config/database.php`: `use_single_transaction => true` cho `mysqldump` (sửa lỗi
  `Access denied ... when using LOCK TABLES` trên DB `eduka_v2`).
- `docker/entrypoint.sh`: sửa lỗi `key:generate` khi thiếu `/var/www/.env`.
- `config/services.php`: `internal_api_secret` suy ra từ `APP_KEY` nếu thiếu biến.
- `composer.json/lock`: vá bảo mật `guzzle 7.15.2`, `league/commonmark 2.10.1`,
  `maatwebsite/excel 3.1.70`.
- `k8s/*/deployment.yaml`: thêm `SESSION_DRIVER`/`CACHE_STORE`/`QUEUE_CONNECTION=database`
  tường minh (bắt buộc khi 1 pod → 6 pod) + `imagePullPolicy: Always`.
- `k8s/storage/pvc.yaml`: `accessModes` → `ReadWriteOnce` (khớp cluster; PVC bất biến).
- `k8s/traefik/*`: sửa RBAC (`endpointslices`, `nodes`), `--ping.entryPoint=web`,
  bỏ `X-Forwarded-Proto` cứng, sửa `PathPrefix` + `priority`.
- `.github/workflows/build-and-deploy.yml`: precheck CRD/PVC trước khi gỡ cổng vào,
  tự khôi phục khi rollout thất bại, xoá `k8s/gateway` cũ.

---

## 8. Thông tin cấu hình cần biết

| Biến/Thành phần | Giá trị |
|---|---|
| DB prod | `eduka_v2`, user `cdhc2_admin` (thiếu quyền `LOCK TABLES` — đã xử lý) |
| S3 | bucket `data.qlhl`, endpoint `https://vcos.cloudstorage.com.vn` |
| SMTP | `mail.cdhc2.edu.vn:587`, user `hc2@cdhc2.edu.vn`, `MAIL_ENCRYPTION` rỗng |
| Backup | `laravel-backup` với prefix filename `qlhl-backup-`, ghi ra `['local','s3']` |
| Prod URL | `http://tkb.cdhc2.edu.vn` (Ingress nginx) |
| Stack mới | `http://10.0.6.201:30800` (Traefik NodePort) |
| Super admin | `admin@example.com` / `password` |

**Giá trị bí mật KHÔNG có trong tài liệu này** (theo nguyên tắc). Lấy từ Secret:
```bash
kubectl -n tkb get secret tkb-env -o jsonpath='{.data.APP_KEY}' | base64 -d; echo
kubectl -n tkb get secret tkb-env -o go-template='{{range $k,$v := .data}}{{$k}}{{"\n"}}{{end}}'
```

---

## 9. Cách làm việc đã được kiểm chứng là hiệu quả

1. **Kiểm chứng trước, kết luận sau.** Mọi kết luận về cluster phải có bằng chứng từ
   workflow chẩn đoán. Tôi đã nhiều lần kết luận sai vì suy đoán.
2. **Kiểm tra đối chứng (control test).** Trước khi tin một phép kiểm tra, thử nó với đầu
   vào *đã biết là sai* (ví dụ `exists()` với key không tồn tại). Chính phép này phát hiện
   `exists()` luôn `true`.
3. **Xác minh bằng nội dung, không bằng cờ.** So md5 thay vì tin `exists()`/exit code.
4. **Mỗi thay đổi prod phải có đường lùi tự động.** `build-monolith.yaml` và
   `cutover-ingress.yaml` đều tự lùi nếu thất bại.
5. **Trước khi thay thế một thành phần hạ tầng, chứng minh bản mới chạy được với endpoint
   thật** (bài học từ mục 4.2).
6. **Không push `main` khi chưa xác minh được cluster** (bài học đắt nhất).

---

## 10. Câu hỏi cần chủ dự án quyết

| # | Câu hỏi | Ghi chú |
|---|---|---|
| 1 | Cutover sang microservices khi nào? | Cần người trực + xác nhận cutover |
| 2 | Có bật `JWT_ENFORCE=true` không? | Hiện JWT hoạt động nhưng vẫn chấp nhận shared secret |
| 3 | Bao giờ tách DB (Gate D)? | Kế hoạch: TMS trước. Nên làm sau khi microservices ổn định |
| 4 | Có làm Phase 4 (S3 cho file người dùng) không? | Cần helper kiểm tra tồn tại bằng nội dung trước (mục 5.1) |
| 5 | Ai đặt lifecycle rule cho bucket S3? | Cần quyền console Viettel |
| 6 | Có bổ sung `php artisan test` vào CI không? | Hiện test đỏ vẫn deploy được — rủi ro chất lượng lớn nhất còn lại |
