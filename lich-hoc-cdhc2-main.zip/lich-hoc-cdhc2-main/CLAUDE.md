# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Application Overview

This is a **Training Management System (Qu�n l� �o T�o)** built with Laravel 12 for managing students, instructors, classes, schedules, and training programs. The application uses a modular architecture with role-based access control (RBAC) via Spatie Laravel Permission.

## Quick Start Commands

Dev/build/test commands are the scripts in `package.json` and `composer.json` (`composer run dev`, `npm run dev`, `npm run build`, `composer test`, etc.) — read those files for the full list.

**MUST run `vendor/bin/pint --dirty` before finalizing changes** (formats modified files only).

**IMPORTANT:** See [SECURITY.md](SECURITY.md) for:
- Cookie security & HTTP headers configuration
- Production deployment checklist
- Secrets management best practices
- Security testing procedures

## Architecture

### Modular Structure

The application uses a **custom module-based architecture** where each feature is encapsulated in its own module under `modules/`. This is NOT nanobox/laravel-modules - it's a custom implementation.

**Module Structure:**
```
modules/{ModuleName}/
├── Controllers/          # HTTP controllers
├── Models/              # Eloquent models (optional, may not exist)
├── Requests/            # Form request validation
├── Providers/           # Service provider (registers routes, views)
├── Routes/
│   ├── web.php         # Web routes
│   ├── api.php         # API routes (optional)
├── Views/              # Blade templates
```

**Module Registration:**
- All module service providers are registered in `bootstrap/providers.php`
- Each module's provider extends `Modules\ModuleServiceProvider` abstract class
- Routes, views, and configs are loaded automatically by the provider

### Creating New Modules

Use `php artisan module:scaffold {ModuleName}` — see `.claude/skills/module-generator.md` for the full workflow.

### Models Location

Models can be in two places:
1. `modules/{ModuleName}/Models/{ModelName}.php` - Module-specific models
2. `app/Models/{ModelName}.php` - Shared/core models (like User)

All models are autoloaded via the `Modules\` namespace in `composer.json`.

### Role-Based Access Control (RBAC)

**System Roles (3 roles only):**
1. `super-admin` - Full system access (admin@example.com only)
2. `student` - Can view student-schedule and dashboards
3. `instructor` - Can view instructor-schedule and dashboards

**Permission Naming Convention:**
- Format: `{module}.{action}` (e.g., `users.index`, `classes.create`, `student-schedule.show`)
- **Standard Actions**: `index`, `show`, `create`, `edit`, `delete`
- **Example**: `users.index`, `classes.create`, `instructor-schedule.show`

**IMPORTANT:** The system uses `module.action` format, NOT `action.module`!

**Permission Assignment:**
- `super-admin`: ALL 70 permissions
- `student`: Only `student-schedule.index`, `student-schedule.show`, `dashboards.index`
- `instructor`: Only `instructor-schedule.index`, `instructor-schedule.show`, `dashboards.index`

**Custom Middleware:**
- `permission` - Single permission check
- `permission.multiple` - Multiple permissions (any)
- `role` - Role-based access

**Usage in routes:**
```php
// Correct format: module.action
Route::middleware(['auth', 'permission:users.index'])->group(function() {
    // Routes requiring users.index permission
});

Route::middleware(['auth', 'permission:student-schedule.index'])->group(function() {
    // Routes for student schedule
});
```

**Single Source of Truth:**
All permissions and roles are managed in `app/Console/Commands/SyncPermissionsAndRoles.php`. This is the ONLY place to define permissions and role assignments.

### Laravel 12 Specifics

This project follows Laravel 12's streamlined structure:
- **No `app/Http/Kernel.php`** - middleware registered in `bootstrap/app.php`
- **No `app/Console/Kernel.php`** - schedule defined in `bootstrap/app.php`
- Commands auto-register from `app/Console/Commands/`
- Service providers registered in `bootstrap/providers.php`

### Scheduled Tasks

Automated backup schedule (defined in `bootstrap/app.php`):
- Daily DB backup to S3 at 2 AM
- Weekly full backup (DB + files) on Sundays at 3 AM
- Daily backup cleanup at 4 AM
- Daily backup health monitoring at 5 AM

### File Storage

**Configured Disks:**
- `public` - Local public storage (`storage/app/public`)
- `s3` - Viettel Cloud S3 (via `kaibatech/viettel-cloud-s3` package)
  - Requires: `VIETTEL_S3_KEY`, `VIETTEL_S3_SECRET`, `VIETTEL_S3_BUCKET`, `VIETTEL_S3_ENDPOINT`

## Default Credentials

**Super Admin (created by permissions:sync command):**
- Email: `admin@example.com`
- Password: `password`
- Role: `super-admin` (only user with this role)

**Sample Users (from seeders):**
- `nguyenvana@example.com` / `it@Cdhc2`
- `tranthib@example.com` / `it@Cdhc2`
- `levanc@example.com` / `it@Cdhc2`
- These users need to be manually assigned `student` or `instructor` role

**Note:** The `permissions:sync` command automatically creates and assigns the super-admin role to `admin@example.com`.

## Important Conventions

### Views

**Layouts:**
- `resources/views/layouts/admin.blade.php` - Admin panel layout
- `resources/views/layouts/app.blade.php` - Public/general layout

**Module Views:**
- Accessed via namespace: `{modulename}::viewname`
- Example: `return view('student::index');`

### Form Validation

Always create Form Request classes in `modules/{Module}/Requests/`:
- `Create{Module}Request.php`
- `Update{Module}Request.php`

### Database Conventions

- When modifying columns, include ALL previous attributes or they'll be lost

### Frontend

**Stack:**
- Vite for asset bundling
- Tailwind CSS v4 (uses `@import "tailwindcss"` NOT `@tailwind` directives)
- Alpine.js (if present in modules)

**If frontend changes don't appear:**
Run `npm run build` or ask user to run `npm run dev`

## Testing

Tests are located in `tests/` directory using PHPUnit. See `.claude/skills/testing-guide.md` for conventions.

## Common Workflows

### Adding a New Feature Module

See `.claude/skills/module-generator.md` for the full workflow (scaffold → model/migrations → permissions → seeder).

### Modifying Permissions

**IMPORTANT: Single Source of Truth** — all permission management is centralized in `app/Console/Commands/SyncPermissionsAndRoles.php`. Do NOT create separate seeders, manually modify permission tables, or use `PermissionService` (deprecated and removed). See `.claude/skills/permission-manager.md` for the full edit/sync workflow.

### Database Changes

1. Create migration: `php artisan make:migration description`
2. Run migration: `php artisan migrate`
3. Update seeders if needed

## Key Files

- `bootstrap/app.php` - Application configuration, middleware, scheduling
- `bootstrap/providers.php` - Service provider registration
- `modules/ModuleServiceProvider.php` - Base class for all module providers
- `app/Console/Commands/SyncPermissionsAndRoles.php` - RBAC configuration
- `app/Console/Commands/MakeModule.php` - Module scaffolding logic
- `config/permission.php` - Spatie permission package configuration
- `config/backup.php` - Backup configuration for Spatie Laravel Backup

## Environment Variables

**Required:**
- Standard Laravel variables (APP_*, DB_*)
- `VIETTEL_S3_KEY`, `VIETTEL_S3_SECRET`, `VIETTEL_S3_BUCKET`, `VIETTEL_S3_ENDPOINT` - For S3 backups
- `BACKUP_NOTIFICATIONS_MAIL` - Email for backup failure notifications

## Package-Specific Notes

**Spatie Laravel Permission:**
- Cache expiration: 24 hours
- Permissions/roles auto-sync on updates
- Use `permissions:sync` to rebuild from code definitions

**Spatie Laravel Backup:**
- Configured to backup to both local and S3
- Excludes: vendor, node_modules, storage/framework, storage/logs
- Monitor with: `php artisan backup:monitor`

**Viettel Cloud S3:**
- Custom S3-compatible driver for Viettel Cloud storage
- Service provider: `Kaibatech\ViettelCloudS3\ViettelCloudS3ServiceProvider`

## Skills & Extended Documentation

For detailed guidance on specific tasks, refer to the specialized skills and documentation in `.claude/`:

### Skills (Task-Specific Guides)

- **`.claude/skills/module-generator.md`** - Complete workflow for creating new modules with CRUD operations
- **`.claude/skills/permission-manager.md`** - Managing RBAC permissions, roles, and access control
- **`.claude/skills/testing-guide.md`** - Creating and running PHPUnit tests with best practices
- **`.claude/skills/laravel-12-expert.md`** - Laravel 12 specific patterns, breaking changes, and new features

### Documentation (Reference Guides)

- **`.claude/docs/architecture.md`** - System architecture, design patterns, and data flow
- **`.claude/docs/database-conventions.md`** - Database design, migrations, Eloquent relationships, and query optimization
- **`.claude/docs/frontend-guide.md`** - Tailwind CSS v4, Alpine.js, Blade components, and Vite integration

### Quick Reference

**See `.claude/README.md`** for:
- Complete skills and documentation index
- Common workflows and decision matrices
- Troubleshooting quick links
- Code style standards
- Learning path for new contributors

**When to use:**
- Creating a new module → Reference `module-generator.md`
- Adding/modifying permissions → Reference `permission-manager.md`
- Writing tests → Reference `testing-guide.md`
- Working with Laravel 12 specifics → Reference `laravel-12-expert.md`
- Understanding system design → Reference `architecture.md`
- Database work → Reference `database-conventions.md`
- Frontend development → Reference `frontend-guide.md`

## Troubleshooting

**Vite manifest error:**
Run `npm run build` or ask user to run `npm run dev`

**Permission denied errors:**
Run `php artisan permissions:sync` to rebuild permissions cache

**Routes not found:**
Check that module's ServiceProvider is registered in `bootstrap/providers.php`
