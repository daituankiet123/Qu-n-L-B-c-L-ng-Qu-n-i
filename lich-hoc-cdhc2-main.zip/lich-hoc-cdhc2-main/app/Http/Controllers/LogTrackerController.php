<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

/**
 * Công cụ tra cứu nhanh log ứng dụng (storage/logs/laravel-*.log) ngay trên
 * web — dùng khi người dùng báo mã lỗi từ trang lỗi thân thiện (403/422/500)
 * mà không cần SSH/kubectl vào server. Chỉ super-admin được dùng vì log có
 * thể chứa thông tin nhạy cảm (stack trace, đường dẫn server, dữ liệu request).
 */
class LogTrackerController extends Controller
{
    private const MAX_RESULTS = 100;

    private const MAX_BLOCK_CHARS = 6000;

    public function index(Request $request)
    {
        $data = $request->validate([
            'q' => 'nullable|string|max:255',
            'from' => 'nullable|date',
            'to' => 'nullable|date',
        ]);

        $query = trim((string) ($data['q'] ?? ''));
        $to = isset($data['to']) ? Carbon::parse($data['to']) : now();
        $from = isset($data['from']) ? Carbon::parse($data['from']) : $to->copy()->subDays(7);
        if ($from->gt($to)) {
            [$from, $to] = [$to, $from];
        }

        $availableFiles = $this->availableLogFiles();
        $results = [];
        $scannedFiles = [];
        $truncated = false;

        if ($query !== '') {
            $period = collect($availableFiles)->filter(function ($file) use ($from, $to) {
                return $file['date']->betweenIncluded($from->copy()->startOfDay(), $to->copy()->endOfDay());
            })->sortByDesc('date')->values();

            foreach ($period as $file) {
                $scannedFiles[] = $file['name'];
                $blocks = $this->searchFile($file['path'], $query);
                foreach (array_reverse($blocks) as $block) {
                    $results[] = [
                        'file' => $file['name'],
                        'service' => $file['service'],
                        'level' => $this->detectLevel($block),
                        'content' => mb_strlen($block) > self::MAX_BLOCK_CHARS
                            ? mb_substr($block, 0, self::MAX_BLOCK_CHARS)."\n... (đã cắt bớt, xem trực tiếp file log để đầy đủ)"
                            : $block,
                    ];
                    if (count($results) >= self::MAX_RESULTS) {
                        $truncated = true;
                        break 2;
                    }
                }
            }
        }

        return view('system.log-tracker', [
            'query' => $query,
            'from' => $from->toDateString(),
            'to' => $to->toDateString(),
            'results' => $results,
            'scannedFiles' => $scannedFiles,
            'truncated' => $truncated,
            'availableFiles' => $availableFiles,
        ]);
    }

    /** @return array<int, array{name:string, path:string, date:Carbon, service:string}> */
    private function availableLogFiles(): array
    {
        $files = glob(storage_path('logs/laravel-*.log')) ?: [];

        return collect($files)
            ->map(function (string $path) {
                $name = basename($path);
                // Chap nhan ca hai dang:
                //   laravel-2026-09-20.log         -> monolith (khong co ten service)
                //   laravel-lms-2026-09-20.log     -> tung service microservices
                // Nho vay trang nay doc duoc log cua ca 4 service tren volume dung chung.
                if (! preg_match('/^laravel(?:-(?<service>[a-z0-9-]+?))?-(?<date>\d{4}-\d{2}-\d{2})\.log$/', $name, $m)) {
                    return null;
                }

                return [
                    'name' => $name,
                    'path' => $path,
                    'date' => Carbon::parse($m['date']),
                    'service' => ($m['service'] ?? '') !== '' ? $m['service'] : 'monolith',
                ];
            })
            ->filter()
            ->sortByDesc('date')
            ->values()
            ->all();
    }

    /** Tách file log thành từng khối theo mốc thời gian, trả về các khối chứa $query. */
    private function searchFile(string $path, string $query): array
    {
        if (! is_file($path) || filesize($path) > 20 * 1024 * 1024) {
            return [];
        }

        $content = file_get_contents($path);
        if ($content === false || $content === '') {
            return [];
        }

        preg_match_all(
            '/^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\].*?(?=^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\]|\z)/ms',
            $content,
            $matches
        );

        return array_values(array_filter(
            $matches[0] ?? [],
            fn (string $block) => stripos($block, $query) !== false
        ));
    }

    private function detectLevel(string $block): string
    {
        if (preg_match('/^\[[^\]]+\]\s+\S+\.(\w+):/', $block, $m)) {
            return strtoupper($m[1]);
        }

        return 'INFO';
    }
}
