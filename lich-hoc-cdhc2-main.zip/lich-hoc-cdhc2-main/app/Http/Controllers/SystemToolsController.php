<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;

/**
 * "Công cụ hệ thống" — bảng nút lệnh artisan đã được duyệt trước (whitelist
 * cố định, không nhận lệnh tự do) để super-admin tự xử lý vài việc vặt quen
 * thuộc (xóa cache, đồng bộ quyền, xem trạng thái...) mà không cần SSH/kubectl
 * vào server. KHÔNG phải terminal — chỉ chạy đúng command đã định nghĩa sẵn ở
 * đây, không truyền tham số tùy ý từ request vào Artisan::call().
 */
class SystemToolsController extends Controller
{
    /** @return array<string, array{command:string, args:array, label:string, desc:string, group:string, confirm:bool, readonly:bool}> */
    private function commands(): array
    {
        return [
            'cache-clear' => ['command' => 'cache:clear', 'args' => [], 'label' => 'Xóa cache ứng dụng', 'desc' => 'Xóa toàn bộ cache dữ liệu (Cache facade). An toàn, không mất dữ liệu.', 'group' => 'Cache & tối ưu', 'confirm' => false, 'readonly' => false],
            'config-clear' => ['command' => 'config:clear', 'args' => [], 'label' => 'Xóa cache config', 'desc' => 'Xóa file cache cấu hình (bootstrap/cache/config.php). Dùng khi sửa .env mà chưa thấy hiệu lực.', 'group' => 'Cache & tối ưu', 'confirm' => false, 'readonly' => false],
            'route-clear' => ['command' => 'route:clear', 'args' => [], 'label' => 'Xóa cache route', 'desc' => 'Xóa file cache route. Dùng khi vừa thêm route mới mà truy cập báo 404.', 'group' => 'Cache & tối ưu', 'confirm' => false, 'readonly' => false],
            'view-clear' => ['command' => 'view:clear', 'args' => [], 'label' => 'Xóa cache view (Blade)', 'desc' => 'Xóa các file Blade đã biên dịch. Dùng khi sửa giao diện mà không thấy thay đổi.', 'group' => 'Cache & tối ưu', 'confirm' => false, 'readonly' => false],
            'optimize-clear' => ['command' => 'optimize:clear', 'args' => [], 'label' => 'Xóa toàn bộ cache (gộp)', 'desc' => 'Gộp cả cache/config/route/view/event ở trên vào 1 nút. An toàn.', 'group' => 'Cache & tối ưu', 'confirm' => false, 'readonly' => false],
            'queue-restart' => ['command' => 'queue:restart', 'args' => [], 'label' => 'Khởi động lại queue worker', 'desc' => 'Báo các worker đang chạy tự thoát sau khi xong job hiện tại (supervisor sẽ tự khởi động lại). Không mất job trong hàng đợi.', 'group' => 'Hàng đợi', 'confirm' => false, 'readonly' => false],
            'permission-cache-reset' => ['command' => 'permission:cache-reset', 'args' => [], 'label' => 'Xóa cache phân quyền (Spatie)', 'desc' => 'Xóa cache role/permission — dùng khi vừa đổi quyền mà tài khoản chưa thấy áp dụng ngay.', 'group' => 'Phân quyền', 'confirm' => false, 'readonly' => false],
            'permissions-sync' => ['command' => 'permissions:sync', 'args' => [], 'label' => 'Đồng bộ lại toàn bộ quyền & vai trò', 'desc' => 'Chạy lại SyncPermissionsAndRoles — tạo permission còn thiếu và gán lại đúng theo cấu hình trong code. Có thể đổi quyền của nhiều tài khoản, nên xác nhận trước khi chạy.', 'group' => 'Phân quyền', 'confirm' => true, 'readonly' => false],
            'schedule-clear-cache' => ['command' => 'schedule:clear-cache', 'args' => [], 'label' => 'Xóa cache lịch chạy nền (scheduler)', 'desc' => 'Xóa mutex file kẹt lại khiến 1 tác vụ định kỳ bị coi là "đang chạy" mãi không tới lượt tiếp theo.', 'group' => 'Hàng đợi', 'confirm' => false, 'readonly' => false],
            'migrate-status' => ['command' => 'migrate:status', 'args' => [], 'label' => 'Xem trạng thái migration', 'desc' => 'Chỉ xem — liệt kê migration nào đã chạy/chưa chạy trên CSDL hiện tại.', 'group' => 'Chẩn đoán (chỉ xem)', 'confirm' => false, 'readonly' => true],
            'migrate' => ['command' => 'migrate', 'args' => ['--force' => true], 'label' => 'Chạy migration còn thiếu', 'desc' => 'Áp dụng các migration MỚI chưa từng chạy trên CSDL này (chỉ thêm bảng/cột, không xóa dữ liệu, không phải migrate:fresh/rollback). Đây là nguyên nhân phổ biến nhất gây lỗi 500 "bảng/cột không tồn tại" ngay sau khi deploy tính năng mới.', 'group' => 'Cơ sở dữ liệu', 'confirm' => true, 'readonly' => false],
            'db-stats' => ['command' => 'db:stats', 'args' => [], 'label' => 'Thống kê CSDL', 'desc' => 'Chỉ xem — số bảng, số dòng, dữ liệu mẫu.', 'group' => 'Chẩn đoán (chỉ xem)', 'confirm' => false, 'readonly' => true],
            'about' => ['command' => 'about', 'args' => ['--only' => 'environment,cache,drivers'], 'label' => 'Thông tin môi trường ứng dụng', 'desc' => 'Chỉ xem — phiên bản PHP/Laravel, driver cache/queue/session đang dùng.', 'group' => 'Chẩn đoán (chỉ xem)', 'confirm' => false, 'readonly' => true],
        ];
    }

    public function index(Request $request)
    {
        $lastKey = $request->session()->get('system_tools.last_key');
        $lastOutput = $request->session()->get('system_tools.last_output');
        $lastAt = $request->session()->get('system_tools.last_at');

        return view('system.tools', [
            'commands' => $this->commands(),
            'lastKey' => $lastKey,
            'lastOutput' => $lastOutput,
            'lastAt' => $lastAt,
        ]);
    }

    public function run(Request $request, string $key)
    {
        $commands = $this->commands();
        abort_unless(array_key_exists($key, $commands), 404);

        $def = $commands[$key];
        $user = $request->user();

        $exitCode = Artisan::call($def['command'], $def['args']);
        $output = trim(Artisan::output());

        Log::warning("Công cụ hệ thống: {$def['label']} [{$key}]", [
            'tool' => $key,
            'command' => $def['command'],
            'exit_code' => $exitCode,
            'user_id' => $user?->id,
            'user_name' => $user?->name,
            'output' => mb_substr($output, 0, 4000),
        ]);

        $request->session()->flash('system_tools.last_key', $key);
        $request->session()->flash('system_tools.last_output', $output !== '' ? $output : '(không có output)');
        $request->session()->flash('system_tools.last_at', now()->format('d/m/Y H:i:s'));

        return back()->with(
            $exitCode === 0 ? 'success' : 'error',
            $exitCode === 0 ? "Đã chạy \"{$def['label']}\" thành công." : "\"{$def['label']}\" chạy xong nhưng exit code = {$exitCode}, xem output bên dưới."
        );
    }
}
