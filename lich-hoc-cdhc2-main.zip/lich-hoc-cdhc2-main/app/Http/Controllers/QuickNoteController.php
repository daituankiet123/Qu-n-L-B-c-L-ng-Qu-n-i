<?php

namespace App\Http\Controllers;

use App\Models\QuickNote;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Ô ghi chú tạm dùng chung — cầu nối copy/paste giữa 2 máy không chung mạng
 * ngoài (VD: server prod chỉ ra được Internet qua chính domain tkb), miễn là
 * cả 2 mở được cùng 1 trang này qua tkb. KHÔNG dùng để lưu thông tin nhạy
 * cảm lâu dài — chỉ là notepad tạm thời, ai có quyền super-admin cũng đọc
 * được nội dung.
 */
class QuickNoteController extends Controller
{
    public function show(): \Illuminate\View\View
    {
        return view('quick-notes.show', ['note' => QuickNote::singleton()]);
    }

    public function poll(): JsonResponse
    {
        $note = QuickNote::singleton();

        return response()->json([
            'content' => $note->content,
            'updated_at' => $note->updated_at?->toIso8601String(),
            'updated_by' => $note->updater?->name,
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'content' => 'nullable|string|max:200000',
        ]);

        $note = QuickNote::singleton();
        $note->update([
            'content' => $data['content'] ?? '',
            'updated_by' => $request->user()->id,
        ]);

        return response()->json([
            'content' => $note->content,
            'updated_at' => $note->updated_at?->toIso8601String(),
            'updated_by' => $request->user()->name,
        ]);
    }
}
