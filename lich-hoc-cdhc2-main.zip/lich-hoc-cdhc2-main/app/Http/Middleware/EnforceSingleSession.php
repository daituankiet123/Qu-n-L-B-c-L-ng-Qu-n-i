<?php

namespace App\Http\Middleware;

use App\Services\LoginSessionService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * 1 tai khoan - 1 thiet bi: phien khong con la phien moi nhat cua tai khoan (co noi khac vua dang nhap)
 * -> dang xuat ngay, ve trang dang nhap kem thong bao. Chay trong nhom `web` (sau StartSession).
 */
class EnforceSingleSession
{
    public function __construct(private readonly LoginSessionService $sessions) {}

    public function handle(Request $request, Closure $next): Response
    {
        $guard = Auth::guard('web');
        if (! $request->hasSession() || ! $guard->check()) {
            return $next($request);
        }

        $user = $guard->user();
        if ($this->sessions->isCurrent($request, $user)) {
            return $next($request);
        }

        $guard->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        if ($request->expectsJson()) {
            return response()->json(['message' => LoginSessionService::KICKED_MESSAGE, 'reason' => 'signed_in_elsewhere'], 401);
        }

        return redirect()->route('login')->with('session_kicked', LoginSessionService::KICKED_MESSAGE);
    }
}
