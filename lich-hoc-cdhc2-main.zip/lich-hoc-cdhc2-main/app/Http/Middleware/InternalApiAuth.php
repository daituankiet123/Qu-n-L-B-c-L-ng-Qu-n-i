<?php

namespace App\Http\Middleware;

use App\Services\JwtTokenService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class InternalApiAuth
{
    public function __construct(private JwtTokenService $jwt) {}

    public function handle(Request $request, Closure $next): Response
    {
        $audience = $this->audience();
        $enforce = (bool) config('jwt.enforce', false);
        $bearer = $request->bearerToken();

        // 1. JWT Bearer — đường chính
        if ($bearer) {
            try {
                $claims = $this->jwt->verify($bearer, $audience);
                $request->attributes->set('jwt_service', $claims->service ?? null);
                $request->attributes->set('jwt_sub', $claims->sub ?? null);

                return $next($request);
            } catch (\Throwable $e) {
                // Có Bearer nhưng không hợp lệ thì chặn ngay, KHÔNG rơi xuống
                // shared secret — tránh việc token hỏng âm thầm hạ cấp bảo mật.
                $this->reject($request, 'invalid_token', $audience, $enforce, $e->getMessage());
                abort(403, 'Invalid service token');
            }
        }

        // 2. Fallback shared secret — chỉ khi chưa bật enforce
        if (! $enforce) {
            $token = $request->header('X-Internal-Token');
            $secret = config('services.internal_api_secret');

            if ($secret && $token && hash_equals($secret, $token)) {
                return $next($request);
            }
        }

        $this->reject($request, 'no_valid_credentials', $audience, $enforce);
        abort(403, 'Unauthorized internal request');
    }

    /**
     * Ghi lại mọi lời gọi nội bộ bị từ chối: gọi service-to-service không đi qua Traefik nên đây
     * là chỗ duy nhất thấy được việc bật JWT_ENFORCE làm gãy luồng nào (lọc log "internal auth").
     */
    private function reject(Request $request, string $reason, ?string $audience, bool $enforce, ?string $detail = null): void
    {
        Log::warning('internal auth rejected', [
            'reason' => $reason,
            'path' => $request->path(),
            'audience' => $audience,
            'enforce' => $enforce,
            'has_shared_secret_header' => $request->hasHeader('X-Internal-Token'),
            'detail' => $detail,
        ]);
    }

    /**
     * Service hiện tại — audience mong đợi của token.
     */
    private function audience(): ?string
    {
        $service = (string) config('app.cdhc2_service', 'monolith');

        return in_array($service, ['core', 'lms', 'tms', 'grades', 'salary'], true) ? $service : null;
    }
}
