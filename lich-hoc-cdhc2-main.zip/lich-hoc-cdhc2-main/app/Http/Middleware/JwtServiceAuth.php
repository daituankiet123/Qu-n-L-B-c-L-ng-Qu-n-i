<?php

namespace App\Http\Middleware;

use App\Services\JwtTokenService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class JwtServiceAuth
{
    public function __construct(private JwtTokenService $jwt) {}

    public function handle(Request $request, Closure $next): Response
    {
        $bearer = $request->bearerToken();
        if (! $bearer) {
            abort(401, 'Missing service token');
        }

        try {
            $claims = $this->jwt->verify($bearer, $this->audience());
        } catch (\Throwable) {
            abort(401, 'Invalid service token');
        }

        $request->attributes->set('jwt_service', $claims->service ?? null);
        $request->attributes->set('jwt_sub', $claims->sub ?? null);

        return $next($request);
    }

    /**
     * Service hiện tại — dùng làm audience mong đợi.
     * Trả null khi monolith để không chặn token không kèm `aud`.
     */
    private function audience(): ?string
    {
        $service = (string) config('app.cdhc2_service', 'monolith');

        return in_array($service, ['core', 'lms', 'tms', 'grades'], true) ? $service : null;
    }
}
