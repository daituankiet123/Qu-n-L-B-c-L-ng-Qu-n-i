<?php

namespace App\Services;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use RuntimeException;
use UnexpectedValueException;

class JwtTokenService
{
    /**
     * Phát hành service token cho 1 internal API call.
     *
     * @param  int  $userId  user đang thực hiện request (0 nếu là tiến trình hệ thống)
     * @param  string  $sourceService  service phát hành (core|lms|tms|grades|scheduler)
     * @param  string|null  $targetService  service nhận — đưa vào claim `aud` để chống replay chéo
     */
    public function issue(int $userId, string $sourceService, ?string $targetService = null): string
    {
        $now = time();
        $ttl = max(30, (int) config('jwt.ttl', 300));

        $payload = [
            'iss' => $sourceService,
            'sub' => (string) $userId,
            'service' => $sourceService,
            'iat' => $now,
            'nbf' => $now - (int) config('jwt.leeway', 5),
            'exp' => $now + $ttl,
            'jti' => bin2hex(random_bytes(8)),
        ];

        if ($targetService !== null && $targetService !== '') {
            $payload['aud'] = $targetService;
        }

        return JWT::encode($payload, $this->secret(), $this->algo());
    }

    /**
     * Xác thực token và (tuỳ chọn) đối chiếu audience.
     *
     * @throws UnexpectedValueException khi token sai/hết hạn/sai audience
     */
    public function verify(string $token, ?string $expectedAudience = null): object
    {
        JWT::$leeway = (int) config('jwt.leeway', 5);

        $claims = JWT::decode($token, new Key($this->secret(), $this->algo()));

        if ($expectedAudience !== null && isset($claims->aud) && $claims->aud !== $expectedAudience) {
            throw new UnexpectedValueException('Token audience mismatch');
        }

        return $claims;
    }

    public function isConfigured(): bool
    {
        $secret = (string) config('jwt.secret');

        return strlen($secret) >= (int) config('jwt.min_secret_length', 32);
    }

    /**
     * Khoá ký — ném lỗi rõ ràng nếu chưa cấu hình hoặc quá yếu,
     * thay vì âm thầm ký bằng chuỗi rỗng.
     */
    private function secret(): string
    {
        $secret = (string) config('jwt.secret');
        $min = (int) config('jwt.min_secret_length', 32);

        if ($secret === '') {
            throw new RuntimeException('JWT_SECRET chưa được cấu hình.');
        }

        if (strlen($secret) < $min) {
            throw new RuntimeException("JWT_SECRET quá ngắn (cần >= {$min} ký tự).");
        }

        return $secret;
    }

    private function algo(): string
    {
        $algo = (string) config('jwt.algo', 'HS256');

        // Chỉ cho phép HMAC — chặn thuật toán "none" và RS/ES khi chưa có hạ tầng khoá bất đối xứng.
        if (! in_array($algo, ['HS256', 'HS384', 'HS512'], true)) {
            throw new RuntimeException("JWT_ALGO không được hỗ trợ: {$algo}");
        }

        return $algo;
    }
}
