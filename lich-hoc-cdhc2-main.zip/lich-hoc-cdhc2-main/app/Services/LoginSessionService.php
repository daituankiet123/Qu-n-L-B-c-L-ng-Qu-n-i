<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

/**
 * Moi tai khoan chi 1 phien dang nhap hop le tai mot thoi diem + ghi "lan dang nhap truoc".
 *
 * - begin(): goi NGAY SAU khi dang nhap thanh cong bang mat khau. Sinh session_token moi (luu o users + session),
 *   doi remember_token -> cookie "ghi nho" cua may cu het hieu luc, don lan dang nhap hien tai sang "lan truoc".
 * - Middleware EnforceSingleSession: phien mang token khac users.session_token -> dang xuat, bao "da dang nhap o may khac".
 */
class LoginSessionService
{
    public const SESSION_KEY = 'auth.session_token';

    public const KICKED_MESSAGE = 'Tài khoản của bạn vừa được đăng nhập trên một thiết bị khác, nên phiên trên máy này đã kết thúc. Nếu không phải bạn, hãy đăng nhập lại và đổi mật khẩu ngay.';

    public function begin(Request $request, User $user, bool $remember = false): void
    {
        $token = Str::random(64);
        $user->forceFill([
            'last_login_at' => $user->current_login_at,
            'last_login_ip' => $user->current_login_ip,
            'last_login_user_agent' => $user->current_login_user_agent,
            'current_login_at' => now(),
            'current_login_ip' => $request->ip(),
            'current_login_user_agent' => mb_substr((string) $request->userAgent(), 0, 255),
            'session_token' => $token,
        ]);
        // Doi remember_token: cookie "ghi nho dang nhap" cua moi may khac khong con dang nhap lai duoc.
        $user->setRememberToken(Str::random(60));
        $user->save();

        if ($remember) {
            // Cookie ghi nho da xep hang voi token cu trong luc attempt() -> xep lai theo token moi.
            Auth::guard('web')->login($user, true);
        }

        $request->session()->put(self::SESSION_KEY, $token);
    }

    /** Phien hien tai con la phien hop le duy nhat cua tai khoan? (null token o user = chua ap dung, cho qua). */
    public function isCurrent(Request $request, User $user): bool
    {
        $expected = (string) ($user->session_token ?? '');
        if ($expected === '') {
            return true;
        }
        $token = $request->session()->get(self::SESSION_KEY);
        if ($token === null && Auth::guard('web')->viaRemember()) {
            // Phien het han, dang nhap lai tu cookie ghi nho: remember_token doi moi lan dang nhap moi
            // nen chi may dang nhap sau cung con cookie hop le -> nhan lai token.
            $request->session()->put(self::SESSION_KEY, $expected);

            return true;
        }

        return is_string($token) && hash_equals($expected, $token);
    }

    /** " Lần đăng nhập trước: 14:20 30/09/2026 · IP 10.0.0.5 · Chrome · Windows." (rong neu chua co). */
    public static function previousLoginNote(?User $user): string
    {
        if (! $user?->last_login_at) {
            return '';
        }

        return ' Lần đăng nhập trước: '.$user->last_login_at->timezone('Asia/Ho_Chi_Minh')->format('H:i d/m/Y')
            .' · IP '.($user->last_login_ip ?: '—').' · '.self::deviceLabel($user->last_login_user_agent).'.';
    }

    /** "Chrome · Windows" tu user agent (du de nguoi dung nhan ra thiet bi). */
    public static function deviceLabel(?string $userAgent): string
    {
        $ua = (string) $userAgent;
        if ($ua === '') {
            return 'Không rõ thiết bị';
        }
        $browser = match (true) {
            str_contains($ua, 'Edg/') => 'Edge',
            str_contains($ua, 'OPR/') || str_contains($ua, 'Opera') => 'Opera',
            str_contains($ua, 'CocCoc') || str_contains($ua, 'coc_coc') => 'Cốc Cốc',
            str_contains($ua, 'Firefox/') => 'Firefox',
            str_contains($ua, 'Chrome/') => 'Chrome',
            str_contains($ua, 'Safari/') => 'Safari',
            default => 'Trình duyệt khác',
        };
        $os = match (true) {
            str_contains($ua, 'Windows') => 'Windows',
            str_contains($ua, 'Android') => 'Android',
            str_contains($ua, 'iPhone') || str_contains($ua, 'iPad') => 'iOS',
            str_contains($ua, 'Mac OS X') || str_contains($ua, 'Macintosh') => 'macOS',
            str_contains($ua, 'Linux') => 'Linux',
            default => 'hệ điều hành khác',
        };

        return "{$browser} · {$os}";
    }
}
