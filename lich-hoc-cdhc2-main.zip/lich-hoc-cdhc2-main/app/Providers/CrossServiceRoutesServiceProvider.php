<?php

namespace App\Providers;

use App\Support\ServiceTopology;
use Illuminate\Support\ServiceProvider;

/**
 * Dang ky route web cua cac module KHONG thuoc service hien tai - CHI de sinh URL.
 *
 * Moi service microservices chi nap provider cua minh (xem ServiceTopology). Nen o
 * service `lms`, route 'dashboard', 'tms.hub', 'grades.hub', 'inventory.index'...
 * khong ton tai: goi route() thi RouteNotFoundException (500), con guard
 * Route::has() thi AN MAT muc do khoi sidebar va App Grid. Nguoi dung dang o LMS se
 * khong thay link sang Bang dieu khien, TMS, Quan ly diem, Vat tu, Quan ly phep.
 *
 * Nap file routes/web.php cua cac module con thieu thi route() va Route::has() chay
 * dung o moi service. Request that van den dung service vi Traefik dinh tuyen theo
 * prefix duong dan (/tms/, /grades/, /vat-tu/...) - route "muon" o day khong bao gio
 * nhan traffic. Chi nap file route, KHONG nap ca provider (khong view, khong
 * observer, khong binding cua module khac).
 */
class CrossServiceRoutesServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        if ($this->app->routesAreCached()) {
            return;
        }

        foreach (self::missingRouteFiles(fn (string $provider) => $this->app->getProviders($provider) !== []) as $file) {
            $this->loadRoutesFrom(base_path($file));
        }
    }

    /**
     * File route cua cac module thuoc service KHAC, tuc provider cua no chua duoc nap.
     *
     * @param  callable(string): bool  $isLoaded
     * @return list<string>
     */
    public static function missingRouteFiles(callable $isLoaded): array
    {
        $files = [];
        foreach (ServiceTopology::serviceModuleProviders() as $provider) {
            if ($isLoaded($provider)) {
                continue;
            }
            $file = ServiceTopology::webRoutesFile($provider);
            if ($file !== null && is_file(base_path($file))) {
                $files[] = $file;
            }
        }

        return $files;
    }
}
