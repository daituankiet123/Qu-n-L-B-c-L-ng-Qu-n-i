<?php

namespace App\Support;

use App\Models\User;
use Illuminate\Support\Facades\Auth;

/**
 * Quyet dinh "vo giao dien" cua LMS: nguoi dung vao shell admin hay shell
 * hoc vien / giang vien, va vao cua nao.
 *
 * Nam o core (khong phai module Lms) vi sidebar, App Grid, portal-switcher va
 * layout lms-learner deu la giao dien dung chung: service tms/grades khong nap
 * module Lms nhung van phai ve duoc cac lien ket nay. Luat o day chi dung du
 * kien cua core (vai tro, don vi, route, request) — phan can du lieu LMS that
 * (vd. `LmsAccess::canTeachCourse`) van o trong module Lms.
 */
class LmsShell
{
    public static function user(?User $user = null): ?User
    {
        return $user ?: Auth::user();
    }

    /** Dùng shell admin LMS (không phải trang học viên/GV) */
    public static function usesAdminShell(?User $user = null): bool
    {
        $user = self::user($user);
        if (! $user) {
            return false;
        }

        if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) {
            return true;
        }

        if (method_exists($user, 'isManager') && $user->isManager()) {
            return true;
        }

        if (TrainingDept::unitIsTrainingOffice($user)) {
            return true;
        }

        return false;
    }

    /** Portal học viên / giảng viên (giao diện tách) */
    public static function usesLearnerShell(?User $user = null): bool
    {
        $user = self::user($user);
        if (! $user) {
            return false;
        }

        return ! self::usesAdminShell($user);
    }

    public static function isInstructorUser(?User $user = null): bool
    {
        $user = self::user($user);
        if (! $user) {
            return false;
        }

        return (method_exists($user, 'isInstructor') && $user->isInstructor())
            || $user->user_type === 'instructor'
            || (method_exists($user, 'hasRole') && $user->hasRole('instructor'));
    }

    public static function isStudentUser(?User $user = null): bool
    {
        $user = self::user($user);
        if (! $user) {
            return false;
        }

        return (method_exists($user, 'isStudent') && $user->isStudent())
            || $user->user_type === 'student';
    }

    /**
     * Entry sau đăng nhập / nút LMS trên home.
     */
    public static function entryRouteName(?User $user = null): string
    {
        $user = self::user($user);
        if (! $user) {
            return 'home';
        }

        if (self::usesAdminShell($user)) {
            return 'lms.hub';
        }

        if (self::isInstructorUser($user) && ($user->can('lms.index') || $user->can('lms.edit'))) {
            return 'lms.teach.home';
        }

        return 'lms.learn.home';
    }

    public static function entryUrl(?User $user = null): string
    {
        return route(self::entryRouteName($user));
    }

    public static function isTeachMode(): bool
    {
        if (request()->routeIs('lms.teach.*')) {
            return true;
        }

        return request()->query('mode') === 'teach';
    }
}
