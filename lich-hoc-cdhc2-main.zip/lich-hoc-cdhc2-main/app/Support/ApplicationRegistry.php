<?php

namespace App\Support;

/**
 * Danh mục ứng dụng của toàn hệ thống — nguồn duy nhất cho ma trận phân quyền.
 *
 * Cấu trúc: Phân hệ → Ứng dụng → Hành động (Xem / Thêm / Sửa / Xóa / Duyệt / Xuất).
 *
 * Mỗi hành động ánh xạ sang danh sách hậu tố permission thật đang dùng trong
 * code, nên bảng ma trận hiển thị theo ngôn ngữ nghiệp vụ mà không phải đổi tên
 * permission nào. Tick một ô = cấp trọn danh sách permission của ô đó.
 */
final class ApplicationRegistry
{
    public const ACTION_VIEW = 'view';

    public const ACTION_CREATE = 'create';

    public const ACTION_EDIT = 'edit';

    public const ACTION_DELETE = 'delete';

    public const ACTION_APPROVE = 'approve';

    public const ACTION_EXPORT = 'export';

    public const ACTION_IMPORT = 'import';

    public const ACTION_SUBMIT = 'submit';

    public const ACTION_ASSIGN = 'assign';

    public const ACTION_COMPLETE = 'complete';

    /**
     * Các prefix từng có permission gộp `<prefix>.manage` trước khi tách chi tiết.
     * Dùng để migrate role cũ; không thêm prefix mới vào đây.
     *
     * @var list<string>
     */
    private const LEGACY_MANAGE_PREFIXES = [
        'standard-hours.object-types',
        'standard-hours.positions',
        'standard-hours.departments',
        'standard-hours.department-overtime',
        'standard-hours.norm-reductions',
        'standard-hours.conversion-categories',
        'standard-hours.research-categories',
        'standard-hours.conversion-records',
        'standard-hours.research-records',
        'standard-hours.external-activities',
        'standard-hours.hour-exchanges',
    ];

    /** Bộ hành động CRUD chuẩn của các module dùng ModuleBaseController. */
    private const CRUD_CORE = [
        self::ACTION_VIEW => ['index', 'show'],
        self::ACTION_CREATE => ['create'],
        self::ACTION_EDIT => ['edit'],
        self::ACTION_DELETE => ['delete'],
    ];

    /** Bộ hành động CRUD của các ứng dụng Giờ chuẩn GV (prefix riêng). */
    private const CRUD_STANDARD_HOURS = [
        self::ACTION_VIEW => ['view'],
        self::ACTION_CREATE => ['create'],
        self::ACTION_EDIT => ['edit'],
        self::ACTION_DELETE => ['delete'],
    ];

    /** Bộ hành động CRUD của các ứng dụng con trong LMS. */
    private const CRUD_LMS = self::CRUD_STANDARD_HOURS;

    /** Bộ hành động CRUD của các ứng dụng con trong Quản lý điểm. */
    private const CRUD_GRADES = self::CRUD_STANDARD_HOURS;

    /** @return array<string, string> */
    public static function actionLabels(): array
    {
        return [
            self::ACTION_VIEW => 'Xem',
            self::ACTION_CREATE => 'Thêm',
            self::ACTION_EDIT => 'Sửa',
            self::ACTION_DELETE => 'Xóa',
            self::ACTION_APPROVE => 'Duyệt',
            self::ACTION_EXPORT => 'Xuất',
            self::ACTION_IMPORT => 'Nhập dữ liệu',
            self::ACTION_SUBMIT => 'Gửi duyệt',
            self::ACTION_ASSIGN => 'Duyệt cấp đơn vị',
            self::ACTION_COMPLETE => 'Hoàn thành',
        ];
    }

    /** Thứ tự cột trong ma trận phân quyền. @return list<string> */
    public static function actionOrder(): array
    {
        return array_keys(self::actionLabels());
    }

    public static function actionLabel(string $action): string
    {
        return self::actionLabels()[$action] ?? ucfirst($action);
    }

    /**
     * Phân hệ → ứng dụng.
     *
     * @return list<array{
     *     key: string,
     *     label: string,
     *     applications: list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     * }>
     */
    public static function subsystems(): array
    {
        $subsystems = [
            [
                'key' => 'training',
                'label' => 'Lịch đào tạo',
                'applications' => [
                    self::app('training-schedules', 'Tạo lịch đào tạo', self::CRUD_CORE),
                    self::app('schedule-details', 'Phân chia lịch học', self::CRUD_CORE),
                    self::app('teaching-assignments', 'Phân công giảng dạy', self::CRUD_CORE),
                    self::app('specializations', 'Ngành đào tạo', self::CRUD_CORE),
                    self::app('subjects', 'Môn học', self::CRUD_CORE),
                    self::app('subject-lessons', 'Bài học (khung CTĐT)', self::CRUD_CORE),
                    self::app('classes', 'Lớp học', self::CRUD_CORE),
                ],
            ],
            [
                'key' => 'standard-hours',
                'label' => 'Giờ chuẩn GV',
                'applications' => self::standardHoursApplications(),
            ],
            [
                'key' => 'scientific-research',
                'label' => 'Nghiên cứu khoa học',
                'applications' => self::scientificResearchApplications(),
            ],
            [
                'key' => 'lms',
                'label' => 'LMS',
                'applications' => self::lmsApplications(),
            ],
            [
                'key' => 'grades',
                'label' => 'Quản lý điểm',
                'applications' => self::gradeApplications(),
            ],
            [
                'key' => 'tms',
                'label' => 'TMS — Đào tạo & Khảo thí Nội bộ',
                'applications' => self::tmsApplications(),
            ],
            [
                'key' => 'essay-exam',
                'label' => 'Quản lý đề thi tự luận & tích hợp',
                'applications' => self::essayExamApplications(),
            ],
            [
                'key' => 'exam-organization',
                'label' => 'Tổ chức thi',
                'applications' => self::examOrganizationApplications(),
            ],
            [
                'key' => 'inventory',
                'label' => 'Quản lý vật tư / tài sản',
                'applications' => self::inventoryApplications(),
            ],
            [
                'key' => 'leave-management',
                'label' => 'Quản lý nghỉ phép',
                'applications' => self::leaveManagementApplications(),
            ],
            [
                'key' => 'system',
                'label' => 'Hệ thống và dữ liệu dùng chung',
                'applications' => [
                    self::app('dashboards', 'Dashboard tổng quan', [self::ACTION_VIEW => ['index']],
                        'Số liệu tổng hợp từ Lịch đào tạo, LMS và Quản lý điểm.'),
                    self::app('units', 'Đơn vị (Khoa / Phòng / Ban)', self::CRUD_CORE),
                    self::app('instructors', 'Hồ sơ giảng viên', self::CRUD_CORE),
                    self::app('buildings', 'Giảng đường', self::CRUD_CORE),
                    self::app('classrooms', 'Phòng học', self::CRUD_CORE),
                    self::app('student-schedule', 'Lịch học của học viên', [self::ACTION_VIEW => ['index', 'show']],
                        'Màn hình học viên tự xem lịch của mình.'),
                    self::app('instructor-schedule', 'Lịch giảng của giảng viên', [self::ACTION_VIEW => ['index', 'show']],
                        'Màn hình giảng viên tự xem lịch dạy của mình.'),
                    self::app('export-templates', 'Mẫu xuất dữ liệu', self::CRUD_CORE,
                        'Mẫu Word/Excel dùng chung cho Dashboard, LMS và Quản lý điểm.'),
                    self::app('trash', 'Thùng rác', [
                        self::ACTION_VIEW => ['index', 'show'],
                        self::ACTION_EDIT => ['restore'],
                        self::ACTION_DELETE => ['delete'],
                    ], 'Sửa = khôi phục bản ghi đã xóa mềm. Xóa = xóa vĩnh viễn.'),
                ],
            ],
            [
                'key' => 'users',
                'label' => 'Người dùng',
                'applications' => [
                    self::app('users', 'Tài khoản người dùng', self::CRUD_CORE,
                        'Gồm cả nhập khẩu danh sách và gán đơn vị công tác.'),
                    self::app('roles', 'Vai trò', self::CRUD_CORE,
                        'Quyền nhạy cảm: ai sửa được vai trò là sửa được quyền của mọi người.'),
                    self::app('permissions', 'Quyền hệ thống', self::CRUD_CORE,
                        'Danh mục permission thô — chỉ quản trị hệ thống mới cần.'),
                ],
            ],
        ];

        return $subsystems;
    }

    /**
     * 15 ứng dụng Giờ chuẩn GV theo đúng "Bảng phân quyền vai trò".
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function standardHoursApplications(): array
    {
        return [
            self::app('standard-hours', 'Truy cập phân hệ Giờ chuẩn GV', [
                self::ACTION_VIEW => ['index', 'show', 'view'],
            ], 'Bắt buộc tick Xem thì tài khoản mới vào được phân hệ.'),
            self::app('standard-hours.object-types', 'Đối tượng (định mức GC/NCKH)', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.positions', 'Chức danh (tỷ lệ)', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.departments', 'Bộ môn (Khoa)', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.department-overtime', 'Tính định mức giờ chuẩn', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.norm-reductions', 'Giảm trừ định mức', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.conversion-categories', 'Hoạt động chuyên môn (danh mục)', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.research-categories', 'Danh mục NCKH', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.calculations', 'Tính giờ chuẩn', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_CREATE => ['create', 'run'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_APPROVE => ['approve'],
            ], 'Thêm = chạy tính giờ chuẩn cho kỳ.'),
            self::app('standard-hours.reports', 'Báo cáo thống kê', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EXPORT => ['export'],
            ], 'Báo cáo chỉ đọc — không có Thêm/Sửa/Xóa.'),
            self::app('standard-hours.settings.period-mode', 'Kỳ tính năm học', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EDIT => ['edit'],
            ]),
            self::app('standard-hours.settings.research-rules', 'Luật quy đổi', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EDIT => ['edit'],
            ]),
            self::app('standard-hours.conversion-records', 'Kê khai hoạt động chuyên môn', self::CRUD_STANDARD_HOURS + [
                self::ACTION_APPROVE => ['approve'],
            ]),
            self::app('standard-hours.research-records', 'Kê khai NCKH', self::CRUD_STANDARD_HOURS + [
                self::ACTION_APPROVE => ['approve'],
            ]),
            self::app('standard-hours.external-activities', 'Hoạt động ngoài HĐCM', self::CRUD_STANDARD_HOURS + [
                self::ACTION_APPROVE => ['approve'],
            ]),
            self::app('standard-hours.other-teaching', 'Giờ giảng dạy khác', self::CRUD_STANDARD_HOURS + [
                self::ACTION_APPROVE => ['approve'],
            ], 'Giảng viên kê khai giờ dạy ngoài lịch; Khoa thẩm định trước, Phòng Đào Tạo duyệt cuối (quyền Duyệt ở đây).'),
            self::app('standard-hours.hour-exchanges', 'Quyết định bù giờ', self::CRUD_STANDARD_HOURS),
            self::app('standard-hours.declarations', 'Hồ sơ kê khai giờ chuẩn', self::CRUD_STANDARD_HOURS + [
                self::ACTION_APPROVE => ['approve'],
            ]),
        ];
    }

    private static function scientificResearchApplications(): array
    {
        return [
            self::app('scientific-research', 'Phân hệ nghiên cứu khoa học', [
                self::ACTION_VIEW => ['index', 'show', 'view', 'portal'],
                self::ACTION_CREATE => ['create', 'store'],
                self::ACTION_EDIT => ['edit', 'update'],
                self::ACTION_DELETE => ['delete', 'destroy'],
                self::ACTION_APPROVE => ['approve', 'status'],
                self::ACTION_EXPORT => ['export'],
            ]),
            self::app('scientific-research.announcements', 'Thông báo NCKH', self::scientificCrudActions()),
            self::app('scientific-research.registrations', 'Đăng ký NCKH', [
                self::ACTION_VIEW => ['view', 'index', 'show'],
                self::ACTION_CREATE => ['create', 'store'],
                self::ACTION_EDIT => ['edit', 'update'],
                self::ACTION_DELETE => ['delete', 'destroy'],
                self::ACTION_SUBMIT => ['submit'],
                self::ACTION_ASSIGN => ['unit-approve'],
                self::ACTION_APPROVE => ['agency-approve', 'return', 'status'],
                self::ACTION_COMPLETE => ['sync-standard-hours'],
            ]),
            self::app('scientific-research.results', 'Nộp kết quả NCKH', array_replace(self::scientificCrudActions(), [
                self::ACTION_SUBMIT => ['submit'],
                self::ACTION_APPROVE => ['approve', 'status'],
            ])),
            self::app('scientific-research.staff', 'Cán bộ NCKH', self::scientificCrudActions()),
            self::app('scientific-research.plans', 'Kế hoạch NCKH', self::scientificCrudActions()),
            self::app('scientific-research.councils', 'Hội đồng khoa học', self::scientificCrudActions()),
            self::app('scientific-research.funding', 'Kinh phí NCKH', self::scientificCrudActions()),
            self::app('scientific-research.products', 'Sản phẩm khoa học', self::scientificCrudActions()),
            self::app('scientific-research.repository', 'Kho dữ liệu NCKH', self::scientificCrudActions()),
            self::app('scientific-research.reports', 'Báo cáo NCKH', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EXPORT => ['export', 'csv', 'excel', 'word'],
            ]),
            self::app('scientific-research.audit', 'Nhật ký NCKH', [
                self::ACTION_VIEW => ['view', 'index'],
            ]),
        ];
    }

    private static function scientificCrudActions(): array
    {
        return [
            self::ACTION_VIEW => ['index', 'show', 'view'],
            self::ACTION_CREATE => ['create', 'store'],
            self::ACTION_EDIT => ['edit', 'update'],
            self::ACTION_DELETE => ['delete', 'destroy'],
        ];
    }

    /**
     * Các ứng dụng của phân hệ LMS, bám theo màn hình thật trong
     * `modules/Lms` (shell quản trị, cổng giảng viên và cổng học viên).
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function lmsApplications(): array
    {
        return [
            self::app('lms', 'Truy cập LMS / Danh sách khóa học', self::CRUD_CORE + [
                self::ACTION_APPROVE => ['manage'],
            ], 'Bắt buộc tick Xem thì tài khoản mới vào được LMS. Duyệt = quản trị mọi khóa, bỏ qua giới hạn "khóa mình dạy".'),
            self::app('lms.lessons', 'Bài giảng trong khóa', self::CRUD_LMS),
            self::app('lms.materials', 'Tài liệu học tập', self::CRUD_LMS),
            self::app('lms.assignments', 'Bài tập & chấm bài', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['grade'],
            ], 'Duyệt = chấm điểm bài nộp của học viên.'),
            self::app('lms.exams', 'Thi online', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['grade'],
            ], 'Duyệt = chấm và mở khóa lượt thi.'),
            self::app('lms.question-banks', 'Ngân hàng câu hỏi', self::CRUD_LMS),
            self::app('lms.attendance', 'Điểm danh lớp học số', self::CRUD_LMS,
                'Nối trực tiếp với tiết học trong Lịch đào tạo (schedule_details).'),
            self::app('lms.gradebook', 'Sổ điểm LMS', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['transfer'],
                self::ACTION_EXPORT => ['export'],
            ], 'Duyệt = chuyển điểm tổng hợp sang phân hệ Quản lý điểm.'),
            self::app('lms.certificates', 'Chứng chỉ hoàn thành', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['issue'],
            ], 'Duyệt = cấp chứng chỉ cho học viên đủ điều kiện.'),
            self::app('lms.surveys', 'Khảo sát khóa học', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['publish'],
            ], 'Duyệt = phát hành khảo sát cho học viên.'),
            self::app('lms.alerts', 'Cảnh báo học tập', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['resolve'],
            ], 'Duyệt = xử lý và đóng cảnh báo.'),
            self::app('lms.forum', 'Diễn đàn khóa học', self::CRUD_LMS),
            self::app('lms.chat', 'Tin nhắn lớp', self::CRUD_LMS),
            self::app('lms.progress', 'Tiến độ học tập', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EXPORT => ['export'],
            ], 'Chỉ đọc — tiến độ do hệ thống ghi nhận tự động.'),
            self::app('lms.members', 'Thành viên khóa học', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['sync'],
            ], 'Duyệt = đồng bộ danh sách học viên từ lớp gốc.'),
            self::app('lms.scorm', 'Học liệu SCORM', self::CRUD_LMS),
            self::app('campus-network', 'Wi-Fi trường (điểm danh QR)', self::CRUD_CORE,
                'Cấu hình dải IP / GPS dùng để xác minh điểm danh tại trường.'),
        ];
    }

    /**
     * Các ứng dụng của phân hệ TMS (`modules/Tms`) — cổng đào tạo/khảo thí nội
     * bộ dành cho cán bộ/giảng viên, hoàn toàn tách biệt với `modules/Lms`.
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function tmsApplications(): array
    {
        return [
            self::app('tms.courses', 'Khóa học TMS (bài học/tài liệu)', self::CRUD_LMS),
            self::app('tms.lessons', 'Bài học TMS', self::CRUD_LMS),
            self::app('tms.question-banks', 'Ngân hàng câu hỏi TMS', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['approve'],
            ], 'Duyệt = duyệt/trả lại NHCH qua từng cấp (Khoa → Khảo thí → BGH), giống cơ chế đã dùng cho LMS/Ra đề tự luận.'),
            self::app('tms.exams', 'Đề thi TMS', self::CRUD_LMS),
            self::app('tms.assignments', 'Giao nhiệm vụ TMS', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['manage'],
            ], 'Duyệt = chọn đối tượng (đơn vị/chức vụ/nhóm/cá nhân) và giao khóa học hoặc đề thi.'),
            self::app('tms.tasks', 'Nhiệm vụ TMS (cấp trên giao theo đơn vị)', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_APPROVE => ['accept', 'distribute'],
            ], 'Cấp trên tạo nhiệm vụ + chọn đơn vị nhận; người phụ trách đơn vị (theo scope) tiếp nhận rồi phân công xuống cá nhân.'),
            self::app('tms.reports', 'Báo cáo hoàn thành TMS', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EXPORT => ['export'],
            ], 'Chỉ đọc — % hoàn thành theo đơn vị, drill-down từng người.'),
            self::app('tms.certificates', 'Chứng chỉ TMS', [
                self::ACTION_VIEW => ['view'],
            ], 'Chỉ đọc — chứng chỉ được hệ thống tự cấp khi hoàn thành đạt yêu cầu.'),
            self::app('tms.offline-sessions', 'Đào tạo trực tiếp TMS (offline)', self::CRUD_LMS,
                'CRUD buổi đào tạo trực tiếp + điểm danh QR/OTP/thủ công.'),
            self::app('tms.learning-profile', 'Hồ sơ năng lực TMS', [
                self::ACTION_VIEW => ['view'],
            ], 'Chỉ đọc — tổng hợp khóa học/chứng chỉ/điểm danh của 1 cán bộ.'),
            self::app('tms.hierarchy', 'Quản lý cấp (chức vụ/đơn vị) TMS', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_APPROVE => ['manage'],
            ], 'Chỉ super-admin — xem cây đơn vị/chức vụ và người đang giữ từng chức vụ.'),
            self::app('tms.documents', 'Văn bản đi/đến TMS', self::CRUD_LMS + [
                self::ACTION_APPROVE => ['forward'],
            ], 'Đăng ký văn bản đến/đi, chuyển tiếp xử lý qua từng đơn vị/chức vụ, theo dõi trạng thái.'),
        ];
    }

    /**
     * Các ứng dụng của phân hệ Quản lý điểm, bám theo `modules/Grades`.
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function gradeApplications(): array
    {
        return [
            self::app('grades', 'Truy cập Quản lý điểm', self::CRUD_CORE + [
                self::ACTION_APPROVE => ['manage'],
            ], 'Bắt buộc tick Xem thì tài khoản mới vào được phân hệ. Duyệt = phạm vi toàn trường (Phòng Đào tạo).'),
            self::app('grades.books', 'Bảng điểm môn học', self::CRUD_GRADES,
                'Mỗi bảng điểm gắn với một lớp + một môn; khóa LMS chuyển điểm sang đây.'),
            self::app('grades.columns', 'Cột điểm & trọng số', self::CRUD_GRADES,
                'Điểm thành phần, hệ số và cách tính điểm tổng.'),
            self::app('grades.entry', 'Nhập điểm', self::CRUD_GRADES,
                'Nhập trực tiếp hoặc nhập theo lô cho từng cột điểm.'),
            self::app('grades.approval', 'Khóa & phê duyệt bảng điểm', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_APPROVE => ['approve'],
                self::ACTION_EDIT => ['lock'],
            ], 'Sửa = khóa/mở khóa bảng điểm. Duyệt = phê duyệt chốt điểm.'),
            self::app('grades.requests', 'Yêu cầu sửa điểm sau khóa', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_APPROVE => ['review'],
            ], 'Giảng viên đề nghị, cấp quản lý xét duyệt.'),
            self::app('grades.conduct', 'Hạnh kiểm / rèn luyện', self::CRUD_GRADES),
            self::app('grades.graduation', 'Xét tốt nghiệp', self::CRUD_GRADES + [
                self::ACTION_APPROVE => ['approve'],
            ], 'Duyệt = chốt kết quả xét tốt nghiệp của đợt.'),
            self::app('grades.extracts', 'Trích xuất bảng điểm', [
                self::ACTION_VIEW => ['view'],
                self::ACTION_EXPORT => ['export'],
            ], 'Bảng điểm cá nhân, bảng điểm lớp, hồ sơ học viên.'),
        ];
    }

    /**
     * Ra đề tự luận (`modules/EssayExam`) — luồng duyệt 3 cấp: Khoa
     * (faculty-manager) → Khảo thí (exam-manager) → Ban Giám hiệu
     * (system-manager, vì hệ thống không có role "bgh" riêng). Duyệt cấp cuối
     * (BGH) tự động vào ngân hàng câu hỏi, khóa đề và sinh mã QR.
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function essayExamApplications(): array
    {
        return [
            self::app('essay-exams', 'Truy cập Quản lý đề thi tự luận', [
                self::ACTION_VIEW => ['index', 'mine', 'show'],
            ], 'Bắt buộc tick Xem thì tài khoản mới vào được phân hệ.'),
            self::app('essay-exams.authoring', 'Soạn / import / gửi duyệt đề tự luận', [
                self::ACTION_VIEW => ['index'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_DELETE => ['delete'],
            ], 'Giảng viên tự soạn đề trực tiếp trên hệ thống. Xóa: chỉ xóa được đề tự tạo, còn ở trạng thái Bản nháp/Bị trả lại.'),
            self::app('essay-exams.import', 'Import đề tự luận', [
                self::ACTION_VIEW => ['create'],
                self::ACTION_CREATE => ['create'],
            ], 'Giảng viên nhập đề từ file có sẵn. Không có màn hình xem riêng — Xem và Thêm dùng chung 1 permission vì import là thao tác một bước.'),
            self::app('essay-exams.submission', 'Gửi đề đi duyệt', [
                self::ACTION_VIEW => ['create'],
                self::ACTION_CREATE => ['create'],
            ], 'Giảng viên gửi đề đã soạn/import vào luồng duyệt (Khoa → Khảo thí → BGH). Không có màn hình xem riêng — Xem và Thêm dùng chung 1 permission vì gửi duyệt là thao tác một bước.'),
            self::app('essay-exams.approval', 'Duyệt đề tự luận', [
                self::ACTION_VIEW => ['index'],
                self::ACTION_APPROVE => ['approve'],
            ], 'Duyệt hoặc trả lại đề theo đúng cấp của tài khoản (Khoa/Khảo thí/BGH do code tự xác định theo vai trò).'),
            self::app('essay-exams.bank', 'Ngân hàng đề đã duyệt', [
                self::ACTION_VIEW => ['index'],
            ], 'Xem đề đã được BGH duyệt và khóa, đã có mã QR.'),
            self::app('essay-exams.draw', 'Rút đề / In đề', [
                self::ACTION_VIEW => ['index'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EXPORT => ['export'],
            ], 'Rút đề từ ngân hàng đã duyệt để tổ hợp thành đề thi, in biên bản.'),
        ];
    }

    /**
     * Tổ chức thi (`modules/ExamOrganization`) — lập kế hoạch, phân công coi
     * thi/chấm thi, đánh số báo danh, xếp phòng, ghép túi bài, nhập điểm.
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function examOrganizationApplications(): array
    {
        return [
            self::app('exam-organization', 'Tổ chức thi', [
                self::ACTION_VIEW => ['index'],
                self::ACTION_CREATE => ['plan', 'assignment', 'execution', 'grading'],
            ], 'Thêm = lập kế hoạch thi, phân công nhân sự, xử lý nghiệp vụ trước/trong/sau thi (đánh số báo danh, xếp phòng, ghép túi, nhập điểm).'),
        ];
    }

    /**
     * Quản lý vật tư / tài sản (`modules/Inventory`).
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function inventoryApplications(): array
    {
        return [
            self::app('inventory.access', 'Vật tư — Truy cập cổng', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Vào được cổng quản lý vật tư (điều kiện cần cho mọi thao tác khác).'),
            self::app('inventory.materials', 'Vật tư — Danh mục', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_IMPORT => ['import'],
            ], 'Danh mục các loại vật tư/tài sản dùng chung.'),
            self::app('inventory.categories', 'Vật tư — Ngành / loại vật tư', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
            ], 'Phân cấp ngành và loại vật tư để dùng thống nhất trong toàn hệ thống.'),
            self::app('inventory.assets', 'Vật tư — Cập nhật trong đơn vị', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_IMPORT => ['import'],
            ], 'Cập nhật số lượng/tình trạng vật tư trong đơn vị quản lý.'),
            self::app('inventory.warehouses', 'Vật tư — Kho', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
            ], 'Quản lý kho vật tư theo đơn vị.'),
            self::app('inventory.locations', 'Vật tư — Tòa nhà / phòng', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_IMPORT => ['import'],
            ], 'Quản lý vị trí lắp đặt, ảnh và người phụ trách phòng.'),
            self::app('inventory.proposals', 'Vật tư — Đề xuất', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_APPROVE => ['approve'],
                self::ACTION_EXPORT => ['export'],
            ], 'Đề xuất mua sắm/cấp phát vật tư và duyệt đề xuất.'),
            self::app('inventory.transfers', 'Vật tư — Điều động', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_APPROVE => ['approve'],
                self::ACTION_EXPORT => ['export'],
            ], 'Điều động, thu hồi vật tư giữa các đơn vị/kho.'),
            self::app('inventory.repairs', 'Vật tư — Phân công / sửa chữa', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
            ], 'Theo dõi hỏng hóc và phân công sửa chữa vật tư.'),
            self::app('inventory.reports', 'Vật tư — Báo cáo', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_EXPORT => ['export'],
            ], 'Báo cáo tổng hợp vật tư theo kỳ/vị trí/đơn vị.'),
            self::app('inventory.logs', 'Vật tư — Nhật ký', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
            ], 'Nhật ký thao tác cập nhật/điều động vật tư.'),
            self::app('inventory.templates', 'Vật tư — Mẫu biểu', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
                self::ACTION_DELETE => ['delete'],
                self::ACTION_EXPORT => ['export'],
            ], 'Mẫu biểu Word/Excel dùng khi xuất báo cáo vật tư.'),
            self::app('inventory.liquidations', 'Vật tư — Thanh lý', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Tra cứu vật tư đã thanh lý.'),
            self::app('inventory.search', 'Vật tư — Tìm kiếm', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Tra cứu nhanh vật tư theo danh mục, vị trí hoặc đơn vị.'),
            self::app('inventory', 'Quản lý vật tư (tương thích quyền cũ)', self::CRUD_CORE + [
                self::ACTION_APPROVE => ['approve'],
                self::ACTION_EXPORT => ['export'],
                self::ACTION_IMPORT => ['import'],
            ], 'Quyền tổng — giữ lại để tương thích tài khoản đã cấp quyền theo cấu trúc cũ.'),
        ];
    }

    /**
     * Quản lý nghỉ phép (`modules/LeaveManagement`).
     *
     * @return list<array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}>
     */
    private static function leaveManagementApplications(): array
    {
        return [
            self::app('leave-management', 'Quản lý nghỉ phép (tổng)', self::CRUD_CORE + [
                self::ACTION_APPROVE => ['approve'],
                self::ACTION_EXPORT => ['export'],
            ], 'Đề xuất, duyệt và theo dõi nghỉ phép.'),
            self::app('leave-management.access', 'Phép — Truy cập cổng', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Vào được cổng quản lý phép (điều kiện cần cho mọi thao tác khác).'),
            self::app('leave-management.personnel', 'Phép — Hồ sơ quân nhân', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Xem danh sách quân nhân / nhân sự quản lý phép.'),
            self::app('leave-management.requests', 'Phép — Đề xuất nghỉ', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_CREATE => ['create'],
                self::ACTION_EDIT => ['edit'],
            ], 'Tạo và chỉnh sửa đề xuất nghỉ phép.'),
            self::app('leave-management.approvals', 'Phép — Duyệt đơn', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_APPROVE => ['approve'],
            ], 'Xem và duyệt các đơn nghỉ phép đang chờ xử lý.'),
            self::app('leave-management.batches', 'Phép — Đợt nghỉ', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Theo dõi các đợt nghỉ đã duyệt.'),
            self::app('leave-management.records', 'Phép — Hồ sơ lưu trữ', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Tra cứu hồ sơ phép đã lưu trữ.'),
            self::app('leave-management.alerts', 'Phép — Thông báo', [
                self::ACTION_VIEW => ['index', 'show'],
            ], 'Xem và đánh dấu đã đọc các thông báo/cảnh báo phép.'),
            self::app('leave-management.reports', 'Phép — Báo cáo', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_EXPORT => ['export'],
            ], 'Xem và xuất báo cáo tổng hợp phép theo năm.'),
            self::app('leave-management.report-templates', 'Phép — Mẫu báo cáo', [
                self::ACTION_VIEW => ['index', 'show'],
                self::ACTION_EXPORT => ['export'],
            ], 'Xuất báo cáo phép theo mẫu Word cố định (quân nhân đã/chưa nghỉ, đăng ký phép năm...).'),
        ];
    }

    /**
     * @param  array<string, list<string>>  $actions
     * @return array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string}
     */
    private static function app(string $permission, string $label, array $actions, ?string $note = null): array
    {
        $entry = [
            'key' => $permission,
            'label' => $label,
            'permission' => $permission,
            'actions' => $actions,
        ];

        if ($note !== null) {
            $entry['note'] = $note;
        }

        return $entry;
    }

    /**
     * Danh sách ứng dụng phẳng, key = permission prefix.
     *
     * @return array<string, array{key: string, label: string, permission: string, actions: array<string, list<string>>, note?: string, subsystem: string, subsystemLabel: string}>
     */
    public static function applications(): array
    {
        $flat = [];

        foreach (self::subsystems() as $subsystem) {
            foreach ($subsystem['applications'] as $application) {
                $flat[$application['key']] = $application + [
                    'subsystem' => $subsystem['key'],
                    'subsystemLabel' => $subsystem['label'],
                ];
            }
        }

        return $flat;
    }

    public static function label(string $applicationKey): string
    {
        return self::applications()[$applicationKey]['label'] ?? $applicationKey;
    }

    /**
     * Permission thật của một ô trong ma trận.
     *
     * @return list<string>
     */
    public static function permissionNamesFor(string $applicationKey, string $action): array
    {
        $application = self::applications()[$applicationKey] ?? null;
        if ($application === null) {
            return [];
        }

        return array_map(
            fn (string $suffix) => $application['permission'].'.'.$suffix,
            $application['actions'][$action] ?? []
        );
    }

    /**
     * Toàn bộ permission mà registry khai báo.
     *
     * @return list<string>
     */
    public static function permissionNames(): array
    {
        $names = [];

        foreach (self::applications() as $application) {
            foreach ($application['actions'] as $suffixes) {
                foreach ($suffixes as $suffix) {
                    $names[] = $application['permission'].'.'.$suffix;
                }
            }
        }

        return array_values(array_unique($names));
    }

    /**
     * Toàn bộ permission của một phân hệ.
     *
     * @return list<string>
     */
    public static function subsystemPermissionNames(string $subsystemKey): array
    {
        $names = [];

        foreach (self::applications() as $application) {
            if ($application['subsystem'] !== $subsystemKey) {
                continue;
            }

            foreach ($application['actions'] as $suffixes) {
                foreach ($suffixes as $suffix) {
                    $names[] = $application['permission'].'.'.$suffix;
                }
            }
        }

        return array_values(array_unique($names));
    }

    /**
     * Permission do registry sinh ra cho một prefix, dạng prefix => [action…]
     * — dùng khi seed permission trong SyncPermissionsAndRoles.
     *
     * @return array<string, list<string>>
     */
    public static function permissionDefinitions(): array
    {
        $definitions = [];

        foreach (self::applications() as $application) {
            $suffixes = [];
            foreach ($application['actions'] as $actionSuffixes) {
                foreach ($actionSuffixes as $suffix) {
                    $suffixes[$suffix] = true;
                }
            }

            $definitions[$application['permission']] = array_keys($suffixes);
        }

        return $definitions;
    }

    /**
     * Quyền gộp cũ → quyền chi tiết tương đương.
     *
     * Dùng để migrate role đang giữ `.manage` (và các quyền tổng của phân hệ
     * Giờ chuẩn) sang bộ Thêm/Sửa/Xóa chi tiết mà không ai bị mất quyền.
     *
     * @return array<string, list<string>>
     */
    public static function legacyPermissionMap(): array
    {
        $map = [];

        foreach (self::applications() as $application) {
            if (! in_array($application['permission'], self::LEGACY_MANAGE_PREFIXES, true)) {
                continue;
            }

            $granular = [];
            foreach ([self::ACTION_CREATE, self::ACTION_EDIT, self::ACTION_DELETE] as $action) {
                foreach (self::permissionNamesFor($application['key'], $action) as $name) {
                    $granular[] = $name;
                }
            }

            if ($granular !== []) {
                $map[$application['permission'].'.manage'] = $granular;
            }
        }

        // Chạy tính giờ chuẩn trước đây là `.run`, nay nằm dưới cột "Thêm".
        $map['standard-hours.calculations.run'] = ['standard-hours.calculations.create'];

        // Hai trang cài đặt tách ra từ `standard-hours.settings`.
        $map['standard-hours.settings.view'] = [
            'standard-hours.settings.period-mode.view',
            'standard-hours.settings.research-rules.view',
        ];
        $map['standard-hours.settings.manage'] = [
            'standard-hours.settings.period-mode.view',
            'standard-hours.settings.period-mode.edit',
            'standard-hours.settings.research-rules.view',
            'standard-hours.settings.research-rules.edit',
        ];

        return $map;
    }
}
