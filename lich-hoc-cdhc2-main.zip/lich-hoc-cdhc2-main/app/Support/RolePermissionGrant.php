<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

/**
 * Gan quyen cho vai tro, AN TOAN khi nhieu tien trinh chay cung luc.
 *
 * `permissions:sync` chay o initContainer moi lan rollout. Khi 2 tien trinh chay
 * song song (HPA > 1 replica, hoac monolith + core cung khoi dong sau su co) thi
 * Spatie bi race:
 *   - syncPermissions() = detach() roi attach(): B chen vao giua luc A vua
 *     detach xong va chua attach -> A attach trung.
 *   - givePermissionTo() = attach(diff) voi diff tinh tu quan he DA LOAD: hai
 *     tien trinh tinh cung mot diff roi cung chen.
 * Ca hai deu la INSERT thuong nen no "1062 Duplicate entry ... for key PRIMARY".
 *
 * Ghi thang bang pivot bang insertOrIgnore (INSERT IGNORE) thi ban ghi trung bi
 * bo qua, bao nhieu tien trinh chay song song cung duoc.
 */
final class RolePermissionGrant
{
    /**
     * @param  iterable<int, Permission|int>  $permissions
     * @param  bool  $exact  true = khop chinh xac (bo quyen ngoai danh sach, dung cho
     *                       super-admin); false = chi cong them (dung cho cac nhom
     *                       vai tro, de giu quyen admin tu tay them qua giao dien).
     */
    public static function grant(Role $role, iterable $permissions, bool $exact): void
    {
        $table = config('permission.table_names.role_has_permissions', 'role_has_permissions');
        $roleKey = config('permission.column_names.role_pivot_key') ?: 'role_id';
        $permKey = config('permission.column_names.permission_pivot_key') ?: 'permission_id';

        $ids = collect($permissions)
            ->map(fn ($p) => (int) (is_object($p) ? $p->getKey() : $p))
            ->filter()
            ->unique()
            ->values();

        if ($exact) {
            DB::table($table)
                ->where($roleKey, $role->getKey())
                ->when($ids->isNotEmpty(), fn ($q) => $q->whereNotIn($permKey, $ids->all()))
                ->delete();
        }

        // Chia lo de khong vuot gioi han placeholder cua MySQL khi co hang nghin quyen.
        foreach ($ids->chunk(500) as $chunk) {
            DB::table($table)->insertOrIgnore(
                $chunk->map(fn (int $id) => [$permKey => $id, $roleKey => $role->getKey()])->values()->all()
            );
        }

        // Ghi thang vao pivot la di vong qua Spatie, nen phai tu xoa cache quyen va
        // quan he da load - neu khong hasPermissionTo() van tra ket qua cu.
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $role->unsetRelation('permissions');
    }
}
