<?php

namespace App\Support;

/**
 * Danh mục hành chính 2 cấp (Tỉnh/Thành phố -> Xã/Phường) áp dụng từ 01/07/2025 - 34 tỉnh/thành, 3320 xã/phường.
 * Đọc thẳng database/data/vn-localities (cùng nguồn LeaveLocalitySeeder) để core không phụ thuộc bảng của service khác.
 */
final class VnLocalities
{
    /** @var array<string, array{code: string, name: string, fullName: string}>|null */
    private static ?array $provinces = null;

    /** @var array<string, array{code: string, name: string, fullName: string, provinceCode: string}>|null */
    private static ?array $wards = null;

    /** @return array<string, array{code: string, name: string, fullName: string}> theo mã */
    public static function provinces(): array
    {
        if (self::$provinces === null) {
            self::$provinces = [];
            foreach (self::read('provinces.json') as $p) {
                self::$provinces[(string) $p['code']] = ['code' => (string) $p['code'], 'name' => (string) $p['name'], 'fullName' => (string) ($p['fullName'] ?? $p['name'])];
            }
            uasort(self::$provinces, fn ($a, $b) => strcmp(self::sortKey($a['name']), self::sortKey($b['name'])));
        }

        return self::$provinces;
    }

    /** @return list<array{code: string, name: string, fullName: string}> xã/phường của 1 tỉnh, theo tên */
    public static function wards(?string $provinceCode): array
    {
        if (! $provinceCode) {
            return [];
        }
        $list = array_values(array_filter(self::allWards(), fn ($w) => $w['provinceCode'] === $provinceCode));
        usort($list, fn ($a, $b) => strcmp(self::sortKey($a['name']), self::sortKey($b['name'])));

        return array_map(fn ($w) => ['code' => $w['code'], 'name' => $w['name'], 'fullName' => $w['fullName']], $list);
    }

    public static function provinceName(?string $code): ?string
    {
        return $code ? (self::provinces()[$code]['name'] ?? null) : null;
    }

    public static function wardName(?string $code): ?string
    {
        return $code ? (self::allWards()[$code]['name'] ?? null) : null;
    }

    public static function wardBelongsTo(?string $wardCode, ?string $provinceCode): bool
    {
        return $wardCode !== null && $provinceCode !== null && (self::allWards()[$wardCode]['provinceCode'] ?? null) === $provinceCode;
    }

    /**
     * Quy tắc cho 5 trường quê quán / trú quán của người dùng (form tạo/sửa người dùng).
     *
     * @param  array<string, mixed>  $input
     * @return array<string, list<mixed>>
     */
    public static function userRules(array $input): array
    {
        $rules = ['residence_address' => ['nullable', 'string', 'max:255']];
        foreach (['hometown', 'residence'] as $prefix) {
            $province = $input[$prefix.'_province_code'] ?? null;
            $province = is_string($province) ? $province : null;
            $rules[$prefix.'_province_code'] = ['bail', 'nullable', 'string', function ($attribute, $value, $fail) {
                if ($value !== null && $value !== '' && ! isset(self::provinces()[(string) $value])) {
                    $fail('Tỉnh/thành phố không hợp lệ.');
                }
            }];
            $rules[$prefix.'_ward_code'] = ['bail', 'nullable', 'string', function ($attribute, $value, $fail) use ($province) {
                if ($value !== null && $value !== '' && ! self::wardBelongsTo((string) $value, $province ? (string) $province : null)) {
                    $fail('Xã/phường không thuộc tỉnh/thành phố đã chọn.');
                }
            }];
        }

        return $rules;
    }

    /** "Xã/Phường, Tỉnh" - bỏ phần trống. */
    public static function label(?string $wardCode, ?string $provinceCode): string
    {
        return implode(', ', array_filter([self::wardName($wardCode), self::provinceName($provinceCode)]));
    }

    /** @return array<string, array{code: string, name: string, fullName: string, provinceCode: string}> */
    private static function allWards(): array
    {
        if (self::$wards === null) {
            self::$wards = [];
            foreach (self::read('wards.json') as $w) {
                self::$wards[(string) $w['code']] = ['code' => (string) $w['code'], 'name' => (string) $w['name'],
                    'fullName' => (string) ($w['fullName'] ?? $w['name']), 'provinceCode' => (string) $w['provinceCode']];
            }
        }

        return self::$wards;
    }

    /** @return list<array<string, mixed>> */
    private static function read(string $file): array
    {
        $path = database_path('data/vn-localities/'.$file);

        return is_file($path) ? (json_decode((string) file_get_contents($path), true) ?: []) : [];
    }

    private static function sortKey(string $name): string
    {
        return mb_strtolower(\Normalizer::normalize($name, \Normalizer::FORM_D) ?: $name);
    }
}
