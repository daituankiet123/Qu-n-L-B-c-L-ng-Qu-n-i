<?php

namespace App\Support;

use Modules\Authentication\Providers\AuthenticationServiceProvider;
use Modules\Building\Providers\BuildingServiceProvider;
use Modules\Class\Providers\ClassServiceProvider;
use Modules\Classroom\Providers\ClassroomServiceProvider;
use Modules\Dashboard\Providers\DashboardServiceProvider;
use Modules\DatabaseManagement\Providers\DatabaseManagementServiceProvider;
use Modules\EssayExam\Providers\EssayExamServiceProvider;
use Modules\ExamOrganization\Providers\ExamOrganizationServiceProvider;
use Modules\ExportTemplates\Providers\ExportTemplatesServiceProvider;
use Modules\Grades\Providers\GradesServiceProvider;
use Modules\Home\Providers\HomeServiceProvider;
use Modules\Instructor\Providers\InstructorServiceProvider;
use Modules\InstructorSchedule\Providers\InstructorScheduleServiceProvider;
use Modules\Inventory\Providers\InventoryServiceProvider;
use Modules\LeaveManagement\Providers\LeaveManagementServiceProvider;
use Modules\Lms\Providers\LmsServiceProvider;
use Modules\Salary\Providers\SalaryServiceProvider;
use Modules\ScheduleDetail\Providers\ScheduleDetailServiceProvider;
use Modules\ScientificResearch\Providers\ScientificResearchServiceProvider;
use Modules\Specialization\Providers\SpecializationServiceProvider;
use Modules\StandardHours\Providers\StandardHoursServiceProvider;
use Modules\Student\Providers\StudentServiceProvider;
use Modules\StudentSchedule\Providers\StudentScheduleServiceProvider;
use Modules\Subject\Providers\SubjectServiceProvider;
use Modules\SystemSettings\Providers\SystemSettingsServiceProvider;
use Modules\TeachingAssignment\Providers\TeachingAssignmentServiceProvider;
use Modules\Tms\Providers\TmsServiceProvider;
use Modules\TrainingSchedule\Providers\TrainingScheduleServiceProvider;
use Modules\Trash\Providers\TrashServiceProvider;
use Modules\Unit\Providers\UnitServiceProvider;
use Modules\User\Providers\UserServiceProvider;

/**
 * Nguon duy nhat cho viec "module nao thuoc service nao".
 *
 * bootstrap/providers.php dung no de chon provider cho tung service
 * (CDHC2_SERVICE), va CrossServiceRoutesServiceProvider dung no de biet module
 * nao KHONG duoc nap o service hien tai ma van can dang ky route de sinh URL.
 */
final class ServiceTopology
{
    /**
     * Module nen tang: moi service (ke ca service tach le) deu nap.
     *
     * @return list<class-string>
     */
    public static function core(): array
    {
        return [
            AuthenticationServiceProvider::class,
            UserServiceProvider::class,
            UnitServiceProvider::class,
            ClassServiceProvider::class,
            SubjectServiceProvider::class,
            InstructorServiceProvider::class,
            BuildingServiceProvider::class,
            ClassroomServiceProvider::class,
            SpecializationServiceProvider::class,
            TrainingScheduleServiceProvider::class,
            TeachingAssignmentServiceProvider::class,
            ScheduleDetailServiceProvider::class,
            InstructorScheduleServiceProvider::class,
            StudentServiceProvider::class,
            StudentScheduleServiceProvider::class,
            StandardHoursServiceProvider::class,
            TrashServiceProvider::class,
            SystemSettingsServiceProvider::class,
            DatabaseManagementServiceProvider::class,
            // Bo chuyen doi tai lieu + registry mau xuat dung chung TMS/Grades/TrainingSchedule.
            ExportTemplatesServiceProvider::class,
            ScientificResearchServiceProvider::class,
        ];
    }

    /** @return array<string, list<class-string>> */
    public static function services(): array
    {
        return [
            'lms' => [
                LmsServiceProvider::class,
                EssayExamServiceProvider::class,
                ExamOrganizationServiceProvider::class,
            ],
            'tms' => [
                TmsServiceProvider::class,
                InventoryServiceProvider::class,
                LeaveManagementServiceProvider::class,
            ],
            'grades' => [
                GradesServiceProvider::class,
            ],
            // Service thu 5 (QL Bac Luong QNCH) - pod/DB/pipeline rieng.
            'salary' => [
                SalaryServiceProvider::class,
            ],
            'dashboard' => [
                DashboardServiceProvider::class,
                HomeServiceProvider::class,
            ],
        ];
    }

    /** @return list<class-string> */
    public static function serviceModuleProviders(): array
    {
        return array_values(array_merge(...array_values(self::services())));
    }

    /** modules/{Module}/Routes/web.php suy ra tu namespace Modules\{Module}\Providers\... */
    public static function webRoutesFile(string $providerClass): ?string
    {
        if (! preg_match('/^Modules\\\\([^\\\\]+)\\\\/', $providerClass, $m)) {
            return null;
        }

        return 'modules/'.$m[1].'/Routes/web.php';
    }
}
