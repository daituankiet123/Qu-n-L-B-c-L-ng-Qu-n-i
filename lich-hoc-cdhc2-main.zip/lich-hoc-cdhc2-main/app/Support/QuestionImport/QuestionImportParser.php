<?php

namespace App\Support\QuestionImport;

use Illuminate\Http\UploadedFile;
use PhpOffice\PhpWord\Reader\MsDoc;

class QuestionImportParser
{
    public function readImportText(UploadedFile $file): string
    {
        $path = $file->getRealPath();
        $extension = strtolower($file->getClientOriginalExtension());

        if ($extension === 'docx') {
            return $this->readDocxImportText($path);
        }
        if ($extension === 'doc') {
            return $this->readLegacyDocImportText($path);
        }

        return $this->ensureUtf8Text($this->decodePlainText(file_get_contents($path) ?: ''));
    }

    public function parseImportRows(string $text): array
    {
        $integratedRows = $this->parseIntegratedRows($text);
        if ($integratedRows !== []) {
            $normalizedRows = $this->normalizeQuestionRows($integratedRows);
            $groups = collect($normalizedRows)->groupBy('paper');
            if ($groups->count() > 1 && $groups->every(fn ($items) => $items->count() > 1 && $items->every(fn ($row) => (int) ($row['question'] ?? 0) === 61))) {
                $normalizedRows = collect($normalizedRows)->groupBy('paper')->flatMap(fn ($items) => $items->values()->map(function ($row, $index) {
                    $row['question'] = $index + 1;

                    return $row;
                }))->values()->all();
            }

            return $this->standardizeImportedRows($normalizedRows);
        }
        $lines = array_values(array_filter(preg_split('/\r\n|\r|\n/', $text) ?: [], fn ($line) => trim($line) !== ''));
        if (! $lines) {
            return [];
        }
        $sampleRows = $this->parseAnswerAfterOptionsRows($lines);
        if ($sampleRows !== []) {
            return $this->standardizeImportedRows($sampleRows);
        }
        $lines = array_values(array_filter($lines, function ($line): bool {
            $probe = $this->importProbe($line);

            return ! preg_match('/^(?:mon|thoi gian|bo cau hoi|i\.)\s*:?/u', $probe)
                && ! preg_match('/^cau\s*\d+\s*\(\s*[\d,.]+\s*diem\s*\)\s*$/u', $probe);
        }));
        $lines = array_map(static function ($line): string {
            return preg_replace_callback('/^(\s*Câu\s*\d+)\s*\(\s*([\d,.]+)\s*điểm\s*\)\s*:\s*/iu', static function ($m): string {
                return $m[1].': __POINTS_'.str_replace(',', '.', $m[2]).'__ ';
            }, trim($line)) ?: trim($line);
        }, $lines);
        $wordRows = [];
        $wordPaper = 1;
        $wordAnswerMode = false;
        $wordQuestion = null;
        $wordLastAnswerLine = false;
        foreach ($lines as $rawLine) {
            $line = trim($rawLine);
            $probe = $this->importProbe($line);
            if (preg_match('/^ii\.?\s*(dap an|answer)/', $probe)) {
                $wordAnswerMode = true;
                $wordQuestion = null;
                $wordLastAnswerLine = false;

                continue;
            }
            if ($wordAnswerMode && preg_match('/^([\d]+(?:[,.][\d]+)?)\s*$/', $line, $pm)) {
                $score = (float) str_replace(',', '.', $pm[1]);
                if ($wordQuestion !== null) {
                    $wordRows[$wordQuestion]['points'] = $score > 0 ? $score : 1;
                    if ($wordLastAnswerLine) {
                        $wordRows[$wordQuestion]['answer'] .= ($wordRows[$wordQuestion]['answer'] ? "\n" : '').'['.$pm[1].' điểm]';
                    }
                }
                $wordLastAnswerLine = false;

                continue;
            }
            if (preg_match('/^(?:de|d)\s*(?:thi\s*)?(?:so|s)\s*(\d+)/', $probe, $m)
                || preg_match('/^đề\s*(?:thi\s*)?(?:số|so)\s*(\d+)/iu', $line, $m)) {
                $wordPaper = (int) end($m);
                $wordQuestion = null;

                continue;
            }
            if (preg_match('/^\s*[^\d\r\n]*(\d+)\s*(?:\([^)]*\))?\s*[.\-:)]\s*(.*)$/u', $line, $m)) {
                $number = (int) $m[1];
                $unmatchedAnswerHeader = false;
                if ($wordAnswerMode) {
                    $previousWordQuestion = $wordQuestion;
                    $previousLastAnswerLine = $wordLastAnswerLine;
                    $wordQuestion = null;
                    $wordLastAnswerLine = false;
                    foreach ($wordRows as $idx => $existing) {
                        if ($existing['paper'] === $wordPaper && $existing['question'] === $number) {
                            $wordQuestion = $idx;
                            if (preg_match('/\t\s*([\d,.]+)\s*$/', $m[2], $pm)) {
                                $wordRows[$idx]['points'] = (float) str_replace(',', '.', $pm[1]);
                            }
                            $inlineAnswer = trim(preg_replace('/\t\s*[\d,.]+\s*$/', '', $m[2]) ?: $m[2]);
                            if ($inlineAnswer !== '') {
                                $wordRows[$idx]['answer'] = trim(($wordRows[$idx]['answer'] ? $wordRows[$idx]['answer']."\n" : '').$inlineAnswer);
                                $wordLastAnswerLine = true;
                            }
                            break;
                        }
                    }
                    if ($wordQuestion !== null) {
                        continue;
                    }
                    $wordQuestion = $previousWordQuestion;
                    $wordLastAnswerLine = $previousLastAnswerLine;
                    $unmatchedAnswerHeader = true;
                }
                if (! $unmatchedAnswerHeader) {
                    $content = trim($m[2]);
                    $points = 1;
                    if (preg_match('/\t\s*([\d,.]+)\s*$/', $content, $pm)) {
                        $points = (float) str_replace(',', '.', $pm[1]);
                        $content = trim(substr($content, 0, -strlen($pm[0])));
                    }
                    $wordRows[] = ['paper' => $wordPaper, 'question' => $number, 'content' => $content, 'answer' => '', 'points' => $points > 0 ? $points : 1];
                    $wordQuestion = count($wordRows) - 1;
                    $wordLastAnswerLine = false;

                    continue;
                }
            }
            if ($wordAnswerMode && $wordQuestion !== null) {
                $answerText = null;
                if (preg_match('/^[-•]\s*(.+)$/u', $line, $bm)) {
                    $answerText = trim($bm[1]);
                } elseif (preg_match('/^(?:[A-Za-z]|\d+)\s*[.)]\s*(.+)$/u', $line, $bm)
                    || preg_match('/^(?:y|ý)\s*\d+\s*[:.)-]\s*(.+)$/iu', $line, $bm)) {
                    $answerText = trim($bm[1]);
                } elseif ($line !== '') {
                    $answerText = $line;
                }
                if ($answerText !== null && $answerText !== '') {
                    $wordRows[$wordQuestion]['answer'] .= ($wordRows[$wordQuestion]['answer'] ? "\n" : '').$answerText;
                    $wordLastAnswerLine = true;
                }
            }
        }
        if (count($wordRows) > 0) {
            return array_map(fn ($row) => $this->normalizeImportedAnswerPointBreaks($row), $wordRows);
        }
        $headerIndex = null;
        $map = [];
        foreach (array_slice($lines, 0, 8, true) as $i => $line) {
            $cells = preg_split('/\t|\s*\|\s*|\s*;\s*/', trim($line));
            $normalized = array_map(fn ($v) => mb_strtolower(trim($v)), $cells);
            foreach ($normalized as $k => $v) {
                if (preg_match('/đề\s*số|de\s*so|^exam/', $v)) {
                    $map['paper'] = $k;
                } elseif (preg_match('/nội\s*dung|noi\s*dung|content|câu\s*hỏi/', $v)) {
                    $map['content'] = $k;
                } elseif (preg_match('/đáp\s*án|dap\s*an|answer|hướng\s*dẫn/', $v)) {
                    $map['answer'] = $k;
                } elseif (preg_match('/điểm|diem|point|score/', $v)) {
                    $map['points'] = $k;
                }
            }
            if ((isset($map['content']) || isset($map['answer'])) && count($cells) >= 2 && preg_match('/\t|\||;/', $line)) {
                $headerIndex = $i;
                break;
            }
        }
        $rows = [];
        if ($headerIndex !== null) {
            $lastPaper = 1;
            foreach (array_slice($lines, $headerIndex + 1) as $line) {
                $cells = preg_split('/\t|\s*\|\s*|\s*;\s*/', trim($line));
                $paper = isset($map['paper']) ? (int) ($cells[$map['paper']] ?? 0) : 0;
                if ($paper > 0) {
                    $lastPaper = $paper;
                }
                $content = trim($cells[$map['content'] ?? -1] ?? '');
                $answer = trim($cells[$map['answer'] ?? -1] ?? '');
                if ($content === '' && $answer === '') {
                    continue;
                }
                $points = (float) str_replace(',', '.', trim($cells[$map['points'] ?? -1] ?? '1'));
                $rows[] = ['paper' => $lastPaper, 'content' => $content ?: 'Câu hỏi import', 'answer' => $answer, 'points' => $points > 0 ? $points : 1];
            }
        }
        if ($rows) {
            return $rows;
        }
        $paper = 1;
        $questionIndex = null;
        $answerMode = false;
        foreach ($lines as $line) {
            if (preg_match('/đề\s*(?:thi\s*)?(?:số\s*)?(\d+)/iu', $line, $m)) {
                $paper = (int) $m[1];
                $questionIndex = null;
                $answerMode = false;

                continue;
            }
            if (preg_match('/^(?:câu\s*)?(\d+)\s*[.\-:)]\s*(.*)$/iu', trim($line), $m)) {
                $rows[] = ['paper' => $paper, 'question' => (int) $m[1], 'content' => trim($m[2]), 'answer' => '', 'points' => 1];
                $questionIndex = count($rows) - 1;
                $answerMode = false;

                continue;
            }
            if (preg_match('/đáp\s*án|answer/iu', $line)) {
                $answerMode = true;

                continue;
            }
            if ($questionIndex !== null) {
                if ($answerMode) {
                    $rows[$questionIndex]['answer'] .= ($rows[$questionIndex]['answer'] ? '\n' : '').trim($line);
                } else {
                    $rows[$questionIndex]['content'] .= ($rows[$questionIndex]['content'] ? '\n' : '').trim($line);
                }
            }
        }
        foreach ($rows as &$row) {
            if (preg_match('/^__POINTS_([\d.]+)__\s*/', $row['content'], $m)) {
                $row['points'] = (float) $m[1];
                $row['content'] = trim(substr($row['content'], strlen($m[0])));
            }
        }
        unset($row);

        return array_values(array_map(fn ($row) => $this->normalizeImportedAnswerPointBreaks($row), $rows));
    }

    public function parseAnswerRows(string $text): array
    {
        $result = [];
        $text = str_replace(["\x07", "\x0b"], "\t", $text);
        $paper = 1;
        foreach (preg_split('/\r\n|\r|\n/', $text) ?: [] as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/^(?:đề|de)\s*(?:thi\s*)?(?:số|so)?\s*(\d+)/iu', $line, $paperMatch)) {
                $paper = max(1, (int) $paperMatch[1]);

                continue;
            }
            if (preg_match('/^(?:đáp\s*án\s*)?(?:câu\s*)?0*(\d+)\s*(?:(?:[:.\-\t|;])\s*|\s+)([A-D])(?:\s|\t|\||;|$)/iu', $line, $m)) {
                $result[$paper.':'.(int) $m[1]] = strtoupper($m[2]);
            } elseif (preg_match('/^đáp\s*án\s*(?:câu\s*)?0*(\d+)\s*[:.\-]\s*(.*)$/iu', $line, $m)) {
                $result[$paper.':'.(int) $m[1]] = trim($m[2]);
            }
        }

        return $result;
    }

    public function ensureAnswerHasPoint(string $answer, float $point): string
    {
        $answer = $this->normalizeAnswerPointBreaks(trim($answer));
        if ($answer === '') {
            return $answer;
        }
        $lines = preg_split('/\r\n|\r|\n/', $answer) ?: [];
        $missingIndexes = [];
        $existingPointTotal = 0.0;
        foreach ($lines as $index => $line) {
            if (trim($line) === '') {
                continue;
            }
            if (preg_match('/\[\s*([\d]+(?:[,.][\d]+)?)\s*(?:\x{0111}i\x{1EC3}m|diem)[^\x5D\r\n]*\]/iu', $line, $match)) {
                $existingPointTotal += (float) str_replace(',', '.', $match[1]);
            } else {
                $missingIndexes[] = $index;
            }
        }
        if ($missingIndexes === []) {
            return trim(implode("\n", $lines));
        }
        $remainingPoint = $point > $existingPointTotal ? $point - $existingPointTotal : 0.0;
        $pointPerMissingLine = $remainingPoint > 0 ? $remainingPoint / count($missingIndexes) : $point / count($missingIndexes);
        foreach ($missingIndexes as $index) {
            $lines[$index] = rtrim($lines[$index]).' ['.$this->formatImportedPoint($pointPerMissingLine).' điểm]';
        }

        return trim(implode("\n", $lines));
    }

    private function readDocxImportText(string $path): string
    {
        $xml = false;
        if (class_exists('ZipArchive')) {
            $zip = new \ZipArchive;
            if ($zip->open($path) === true) {
                $xml = $zip->getFromName('word/document.xml') ?: false;
                $zip->close();
            }
        }

        if (! is_string($xml) || $xml === '') {
            $tempDir = sys_get_temp_dir().DIRECTORY_SEPARATOR.'essay-docx-'.bin2hex(random_bytes(6));
            @mkdir($tempDir, 0777, true);
            $zipPath = $tempDir.'.zip';
            @copy($path, $zipPath);
            $psPath = str_replace("'", "''", $zipPath);
            $psDir = str_replace("'", "''", $tempDir);
            $command = 'powershell -NoProfile -ExecutionPolicy Bypass -Command '.escapeshellarg("Expand-Archive -LiteralPath '$psPath' -DestinationPath '$psDir' -Force");
            exec($command, $unusedOutput, $status);
            $xml = $status === 0 ? @file_get_contents($tempDir.DIRECTORY_SEPARATOR.'word'.DIRECTORY_SEPARATOR.'document.xml') : false;
            $this->removeImportDirectory($tempDir);
            @unlink($zipPath);
        }

        abort_unless(is_string($xml) && $xml !== '', 422, 'Không đọc được nội dung file Word .docx. File phải là DOCX hợp lệ.');
        $xml = preg_replace('/<w:tab\s*\/?\s*>/i', "\t", $xml);
        $xml = preg_replace('/<w:br\s*\/?\s*>/i', "\n", $xml);
        $xml = preg_replace('/<\/w:(p|tr)>/i', "\n", $xml);
        $xml = preg_replace('/<\/w:tc>/i', "\t", $xml);

        return $this->ensureUtf8Text(html_entity_decode(strip_tags($xml), ENT_QUOTES | ENT_XML1, 'UTF-8'));
    }

    private function readLegacyDocImportText(string $path): string
    {
        $raw = file_get_contents($path) ?: '';
        if (str_starts_with(ltrim($raw), '{\\rtf')) {
            return $this->ensureUtf8Text($this->decodeRtfTextStable($raw));
        }
        try {
            $reader = new MsDoc;
            $word = $reader->load($path);
            $extract = function ($element) use (&$extract): string {
                if (method_exists($element, 'getText')) {
                    return (string) $element->getText();
                }
                if (method_exists($element, 'getRows')) {
                    return implode("\n", array_map(fn ($row) => implode("\t", array_map(fn ($cell) => $extract($cell), $row->getCells())), $element->getRows()));
                }
                if (method_exists($element, 'getElements')) {
                    return implode('', array_map(fn ($child) => $extract($child), $element->getElements()));
                }

                return '';
            };
            $text = '';
            foreach ($word->getSections() as $section) {
                foreach ($section->getElements() as $element) {
                    $text .= $extract($element)."\n";
                }
            }
            if (trim($text) !== '') {
                return $this->ensureUtf8Text($text);
            }
        } catch (\Throwable $e) {
            abort(422, 'Không đọc được file Word .doc. Hãy dùng đúng file mẫu Word được cung cấp.');
        }

        return '';
    }

    /**
     * Doc file text/csv ve UTF-8.
     *
     * KHONG dung mb_detect_encoding() truoc: Windows-1252 nhan moi chuoi byte nen file
     * UTF-8 co dau tieng Viet bi doan nham la Windows-1252, chuyen doi them mot lan nua
     * ra mojibake kieu "CÃ¢u há»i" (loi that, bao 23/09/2026).
     */
    private function decodePlainText(string $raw): string
    {
        foreach (["\xEF\xBB\xBF" => 'UTF-8', "\xFF\xFE" => 'UTF-16LE', "\xFE\xFF" => 'UTF-16BE'] as $bom => $bomEncoding) {
            if (str_starts_with($raw, $bom)) {
                $raw = substr($raw, strlen($bom));

                return $bomEncoding === 'UTF-8' ? $raw : (string) mb_convert_encoding($raw, 'UTF-8', $bomEncoding);
            }
        }

        if (mb_check_encoding($raw, 'UTF-8')) {
            return $raw;
        }

        // Word/Notepad tieng Viet luu ANSI = CP1258 (mbstring khong ho tro -> iconv).
        $converted = @iconv('CP1258', 'UTF-8//IGNORE', $raw);
        if (is_string($converted) && $converted !== '' && str_contains($converted, "\t")) {
            return $converted;
        }

        $encoding = mb_detect_encoding($raw, ['UTF-16LE', 'UTF-16BE', 'Windows-1252', 'ISO-8859-1'], true) ?: 'Windows-1252';

        return (string) mb_convert_encoding($raw, 'UTF-8', $encoding);
    }

    private function ensureUtf8Text(string $text): string
    {
        if ($text === '' || mb_check_encoding($text, 'UTF-8')) {
            return $text;
        }
        $source = mb_detect_encoding($text, ['UTF-16LE', 'UTF-16BE', 'Windows-1252', 'ISO-8859-1'], true);

        return $source ? mb_convert_encoding($text, 'UTF-8', $source) : $text;
    }

    private function removeImportDirectory(string $directory): void
    {
        if (! is_dir($directory)) {
            return;
        }
        $items = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($directory, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($items as $item) {
            $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
        @rmdir($directory);
    }

    private function decodeRtfTextStable(string $raw): string
    {
        $skipDestinations = ['fonttbl' => true, 'colortbl' => true, 'stylesheet' => true, 'info' => true, 'generator' => true, 'header' => true, 'footer' => true, 'pict' => true, 'object' => true, 'shp' => true, 'shpinst' => true, 'themedata' => true, 'datastore' => true, 'xmlnstbl' => true, 'latentstyles' => true, 'listtable' => true, 'listoverridetable' => true, 'rsidtbl' => true, 'panose' => true, 'wgrffmtfilter' => true, 'colorschememapping' => true, 'listtext' => true, 'nonshppict' => true, 'bkmkstart' => true, 'bkmkend' => true];
        $stack = [['skip' => false, 'uc' => 1, 'fallback' => 0, 'star' => false]];
        $out = '';
        $length = strlen($raw);
        $codepageMap = [1252 => 'CP1252', 1258 => 'CP1258', 1251 => 'CP1251', 1250 => 'CP1250', 1253 => 'CP1253', 1254 => 'CP1254', 1255 => 'CP1255', 1256 => 'CP1256', 1257 => 'CP1257', 437 => 'CP437', 850 => 'CP850', 861 => 'CP861', 865 => 'CP865', 10000 => 'MACINTOSH'];
        $ansiCodepage = 'CP1258';
        if (preg_match('/\\\\ansicpg(\d+)/', $raw, $cpMatch) && isset($codepageMap[(int) $cpMatch[1]])) {
            $ansiCodepage = $codepageMap[(int) $cpMatch[1]];
        }
        $appendByte = static function (string $byte, string $codepage) use ($ansiCodepage): string {
            $converted = @iconv($codepage ?: $ansiCodepage, 'UTF-8//IGNORE', $byte);

            return is_string($converted) && $converted !== '' ? $converted : $byte;
        };
        for ($i = 0; $i < $length;) {
            $ch = $raw[$i];
            if ($ch === '{') {
                $state = $stack[count($stack) - 1];
                $state['star'] = false;
                $stack[] = $state;
                $i++;

                continue;
            }
            if ($ch === '}') {
                if (count($stack) > 1) {
                    array_pop($stack);
                }
                $i++;

                continue;
            }
            $stateIndex = count($stack) - 1;
            if ($ch === '\\') {
                $next = $raw[$i + 1] ?? '';
                if ($next === "'") {
                    $hex = substr($raw, $i + 2, 2);
                    $vietnameseOnlyBytes = ['d0' => true, 'f0' => true, 'dd' => true, 'fd' => true, 'd5' => true, 'f5' => true];
                    $forceVietnameseCodepage = array_key_exists(strtolower($hex), $vietnameseOnlyBytes);
                    if (($stack[$stateIndex]['fallback'] ?? 0) > 0) {
                        $stack[$stateIndex]['fallback']--;
                    } elseif (ctype_xdigit($hex)) {
                        $out .= $appendByte(chr(hexdec($hex)), $forceVietnameseCodepage ? 'CP1258' : '');
                    }
                    $i += 4;

                    continue;
                }
                if (in_array($next, ['\\', '{', '}'], true)) {
                    if (! $stack[$stateIndex]['skip'] && ($stack[$stateIndex]['fallback'] ?? 0) === 0) {
                        $out .= $next;
                    }
                    $i += 2;

                    continue;
                }
                if ($next === '*') {
                    $stack[$stateIndex]['star'] = true;
                    $i += 2;

                    continue;
                }
                if (in_array($next, ['~', '_', '-'], true)) {
                    if (! $stack[$stateIndex]['skip'] && ($stack[$stateIndex]['fallback'] ?? 0) === 0) {
                        $out .= $next === '~' ? ' ' : ($next === '_' ? '‑' : '');
                    }
                    $i += 2;

                    continue;
                }
                if (preg_match('/\\\\([a-zA-Z]+)(-?\d*) ?/A', substr($raw, $i), $control)) {
                    $word = strtolower($control[1]);
                    $parameter = $control[2] === '' ? null : (int) $control[2];
                    $tokenLength = strlen($control[0]);
                    if (array_key_exists($word, $skipDestinations)) {
                        $stack[$stateIndex]['skip'] = true;
                    }
                    $stack[$stateIndex]['star'] = false;
                    if ($word === 'uc' && $parameter !== null) {
                        $stack[$stateIndex]['uc'] = max(0, $parameter);
                    } elseif ($word === 'u' && $parameter !== null) {
                        if (! $stack[$stateIndex]['skip']) {
                            $code = $parameter < 0 ? $parameter + 65536 : $parameter;
                            $out .= mb_convert_encoding(pack('n', $code), 'UTF-8', 'UTF-16BE');
                        }
                        $stack[$stateIndex]['fallback'] = $stack[$stateIndex]['uc'];
                        $afterUnicode = substr($raw, $i + $tokenLength, 5);
                        if ($stack[$stateIndex]['fallback'] === 0 && ($afterUnicode[0] ?? '') === '?') {
                            $stack[$stateIndex]['fallback'] = 1;
                        } elseif ($stack[$stateIndex]['fallback'] === 0 && str_starts_with($afterUnicode, "\\'3f")) {
                            $stack[$stateIndex]['fallback'] = 1;
                        }
                    } elseif ($word === 'bin' && $parameter !== null) {
                        $i += $tokenLength + $parameter;

                        continue;
                    } elseif (! $stack[$stateIndex]['skip'] && ($stack[$stateIndex]['fallback'] ?? 0) === 0) {
                        if (in_array($word, ['par', 'line', 'sect', 'row', 'page'], true)) {
                            $out .= "\n";
                        } elseif ($word === 'tab') {
                            $out .= "\t";
                        }
                    }
                    $i += $tokenLength;

                    continue;
                }
                $i += 2;

                continue;
            }
            if (($stack[$stateIndex]['fallback'] ?? 0) > 0) {
                $stack[$stateIndex]['fallback']--;
                $i++;

                continue;
            }
            if (! $stack[$stateIndex]['skip'] && $ch !== "\r" && $ch !== "\n") {
                $out .= $ch;
            }
            $i++;
        }
        $out = preg_replace('/[ \t]+\n/', "\n", $out) ?: $out;
        $out = str_replace(['\\~', '\\_', '\\-'], [' ', '-', ''], $out);
        $out = strtr($out, [
            'đế?n' => 'đến', 'Đế?n' => 'Đến', 'hợ?p' => 'hợp',
            'tŕnh' => 'trình', 'quá tŕnh' => 'quá trình',
            'đă học' => 'đã học', 'hăy' => 'hãy', 'T́m' => 'Tìm', 'pḥng' => 'phòng',
        ]);
        $out = preg_replace('/(?<=\p{L})\?(?=\p{L})/u', '', $out) ?: $out;
        $out = preg_replace('/(?<=\p{L})\?(?=\s+\p{L})/u', '', $out) ?: $out;

        return trim($out);
    }

    private function importProbe(string $value): string
    {
        $value = mb_strtolower(trim($value), 'UTF-8');
        $value = strtr($value, [
            'à' => 'a', 'á' => 'a', 'ả' => 'a', 'ã' => 'a', 'ạ' => 'a', 'ă' => 'a', 'ằ' => 'a', 'ắ' => 'a', 'ẳ' => 'a', 'ẵ' => 'a', 'ặ' => 'a', 'â' => 'a', 'ầ' => 'a', 'ấ' => 'a', 'ẩ' => 'a', 'ẫ' => 'a', 'ậ' => 'a',
            'è' => 'e', 'é' => 'e', 'ẻ' => 'e', 'ẽ' => 'e', 'ẹ' => 'e', 'ê' => 'e', 'ề' => 'e', 'ế' => 'e', 'ể' => 'e', 'ễ' => 'e', 'ệ' => 'e',
            'ì' => 'i', 'í' => 'i', 'ỉ' => 'i', 'ĩ' => 'i', 'ị' => 'i', 'ò' => 'o', 'ó' => 'o', 'ỏ' => 'o', 'õ' => 'o', 'ọ' => 'o', 'ô' => 'o', 'ồ' => 'o', 'ố' => 'o', 'ổ' => 'o', 'ỗ' => 'o', 'ộ' => 'o', 'ơ' => 'o', 'ờ' => 'o', 'ớ' => 'o', 'ở' => 'o', 'ỡ' => 'o', 'ợ' => 'o',
            'ù' => 'u', 'ú' => 'u', 'ủ' => 'u', 'ũ' => 'u', 'ụ' => 'u', 'ư' => 'u', 'ừ' => 'u', 'ứ' => 'u', 'ử' => 'u', 'ữ' => 'u', 'ự' => 'u', 'ỳ' => 'y', 'ý' => 'y', 'ỷ' => 'y', 'ỹ' => 'y', 'ỵ' => 'y', 'đ' => 'd',
        ]);
        $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);

        return $ascii !== false ? $ascii : $value;
    }

    private function parseIntegratedRows(string $text): array
    {
        $lines = array_values(array_filter(preg_split('/\r\n|\r|\n/', $text) ?: [], fn ($line) => trim($line) !== ''));
        $joinedLines = [];
        foreach ($lines as $line) {
            $line = trim($line);
            $previous = $joinedLines[count($joinedLines) - 1] ?? null;
            $isContinuation = $previous !== null
                && preg_match('/^(?:[A-D]\s*[.)]|cau\s*\d+)/iu', $line) !== 1
                && (preg_match('/^[\p{Ll}]/u', $line) === 1 && preg_match('/[\p{L}]$/u', $previous) === 1
                    || preg_match('/^[.]\s*/u', $line) === 1 && preg_match('/^[A-D]$/iu', $previous) === 1
                    || preg_match('/^[\p{L}\d]/u', $line) === 1 && preg_match('/^[A-D]\s*[.)]?$/iu', $previous) === 1
                    || preg_match('/^\d/', $line) === 1 && preg_match('/[\p{L}]$/u', $previous) === 1);
            if ($isContinuation) {
                $joinedLines[count($joinedLines) - 1] .= $line;
            } else {
                $joinedLines[] = $line;
            }
        }
        $lines = $joinedLines;
        $probeText = implode("\n", array_map(fn ($line) => $this->importProbe($line), $lines));
        $hasPartOne = preg_match('/^\s*(?:i|1)\.\s*/um', $probeText) === 1;
        $hasPartTwo = preg_match('/^\s*(?:ii|2)\.\s*/um', $probeText) === 1;
        $hasStructuredSections = $hasPartOne || $hasPartTwo;
        $hasQuestionHeaders = preg_match('/(?:^|\R)\s*c(?:âu|câu|au)\s*0*\d+/iu', $text) === 1
            || preg_match('/c(?:âu|au)\s*\d+/iu', $text) === 1
            || preg_match('/cau\s*\d+/u', $probeText) === 1;
        if (! $hasStructuredSections && ! $hasQuestionHeaders) {
            return [];
        }

        $rows = [];
        $section = $hasPartOne ? null : 'multiple_choice';
        $current = null;
        $paper = 1;
        $answerOnlyDocument = preg_match('/^\s*ii\.\s*.*dap\s*an/um', $probeText) === 1;
        $startedAnswerSection = ! $answerOnlyDocument;
        $flush = function () use (&$rows, &$current): void {
            if ($current === null) {
                return;
            }
            $current['content'] = trim($current['content']);
            unset($current['_has_explicit_points'], $current['_seen_body_line']);
            if ($current['content'] !== '') {
                $rows[] = $current;
            }
            $current = null;
        };

        foreach ($lines as $rawLine) {
            $line = trim(preg_replace('/Hlk\d+/iu', '', $rawLine) ?: $rawLine);
            $line = ltrim($line, " \t\\*_");
            $probe = $this->importProbe($line);
            if (! $startedAnswerSection) {
                if (preg_match('/^\s*ii\.\s*.*dap\s*an/u', $probe)) {
                    $startedAnswerSection = true;
                    $section = 'essay';
                }

                continue;
            }
            if (preg_match('/^de\s*(?:so\s*)?(\d+)/u', $probe, $paperMatch)) {
                $flush();
                $paper = (int) $paperMatch[1];
                $section = 'essay';

                continue;
            }
            if ($section === 'essay' && preg_match('/^\s*\(?\s*(?:sbd|can bo coi thi|chu nhiem khoa|giang vien (?:bien )?soan|(?:pho )?hieu truong(?: dao tao)?|ban giam hieu|ma de|normal;heading)/u', $probe)) {
                $flush();
                $section = null;

                continue;
            }
            if (preg_match('/^\s*(?:i|1)\.\s*/u', $probe) || preg_match('/^\s*(?:i|1)\.\s*/iu', $line)) {
                $flush();
                $section = 'multiple_choice';

                continue;
            }
            if (preg_match('/^\s*(?:ii|2)\.\s*/u', $probe) || preg_match('/^\s*(?:ii|2)\.\s*/iu', $line)) {
                $flush();
                $section = 'essay';
                $points = 1.0;
                if (preg_match('/([\d,.]+)\s*diem/u', $probe, $pointMatch)) {
                    $points = (float) str_replace(',', '.', $pointMatch[1]);
                }
                $current = [
                    'paper' => $paper,
                    'question' => 61,
                    'content' => '',
                    'answer' => '',
                    'points' => $points > 0 ? $points : 1,
                    '_has_explicit_points' => false,
                    'question_type' => 'essay',
                    'options' => [],
                ];

                continue;
            }
            if (preg_match('/^(?:tra loi trac nghiem|phan tra loi|ma so sinh vien|ho ten|ngay sinh|can bo coi thi|luu y|het|tp\.hcm)/u', $probe)) {
                continue;
            }
            if ($section === null) {
                $section = 'multiple_choice';
            }

            $questionMatch = [];
            $hasQuestion = preg_match('/^\s*cau\s*(\d+)\s*[:.)]?\s*(.*)$/u', $probe, $questionMatch)
                || preg_match('/câu\s*(\d+)\s*[:.)]?\s*(.*)$/iu', $line, $questionMatch)
                || preg_match('/^\s*c(?:âu|au)\s*0*(\d{1,2})\s*[:.)]?\s*(.*)$/iu', $line, $questionMatch);
            if ($hasQuestion) {
                $flush();
                $number = (int) $questionMatch[1];
                $rawContent = preg_replace('/^.*?(?:cau|câu|c[^\d]{0,8})\s*\d+\s*[:.)]?\s*/iu', '', $line) ?: '';
                $points = 1.0;
                $hasExplicitPoints = false;
                if (preg_match('/\(\s*([\d,.]+)\s*diem/u', $probe, $pointMatch)) {
                    $points = (float) str_replace(',', '.', $pointMatch[1]);
                    $hasExplicitPoints = true;
                    $rawContent = preg_replace('/\(.*?\)/u', '', $rawContent) ?: $rawContent;
                }
                $current = [
                    'paper' => $paper,
                    'question' => $number,
                    'content' => trim($rawContent, " \t:-()"),
                    'answer' => '',
                    'points' => $points > 0 ? $points : 1,
                    '_has_explicit_points' => $hasExplicitPoints,
                    '_seen_body_line' => false,
                    'question_type' => $section === 'multiple_choice' ? 'multiple_choice' : 'essay',
                    'options' => [],
                ];

                continue;
            }

            if ($current === null) {
                continue;
            }

            if (preg_match('/^(?:dap\s*an|answer)\s*[:.]?\s*([A-D])\b/iu', $probe, $answerMatch)) {
                $current['answer'] = strtoupper($answerMatch[1]);

                continue;
            }

            $optionParts = preg_split('/(?=\b[a-d]\s*[.)]\s*)/iu', $line, -1, PREG_SPLIT_NO_EMPTY) ?: [];
            $foundOption = false;
            foreach ($optionParts as $part) {
                if (preg_match('/^([a-d])\s*[.)]\s*(.*)$/iu', trim($part), $optionMatch)) {
                    $current['options'][strtoupper($optionMatch[1])] = trim($optionMatch[2]);
                    $foundOption = true;
                }
            }
            if (! $foundOption && $section === 'essay') {
                if (preg_match('/^\s*([\d]+(?:[,.]\d+)?)\s*$/u', $probe, $rubricPointMatch)) {
                    $rubricPoint = (float) str_replace(',', '.', $rubricPointMatch[1]);
                    if (! ($current['_has_explicit_points'] ?? false) && ! ($current['_seen_body_line'] ?? false)) {
                        $current['points'] = $rubricPoint > 0 ? $rubricPoint : 1;
                        $current['_has_explicit_points'] = true;
                    } else {
                        $current['answer'] .= ($current['answer'] === '' ? '' : "\n").'['.rtrim(rtrim(number_format($rubricPoint, 2, '.', ''), '0'), '.').' điểm]';
                    }

                    continue;
                }
                $essayLine = preg_replace('/^\s*(?:\(?\s*[\d,.]*\s*)?(?:điểm|diem)\s*\)?\s*/iu', '', $line) ?: $line;
                if (preg_match('/^\s*diem\s*\)/u', $this->importProbe($essayLine))) {
                    $essayLine = preg_replace('/^\s*[^)]*\)\s*/u', '', $essayLine) ?: $essayLine;
                }
                if (preg_match('/^\s*[-–—]\s*(.+)$/u', $essayLine, $answerLineMatch)) {
                    $current['answer'] .= ($current['answer'] === '' ? '' : "\n").trim($answerLineMatch[1]);
                    $current['_seen_body_line'] = true;
                } elseif (trim($essayLine) !== '') {
                    $current['content'] .= ($current['content'] === '' ? '' : "\n").$essayLine;
                    $current['_seen_body_line'] = true;
                }
            } elseif (! $foundOption && $section === 'multiple_choice' && ! preg_match('/^(?:dap an|cau\s*\d+)/u', $probe)) {
                $current['content'] .= ($current['content'] === '' ? '' : "\n").$line;
            }
        }
        $flush();

        return $rows;
    }

    private function normalizeImportedAnswerPointBreaks(array $row): array
    {
        $row['answer'] = $this->normalizeAnswerPointBreaks(trim((string) ($row['answer'] ?? '')));
        if ($row['answer'] !== '') {
            $row['answer'] = $this->ensureAnswerHasPoint($row['answer'], (float) ($row['points'] ?? 1));
        }

        return $row;
    }

    private function normalizeAnswerPointBreaks(string $answer): string
    {
        return preg_replace('/\R\s*(\[[^\x5D\r\n]*(?:\x{0111}i\x{1EC3}m|diem)[^\x5D\r\n]*\])/iu', ' $1', $answer) ?: $answer;
    }

    private function formatImportedPoint(float $point): string
    {
        $formatted = rtrim(rtrim(number_format($point, 2, ',', '.'), '0'), ',');

        return str_contains($formatted, ',') ? $formatted : $formatted.',0';
    }

    private function parseAnswerAfterOptionsRows(array $lines): array
    {
        if (! collect($lines)->contains(fn ($line) => preg_match('/^\s*answer\s*:/iu', trim($line)))) {
            return [];
        }

        $rows = [];
        $question = null;
        $options = [];
        $paper = 1;
        $flush = function () use (&$rows, &$question, &$options, &$paper): void {
            if ($question !== null && count($options) >= 2) {
                $rows[] = [
                    'paper' => $paper,
                    'content' => trim($question),
                    'answer' => '',
                    'options' => $options,
                    'question_type' => 'multiple_choice',
                    'points' => 1,
                ];
            }
            $question = null;
            $options = [];
        };

        foreach ($lines as $rawLine) {
            $line = trim($rawLine);
            if ($line === '') {
                continue;
            }
            if (preg_match('/^b(?:ài|ai)\s*(\d+)\s*:\s*\d+\s*c(?:âu|au)/iu', $line, $paperMatch)) {
                $flush();
                $paper = max(1, (int) $paperMatch[1]);

                continue;
            }

            if (preg_match('/^answer\s*:\s*([A-D])/iu', $line, $answerMatch)) {
                if ($question !== null && count($options) >= 2) {
                    $rows[] = [
                        'paper' => $paper,
                        'content' => trim($question),
                        'answer' => strtoupper($answerMatch[1]),
                        'options' => $options,
                        'question_type' => 'multiple_choice',
                        'points' => 1,
                    ];
                }
                $question = null;
                $options = [];

                continue;
            }

            if (preg_match('/^([A-D])\s*[.)]?\s+(.+)$/u', $line, $optionMatch)) {
                if ($question !== null) {
                    $options[strtoupper($optionMatch[1])] = trim($optionMatch[2]);
                }

                continue;
            }

            if ($question === null) {
                $question = $line;
            } elseif ($options === []) {
                $question .= "\n".$line;
            }
        }

        $flush();

        return $rows;
    }

    private function standardizeImportedRows(array $rows): array
    {
        $questionNumber = 1;
        $essayRows = [];
        $standard = [];
        $essayNumbers = [];
        $multiPaper = collect($rows)->pluck('paper')->unique()->count() > 1;
        foreach ($rows as $row) {
            $row['paper'] = (int) ($row['paper'] ?? 1) ?: 1;
            $row['content'] = trim((string) ($row['content'] ?? ''));
            if (preg_match('/^b(?:ài|ai)\s*\d+\s*:\s*\d+\s*c(?:âu|au)\b/iu', $row['content'])) {
                continue;
            }
            $row['content'] = preg_replace('/^\s*b(?:ài|ai)\s*\d+\s*[:.)-]\s*\d+\s*c(?:âu|au)\s*/iu', '', $row['content']) ?: $row['content'];
            $scoreFromContent = null;
            if (preg_match('/\s*([\d]+[,.]\d+)\s*(?:\(\s*[\d]+(?:[,.]\d+)?\s*(?:điểm|diem)\s*\))?\s*$/iu', $row['content'], $scoreMatch)) {
                $scoreFromContent = (float) str_replace(',', '.', $scoreMatch[1]);
            }
            $row['content'] = preg_replace('/\s*\(\s*[\d]+(?:[,.]\d+)?\s*(?:điểm|diem)\s*\)\s*$/iu', '', $row['content']) ?: $row['content'];
            $row['content'] = preg_replace('/\s*[\d]+[,.]\d+\s*$/u', '', $row['content']) ?: $row['content'];
            $row['content'] = trim($row['content']);
            if (($row['question_type'] ?? '') === 'essay' && $scoreFromContent !== null && $scoreFromContent > 0) {
                $row['points'] = $scoreFromContent;
            }
            $row['points'] = (float) ($row['points'] ?? 1) > 0 ? (float) $row['points'] : 1;
            $row['answer'] = $this->ensureAnswerHasPoint(trim((string) ($row['answer'] ?? '')), $row['points']);
            $row['options'] = is_array($row['options'] ?? null) ? $row['options'] : [];
            $row['options'] = array_intersect_key($row['options'], array_flip(['A', 'B', 'C', 'D']));
            if (($row['question_type'] ?? '') === 'essay') {
                $paper = $row['paper'];
                $row['question'] = $multiPaper
                    ? ($essayNumbers[$paper] = ($essayNumbers[$paper] ?? 0) + 1)
                    : 61;
                $row['question_type'] = 'essay';
                $essayRows[] = $row;

                continue;
            }
            $row['question'] = $questionNumber++;
            $row['question_type'] = 'multiple_choice';
            $standard[] = $row;
        }
        foreach ($essayRows as $row) {
            $standard[] = $row;
        }

        return $standard;
    }

    private function normalizeQuestionRows(array $rows): array
    {
        foreach ($rows as &$row) {
            if (($row['question_type'] ?? '') !== 'multiple_choice') {
                continue;
            }
            $lines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) ($row['content'] ?? '')) ?: []), fn ($line) => $line !== ''));
            if (count($lines) >= 2 && count($row['options'] ?? []) > 0) {
                $row['content'] = array_shift($lines);
                $unlabelled = [];
                foreach ($lines as $line) {
                    if (preg_match('/^([A-D])(?:\s*[.)]\s*|\s+)(.*)$/iu', $line, $match)) {
                        $row['options'][strtoupper($match[1])] = trim($match[2]);
                    } else {
                        $unlabelled[] = $line;
                    }
                }
                foreach (['A', 'B', 'C', 'D'] as $key) {
                    if (! isset($row['options'][$key]) && $unlabelled) {
                        $row['options'][$key] = array_shift($unlabelled);
                    }
                }

                continue;
            }
            $lines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) ($row['content'] ?? '')) ?: []), fn ($line) => $line !== ''));
            if (count($lines) >= 5) {
                $row['content'] = array_shift($lines);
                foreach (array_slice($lines, 0, 4) as $index => $option) {
                    $row['options'][chr(65 + $index)] = preg_replace('/^[A-D][.)]\s*/iu', '', $option) ?: $option;
                }

                continue;
            }
            if (preg_match('/^(.*?\bchính)\s*((?:[2-5]\s*nhóm\s*){2,})$/iu', trim((string) ($row['content'] ?? '')), $match)) {
                $row['content'] = trim($match[1]);
                preg_match_all('/([2-5])\s*nhóm/iu', $match[2], $numbers);
                foreach ($numbers[1] ?? [] as $index => $number) {
                    $row['options'][chr(65 + $index)] = $number.' nhóm';
                }
            }
        }
        unset($row);

        return $rows;
    }
}
