<?php

namespace App\Support;

/**
 * Loại điểm đặt được số chữ số làm tròn riêng (khoá `grades.decimal_places_{kind}`; trống = theo mức chung).
 * Nằm ở core vì form Cài đặt (module SystemSettings, core) cần danh sách này mà không được import module Grades.
 */
final class GradeRoundingKinds
{
    public const KINDS = [
        'kttx' => 'Kiểm tra thường xuyên (KTTX)',
        'ktdk' => 'Kiểm tra định kỳ (KTĐK)',
        'exam' => 'Thi kết thúc môn',
        'dtbkt' => 'Điểm TB kiểm tra (ĐTBKT)',
        'dmh' => 'Điểm môn học (ĐMH)',
        'gpa' => 'Điểm TB chung / tổng kết',
    ];
}
