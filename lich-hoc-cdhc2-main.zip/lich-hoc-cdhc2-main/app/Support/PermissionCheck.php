<?php

namespace App\Support;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

/**
 * Safe permission checks — never throw when permission name is missing in DB.
 */
class PermissionCheck
{
    public const LEAVE_AGENCY_ROLE = RoleCatalog::LEAVE_QUAN_LUC;

    public static function isLeaveAgency(?User $user): bool
    {
        if (! $user) {
            return false;
        }

        try {
            return $user->isSuperAdmin() || $user->hasRole(self::LEAVE_AGENCY_ROLE) || $user->hasRole(RoleCatalog::LEAVE_MANAGEMENT_AGENCY);
        } catch (\Throwable) {
            return false;
        }
    }

    public static function can(?User $user, string $permission): bool
    {
        if (! $user) {
            return false;
        }

        try {
            if (method_exists($user, 'hasRole') && $user->hasRole('super-admin')) {
                return true;
            }

            // Tài khoản quân nhân luôn được vào màn hình gửi đề xuất phép,
            // kể cả khi migration đồng bộ permission chưa chạy hoặc cache quyền cũ.
            if (method_exists($user, 'hasRole')
                && $user->hasRole(RoleCatalog::LEAVE_MILITARY)
                && in_array($permission, [
                    'leave-management.access.index',
                    'leave-management.access.show',
                    'leave-management.index',
                    'leave-management.create',
                    'leave-management.requests.index',
                    'leave-management.requests.show',
                    'leave-management.requests.create',
                ], true)) {
                return true;
            }

            // Tài khoản có vai trò quản lý được vào luồng quản lý phép để
            // tiếp nhận đơn của thành viên thuộc cùng đơn vị.
            if (in_array($permission, [
                'leave-management.access.index',
                'leave-management.index',
                'leave-management.approvals.index',
                'leave-management.requests.index',
            ], true) && Gate::has('cdhc2.leave.commander')
                && Gate::forUser($user)->allows('cdhc2.leave.commander')) {
                return true;
            }

            $approvalDecision = ApprovalAgency::permissionDecision($user, $permission);
            if ($approvalDecision !== null) {
                return $approvalDecision;
            }

            return $user->can($permission);
        } catch (\Throwable) {
            return false;
        }
    }

    public static function userCan(string $permission): bool
    {
        $user = Auth::user();

        return $user instanceof User && self::can($user, $permission);
    }

    /**
     * @param  list<string>  $permissions
     */
    public static function userCanAny(array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if (self::userCan($permission)) {
                return true;
            }
        }

        return false;
    }
}
