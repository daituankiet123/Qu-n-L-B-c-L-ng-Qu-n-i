<?php

namespace App\Models;

use App\Models\Concerns\UsesCoreConnection;
use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    use UsesCoreConnection;

    protected $fillable = ['portal', 'key', 'value', 'type', 'updated_by'];

    protected $casts = ['value' => 'json'];
}
