<?php

namespace App\Models;

use App\Models\Concerns\UsesCoreConnection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class QuickNote extends Model
{
    use UsesCoreConnection;

    protected $fillable = ['content', 'updated_by'];

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    /**
     * Ô ghi chú dùng chung, luôn chỉ 1 bản ghi (id=1) — không cần danh sách nhiều note.
     */
    public static function singleton(): self
    {
        return static::firstOrCreate(['id' => 1]);
    }
}
