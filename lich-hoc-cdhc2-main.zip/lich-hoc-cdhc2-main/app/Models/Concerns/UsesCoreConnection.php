<?php

namespace App\Models\Concerns;

use Cdhc2\Core\Support\TableOwnership;

/**
 * Model cua core luon dung connection MAC DINH (theo ten), khong bao gio null.
 *
 * Neu getConnectionName() tra null, Laravel cho model nay muon connection cua
 * model cha khi di qua relation (HasRelationships::newRelatedInstance) — vd.
 * `LmsCourse->subject` se doc `subjects` trong DB lms va vo khi tach DB (Buoc 2).
 */
trait UsesCoreConnection
{
    public function getConnectionName()
    {
        return $this->connection ?? TableOwnership::resolve('mysql');
    }
}
