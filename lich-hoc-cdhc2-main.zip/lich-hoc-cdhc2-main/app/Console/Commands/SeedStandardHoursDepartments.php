<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Modules\StandardHours\Models\AcademicDepartment;
use Modules\Unit\Models\Unit;

/**
 * Cài sẵn các Tổ Bộ môn thật của 3 Khoa đang có chia bộ môn (Giờ chuẩn GV
 * — Điều 17 TT 06/2026/TT-BQP). Idempotent: bỏ qua bộ môn đã tồn tại
 * (theo unit_id + code), không đụng dữ liệu đã có.
 */
class SeedStandardHoursDepartments extends Command
{
    protected $signature = 'standard-hours:seed-departments';

    protected $description = 'Tạo sẵn các Tổ Bộ môn thật cho 3 Khoa: Y học cơ sở, Y học lâm sàng, Hậu cần chung';

    public function handle(): int
    {
        $plan = [
            'Khoa Y học cơ sở' => [
                'BM-YHCS' => 'Tổ bộ môn Y học cơ sở',
                'BM-KTCS' => 'Tổ bộ môn Kỹ thuật cơ sở',
            ],
            'Khoa Y học lâm sàng' => [
                'BM-YHLS' => 'Tổ bộ môn Y học lâm sàng',
                'BM-YHCT' => 'Tổ bộ môn Y học cổ truyền',
            ],
            'Khoa Hậu cần chung' => [
                'BM-QN' => 'Tổ Bộ môn Quân nhu',
                'BM-TC' => 'Tổ Bộ môn Tài chính',
                'BM-HCC' => 'Tổ Bộ môn Hậu cần chung',
            ],
        ];

        foreach ($plan as $facultyName => $departments) {
            $unit = Unit::query()->where('name', $facultyName)->first();
            if (! $unit) {
                $this->error("Không tìm thấy Khoa [{$facultyName}] trong bảng units — bỏ qua.");

                continue;
            }

            foreach ($departments as $code => $name) {
                $dept = AcademicDepartment::query()->where('unit_id', $unit->id)->where('code', $code)->first();
                if ($dept) {
                    $this->line("[{$facultyName}] {$name} đã có, bỏ qua.");

                    continue;
                }

                AcademicDepartment::create([
                    'unit_id' => $unit->id,
                    'code' => $code,
                    'name' => $name,
                    'is_active' => true,
                    'is_auto_created' => false,
                ]);
                $this->info("[{$facultyName}] đã tạo: {$name}");
            }
        }

        return self::SUCCESS;
    }
}
