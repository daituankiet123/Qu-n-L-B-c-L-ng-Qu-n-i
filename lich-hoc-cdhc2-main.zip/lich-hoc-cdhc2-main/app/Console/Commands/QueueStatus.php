<?php

namespace App\Console\Commands;

use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Bang job cua tung service dang ton gi (Buoc 4A). Truoc 25/09 khong co worker nao tren cum nen
 * job (chu yeu email thong bao) chi chat dong trong `jobs` cua core; bat worker se chay NGAY moi
 * job cu -> phai xem truoc.
 *
 *   php artisan cdhc2:queue-status                       # chi doc
 *   php artisan cdhc2:queue-status --purge-stale-mail=3  # xoa email thong bao cu hon 3 ngay
 */
class QueueStatus extends Command
{
    protected $signature = 'cdhc2:queue-status
        {--purge-stale-mail= : Xoa job SendSystemNotificationEmail cu hon N ngay trong jobs cua core}';

    protected $description = 'Dem job cho / that bai trong bang queue cua moi service';

    /** @var array<string, list<string>> connection logic => bang */
    private const TABLES = [
        'mysql' => ['jobs', 'failed_jobs'],
        'lms' => ['lms_jobs', 'lms_failed_jobs'],
        'tms' => ['tms_jobs', 'tms_failed_jobs'],
        'grades' => ['grade_jobs', 'grade_failed_jobs'],
        'salary' => ['salary_jobs', 'salary_failed_jobs'],
    ];

    private const MAIL_JOB = 'App\\Jobs\\SendSystemNotificationEmail';

    public function handle(): int
    {
        $purge = $this->option('purge-stale-mail');
        if ($purge !== null) {
            return $this->purge((int) $purge);
        }

        foreach (self::TABLES as $logical => $tables) {
            $connection = TableOwnership::resolve($logical);
            foreach ($tables as $table) {
                if (! Schema::connection($connection)->hasTable($table)) {
                    $this->line("{$connection}.{$table}: (chua co)");

                    continue;
                }
                $this->report($connection, $table);
            }
        }

        return self::SUCCESS;
    }

    private function report(string $connection, string $table): void
    {
        $failed = str_contains($table, 'failed');
        $query = DB::connection($connection)->table($table);
        $count = $query->count();
        $column = $failed ? 'failed_at' : 'created_at';
        $format = fn ($value) => $value === null ? '-' : (is_numeric($value) ? date('Y-m-d H:i', (int) $value) : (string) $value);

        $this->line(sprintf(
            '%s.%s: %d dong, cu nhat %s, moi nhat %s',
            $connection, $table, $count, $format($query->min($column)), $format($query->max($column))
        ));
        // Dong rieng de grep/test khong phu thuoc ten connection.
        $this->line("  {$table}: {$count}");

        if ($count === 0) {
            return;
        }
        $byClass = DB::connection($connection)->table($table)->pluck('payload')
            ->countBy(fn (string $payload) => json_decode($payload)->displayName ?? '?')
            ->sortDesc();
        foreach ($byClass as $class => $n) {
            $this->line("    {$class}: {$n}");
        }
    }

    private function purge(int $days): int
    {
        if ($days < 1) {
            $this->error('--purge-stale-mail phai >= 1 (ngay)');

            return self::FAILURE;
        }

        $cutoff = now()->subDays($days)->timestamp;
        $ids = DB::table('jobs')->where('created_at', '<', $cutoff)->get(['id', 'payload'])
            ->filter(fn ($job) => (json_decode($job->payload)->displayName ?? null) === self::MAIL_JOB)
            ->pluck('id');
        $deleted = $ids->isEmpty() ? 0 : DB::table('jobs')->whereIn('id', $ids)->delete();

        $this->info("Da xoa {$deleted} job email thong bao cu hon {$days} ngay.");

        return self::SUCCESS;
    }
}
