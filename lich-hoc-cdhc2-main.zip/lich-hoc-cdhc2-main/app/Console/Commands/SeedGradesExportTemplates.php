<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Modules\ExportTemplates\Models\ExportTemplate;
use Modules\ExportTemplates\Models\ExportTemplateVersion;
use Modules\ExportTemplates\Services\TemplateBindingService;
use Modules\ExportTemplates\Services\TemplateLifecycleService;

/**
 * Cài sẵn (hoặc cập nhật) 2 mẫu Word chính thức của trường cho Quản lý điểm (Xuất bảng điểm):
 * - grades.course_final_summary  — Kết quả tổng kết môn học
 * - grades.exam_eligibility_list — Danh sách học viên xét dự thi
 * Mặc định idempotent (bỏ qua nếu feature key đã có template). Dùng --update-version
 * để tải file mẫu mới nhất trong repo lên thành 1 version mới cho template đã tồn tại
 * (ví dụ khi sửa lại file mẫu — thêm placeholder Môn/Lớp — sau khi đã seed lần đầu).
 */
class SeedGradesExportTemplates extends Command
{
    protected $signature = 'export-templates:seed-grades-defaults
        {--actor= : User ID gán làm người tạo/kích hoạt (mặc định: super-admin đầu tiên)}
        {--update-version : Nếu template đã tồn tại, tải file mẫu mới trong repo lên thành version mới và kích hoạt lại}';

    protected $description = 'Tải và kích hoạt 2 mẫu Word mặc định (Kết quả tổng kết môn học, Danh sách xét dự thi) cho Quản lý điểm';

    public function handle(TemplateLifecycleService $lifecycle, TemplateBindingService $bindingService): int
    {
        $actorId = (int) ($this->option('actor') ?: $this->defaultActorId());
        if (! $actorId) {
            $this->error('Không tìm thấy user để gán làm actor. Truyền --actor=<id>.');

            return self::FAILURE;
        }

        $update = (bool) $this->option('update-version');

        $this->installCourseFinalSummary($lifecycle, $bindingService, $actorId, $update);
        $this->installExamEligibilityList($lifecycle, $bindingService, $actorId, $update);

        return self::SUCCESS;
    }

    private function defaultActorId(): ?int
    {
        return \App\Models\User::role('super-admin')->value('id');
    }

    private function installCourseFinalSummary(TemplateLifecycleService $lifecycle, TemplateBindingService $bindingService, int $actorId, bool $update): void
    {
        $featureKey = 'grades.course_final_summary';
        $existing = ExportTemplate::query()->where('feature_key', $featureKey)->first();

        if ($existing && ! $update) {
            $this->line("[{$featureKey}] đã có template, bỏ qua.");

            return;
        }

        $file = $this->uploadedFile(
            database_path('seed-assets/grades/mau_ket_qua_tong_ket_mon_hoc.docx'),
            'Mau_Ket_qua_tong_ket_mon_hoc.docx'
        );

        if ($existing) {
            $template = $existing;
            $version = $lifecycle->createVersion($template, $file, $actorId);
        } else {
            $template = $lifecycle->createTemplate(
                ['name' => 'Kết quả tổng kết môn học', 'feature_key' => $featureKey, 'notes' => 'Mẫu chính thức - Ban KT&ĐBCLGDĐT'],
                $file,
                'grades',
                $actorId
            );
            $version = $template->latestVersion;
        }

        $this->pointToSeedAsset($template, $version, 'grades/mau_ket_qua_tong_ket_mon_hoc.docx');

        $targets = $version->manifest['targets'] ?? [];

        $this->bindPlaceholders($bindingService, $version, $targets, [
            'grade_book.subject_name' => 'grade_book.subject_name',
            'grade_book.class_name' => 'grade_book.class_name',
        ], $actorId);

        $this->bindTable($bindingService, $version, $targets, 1, 3, [
            0 => 'students[].index', 1 => 'students[].ho', 2 => 'students[].ten', 3 => 'students[].code',
            4 => 'students[].kttx_1', 5 => 'students[].kttx_2', 6 => 'students[].kttx_3',
            7 => 'students[].ktdk_1', 8 => 'students[].ktdk_2', 9 => 'students[].ktdk_3',
            10 => 'students[].tbkt', 11 => 'students[].thi_l1', 12 => 'students[].thi_l2',
            13 => 'students[].tong_ket_l1', 14 => 'students[].tong_ket_l2',
            15 => 'students[].tk_mh', 16 => 'students[].xep_loai', 17 => 'students[].ghi_chu',
        ], 'students', $actorId);

        $this->bindScalarRow($bindingService, $version, $targets, 2, 3, [
            0 => 'summary.total',
            1 => 'summary.xuat_sac.count', 2 => 'summary.xuat_sac.percent',
            3 => 'summary.gioi.count', 4 => 'summary.gioi.percent',
            5 => 'summary.kha.count', 6 => 'summary.kha.percent',
            7 => 'summary.trung_binh.count', 8 => 'summary.trung_binh.percent',
            9 => 'summary.yeu.count', 10 => 'summary.yeu.percent',
        ], $actorId);

        $lifecycle->activateVersion($template, $version, $actorId);
        $this->info("[{$featureKey}] template #{$template->id} version {$version->version_number} đã kích hoạt.");
    }

    private function installExamEligibilityList(TemplateLifecycleService $lifecycle, TemplateBindingService $bindingService, int $actorId, bool $update): void
    {
        $featureKey = 'grades.exam_eligibility_list';
        $existing = ExportTemplate::query()->where('feature_key', $featureKey)->first();

        if ($existing && ! $update) {
            $this->line("[{$featureKey}] đã có template, bỏ qua.");

            return;
        }

        $file = $this->uploadedFile(
            database_path('seed-assets/grades/mau_danh_sach_hoc_vien_xet_du_thi.docx'),
            'Mau_Danh_sach_hoc_vien_xet_du_thi.docx'
        );

        if ($existing) {
            $template = $existing;
            $version = $lifecycle->createVersion($template, $file, $actorId);
        } else {
            $template = $lifecycle->createTemplate(
                ['name' => 'Danh sách học viên xét dự thi', 'feature_key' => $featureKey, 'notes' => 'Mẫu chính thức - Khoa'],
                $file,
                'grades',
                $actorId
            );
            $version = $template->latestVersion;
        }

        $this->pointToSeedAsset($template, $version, 'grades/mau_danh_sach_hoc_vien_xet_du_thi.docx');

        $targets = $version->manifest['targets'] ?? [];

        $this->bindPlaceholders($bindingService, $version, $targets, [
            'grade_book.subject_name' => 'grade_book.subject_name',
            'grade_book.class_name' => 'grade_book.class_name',
        ], $actorId);

        $this->bindTable($bindingService, $version, $targets, 1, 3, [
            0 => 'students[].index', 1 => 'students[].ho', 2 => 'students[].ten', 3 => 'students[].code',
            4 => 'students[].kttx_1', 5 => 'students[].kttx_2', 6 => 'students[].kttx_3',
            7 => 'students[].ktdk_1', 8 => 'students[].ktdk_2', 9 => 'students[].ktdk_3',
            10 => 'students[].tbkt', 11 => 'students[].ghi_chu',
        ], 'students', $actorId);

        $lifecycle->activateVersion($template, $version, $actorId);
        $this->info("[{$featureKey}] template #{$template->id} version {$version->version_number} đã kích hoạt.");
    }

    /**
     * File mau upload qua createTemplate()/createVersion() bi copy vao disk
     * 'local' (storage/app) - khong ben vung, mat khi pod restart vi khong
     * co persistent volume. Vi file goc da nam san trong code
     * (database/seed-assets/...), tro thang ExportTemplate/Version ve disk
     * 'export_template_seeds' (root = database/seed-assets, luon co san
     * trong moi ban deploy) roi xoa ban copy tam thoi di, thay vi giu ban
     * copy o storage/app.
     */
    private function pointToSeedAsset(ExportTemplate $template, ExportTemplateVersion $version, string $relativePath): void
    {
        $oldDisk = $version->disk;
        $oldPath = $version->file_path;

        $version->forceFill(['disk' => 'export_template_seeds', 'file_path' => $relativePath])->save();
        $template->forceFill(['disk' => 'export_template_seeds', 'file_path' => $relativePath])->save();

        if ($oldDisk && $oldPath && $oldDisk !== 'export_template_seeds') {
            Storage::disk($oldDisk)->delete($oldPath);
        }
    }

    private function uploadedFile(string $path, string $originalName): UploadedFile
    {
        if (! is_file($path)) {
            throw new \RuntimeException("Không tìm thấy file mẫu: {$path}");
        }

        return new UploadedFile(
            $path,
            $originalName,
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            null,
            true
        );
    }

    /** @param  array<string, string>  $placeholderKeyToDataKey  key = data_key nhúng trong {{...}} của file mẫu, value = field schema tương ứng */
    private function bindPlaceholders(TemplateBindingService $svc, ExportTemplateVersion $version, array $targets, array $placeholderKeyToDataKey, int $actorId): void
    {
        foreach ($placeholderKeyToDataKey as $placeholderKey => $dataKey) {
            $target = collect($targets)->first(fn ($t) => ($t['kind'] ?? null) === 'placeholder' && ($t['data_key'] ?? null) === $placeholderKey);
            if (! $target) {
                continue;
            }
            $svc->bind($version, $target['ref'], $dataKey, null, [], $actorId);
        }
    }

    /** @param  array<int, string>  $colToKey */
    private function bindTable(TemplateBindingService $svc, ExportTemplateVersion $version, array $targets, int $tableIndex, int $rowIndex, array $colToKey, string $collectionKey, int $actorId): void
    {
        $tableRef = collect($targets)->first(fn ($t) => ($t['kind'] ?? null) === 'table' && (int) ($t['table_index'] ?? -1) === $tableIndex)['ref'];
        $svc->bind($version, $tableRef, $collectionKey, null, [], $actorId);

        foreach ($colToKey as $cellIndex => $dataKey) {
            $cellRef = collect($targets)->first(fn ($t) => ($t['kind'] ?? null) === 'table_cell'
                && (int) ($t['table_index'] ?? -1) === $tableIndex
                && (int) ($t['row_index'] ?? -1) === $rowIndex
                && (int) ($t['cell_index'] ?? -1) === $cellIndex)['ref'];
            $svc->bind($version, $cellRef, $dataKey, null, [], $actorId);
        }
    }

    /** @param  array<int, string>  $colToKey */
    private function bindScalarRow(TemplateBindingService $svc, ExportTemplateVersion $version, array $targets, int $tableIndex, int $rowIndex, array $colToKey, int $actorId): void
    {
        foreach ($colToKey as $cellIndex => $dataKey) {
            $cellRef = collect($targets)->first(fn ($t) => ($t['kind'] ?? null) === 'table_cell'
                && (int) ($t['table_index'] ?? -1) === $tableIndex
                && (int) ($t['row_index'] ?? -1) === $rowIndex
                && (int) ($t['cell_index'] ?? -1) === $cellIndex)['ref'];
            $svc->bind($version, $cellRef, $dataKey, null, [], $actorId);
        }
    }
}
