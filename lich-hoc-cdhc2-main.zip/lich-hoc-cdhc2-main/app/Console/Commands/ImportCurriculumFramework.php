<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Modules\Specialization\Models\Specialization;
use Modules\Subject\Models\Subject;
use Modules\Subject\Models\SubjectLesson;
use Modules\Subject\Support\SubjectCodePrefix;

/**
 * Nạp NGUYÊN khung chương trình một ngành (Ngành + Môn + Bài học) từ file JSON trong
 * database/seeders/data/curriculum/ (dựng từ Excel bằng docs/curriculum/build_*.py).
 *
 * Khác subject-lessons:bulk-import (chỉ ghi Bài cho Môn đã có), lệnh này tạo được ngành/môn mới —
 * dùng khi đổi chương trình đào tạo mà lớp cũ vẫn học khung cũ (vd Y sỹ đa khoa: khung cũ A.5720101
 * cho Y54, khung 2026 A.5720102, cùng mã ngành 5720101). Chạy lại nhiều lần không nhân đôi.
 *
 *   php artisan subject-lessons:curriculum-import                 # xem trước
 *   php artisan subject-lessons:curriculum-import --apply         # ghi
 *   php artisan subject-lessons:curriculum-import --file=ysdk-2026
 */
class ImportCurriculumFramework extends Command
{
    protected $signature = 'subject-lessons:curriculum-import
        {--file=ysdk-2026 : Tên file JSON trong database/seeders/data/curriculum (không cần .json)}
        {--apply : Ghi dữ liệu (mặc định chỉ xem trước)}';

    protected $description = 'Nạp khung chương trình (Ngành + Môn + Bài) từ file JSON đã dựng từ Excel';

    public function handle(): int
    {
        $name = basename((string) $this->option('file'), '.json');
        $path = database_path('seeders/data/curriculum/'.$name.'.json');
        if (! is_file($path)) {
            $this->error("Không tìm thấy {$path}");

            return self::FAILURE;
        }
        $data = json_decode((string) file_get_contents($path), true, flags: JSON_THROW_ON_ERROR);
        $apply = (bool) $this->option('apply');
        $specData = $data['specialization'];

        $template = ! empty($specData['copy_attributes_from'])
            ? Specialization::query()->where('code', $specData['copy_attributes_from'])->first()
            : null;
        $specialization = Specialization::withTrashed()->where('code', $specData['code'])->first();

        $this->info(($specialization ? 'Cập nhật' : 'Tạo mới')." ngành {$specData['code']} — {$specData['name']} (mã ngành {$specData['major_code']})"
            .($template ? ", sao chép hệ/trình độ/hình thức/thời gian/chứng chỉ từ {$template->code}" : ''));

        // Mã môn: A_<mã số ngành>_<mã MH>, không đụng môn của khung cũ.
        $probe = $specialization ?? new Specialization(['code' => $specData['code']]);
        $prefix = SubjectCodePrefix::normalizePrefix(null, $probe);
        $rows = [];
        $conflicts = [];
        foreach ($data['subjects'] as $s) {
            $fullCode = SubjectCodePrefix::buildSubjectCode($prefix, $s['code']);
            $existing = Subject::withTrashed()->where('code', $fullCode)->first();
            if ($existing && $specialization && (int) $existing->specialization_id !== (int) $specialization->id) {
                $conflicts[] = "{$fullCode} đang thuộc ngành khác (id {$existing->specialization_id})";
            }
            $rows[] = [$fullCode, $s['name'], $s['credits'], $s['semester'], count($s['lessons']), $existing ? 'cập nhật' : 'mới'];
        }
        $this->table(['Mã môn', 'Tên', 'TC', 'Học kỳ', 'Số dòng bài', ''], $rows);
        $this->line(sprintf('Tổng: %d môn, %d tín chỉ, %d dòng bài.', count($data['subjects']),
            array_sum(array_column($data['subjects'], 'credits')), array_sum(array_map(fn ($s) => count($s['lessons']), $data['subjects']))));

        if ($conflicts !== []) {
            foreach ($conflicts as $c) {
                $this->error($c);
            }

            return self::FAILURE;
        }
        if (! $apply) {
            $this->warn('DRY-RUN: chưa ghi gì. Chạy lại với --apply.');

            return self::SUCCESS;
        }

        $stats = ['subjects_created' => 0, 'subjects_updated' => 0, 'lessons_created' => 0, 'lessons_updated' => 0];
        DB::transaction(function () use ($data, $specData, $template, &$specialization, $prefix, &$stats) {
            $attrs = [
                'name' => $specData['name'],
                'major_code' => $specData['major_code'],
                'description' => $specData['description'] ?? null,
            ];
            if ($template) {
                $attrs += $template->only(['training_system_id', 'level', 'training_form', 'duration_months', 'certification_type']);
            }
            if ($specialization) {
                if ($specialization->trashed()) {
                    $specialization->restore();
                }
                $specialization->update($attrs);
            } else {
                $specialization = Specialization::query()->create($attrs + ['code' => $specData['code'], 'is_active' => true]);
            }

            foreach ($data['subjects'] as $s) {
                $fullCode = SubjectCodePrefix::buildSubjectCode($prefix, $s['code']);
                $payload = [
                    'name' => $s['name'],
                    'specialization_id' => $specialization->id,
                    'faculty_code' => SubjectCodePrefix::facultyCodeFromSubjectCode($s['code']),
                    'credits' => (int) $s['credits'],
                    'theory_hours' => (int) $s['theory'],
                    'practice_hours' => (int) $s['practice'],
                    'exam_hours' => (int) $s['exam'],
                    'self_study_hours' => (int) $s['self_study'],
                    'semester' => $s['semester'],
                    'is_active' => true,
                ];
                $subject = Subject::withTrashed()->where('code', $fullCode)->first();
                if ($subject) {
                    if ($subject->trashed()) {
                        $subject->restore();
                    }
                    $subject->update($payload);
                    $stats['subjects_updated']++;
                } else {
                    $subject = Subject::query()->create($payload + [
                        'code' => $fullCode,
                        'abbreviation' => Subject::generateAbbreviationFromName($s['name']),
                        'color' => Subject::defaultColorForKey($s['code']),
                        'review_hours' => 0,
                        'level' => 'basic',
                        'assessment_method' => 'exam',
                        'is_required' => true,
                    ]);
                    $stats['subjects_created']++;
                }

                $ids = [];
                foreach ($s['lessons'] as $row) {
                    $lesson = SubjectLesson::withTrashed()->where('subject_id', $subject->id)->where('code', $row['code'])->first();
                    $lessonPayload = [
                        'subject_id' => $subject->id,
                        'parent_id' => null,
                        'code' => $row['code'],
                        'name' => $row['name'],
                        'lesson_kind' => $this->kind($row['kind']),
                        'sort_order' => (int) $row['order'],
                        'theory_hours' => (int) $row['theory_hours'],
                        'practice_hours' => (int) $row['practice_hours'],
                        'exam_hours' => (int) $row['exam_hours'],
                        'total_hours' => (int) $row['total_hours'],
                        'semester' => $s['semester'],
                        'description' => ($row['description'] ?? '') ?: null,
                    ];
                    if ($lesson) {
                        if ($lesson->trashed()) {
                            $lesson->restore();
                        }
                        $lesson->update($lessonPayload);
                        $stats['lessons_updated']++;
                    } else {
                        $lesson = SubjectLesson::query()->create($lessonPayload);
                        $stats['lessons_created']++;
                    }
                    $ids[$row['code']] = $lesson->id;
                }
                foreach ($s['lessons'] as $row) {
                    if (! empty($row['parent_code']) && isset($ids[$row['parent_code']])) {
                        SubjectLesson::query()->whereKey($ids[$row['code']])->update(['parent_id' => $ids[$row['parent_code']]]);
                    }
                }
            }
        });

        $this->info("Đã ghi ngành {$specialization->code} (id {$specialization->id}): "
            ."môn mới {$stats['subjects_created']}, môn cập nhật {$stats['subjects_updated']}, "
            ."bài mới {$stats['lessons_created']}, bài cập nhật {$stats['lessons_updated']}.");

        return self::SUCCESS;
    }

    private function kind(string $kind): string
    {
        return match (mb_strtolower(trim($kind))) {
            'unit' => SubjectLesson::KIND_UNIT,
            'chương', 'chuong' => SubjectLesson::KIND_CHAPTER,
            'thi' => SubjectLesson::KIND_EXAM,
            default => SubjectLesson::KIND_LESSON,
        };
    }
}
