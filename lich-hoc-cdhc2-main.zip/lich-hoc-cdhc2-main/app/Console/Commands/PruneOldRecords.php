<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class PruneOldRecords extends Command
{
    protected $signature = 'app:prune-old-records {--days=90 : Days to keep}';

    protected $description = 'Prune old system_notifications and trash_logs records';

    public function handle(): int
    {
        $days = (int) $this->option('days');
        $cutoff = now()->subDays($days);

        $notifications = DB::table('system_notifications')
            ->whereNotNull('read_at')
            ->where('created_at', '<', $cutoff)
            ->delete();

        $trashLogs = DB::table('trash_logs')
            ->whereNotNull('restored_at')
            ->where('deleted_at', '<', $cutoff)
            ->delete();

        $this->info("Pruned {$notifications} notifications, {$trashLogs} trash logs older than {$days} days.");

        return self::SUCCESS;
    }
}
