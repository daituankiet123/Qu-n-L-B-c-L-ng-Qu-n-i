<?php

namespace App\Console\Commands;

use Cdhc2\Core\Support\TableOwnership;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * Buoc 2 (tach DB) — chuyen bang cua lms/tms/grades tu database core sang database
 * rieng tren CUNG server bang RENAME TABLE (nguyen tu, giu du lieu va FK).
 *
 * Mac dinh chi IN ke hoach + cau lenh lui. Chay that can:
 *   php artisan cdhc2:db-split --execute --confirm-backup=<ten ban backup>
 * Xem runbook: docs/runbooks/db-split.md. Chi cham bang ma TableOwnership xep cho
 * mot service; khong bao gio cham bang core, bang cua ung dung khac (Moodle...).
 */
class DbSplitCommand extends Command
{
    protected $signature = 'cdhc2:db-split
        {--plan : Chi in ke hoach (mac dinh)}
        {--execute : Chay that cac cau lenh}
        {--confirm-backup= : Ten ban backup DB vua tao (bat buoc khi --execute)}';

    protected $description = 'Chuyen bang cua lms/tms/grades tu DB core sang database rieng (RENAME TABLE, co duong lui)';

    public function handle(): int
    {
        $coreConnection = TableOwnership::resolve('mysql');
        $core = (string) config("database.connections.{$coreConnection}.database");

        $targets = [];
        foreach (TableOwnership::serviceConnections() as $connection) {
            $database = (string) config("database.connections.{$connection}.database");
            if ($database === '' || $database === $core) {
                $this->error("Connection {$connection} van tro ve database core ({$core}). Dat DB_".strtoupper($connection).'_DATABASE truoc.');

                return self::FAILURE;
            }
            $targets[$connection] = $database;
        }

        $tables = collect(DB::connection($coreConnection)->select(
            'SELECT TABLE_NAME AS t FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = ?',
            [$core, 'BASE TABLE']
        ))->map(fn ($row) => $row->t ?? $row->T);

        $forward = [];
        $backward = [];
        foreach ($targets as $connection => $database) {
            $mine = $tables->filter(fn (string $t) => TableOwnership::connectionFor($t) === $connection)->sort()->values();
            if ($mine->isEmpty()) {
                continue;
            }
            $forward[] = "CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            $forward[] = 'RENAME TABLE '.$mine->map(fn ($t) => "`{$core}`.`{$t}` TO `{$database}`.`{$t}`")->implode(', ');
            $backward[] = 'RENAME TABLE '.$mine->map(fn ($t) => "`{$database}`.`{$t}` TO `{$core}`.`{$t}`")->implode(', ');
        }

        $this->line("-- DB core: {$core} (connection {$coreConnection})");
        $this->line('-- KE HOACH CHUYEN');
        foreach ($forward as $sql) {
            $this->line($sql.';');
        }
        $this->line('-- DUONG LUI (chay neu kiem tra sau khi chuyen that bai)');
        foreach ($backward as $sql) {
            $this->line($sql.';');
        }

        if (! $this->option('execute')) {
            return self::SUCCESS;
        }
        if (! $this->option('confirm-backup')) {
            $this->error('Thieu --confirm-backup=<ten ban backup>. Khong chay gi ca.');

            return self::FAILURE;
        }
        if ($forward === []) {
            $this->warn('Khong con bang nao can chuyen (da tach truoc do?).');

            return self::SUCCESS;
        }

        foreach ($forward as $sql) {
            DB::connection($coreConnection)->statement($sql);
        }
        $this->info('Da chuyen. Backup xac nhan: '.$this->option('confirm-backup').'. Kiem tra: php artisan cdhc2:db-topology');

        return self::SUCCESS;
    }
}
