<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Throwable;

class VerifyBackup extends Command
{
    protected $signature = 'cdhc2:verify-backup
                            {--all : Kiểm tra tất cả bản backup local thay vì chỉ bản mới nhất}';

    protected $description = 'Đối chiếu nội dung backup local với bản sao trên S3';

    public function handle(): int
    {
        $files = collect(Storage::disk('local')->allFiles((string) config('backup.backup.name')))
            ->filter(fn (string $path): bool => str_ends_with(strtolower($path), '.zip'))
            ->sort()
            ->values();

        if ($files->isEmpty()) {
            $this->error('Không tìm thấy bản backup local để kiểm chứng.');

            return self::FAILURE;
        }

        if (! $this->option('all')) {
            $files = $files->take(-1);
        }

        $failed = false;

        foreach ($files as $path) {
            try {
                $localContents = Storage::disk('local')->get($path);
                $remoteContents = Storage::disk('s3')->get($path);
            } catch (Throwable $exception) {
                $this->error("Không đọc được {$path} từ local hoặc S3: {$exception->getMessage()}");
                $failed = true;

                continue;
            }

            if (strlen($localContents) !== strlen($remoteContents) || md5($localContents) !== md5($remoteContents)) {
                $this->error("Backup không khớp: {$path}");
                $failed = true;

                continue;
            }

            $this->info(sprintf(
                'Backup hợp lệ: %s (%s bytes, md5 %s)',
                $path,
                number_format(strlen($localContents)),
                md5($localContents),
            ));
        }

        return $failed ? self::FAILURE : self::SUCCESS;
    }
}
