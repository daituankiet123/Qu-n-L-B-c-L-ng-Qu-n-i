<?php

namespace App\Console\Commands;

use Cdhc2\Core\Support\DbRef;
use Illuminate\Console\Command;

/**
 * Kiểm tra cấu hình tách database (Gate D) trước khi deploy.
 *
 * Rủi ro cần chặn: đặt `DB_TMS_DATABASE`/`DB_LMS_DATABASE`/`DB_GRADES_DATABASE`
 * KHÔNG đồng thời. Khi đó một phần bảng nằm ở DB cũ, một phần ở DB mới, và các
 * câu JOIN xuyên database (qua Cdhc2\Core\Support\DbRef) sẽ đọc nhầm chỗ mà
 * không báo lỗi rõ ràng.
 *
 * Dùng được như bước kiểm tra trước rollout:
 *   php artisan cdhc2:db-topology
 * Exit code 1 nếu phát hiện cấu hình không nhất quán.
 */
class DbTopologyCheck extends Command
{
    protected $signature = 'cdhc2:db-topology {--json : Xuất kết quả dạng JSON}';

    protected $description = 'Kiểm tra cấu hình kết nối database của từng service (chống tách DB nửa vời)';

    /** @var array<string, string> connection => tên biến env database tương ứng */
    private const SERVICE_CONNECTIONS = [
        'tms' => 'DB_TMS_DATABASE',
        'lms' => 'DB_LMS_DATABASE',
        'grades' => 'DB_GRADES_DATABASE',
        'salary' => 'DB_SALARY_DATABASE',
    ];

    public function handle(): int
    {
        $service = (string) config('app.cdhc2_service', 'monolith');
        $problems = [];
        $rows = [];

        $coreDb = $this->databaseName('mysql');
        $rows[] = $this->row('mysql (core)', $coreDb, 'DB_DATABASE');

        $configured = [];

        foreach (self::SERVICE_CONNECTIONS as $connection => $envKey) {
            $db = $this->databaseName($connection);
            $isSeparate = $db !== $coreDb;
            $configured[$connection] = $isSeparate;
            $rows[] = $this->row($connection, $db, $envKey, $isSeparate ? 'tách riêng' : 'dùng chung core');
        }

        // 1. Tách nửa vời: có connection tách riêng, có connection vẫn dùng chung.
        $separate = array_keys(array_filter($configured));
        $shared = array_keys(array_filter($configured, fn ($v) => ! $v));

        if ($separate !== [] && $shared !== []) {
            $problems[] = sprintf(
                'Tách DB KHÔNG đồng bộ: đã tách [%s] nhưng [%s] vẫn trỏ về database core. '
                .'Các JOIN xuyên database sẽ đọc nhầm database.',
                implode(', ', $separate),
                implode(', ', $shared)
            );
        }

        // 2. Service đang chạy không khớp với việc tách DB.
        if ($service !== 'monolith' && $service !== 'core') {
            if (! ($configured[$service] ?? false)) {
                $problems[] = sprintf(
                    "Service đang chạy là '%s' nhưng connection '%s' vẫn trỏ về database core. "
                    .'Nếu đã chuyển dữ liệu sang DB riêng thì service này đang đọc sai chỗ.',
                    $service,
                    $service
                );
            }
        }

        if ($service === 'monolith' && $separate !== []) {
            $problems[] = 'Đang chạy monolith nhưng đã tách DB cho ['.implode(', ', $separate).']. '
                .'Monolith chạy Direct trên mọi bảng nên sẽ sai nếu dữ liệu đã dời đi.';
        }

        // 3. Cảnh báo khi chưa tách DB nào (trạng thái hiện tại — hợp lệ).
        if ($separate === []) {
            $this->line('Trạng thái: chưa tách database — mọi connection dùng chung 1 DB (no-op an toàn).');
        }

        if ($this->option('json')) {
            $this->line((string) json_encode([
                'service' => $service,
                'core_database' => $coreDb,
                'connections' => $rows,
                'problems' => $problems,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            return $problems === [] ? self::SUCCESS : self::FAILURE;
        }

        $this->newLine();
        $this->table(
            ['Connection', 'Database', 'Env', 'Trạng thái'],
            array_map(fn ($r) => [$r['connection'], $r['database'], $r['env'], $r['state']], $rows)
        );

        $this->line("Service hiện tại: <info>{$service}</info>");
        $this->newLine();

        if ($problems === []) {
            $this->info('✅ Cấu hình database nhất quán.');

            return self::SUCCESS;
        }

        foreach ($problems as $p) {
            $this->error('⛔ '.$p);
        }

        return self::FAILURE;
    }

    private function databaseName(string $connection): string
    {
        // Dùng chung nguồn với DbRef: ưu tiên config, chỉ hỏi connection thật khi
        // config không có `database` (ví dụ chỉ cấu hình qua `url`).
        return DbRef::databaseFor($connection);
    }

    /**
     * @return array{connection: string, database: string, env: string, state: string}
     */
    private function row(string $connection, string $database, string $env, string $state = 'core'): array
    {
        return compact('connection', 'database', 'env', 'state');
    }
}
