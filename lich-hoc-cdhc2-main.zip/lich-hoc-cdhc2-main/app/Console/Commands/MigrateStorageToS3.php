<?php

namespace App\Console\Commands;

use Cdhc2\Core\Support\StorageHelper;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Modules\ExportTemplates\Models\ExportTemplateVersion;
use Modules\LeaveManagement\Models\LeaveReportTemplate;
use Modules\Lms\Models\LmsAssignmentSubmission;
use Modules\Lms\Models\LmsAssignmentSubmissionVersion;
use Modules\Lms\Models\LmsMaterial;
use Modules\Tms\Models\TmsAttachment;
use Modules\Tms\Models\TmsMaterial;

class MigrateStorageToS3 extends Command
{
    protected $signature = 'storage:migrate-s3
                            {--from=public : Source disk name}
                            {--dry-run : Only count files, do not copy}
                            {--batch=100 : Number of records per batch}
                            {--model= : Migrate only this model (e.g. LmsMaterial)}';

    protected $description = 'Migrate files from local/public disk to S3 and update disk column on models';

    private const MODELS_WITH_DISK = [
        'lms_assignment_submissions' => ['model' => LmsAssignmentSubmission::class, 'file_col' => 'file_path'],
        'lms_assignment_submission_versions' => ['model' => LmsAssignmentSubmissionVersion::class, 'file_col' => 'file_path'],
        'lms_materials' => ['model' => LmsMaterial::class, 'file_col' => 'file_path'],
        'tms_materials' => ['model' => TmsMaterial::class, 'file_col' => 'file_path'],
        'tms_attachments' => ['model' => TmsAttachment::class, 'file_col' => 'file_path'],
        'export_template_versions' => ['model' => ExportTemplateVersion::class, 'file_col' => 'file_path'],
        'leave_report_templates' => ['model' => LeaveReportTemplate::class, 'file_col' => 'file_path'],
    ];

    public function handle(): int
    {
        $fromDisk = (string) $this->option('from');
        $dryRun = (bool) $this->option('dry-run');
        $batchSize = (int) $this->option('batch') ?: 100;
        $filterModel = $this->option('model');

        if (! Storage::disk('s3')->getAdapter()) {
            $this->error('S3 disk is not configured. Set VIETTEL_S3_* env vars.');

            return self::FAILURE;
        }

        $totalMoved = 0;
        $totalMissing = 0;
        $totalFailed = 0;

        foreach (self::MODELS_WITH_DISK as $table => $config) {
            $modelClass = $config['model'];
            $fileCol = $config['file_col'];
            $shortName = class_basename($modelClass);

            if ($filterModel && $shortName !== $filterModel) {
                continue;
            }

            if (! class_exists($modelClass)) {
                $this->warn("Skipping {$shortName}: class not found");

                continue;
            }

            $query = $modelClass::query()
                ->whereNotNull($fileCol)
                ->where(function ($q) use ($fromDisk) {
                    $q->where('disk', $fromDisk)->orWhereNull('disk');
                })
                ->orderBy('id');

            $total = (clone $query)->count();
            $this->info(($dryRun ? '[DRY-RUN] ' : '')."{$shortName}: {$total} records on '{$fromDisk}' disk");

            if ($total === 0) {
                continue;
            }

            $moved = 0;
            $missing = 0;
            $failed = 0;
            $bar = $this->output->createProgressBar($total);

            $query->chunkById($batchSize, function ($records) use ($fromDisk, $fileCol, $dryRun, &$moved, &$missing, &$failed, $bar) {
                foreach ($records as $record) {
                    $bar->advance();
                    $path = (string) $record->{$fileCol};

                    if (! StorageHelper::fileExists($fromDisk, $path)) {
                        $missing++;

                        continue;
                    }

                    if ($dryRun) {
                        $moved++;

                        continue;
                    }

                    $stream = Storage::disk($fromDisk)->readStream($path);
                    if (! is_resource($stream)) {
                        $failed++;
                        $this->warn(" #{$record->id}: cannot read source");

                        continue;
                    }

                    try {
                        $written = Storage::disk('s3')->writeStream($path, $stream);
                    } finally {
                        if (is_resource($stream)) {
                            fclose($stream);
                        }
                    }

                    if (! $written) {
                        $failed++;
                        $this->warn(" #{$record->id}: S3 write failed");

                        continue;
                    }

                    $record->forceFill(['disk' => 's3'])->save();
                    $moved++;
                }
            });

            $bar->finish();
            $this->newLine();
            $this->info("  Moved: {$moved}, Missing: {$missing}, Failed: {$failed}");

            $totalMoved += $moved;
            $totalMissing += $missing;
            $totalFailed += $failed;
        }

        $this->newLine();
        $this->info("=== Total: Moved {$totalMoved}, Missing {$totalMissing}, Failed {$totalFailed} ===");

        return $totalFailed > 0 ? self::FAILURE : self::SUCCESS;
    }
}
