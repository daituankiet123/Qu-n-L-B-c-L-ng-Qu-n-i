#!/bin/sh
set -e

CDHC2_SERVICE="${CDHC2_SERVICE:-monolith}"

# Sidecar container: nginx only, skip all PHP setup
if [ "$CDHC2_SERVICE" = "sidecar" ]; then
    exec "$@"
fi

# Ensure storage & cache directories exist (all containers)
#
# `storage/logs` PHAI co trong danh sach nay. Git khong track gi trong storage/
# va .dockerignore loai `storage/logs/*`, nen thu muc nay khong bao gio vao
# image. Thieu no thi LOG_CHANNEL mac dinh (stack -> single) khong ghi duoc
# laravel.log, va moi Log::error - ke ca cua handler 500 o bootstrap/app.php -
# bien mat khong dau vet. Da mat mot buoi debug loi 500 cua service LMS vi dung
# cai nay: access log co ghi "GET /index.php" 500 nhung khong co stack trace nao.
mkdir -p /var/www/storage/logs
mkdir -p /var/www/storage/framework/{cache,sessions,views}
mkdir -p /var/www/bootstrap/cache
mkdir -p /var/www/storage/app/private /var/www/storage/app/public
chown -R www-data:www-data /var/www/storage /var/www/bootstrap/cache
chmod -R ug+rwx /var/www/storage /var/www/bootstrap/cache

php artisan storage:link || true

# Nginx temp dirs (gateway container, or monolith which runs nginx)
if [ "$CDHC2_SERVICE" = "gateway" ] || [ "$CDHC2_SERVICE" = "monolith" ]; then
    mkdir -p \
        /var/lib/nginx/tmp/client_body \
        /var/lib/nginx/tmp/proxy \
        /var/lib/nginx/tmp/fastcgi \
        /var/lib/nginx/tmp/uwsgi \
        /var/lib/nginx/tmp/scgi
    chown -R www-data:www-data /var/lib/nginx
fi

# APP_KEY: ưu tiên biến môi trường.
#
# Trong kiến trúc microservices, container KHÔNG có file /var/www/.env — toàn bộ
# cấu hình đến từ Secret qua `envFrom`. Bản cũ ở đây làm:
#     if ! grep -q "APP_KEY=" /var/www/.env || ...
# nên khi không có .env thì grep fail -> điều kiện đúng -> gọi
# `php artisan key:generate --force` -> lỗi "file_get_contents(/var/www/.env):
# Failed to open stream" -> `set -e` giết initContainer `migrate` -> pod BackOff
# vĩnh viễn (đã xảy ra thật ở lần deploy 17/09).
#
# Nay: chỉ gọi key:generate khi THẬT SỰ có file .env và chưa có APP_KEY.
if [ -n "${APP_KEY}" ]; then
    echo ">> APP_KEY lay tu bien moi truong."
elif [ -f /var/www/.env ] && grep -q "APP_KEY=" /var/www/.env \
     && [ -n "$(grep APP_KEY= /var/www/.env | cut -d '=' -f2)" ]; then
    echo ">> APP_KEY co san trong /var/www/.env."
elif [ -f /var/www/.env ]; then
    echo ">> Generating APP_KEY into /var/www/.env..."
    php artisan key:generate --force || echo "!! key:generate that bai (bo qua)"
else
    echo "!! CANH BAO: khong co APP_KEY trong bien moi truong va khong co /var/www/.env."
    echo "!! Dat APP_KEY trong Secret (vi du tkb-env) roi rollout lai."
fi

echo ">> Clearing stale application caches..."
php artisan optimize:clear || true

# Migrations and seeders: ONLY in core or monolith container
if [ "$CDHC2_SERVICE" = "core" ] || [ "$CDHC2_SERVICE" = "monolith" ]; then
    if [ "${APP_ENV}" != "production" ] || [ "${RUN_MIGRATIONS}" = "true" ]; then
        echo ">> Running migrations (service=$CDHC2_SERVICE)..."
        php artisan migrate --force
        echo ">> Syncing permissions & roles..."
        php artisan permissions:sync || echo "!! permissions:sync failed (non-fatal)"
    else
        echo ">> Skipping migrations (APP_ENV=production and RUN_MIGRATIONS not set)"
    fi

    if [ "${APP_ENV}" != "production" ] || [ "${RUN_SEEDERS}" = "true" ]; then
        echo ">> Running seeders..."
        php artisan db:seed --force
    else
        echo ">> Skipping seeders (APP_ENV=production and RUN_SEEDERS not set)"
    fi
fi

exec "$@"
